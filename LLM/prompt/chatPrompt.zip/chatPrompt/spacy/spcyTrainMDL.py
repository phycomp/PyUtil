from spacy.vocab import Vocab
vocab = Vocab(strings=["hello", "world"])
doc = nlp("This is a sentence.")
assert len(nlp.vocab) > 0
apple = nlp.vocab.strings["apple"]
assert nlp.vocab[apple] == nlp.vocab["apple"]
stop_words = (lex for lex in nlp.vocab if lex.is_stop)
apple = nlp.vocab.strings["apple"]
oov = nlp.vocab.strings["dskfodkfos"]
assert apple in nlp.vocab
assert oov not in nlp.vocab
def is_my_product(text):
    products = ["spaCy", "Thinc", "displaCy"]
    return text in products

MY_PRODUCT = nlp.vocab.add_flag(is_my_product)
doc = nlp("I like spaCy")
assert doc[2].check_flag(MY_PRODUCT) == True
import scispacy
import spacy

nlp = spacy.load("en_core_sci_sm")
text = """
Myeloid derived suppressor cells (MDSC) are immature 
myeloid cells with immunosuppressive activity. 
They accumulate in tumor-bearing mice and humans 
with different types of cancer, including hepatocellular 
carcinoma (HCC).
"""
doc = nlp(text)

print(list(doc.sents))
>>> ["Myeloid derived suppressor cells (MDSC) are immature myeloid cells with immunosuppressive activity.", 
     "They accumulate in tumor-bearing mice and humans with different types of cancer, including hepatocellular carcinoma (HCC)."]

# Examine the entities extracted by the mention detector.
# Note that they don't have types like in SpaCy, and they
# are more general (e.g including verbs) - these are any
# spans which might be an entity in UMLS, a large
# biomedical database.
print(doc.ents)
>>> (Myeloid derived suppressor cells, MDSC, immature, myeloid cells, immunosuppressive activity, accumulate, tumor-bearing mice, humans, cancer, hepatocellular carcinoma, HCC)

# We can also visualise dependency parses
# (This renders automatically inside a jupyter notebook!):
from spacy import displacy
displacy.render(next(doc.sents), style='dep', jupyter=True)

# See below for the generated SVG.
# Zoom your browser in a bit!


