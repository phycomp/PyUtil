!python -m spacy init fill-config base_config.cfg config.cfg

!python -m spacy train config.cfg --output ./output --paths.train ./train.spacy --paths.dev ./train.spacy
