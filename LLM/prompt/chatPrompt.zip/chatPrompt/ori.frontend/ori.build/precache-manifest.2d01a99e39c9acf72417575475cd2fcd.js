self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e563830f4a7954331c8d180c3d6b83d0",
    "url": "./index.html"
  },
  {
    "revision": "49187c24fe12d03515f5",
    "url": "./static/css/main.60965e18.chunk.css"
  },
  {
    "revision": "8c41e6b8788e9a16f7b3",
    "url": "./static/js/2.f1cb0ee8.chunk.js"
  },
  {
    "revision": "349298fbb30f981c1395376b153ee9a6",
    "url": "./static/js/2.f1cb0ee8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "49187c24fe12d03515f5",
    "url": "./static/js/main.19b2a94b.chunk.js"
  },
  {
    "revision": "77e61c67eb4f95e15891",
    "url": "./static/js/runtime-main.ff285346.js"
  }
]);