from transformers import AutoConfig, AutoModel
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.optimizers import RMSprop
config = AutoConfig.from_pretrained('bert-base-uncased')
model = AutoModel.from_config(config)
mdcMDL='medicalai/ClinicalBERT'
model.compile(loss=BinaryCrossentropy(from_logits=True), optimizer=RMSprop(), metrics=["accuracy"]) #tf.keras.losses. tf.keras.optimizers.
model.fit()
model.predict()
