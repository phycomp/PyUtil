import React from "react"
import ReactDOM from "react-dom"
//import RadioButton from "./RadioButton"
import NerAnntt from "./NerAnntt"

ReactDOM.render(
  <React.StrictMode>
    <NerAnntt />
  </React.StrictMode>,
  document.getElementById("root")
)
