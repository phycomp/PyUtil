import React, {useEffect, ReactElement} from 'react';
import ReactDOM from 'react-dom';
import {Client as Styletron} from 'styletron-engine-atomic';
import {Provider as StyletronProvider} from 'styletron-react';
import {useStyletron, LightTheme, BaseProvider, styled} from 'baseui';
//import {StatefulInput} from 'baseui/input';
import { ComponentProps, withStreamlitConnection, StreamlitComponentBase, Streamlit} from "streamlit-component-lib"

interface State { selectedIndex: number }
/*
Streamlit.setFrameHeight(500);
Streamlit.setComponentValue(500);
*/
const engine = new Styletron();
//const [css, theme] = useStyletron();
const Centered = styled('div', { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', });   //[name=nerAnntt]

class AnnttNER extends StreamlitComponentBase<State> {
  public constructor(props: ComponentProps) {
    super(props)
    const options = this.props.args["options"] as string[]
    const defaultValue = this.props.args["default"] as string
    let selectedIndex = 0
    if (options != null && defaultValue != null) {
      selectedIndex = options.indexOf(defaultValue)
      if (selectedIndex < 0) selectedIndex = 0
    }
    this.state = { selectedIndex }
     Streamlit.setFrameHeight(1000)
    //() => {}
    //useEffect()
  }

  public render = (): React.ReactNode => {
    return (
    <StyletronProvider value={engine}>
      <BaseProvider theme={LightTheme}>
        <Centered>
          <div>
          </div>
        </Centered>
      </BaseProvider>
    </StyletronProvider>
    );
  }
}
export default withStreamlitConnection(AnnttNER)
