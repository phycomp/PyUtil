import json
from transformers import HfArgumentParser, TrainingArguments
from robust_deid.ner_datasets import DatasetSplitter, DatasetCreator, SpanFixer, SpanValidation
from robust_deid.sequence_tagging import SequenceTagger
from robust_deid.sequence_tagging.arguments import ModelArguments, DataTrainingArguments, EvaluationArguments,

input_file = '/home/pk621/projects/data/ehr_deidentification/i2b2/i2b2.jsonl'
train_file_raw = '/home/pk621/projects/data/ehr_deidentification/i2b2/train_unfixed.jsonl'
validation_file_raw = '/home/pk621/projects/data/ehr_deidentification/i2b2/validation_unfixed.jsonl'
train_file = '/home/pk621/projects/data/ehr_deidentification/i2b2/train.jsonl'
validation_file = '/home/pk621/projects/data/ehr_deidentification/i2b2/validation.jsonl'
validation_spans_file = '/home/pk621/projects/data/ehr_deidentification/i2b2/validation_spans.jsonl'
ner_train_file = '/home/pk621/projects/data/ehr_deidentification/ner_datasets/i2b2_train/train.jsonl'
ner_validation_file = '/home/pk621/projects/data/ehr_deidentification/ner_datasets/i2b2_train/validation.jsonl'
model_config = './run/i2b2/train_i2b2.json'
sentencizer = 'en_core_sci_sm'
tokenizer = 'clinical'
notation = 'BILOU'
spans_key = 'spans'
metadata_key = 'meta'
group_key = 'note_id'
dataset_splitter = DatasetSplitter( train_proportion=87, validation_proportion=13, test_proportion=0)
dataset_splitter.assign_splits( input_file=input_file, spans_key=spans_key, metadata_key=metadata_key, group_key=group_key, margin=0.3)
with open(train_file_raw, 'w') as file:
    for line in open(input_file, 'r'):
        note = json.loads(line)
        key = note[metadata_key][group_key]
        dataset_splitter.set_split('train')
        if dataset_splitter.check_note(key):
            file.write(json.dumps(note) + '\n')
with open(validation_file_raw, 'w') as file:
    for line in open(input_file, 'r'):
        note = json.loads(line)
        key = note[metadata_key][group_key]
        dataset_splitter.set_split('validation')
        if dataset_splitter.check_note(key):
            file.write(json.dumps(note) + '\n')
with open(validation_spans_file, 'w') as file:
    for span_info in SpanValidation.get_spans(
            input_file=validation_file_raw,
            metadata_key='meta',
            note_id_key='note_id',
            spans_key='spans'):
        file.write(json.dumps(span_info) + '\n')
ner_types = ["PATIENT", "STAFF", "AGE", "DATE", "PHONE", "ID", "EMAIL", "PATORG", "LOC", "HOSP", "OTHERPHI"]
ner_priorities = [2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 1]
span_fixer = SpanFixer(tokenizer=tokenizer, sentencizer=sentencizer, ner_priorities={ner_type: priority for ner_type, priority in zip(ner_types, ner_priorities)}, verbose=True)
with open(train_file, 'w') as file:
    for note in span_fixer.fix( input_file=train_file_raw, text_key='text', spans_key='spans'):
        file.write(json.dumps(note) + '\n')
with open(validation_file, 'w') as file:
    for note in span_fixer.fix( input_file=validation_file_raw, text_key='text', spans_key='spans'):
        file.write(json.dumps(note) + '\n')
dataset_creator = DatasetCreator( sentencizer=sentencizer, tokenizer=tokenizer, max_tokens=128, max_prev_sentence_token=32, max_next_sentence_token=32, default_chunk_size=32, ignore_label='NA')
ner_notes_train = dataset_creator.create( input_file=train_file, mode='train', notation=notation, token_text_key='text', metadata_key='meta', note_id_key='note_id', label_key='label', span_text_key='spans')
ner_notes_validation = dataset_creator.create( input_file=validation_file, mode='train', notation=notation, token_text_key='text', metadata_key='meta', note_id_key='note_id', label_key='label', span_text_key='spans')
with open(ner_train_file, 'w') as file:
    for ner_sentence in ner_notes_train:
        file.write(json.dumps(ner_sentence) + '\n')
with open(ner_validation_file, 'w') as file:
    for ner_sentence in ner_notes_validation:
        file.write(json.dumps(ner_sentence) + '\n')
parser = HfArgumentParser(( ModelArguments, DataTrainingArguments, EvaluationArguments, TrainingArguments))
model_args, data_args, evaluation_args, training_args = parser.parse_json_file(json_file=model_config)
sequence_tagger = SequenceTagger( task_name=data_args.task_name, notation=data_args.notation, ner_types=data_args.ner_types, model_name_or_path=model_args.model_name_or_path, config_name=model_args.config_name, tokenizer_name=model_args.tokenizer_name, post_process=model_args.post_process, cache_dir=model_args.cache_dir, model_revision=model_args.model_revision, use_auth_token=model_args.use_auth_token, threshold=model_args.threshold, do_lower_case=data_args.do_lower_case, fp16=training_args.fp16, seed=training_args.seed, local_rank=training_args.local_rank)
sequence_tagger.load()
sequence_tagger.set_train( train_file=data_args.train_file, max_train_samples=data_args.max_train_samples, preprocessing_num_workers=data_args.preprocessing_num_workers, overwrite_cache=data_args.overwrite_cache)
sequence_tagger.set_eval( validation_file=data_args.validation_file, max_val_samples=data_args.max_eval_samples, preprocessing_num_workers=data_args.preprocessing_num_workers, overwrite_cache=data_args.overwrite_cache)
sequence_tagger.set_eval_metrics( validation_spans_file=evaluation_args.validation_spans_file, model_eval_script=evaluation_args.model_eval_script, ner_types_maps=evaluation_args.ner_type_maps, evaluation_mode=evaluation_args.evaluation_mode)
sequence_tagger.setup_trainer(training_args=training_args)
sequence_tagger.train(checkpoint=training_args.resume_from_checkpoint)
metrics = sequence_tagger.evaluate()
print(json.dumps(metrics, indent=2))
