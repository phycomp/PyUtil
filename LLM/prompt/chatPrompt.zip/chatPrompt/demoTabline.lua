require('tabby.tabline').set(function(line)
    line.tabs().foreach(function(tab)
      print(tab.name())
    end)
    end)

