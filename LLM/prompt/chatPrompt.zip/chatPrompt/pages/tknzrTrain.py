from transformers import AutoModelForTokenClassification, AutoTokenizer, AutoModel, BertModel, BertTokenizerFast
#import torch
from numpy import argmax as npArgmax
from streamlit import code as stCode, write as stWrite
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
#AutoModelForTokenClassification #ForTokenClassification
lngmdl='bert-base-uncased'
#model = AutoModel.from_pretrained("dbmdz/bert-large-cased-finetuned-conll03-english")
bertTknzr = BertTokenizerFast.from_pretrained(lngmdl) #"bert-base-cased"
#tokenizer = AutoTokenizer.from_pretrained(lngmdl) #"bert-base-cased"
#vghMDL=BertModel.from_pretrained(lngmdl)  #'bert-base-uncased'
LABELs = [ "O",       # Outside of a named entity    #_list
    "B-MISC",  # Beginning of a miscellaneous entity right after another miscellaneous entity
    "I-MISC",  # Miscellaneous entity
    "B-PER",   # Beginning of a person's name right after another person's name
    "I-PER",   # Person's name
    "B-ORG",   # Beginning of an organisation right after another organisation
    "I-ORG",   # Organisation
    "B-LOC",   # Beginning of a location right after another location
    "I-LOC"    # Location
]
sequence = "Hugging Face Inc. is a company based in New York City. Its headquarters are in DUMBO, therefore very close to the Manhattan Bridge."
# Bit of a hack to get the tokens with the special tokens
seqTkns = bertTknzr.tokenize(sequence)  #bertTknzr.decode(bertTknzr.encode(sequence))
inputs = bertTknzr.encode(sequence) #, return_tensors="pt"
stCode(['inputs=', inputs])
stCode(['seqTkns=', seqTkns])
#vghBertTknzr=bertTknzr.train_new_from_iterator(text_iterator=pthlgyItrtr(), vocab_size=32)   #_000
#outputs = vghMDL(inputs)[0]
#predictions = npArgmax(outputs, dim=2)
#print([(token, LABELs[prediction]) for token, prediction in zip(tokens, predictions[0].tolist())])
#It should be noted that the ConLL annotation scheme, as described in its original paper, provides precisely the information you seek.
