from streamlit import code as stCode, write as stWrite, session_state, sidebar, dataframe
from streamlit import text_area
from spacy import blank as spcyBlank
from spacy.tokens import Doc
from spacy.training import Example
from spacy.vocab import Vocab

stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
MENUs=['訓練bertUncased', '成效', 'getNER', 'BILUO']
menu = sidebar.radio('Output', MENUs, index=0)

def mkExample(ent, rawDset):
  ENTs=list(rtrvENT(ent))
  #stCode(['ENTs', ENTs])    #[(23, 30, 'Position1'), (32, 49, 'Procedure'), (54, 72, 'Classification')]
  #tokenizer(examples["tokens"], padding="max_length", truncation=True, is_split_into_words=True)
  rawWord=rawDset.split() #words = ["Mrs", "Smith", "flew", "to", "New York"]
  enVocab=Vocab(strings=rawWord)
  doc = Doc(enVocab, words=rawWord)
  #entities = [(0, 9, "PERSON"), (18, 26, "LOC")]
  #gold_words = ["Mrs Smith", "flew", "to", "New", "York"]
  try:
    example = Example.from_dict(doc, {"words": rawWord, "entities":ENTs})
    #stCode(['example=', example])
  except: pass
  return example
  nerTags = example.get_aligned_ner()
  #stCode(['nerTags', nerTags])
  #assert nerTags == ["B-PERSON", "L-PERSON", "O", "O", "U-LOC"]
def rtrvENT(row):
  entInfo=[]
  for ent in row.split('@'):
    posInfo, para, NER=ent.split('|')
    startPos, endPos=posInfo.split(':')
    try: entInfo.append((int(startPos), int(endPos), NER))
    except: pass
  return entInfo
if menu==MENUs[0]:
  'spacyNERupdated'
  from pandas import read_csv
  try: dfCOPA=session_state['dfCOPA']
  except:
    session_state['dfCOPA']=dfCOPA=read_csv('/home/josh/NLP/nlpData/bdcrcopa2.csv', sep='\x06')
  lngMDL=spcyBlank('en')
  ner = lngMDL.add_pipe("ner")
  eXmple=[]
  optimizer = lngMDL.initialize()
  for tid, (anntt, rawDset) in dfCOPA.iterrows():
    #stCode(['dfCOPA=', anntt, rawDset])
    try:
      eg=mkExample(anntt, rawDset)
      #stCode(['eg=', eg])
      eXmple.append(eg)
    except: pass
    #stCode(['examples=', examples])
    #docs = [eg.predicted for eg in examples]
    #predictions, _ = lngMDL.begin_update(docs)
    #set_annotations(docs, predictions)
  #for eg in eXmple: stCode(['eg rawText=', eg.text])
  #while losses>1E2:
  #for eg in eXmple: stCode(['eg rawText=', eg.text])
  losses = ner.update(eXmple, sgd=optimizer)
  stCode(['losses', losses])

elif menu==MENUs[-2]:
  'getNER'
  dfCOPA=session_state['dfCOPA']
  stCode([dfCOPA.iloc[10]])  #.iloc[1]
  entities, rawDset=dfCOPA.iloc[10]  #[['annttInfo', 'outcome']]
elif menu==MENUs[-2]:
  'BILUO'
  from spacy.training import offsets_to_biluo_tags as biluoTag
  lngMDL=session_state['lngMDL']
  rawDset=session_state['rawDset']
  doc = lngMDL("I like London.")
  ent = [(7, 13, "LOC")]
  entTags = biluoTag(doc, ent)
  stCode(['entTag', entTag])

