from transformers import BertTokenClassifier
model=BertTokenClassifier(bert_ model='bert-base-cased', )
# model = BertTokenClassifier(bert_model='scibert-scivocab-cased', max_seq_length=178, epochs=3, gradient_accumulation_steps=4, learning_rate=5e-5, train_batch_size=16, eval_batch_size=16, validation_fraction=0., label_list=label_list, ignore_label=['O'])

print(model)

model.fit(np.array(X_train), np.array(y_train)) # finetune model

f1_test = model.score(X_test, y_test, 'macro') # score model
print("Test f1: %0.02f"%(f1_test))

# make predictions
y_preds = model.predict(np.array(X_test))
