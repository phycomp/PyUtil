from nltk import download as nltkDownload, word_tokenize as nltkWordtokenize, pos_tag as nltkPostag
from streamlit import code as stCode, write as stWrite, session_state, sidebar, dataframe
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)

def rtrvSent():
  try:
    sentence=session_state['sentence']
  except:
    session_state['sentence']=sentence="He was being opposed by her without any reason. A plan is being prepared by charles for next project"
  #sentence = "I am learning NLP in Python"
  # Process the sentence using spaCy's NLP pipeline
  return sentence
def rtrvMDL():
  from spacy import load as spcyLoad
  # Load the 'en_core_web_sm' model
  try:
    lngMDL= session_state['lngMDL'] #= spcyLoad('en_core_web_sm')
  except:
    lngMDL = spcyLoad('en_core_web_sm')

MENUs=['訓練NLTK', 'textBlob', 'getNER', 'DEV', 'spacyTrain']#'tokenizer', 'punct', 'fastText', 'csvEye', 'fastChat', 'optimizer','BILUO', 'vocab', 'jsonViewer'] #EMBEDDING 訓練token
menu = sidebar.radio('Output', MENUs, index=0)
if menu==MENUs[-2]:
  nltkDownload('averaged_perceptron_tagger')
  sentence = rtrvSent()#"I am learning NLP in Python"
  tokens = nltkWordtokenize(sentence)
  posTags = nltkPostag(tokens)
  stCode(['posTAGs=', posTags])
elif menu==MENUs[-4]:
  dsetDF=session_state['dsetDF']
  doc = lngMDL(dsetDF)
  doc = nlp(dsetDF)
  tokens = [token.text for token in doc]  #['Four', 'score', 'and', 'seven', 'years', 'ago', 'our', 'fathers', ...
  lemmas = [token.lemma_ for token in doc]
  from spacy.lang.en.stop_words import STOP_WORDS
  stopWords = STOP_WORDS
  #blog = blog.lower()
  aLemmas = [lemma for lemma in lemmas if lemma.isalpha() and lemma not in stopWords]
  stCode(['aLemmas=', aLemmas])
  POS = [(token.text, token.pos_) for token in doc]
  ENTs=[(ent.text, ent.label_) for ent in doc.ents]
  stCode([POS, ENTs])
elif menu==MENUs[0]:
  from textblob import TextBlob# Define a sentence
  #sentence = "I am learning NLP in Python"# Create a TextBlob object
  text_blob = TextBlob(sentence)# Use the 'tags' property to get the POS tags
  pos_tags = text_blob.tags
  stCode(['posTAGs=', pos_tags])
elif menu==MENUs[-1]:
  lngMDL=rtrvMDL()
  sentence=rtrvSent()
  #session_state['sentence']=sentence
  doc = lngMDL(sentence)
  # Iterate through the token and stCode the token text and POS tag
  tknInfo=[]
  for token in doc:
    tknInfo.append((token.text, token.pos_))
  stCode(['text, pos=', tknInfo])    #token.text, token.pos_
elif menu==MENUs[0]:
  #import nltk
  from nltk.tokenize import word_tokenize, sent_tokenize
  for sent in sent_tokenize(sentence):
      wordtokens = word_tokenize(sent)
      print(nltk.pos_tag(wordtokens),end='\n\n')
elif menu==MENUs[-2]:
  from nltk import pos_tag
  from nltk import RegexpParser
  text ="learn php from guru99 and make study easy".split()
  stCode("After Split:", text)
  tokens_tag = pos_tag(text)
  print("After Token:",tokens_tag)
  patterns= """mychunk:{<NN.?>*<VBD.?>*<JJ.?>*<CC>?}"""
  chunker = RegexpParser(patterns)
  print("After Regex:",chunker)
  output = chunker.parse(tokens_tag)
  stCode(["After Chunking", output])
