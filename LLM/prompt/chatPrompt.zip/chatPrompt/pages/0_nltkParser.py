from nltk import RegexpParser
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
from nltk.chunk import ne_chunk
from nltk import download as nltkDownload
from streamlit import code as stCode, text_area, sidebar, write as stWrite, session_state
from pprint import pprint
MENU=['Regexp', 'conll', 'web_sm'] #EMBEDDING 'medText', , 'tokenizer', 'punct', 'fastText', 'csvEye', 'answerQuestion', 'ansQues2', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec'
menu = sidebar.radio('Output', MENU, index=0)

def preprocess(sent):
    wrdTknz = word_tokenize(sent)
    sent = pos_tag(wrdTknz)
    return sent

stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
try:
  medCntxt=session_state['medCntxt']
except:
  session_state['medCntxt']=medCntxt='''European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices'''

if menu==MENU[0]:
  #nltkDownload('averaged_perceptron_tagger')
  #nltkDownload('maxent_ne_chunker')
  #nltkDownload('words')
  rawDset=text_area('medText', medCntxt)
  if rawDset:
    posTag=preprocess(rawDset)
    #pipeline rawDset->tokenized->posTag->neChunk
    neTree=ne_chunk(posTag) #pos_tag(word_tokenize(rawDset))
    stCode([neTree]) #'''Tree('S', [Tree('GPE', [('European', 'JJ')]), ('authorities', 'NNS'), ('fined', 'VBD'), Tree('PERSON', [('Google', 'NNP')]), ('a', 'DT'), ('record', 'NN'), ('$', '$'), ('5.1', 'CD'), ('billion', 'CD'), ('on', 'IN'), ('Wednesday', 'NNP'), ('for', 'IN'), ('abusing', 'VBG'), ('its', 'PRP$'), ('power', 'NN'), ('in', 'IN'), ('the', 'DT'), ('mobile', 'JJ'), ('phone', 'NN'), ('market', 'NN'), ('and', 'CC'), ('ordered', 'VBD'), ('the', 'DT'), ('company', 'NN'), ('to', 'TO'), ('alter', 'VB'), ('its', 'PRP$'), ('practices', 'NNS')])'''
    session_state['neTree']=neTree
    sentence = [("the", "DT"), ("little", "JJ"), ("yellow", "JJ"), ("dog", "NN"), ("barked","VBD"), ("at", "IN"), ("the", "DT"), ("cat", "NN")]
    nltkPttrn = "NP: {<DT>?<JJ>*<NN>}"
    #NPChunker = nltk.RegexpParser(pattern)
    #result = NPChunker.parse(sentence)
    #result.draw()
    NPChunker = RegexpParser(nltkPttrn)
    nltkRSLT = NPChunker.parse(neTree)
    stCode([ nltkRSLT.__dict__ ])
    #'append', 'chomsky_normal_form', 'clear', 'collapse_unary', 'convert', 'copy', 'count', 'draw', 'extend', 'flatten', 'freeze', 'fromlist', 'fromstring', 'height', 'index', 'insert', 'label', 'leaf_treeposition', 'leaves', 'node', 'pformat', 'pformat_latex_qtree', 'pop', 'pos', 'pprint', 'pretty_print', 'productions', 'remove', 'reverse', 'set_label', 'sort', 'subtrees', 'treeposition_spanning_leaves', 'treepositions', 'un_chomsky_normal_form'
    #nltkRSLT.draw()
elif menu==MENU[1]:
  from nltk.chunk import conlltags2tree, tree2conlltags
  session_state['neTree']=neTree
  cp = RegexpParser(pattern)
  cs = cp.parse(sent)
  iob_tagged = tree2conlltags(cs)
  stCode(iob_tagged)
  # nltk.download('maxent_ne_chunker')
  # nltk.download('words')
  # chunk the sentence
  neTree = ne_chunk()   #pos_tag(word_tokenize(sentence))

  # IOB transform
  # B-{CHUNK_TYPE} – for the word in the Beginning chunk
  # I-{CHUNK_TYPE} – for words Inside the chunk
  # O – Outside any chunk

  iob_tagged = tree2conlltags(neTree)
  stCode (iob_tagged)
  #stCode ([iob_tagged])   #i for i in iob_tagged if i[2]=='B-ORGANIZATION'
elif menu==MENU[-1]:
  import en_core_web_sm
  nlp = en_core_web_sm.load()
  doc = nlp(medCntxt)   #'European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices'
  pprint([(X.text, X.label_) for X in doc.ents])
  pprint([(X, X.ent_iob_, X.ent_type_) for X in doc])
  labels = [x.label_ for x in article.ents]
  Counter(labels)
  items = [x.text for x in article.ents]
  Counter(items).most_common(3)
  sentences = [x for x in article.sents]
  print(sentences[20])
  [(x.orth_,x.pos_, x.lemma_) for x in [y for y in nlp(str(sentences[20])) if not y.is_stop and y.pos_ != 'PUNCT']]
  dict([(str(x), x.label_) for x in nlp(str(sentences[20])).ents])
  print([(x, x.ent_iob_, x.ent_type_) for x in sentences[20]])

