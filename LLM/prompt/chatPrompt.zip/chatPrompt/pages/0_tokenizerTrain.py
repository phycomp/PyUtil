from transformers import BertTokenizerFast
from streamlit import code as stCode, write as stWrite, session_state, sidebar, dataframe, text_area
from pandas import read_csv
from st_aggrid import AgGrid, DataReturnMode, GridUpdateMode, GridOptionsBuilder, JsCode
from spcyMDL import rtrvMDL
from nltk import download as ntlkDownload

MENUs=['訓練bertUncased', '成效', 'getNER', 'tknLemma', 'avgPercptron', 'sentTknz', 'nltkToken', 'DEV', 'bertTknzr']#'tokenizer', 'punct', 'fastText', 'csvEye', 'fastChat', 'optimizer','BILUO', 'vocab', 'jsonViewer'] #EMBEDDING 訓練token
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
menu = sidebar.radio('Output', MENUs, index=0)

if menu==MENUs[4]: #punkt, avgPercptron
  from nltk import word_tokenize as nltkWordtknz, pos_tag as nltkPostag
  dsetDF=session_state['dsetDF']
  nltkDownload('punkt')
  nltkDownload('averaged_perceptron_tagger')
  cleanWords = re.sub("[^a-zA-Z]", " ", dsetDF)
  cleanWords = " ".join(cleanWords.split()) # remove multiple whitespaces
  tokens = nltkWordtknz(cleanWords)
  posTkns = nltkPostag(tokens)
  stCode(['posTkns', posTkns])

elif menu==MENUs[3]: #tknLemma
  dsetDF=session_state['dsetDF'] #sentTknz
  lngMDL=rtrvMDL()
  doc=lngMDL(dsetDF)
  tokens = [token.text for token in doc]  #['Four', 'score', 'and', 'seven', 'years', 'ago', 'our', 'fathers', ...
  stCode(['token=', tokens])
  lemmas = [token.lemma_ for token in doc]
  from spacy.lang.en.stop_words import STOP_WORDS
  stopWords = STOP_WORDS
  #blog = blog.lower()
  aLemmas = [lemma for lemma in lemmas if lemma.isalpha() and lemma not in stopWords]
  stCode(['aLemmas, stopWords=', aLemmas, stopWords])
  POS = [(token.text, token.pos_) for token in doc]
  ENTs=[(ent.text, ent.label_) for ent in doc.ents]
  stCode(['POS, ENTs=', POS, ENTs])
if menu==MENUs[-4]: #sentTknz
  from nltk import word_tokenize as nltkWordtknz, pos_tag as nltkPostag
  from nltk.corpus import stopwords
  from nltk.tokenize import word_tokenize, sent_tokenize
  stop_words = set(stopwords.words('english'))

  dsetDF=session_state['dsetDF']
  txt = "Sukanya, Rajib and Naba are my good friends. Sukanya is getting married next year. Marriage is a big step in one’s life. It is both exciting and frightening. But friendship is a sacred bond between people. It is a special kind of love between us. Many of you must have tried searching for a friend but never found the right one."

  # sent_tokenize is one of instances of PunktSentenceTokenizer from the nltk.tokenize.punkt module

  vghTknzr = sent_tokenize(dsetDF)
  stCode(['vghTknzr=', vghTknzr, stop_words])
  for i in vghTknzr:
    wordsList = nltkWordtknz(i)   # Word tokenizers is used to find the words and punctuation in a string
    vghWords = [w for w in wordsList if w not in stop_words]   # removing stop words from wordList

    vghTagger = nltkPostag(vghWords) # Using a Tagger. Which is part-of-speech tagger or POS-tagger.
    stCode(['vghTagger=', vghTagger])

  stCode(['dsetDF', dsetDF])

elif menu==MENUs[-3]:
  from nltk import word_tokenize as nltkWordtknz, pos_tag as nltkPostag
  text = session_state['dsetDF']
  tokens = nltkWordtknz(text)
  stCode(['tokens=', tokens])
  tag = nltkPostag(tokens)
  stCode(['tag=', tag])
elif menu==MENUs[-1]:
  dsetDF=session_state['dsetDF']
  stCode(['dsetDF', dsetDF])
  lngMDL=rtrvMDL()
  #sentence=rtrvSent()
  #session_state['sentence']=sentence
  pttrn=text_area('PTTRN',)
  doc = lngMDL(dsetDF)
  tknInfo=[]
  from functools import partial
  #filter(partial(foo, 1, c=4), myTuple)
  for token in doc:
    tknInfo.append((token.text, token.pos_))
  stCode(['text, pos=', tknInfo])    #token.text, token.pos_
  def isPROPN(seq, PTTRN):  #='PROPN'
    return True if seq[-1]==PTTRN else False
  if pttrn:
    propnSeq=filter(isPROPN(pttrn=pttrn), tknInfo)   #lambda: , args=Pttrn
    #g = filter(foo(1,4),myList)
    #propnSeq=filter(partial(isPROPN, seq, pttrn=pttrn), tknInfo)   #, args=Pttrn
    stCode(['text, pos=', list(propnSeq)])    #token.text, token.pos_
elif menu==MENUs[-2]:
  from streamlit import json as stJson
  from json import loads, load
  from spacy import load as spcyLoad
  lngMDL=spcyLoad("en_core_web_sm")
  lngMDL.add_pipe("ner", source=nlp)
  lngMDL.add_pipe("entity_ruler", before="ner") # insert the entity ruler
  #fin=open('/home/josh/Downloads/dev-v2.0.json')
  #jsnOBJ=load(fin)
  #for k in jsnOBJ:
  # stJson(jsnOBJ[k])
elif menu==MENUs[0]:
  bertTknzr=BertTokenizerFast.from_pretrained("bert-base-uncased")
  stCode(['bertTknzr', bertTknzr])
  #read_csv('bdcrcopa2.ods')
  try:
    dfCOPA=session_state['dfCOPA']
  except:
    session_state['dfCOPA']=dfCOPA=read_csv('/home/josh/NLP/nlpData/bdcrcopa2.csv', sep='\x06')
  #dataframe(dfCOPA)
  from grdOpt import mkGrid
  grdOpt=mkGrid(dfCOPA)
  from streamlit import sidebar
  with sidebar:
    agValue = AgGrid(dfCOPA, gridOptions=grdOpt, allow_unsafe_jscode=True, theme="balham", reload_data=False, update_mode=GridUpdateMode.SELECTION_CHANGED)
    #ValueError: ALPINE is not valid. Available options: {'STREAMLIT': <AgGridTheme.STREAMLIT: 'streamlit'>, 'ALPINE': <AgGridTheme.ALPINE: 'alpine'>, 'BALHAM': <AgGridTheme.BALHAM: 'balham'>, 'MATERIAL': <AgGridTheme.MATERIAL: 'material'>}
    #selected_rows = agValue['selected_rows']

  stCode([agValue.selected_rows])
  if agValue.selected_rows:
    rowNDX=agValue.selected_rows[0]['_selectedRowNodeInfo']['nodeRowIndex']#[agValue.selected_rows[0]['outcome']][0]
    dsetDF=session_state['dsetDF']=agValue.selected_rows[0]['outcome']  #=session_state['rowNDX']
  #session_state['trainData']=dfCOPA['outcome']
  #session_state['pthlgyCntxt']=dfCOPA['outcome']
  #rawDset=dfCOPA['outcome']
  def pthlgyItrtr(batchSize=10000):
    for row in dfCOPA.iterrows():
      #print(row)
      yield row[-1]
    '''
      for i in range(0, len(rawDset), batchSize):
        print(rawDset)
        yield rawDset[i : i + batchSize]["outcome"]

    '''

  try:
    vghBertTknzr=session_state['vghBertTknzr']
  except:
    session_state['vghBertTknzr']=vghBertTknzr=bertTknzr.train_new_from_iterator(text_iterator=pthlgyItrtr(), vocab_size=32)   #_000
  try:
    vghTknzr=session_state['vghTknzr']
  except:
    vghTknzr=session_state['vghTknzr']='vghCOPA'
    vghBertTknzr.save_pretrained(vghTknzr)

  #ner_feature = bertTknzr["ner_tags"] #.features
  #stCode(['dsetDF', dsetDF.split()]) #vghBertTknzr.tokenize
  from calcWord import calcLen
  avgLen=calcLen(dsetDF)
  stCode(['avgLen=', [word for word in dsetDF.split() if len('PATHOLOGICAL')>len(word)>avgLen]])
  icdQuery=text_area('icdQuery')
  if icdQuery:
    icdQuery='&'.join(icdQuery.split())
    fullQuery=f'10.221.252.51:3010/api/v1/concepts?pageSize=15&conceptClass=7-char%20billing%20code&vocabulary=ICD10CM&page=1&query={icdQuery}'  #剛剛會議中有提到的ICD10M指定7 char 這邊給一個範例改domain name跟下query即可
    stCode([fullQuery]) #'fullQuery=', 

  #stCode(['vghBertTknzr', vghBertTknzr.__dict__ ])
  #token有以下tag==>bos, eos, sep, cls, unk, pad, mask
  #from transformers import AutoTokenizer, AutoModel
  #lngMDL=session_state['model']="vghtpe/COPA"
  #tokenizer = AutoTokenizer.from_pretrained(lngMDL)
  #model = AutoModel.from_pretrained("emilyalsentzer/Bio_ClinicalBERT")

elif menu==MENUs[1]:
  from streamlit import text_area
  from transformers import AutoTokenizer
  import multiprocessing
  try: vghTknzr=session_state['vghTknzr']
  except: session_state['vghTknzr']=vghTknzr='vghtpeCOPA'
  # tokenizer = AutoTokenizer.from_pretrained(f"{user_id}/{tokenizer_id}") load tokenizer
  #tokenizer = AutoTokenizer.from_pretrained(vghTknzr)   #"vghtpeCOPA"
  #num_proc = multiprocessing.cpu_count()
  #print(f"The max length for the tokenizer is: {tokenizer.model_max_length}")
  def group_texts(examples):
      tokenized_inputs = tokenizer(examples["text"], return_special_tokens_mask=True, truncation=True, max_length=tokenizer.model_max_length)
      return tokenized_inputs

  # preprocess dataset
  rawDset=text_area('medical文本', )
  #tokenizer(examples["tokens"], padding="max_length", truncation=True, is_split_into_words=True)
  if rawDset:
    from datasets import Dataset
    try: dfCOPA=session_state['dfCOPA']
    except: pass    #stCode(['dfCOPA']) #session_state['dfCOPA']=='datafCOPA'
    session_state['trnDset']=trnDset=Dataset.from_pandas(dfCOPA)   #DataFrame(data=trainData)
    try: vghBertTknzr=session_state['vghBertTknzr']
    except: pass
    #tokenized_datasets = rawDset.map(group_texts, batched=True, remove_columns=["text"], num_proc=num_proc)
    #tokenized_datasets_ = dataset.map(tokenize_function, batched=True)
    tknzInputs = vghBertTknzr([rawDset], return_special_tokens_mask=True, truncation=True, max_length=vghBertTknzr.model_max_length)
    #tknzInputs=vghBertTknzr([rawDset], padding="max_length", truncation=True, is_split_into_words=True)   # trnDset['outcome']
    #tknzInputs = vghBertTknzr.encode(rawDset)
    #tokenized_datasets.features
    stCode(['tknzInputs', tknzInputs.tokens()])#.__dict__
    #vghBertTknzr屬性有 ids, type_ids, tokens, offsets, attention_mask, special_tokens_mask, overflowing
    #data有input_ids, token_type_ids, attention_mask, special_tokens_mask
