#Load the model via the transformers library:
from streamlit import code as stCode, sidebar, session_state, write as stWrite
from pandas import read_csv
from transformers import AutoTokenizer, BertForSequenceClassification
from aggridDF import mkGrid
from st_aggrid import AgGrid, DataReturnMode, GridUpdateMode, GridOptionsBuilder, JsCode

tokenizer = AutoTokenizer.from_pretrained("AkshatSurolia/ICD-10-Code-Prediction")
model = BertForSequenceClassification.from_pretrained("AkshatSurolia/ICD-10-Code-Prediction")
config = model.config
#stCode(['config=', config])

#Run the model with clinical diagonosis text:
MENU=['PCS文件', 'ICD10文件', '判讀ICD碼'] #EMBEDDING   transformer 'AutoTokenizer', 'pretrain', 'keras', 'fastText', 'optimizer','BILUO', 'vocab', 'word2vec'
def mkICD(cntxtDesc):
  encodedCntxt = tokenizer(cntxtDesc, return_tensors='pt')
  output = model(**encodedCntxt)
  #Return the Top-5 predicted ICD-10 codes:
  results = output.logits.detach().cpu().numpy()[0].argsort()[::-1][:5]
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
  #stCode([cntxtDesc])
  cntxtDesc
  stCode([ config.id2label[ids] for ids in results])

menu=sidebar.radio('MENU', MENU)    #, index=-1
if menu==MENU[0]:

  PCSdf=read_csv('/home/josh/icdNLP/PCS200.csv')
  with sidebar:
    #mkGrid(PCSdf)
    grdOpt=mkGrid(PCSdf)
    agValue = AgGrid(PCSdf, gridOptions=grdOpt, allow_unsafe_jscode=True, theme="balham", reload_data=False, update_mode=GridUpdateMode.SELECTION_CHANGED)
    #ValueError: ALPINE is not valid. Available options: {'STREAMLIT': <AgGridTheme.STREAMLIT: 'streamlit'>, 'ALPINE': <AgGridTheme.ALPINE: 'alpine'>, 'BALHAM': <AgGridTheme.BALHAM: 'balham'>, 'MATERIAL': <AgGridTheme.MATERIAL: 'material'>}
    #selected_rows = agValue['selected_rows']
    #stCode([agValue.selected_rows])
    if agValue.selected_rows:
      rowNDX=agValue.selected_rows[0]['_selectedRowNodeInfo']['nodeRowIndex']#[agValue.selected_rows[0]['OUTCOME']][0]
      dsetDF=session_state['dsetDF']=agValue.selected_rows[0]['OUTCOME']  #=session_state['rowNDX']
  dsetDF
  mkICD(dsetDF)
  #session_state['trainData']=dfCOPA['outcome']
elif menu==MENU[1]:
  ICDdf=read_csv('/home/josh/icdNLP/ICD200.csv')
  from aggridDF import mkGrid
  with sidebar:
    #ICDdf
    #mkGrid(PCSdf)
    grdOpt=mkGrid(ICDdf)
    agValue = AgGrid(ICDdf, gridOptions=grdOpt, allow_unsafe_jscode=True, theme="balham", reload_data=False, update_mode=GridUpdateMode.SELECTION_CHANGED)
    #selected_rows = agValue['selected_rows']
    #stCode([agValue.selected_rows])
    if agValue.selected_rows:
      rowNDX=agValue.selected_rows[0]['_selectedRowNodeInfo']['nodeRowIndex']#[agValue.selected_rows[0]['OUTCOME']][0]
      dsetDF=session_state['dsetDF']=agValue.selected_rows[0]['DISC_NOTE']  #=session_state['rowNDX']
  mkICD(dsetDF)
elif menu==MENU[-1]:
  text = "subarachnoid hemorrhage scalp laceration service: surgery major surgical or invasive"
  dsetDF=session_state['dsetDF']
  encoded_input = tokenizer(text, return_tensors='pt')
  output = model(**encoded_input)

  #Return the Top-5 predicted ICD-10 codes:

  results = output.logits.detach().cpu().numpy()[0].argsort()[::-1][:5]
  stCode([ config.id2label[ids] for ids in results])
