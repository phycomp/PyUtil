from streamlit import cache as stCache, write as stWrite, session_state
from procData import dataMnpl

ann=session_state.get('ann')
rtSymbl=session_state.get('rtSymbl')
print('cache', ann, rtSymbl)
tblNHIRD='ageGndrSymblPfkeyIINew'
lwr, mdl, ppr, flwr, fmdl, fppr=None, None, None, None, None, None
maleSQL=f"""SELECT left("RSDATE", 4), string_agg("cmbValue", ',' order by "RSDATE" ) from isc8381."{tblNHIRD}" where "PSEX"='1' and "RSRTSYM"='{rtSymbl}' and left("RSDATE", 4)='{ann}' group by 1;"""
#maleValue = run_query("""SELECT * from "ageGndrSymblPfkeyIIINew" where "PSEX"=1 and left("RSDATE", 4)='{ann}' limit 10;""")
print(maleSQL)
fmSQL=f"""SELECT left("RSDATE", 4), string_agg("cmbValue", ',' order by "RSDATE" ) from isc8381."{tblNHIRD}" where "PSEX"='2' and "RSRTSYM"='{rtSymbl}' and left("RSDATE", 4)='{ann}' group by 1;"""
print(fmSQL)
if ann and rtSymbl:
  qryMale=runQuery(maleSQL)
  if qryMale:
    ann, maleValue = qryMale[0]
    lwr, mdl, ppr=dataMnpl(maleValue)
  qryFemale=runQuery(fmSQL)
  if qryFemale:
    ann, femaleValue = qryFemale[0]
    flwr, fmdl, fppr=dataMnpl(femaleValue)
  #RSDATE|RSRTSYM|PFKEY|HISTNO|PSEX|AGE|cmbValue|
  __all__=[lwr, mdl, ppr, flwr, fmdl, fppr]
# Print results.
#for row in rows: write(f"{row}")
