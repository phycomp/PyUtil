from psycopg import connect as pgCnnct
from streamlit import secrets, cache_resource as stCache#, write as stWrite

# Initialize connection.
# Uses cache to only run once.
#@stCache(allow_output_mutation=True, hash_funcs={"_thread.RLock": lambda _: None})
#def initCnnction(db="postgres", **kwargs):
  #db=kwargs['db']
  #return pgCnnct(**secrets[db])
#print(conn)

# Perform query.
# Uses st.cache to only rerun when the query changes or after 10 min.
#@stCache(ttl=0, allow_output_mutation=True)
#@st.cache(hash_funcs={builtins.weakref: my_hash_func})
#def my_func(...):
#@stCache(allow_output_mutation=True)    #(ttl=600, allow_output_mutation=True, hash_funcs={"_thread.RLock": lambda _: None})
@stCache#(hash_funcs={"_thread.RLock":lambda _:None, "builtins.weakref":lambda _:None})
#@stCache(hash_funcs={"_thread.RLock":lambda _:None})
def runQuery(query, db='postgres', commitType='select'):
  conn=pgCnnct(**secrets[db])
  #initCnnction()#db="postgres", **secrets[])
  with conn.cursor() as cur:
    if commitType=='select':
      cur.execute(query)
      return cur.fetchall()
    else:
      cur.execute(query)
      conn.commit()
__all__=[runQuery]
