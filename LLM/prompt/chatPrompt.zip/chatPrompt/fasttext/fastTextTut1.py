Fasttext轉自http://albertxiebnu.github.io/fasttext/
Fasttext是Facebook AI Research最近推出的文字分類和詞訓練工具，其原始碼已經託管在Github上。Fasttext最大的特點是模型簡單，只有一層的隱層以及輸出層，因此訓練速度非常快，在普通的CPU上可以實現分鐘級別的訓練，比深度模型的訓練要快幾個數量級。同時，在多個標準的測試資料集上，Fasttext在文字分類的準確率上，和現有的一些深度學習的方法效果相當或接近。
最近一直在做微信廣告文章分類的工作，正好順手研究了下Fasttext，並在微信廣告文章識別上做了一些嘗試。因為程式碼開源的時間不長，網上相應的文章和資料還比較少， 希望這篇文章對想了解和使用Fasttext做文字分類的同學有所幫助。
原理
介紹原理之前，我們先稍微聊一點八卦。Fasttext的其中一個作者是Thomas Mikolov。熟悉word2vec的同學應該對這個名字很熟悉，正是他當年在Google帶了一個團隊倒騰出來了word2vec，很好的解決了傳統詞袋錶示的缺點，極大地推動了NLP領域的發展。後來這哥們跳槽去了Facebook，才有了現在的Fasttext。從“血緣”角度來看，Fasttext和word2vec可以說是一脈相承。
回到正題，Fasttext主要有兩個功能，一個是訓練詞向量，另一個是文字分類。詞向量的訓練，相對於word2vec來說，增加了subwords特性。subwords其實就是一個詞的character-level的n-gram。比如單詞”hello”，長度至少為3的char-level的ngram有”hel”,”ell”,”llo”,”hell”,”ello”以及本身”hello”。每個ngram都可以用一個dense的向量zgzg表示，於是整個單詞”hello”就可以表示表示為：
Vhello=∑g∈ϕzTgvcVhello=∑g∈ϕzgTvc
具體細節可以參考論文Enriching Word Vectors with Subword Information，這裡就不展開敘述了。那麼把每個word，拆成若干個char-level的ngram表示有什麼好處呢？其實細想一下也非常容易理解，無非就是豐富了詞表示的層次。比方說”english-born”和”china-born”，從單詞層面上看，是兩個不同的單詞，但是如果用char-level的ngram來表示，都有相同的字尾”born”。因此這種表示方法可以學習到當兩個詞有相同的詞綴時，其語義也具有一定的相似性。這種方法對英語等西語來說可能是奏效的，因為英語中很多相同字首和字尾的單詞，語義上確實有所相近。但對於中文來說，這種方法可能會有些問題。比如說，”原來”和”原則”，雖有相同字首，但意義相去甚遠。可能對中文來說，按照偏旁部首等字形的方式拆解可能會更有意義一些。
Fasttext的另一個功能是做文字分類。主要的原理在論文Bag of Tricks for Efficient Text Classification中有所闡述。其模型結構簡單來說，就是一層word embedding的隱層+輸出層。結構如下圖所示：
此處輸入圖片的描述
上圖中左邊的圖就是Fasttext的網路結構，其中W(1)到W(n)表示document中每個詞的word embedding表示。文章則可以用所有詞的embedding累加後的均值表示，即hdoc=1n∑ni=1wihdoc=1n∑i=1nwi，最後從隱層再經過一次的非線性變換得到輸出層的label。對比word2vec中的cbow模型（continuous bag of word），可以發現兩個模型之前非常的相似。不同之處在於，fasttext模型最後預測的是文章的label，而cbow模型預測的是視窗中間的詞w(t)，一個是有監督的學習，一個是無監督的學習。另外cbow模型中輸入層只包括當前視窗內除中心詞的所以詞，而fasttext模型中輸出層是文章中的所有詞。
和word2vec類似，fasttext本質上也可以看成是一個淺層的神經網路，因此其forward propogation過程可描述如下：
h=1n∑i=1nwiz=sigmoid(Woh)h=1n∑i=1nwiz=sigmoid(Woh)
其中zz是最後輸出層的輸入向量，WoWo表示從隱層到輸出層的權重。
由於模型的最後我們要預測文章屬於某個類別的概率，因此很自然的選擇就是softmax層了，於是損失函式可以定義為：
ŷ =softmax(z)CE(y,ŷ )=−∑jyjlog(ŷ j)loss=1M∑i=1mCE(yi,ŷ i)y^=softmax(z)CE(y,y^)=−∑jyjlog(y^j)loss=1M∑i=1mCE(yi,y^i)
當類別數較少時，直接套用softmax層並沒有效率問題，但是當類別很多時，softmax層的計算就比較費時了。為了加快訓練過程，Fasttext同樣也採用了和word2vec類似的方法。一種方法是使用hierarchical softmax，當類別數為K，word embedding大小為d時，計算複雜度可以從O(Kd)O(Kd)降到O(dlog(K))O(dlog(K))。另一種方法是採用negative sampling，即每次從除當前label外的其他label中選擇幾個作為負樣本，作為出現負樣本的概率加到損失函式中，用公式可表達為：
loss=−1M∑i=1m(logσ(uTohi)+∑j∼P(w)[logσ(−uTjhi)])loss=−1M∑i=1m(logσ(uoThi)+∑j∼P(w)[logσ(−ujThi)])
其中hihi是第ii個樣本的隱層，ujuj表示WoWo中第j行向量。
N-gram特徵
到目前為止，Fasttext模型有個致命的問題，就是丟失了詞順序的資訊，因為隱層是通過簡單的求和取平均得到的。為了彌補這個不足，Fasttext增加了N-gram的特徵。具體做法是把N-gram當成一個詞，也用embedding向量來表示，在計算隱層時，把N-gram的embedding向量也加進去求和取平均。舉個例子來說，假設某篇文章只有3個詞，W1，W2，W3，N-gram的N取2，w1w1、w2w2、w3w3以及w12w12、w23w23分別表示詞W1、W2、W3和bigram W1-W2，W2-W3的embedding向量，那麼文章的隱層可表示為：
h=15(w1+w2+w3+w12+w23)h=15(w1+w2+w3+w12+w23)
通過back-propogation演算法，就可以同時學到詞的Embeding和n-gram的Embedding了。
具體實現上，由於n-gram的量遠比word大的多，完全存下所有的n-gram也不現實。Fasttext採用了Hash桶的方式，把所有的n-gram都雜湊到buckets個桶中，雜湊到同一個桶的所有n-gram共享一個embedding vector。如下圖所示：
wordembeddings
圖中WinWin是Embedding矩陣，每行代表一個word或N-gram的embeddings向量，其中前VV行是word embeddings，後Buckets行是n-grams embeddings。每個n-gram經雜湊函式雜湊到0-bucket-1的位置，得到對應的embedding向量。用雜湊的方式既能保證查詢時O(1)O(1)的效率，又可能把記憶體消耗控制在O(bucket×dim)O(bucket×dim)範圍內。不過這種方法潛在的問題是存在雜湊衝突，不同的n-gram可能會共享同一個embedding。如果桶大小取的足夠大，這種影響會很小。
Tricks
Fasttext為了提升計算效率做了很多方面的優化，除了上節提到的Hash方法外，還使用了很多小技巧，這對我們實際寫程式碼的時候提供了很多的借鑑。
首先，對計算複雜度比較高的運算，Fasttext都採用了預計算的方法，先計算好值，使用的時候再查表，這是典型的空間或時間的優化思路。比如sigmoid函式的計算，原始碼如下：
void initSigmoid() {
    t_sigmoid = new real[SIGMOID_TABLE_SIZE + 1];
    for (int i = 0; i < SIGMOID_TABLE_SIZE + 1; i++) {
        real x = real(i * 2 * MAX_SIGMOID) / SIGMOID_TABLE_SIZE - MAX_SIGMOID;
        t_sigmoid[i] = 1.0 / (1.0 + std::exp(-x));
    }
}
其次，在Negative Sampling中，Fasttext也採用了和word2vec類似的方法，即按照每個詞的詞頻進行隨機負取樣，詞頻越大的詞，被取樣的概率越大。每個詞被取樣的概率並不是簡單的按照詞頻在總量的佔比，而是對詞頻先取根號，再算佔比，即pw=f1/2w∑jf1/2jpw=fw1/2∑jfj1/2。其中fwfw表示詞ww的詞頻。這裡取根號的目的是降低高頻詞的採用概率，同事增加低頻詞的取樣概率，具體程式碼如下：
void Model::initTableNegatives(const std::vector<int64_t>& counts) {
    real z = 0.0;
    for (size_t i = 0; i < counts.size(); i++) {
    z += pow(counts[i], 0.5);
    }
    for (size_t i = 0; i < counts.size(); i++) {
        real c = pow(counts[i], 0.5);
        for (size_t j = 0; j < c * NEGATIVE_TABLE_SIZE / z; j++) {
            negatives.push_back(i);
        }
    }
    std::shuffle(negatives.begin(), negatives.end(), rng);
}
使用說明
Fasttext的使用非常簡單，首先從Github上clone原始碼到本地，然後直接make編譯，生成一個可執行檔案Fasttext。執行fasttext將列印使用幫助說明如下：
./fasttext 
usage: fasttext <command> <args>
The commands supported by fasttext are:
supervised       train a supervised classifier
test             evaluate a supervised classifier
predict          predict most likely label
predict_prob     predict labels and probility
skipgram         train a skipgram model
cbow             train a cbow model
print-vectors    print vectors given a trained model
幫助說明已經非常清楚了。如果要訓練模型，我們選擇supervised選項，執行./fasttext supervised:
./fasttext supervised
Empty input or output path.
The following arguments are mandatory:
-input        training file path
-output       output file path
The following arguments are optional:
-lr           learning rate [0.05]
-lrUpdateRate change the rate of updates for the learning rate [100]
-dim          size of word vectors [100]
-ws           size of the context window [5]
-epoch        number of epochs [5]
-minCount     minimal number of word occurences [1]
-neg          number of negatives sampled [5]
-wordNgrams   max length of word ngram [1]
-loss         loss function {ns, hs, softmax} [ns]
-bucket       number of buckets [2000000]
-minn         min length of char ngram [3]
-maxn         max length of char ngram [6]
-thread       number of threads [12]
-t            sampling threshold [0.0001]
-label        labels prefix [__label__]
訓練模式下涉及到的主要引數有學習率(-lr)，隱層的維數(-dim)，最小詞頻（-minCount），負取樣個數（-neg）和n-grams的長度(-wordNgrams)等。
應用
弄清基本原理後，我們嘗試了用Fasttext對微信的文章進行分類。首先先簡單地說明下任務的背景：微信公眾號的文章中有不少黑四類的文章（包括廣告，活動，招聘和公告），比較影響使用者體驗，其中廣告文章又佔比較大的比例。因此我們希望從現有的文章資料中，訓練出一個分類模型，自動識別每個文章是否屬於廣告。雖然是一個簡單的二分類問題，但是考慮的廣告文章本身的多樣性，和正常文章界限較模糊，以及軟文廣告，圖片廣告等，要做到比較高的準確率還是有不少困難的。
先看下實驗的資料集。我們通過人工標註，交叉驗證的方式收集了約32.4萬的樣本，其中正樣本（廣告文章）15.7萬，負樣本（正常文章）16.7萬。按照8:2的比例切分成訓練資料和驗證資料（用於調參）。另外還有1500左右的獨立測試樣本，正負樣本佔比為1：1。每個樣本為一篇文章，包括文章的標題和正文。
實驗中，我們選擇了另外兩種分類演算法來和Fasttext進行對比。第一種方法是目前正在使用的廣告特徵詞袋的方法，其中包括廣告的特徵詞和bigram大約3萬多個。同時對標題命中詞袋和不同文章位置命中詞袋進行了加權處理，另外還增加了標題和廣告的相似度等特徵。另一種方法是使用CNN+word2vec的方法，先用word2vec訓練詞的Embedding，然後把文章的詞序列轉化成Embeddings向量構成的二維矩陣，之後再套用CNN的網路架構進行分類，具體方法可參考這裡。
Fasttext的引數選擇上，我們使用-dim=64, -lr=0.5, -wordNgram=2 , -minCount=1,-bucket=10000000，-thread 20，其餘引數預設。所有模型的一些超引數都通過驗證集來選擇最優的引數。
首先，我們從分類準確率的評價指標上對比三種方法的實際效果。
準確率對比
從實際效果上來看，Fasttext的表現還是非常不錯的。雖然比特徵詞袋的方法要略差一點，但是特徵詞袋的結果是通過之前一系列的優化後的結果，而Fasttext只是通過了簡單的調參，就能達到90.9%左右的準確率。同時，對比相對複雜一些的CNN的深度學習方法，分類效果還要略好一些。
從演算法的執行效率上看，我們同樣對這三種方法進行了簡單地對比：
此處輸入圖片的描述
上圖顯示的是每種演算法單次迭代的訓練時間，單位是秒。可以看到Fasttext相對於深度學習等方法，在訓練速度上的優勢還是非常明顯，單次迭代時長比CNN快了60多倍。而且Fasttext是在普通CPU上執行，而CNN是在k20的GPU下執行的結果。特徵詞袋的方法最後是用liblinear來訓練，因為採用的是邏輯迴歸演算法，比較簡單，所以速度要比Fasttext快一些。
結論和思考
其實關於學術界對Fasttext的評價，網上也有許多不同的聲音。有些人認為Fasttext模型非常簡單，理論上也沒有什麼很多創新之處。但是從實際的使用效果和訓練速度上來看，我認為Fasttext依然是一個非常優秀的開源文字分類工具。
首先從工業界的角度來看，Fasttext因為其優秀的效能，不錯的分類效果，使用起來也非常簡單，因此非常適合大規模的文字分類問題。實際上Facebook已經將Fasttext應用於實際的大規模文字分類的場景中了。另外作為淺層的文字分類模型，Fasttext也非常適合作為Baseline演算法來和複雜的深度學習演算法進行對比。
另一方面，從理論或者學術的角度看，Fasttext也引發了我們一些新的思考。首先，對於文字分類等偏線性的資料集，複雜的深層網路對於淺層網路來說，優勢並不明顯，深度學習可能容易過擬合，而淺層的簡單網路反而泛化能力更好。但也不是說淺層的方法就一定比深層的好，這是由資料集來決定的。其次，除了資料本身，資料量的大小很大程度上也決定了方法的選擇。對於小規模的資料集，可能簡單的淺層模型就可以了，深度學習因為引數很多，模型複雜，反而訓練不充分。但隨著資料量的增加，可能深度模型的優勢就逐步體現出來。不過深度學習受限於GPU本身的效能和記憶體問題，面對一些超大規模的資料集，深度學習可能無能無力。這時候，選擇有些簡單的淺層方法，反而是一個比較好的選擇。
標籤： Fasttext word 方法 文章 表示 訓練 模型 簡單
