local tabPage=vim.api.nvim_get_current_tabpage()
print(tabPage)
local tabNR=vim.fn.tabpagenr()
local wnnr=vim.fn.winnr()
local tabWinnr=vim.fn.tabpagewinnr(tabNR)  --, wnnr
--|tabpagenr()|, |tabpagewinnr()| and |
local tbbufs=vim.fn.tabpagebuflist() --| to figure out the text to be displayed.  Use 

print(tabNR, tabWinnr, tbbufs)
--tabline="%1T" -- for the first label, 
tabline="%2T" --for the second one, etc.  Use "%X" items for closing labels.
							*hl-StatusLine*
StatusLine	Status line of current window.
							*hl-StatusLineNC*
StatusLineNC	Status lines of not-current windows.
							*hl-TabLine*
TabLine		Tab pages line, not active tab page label.
							*hl-TabLineFill*
TabLineFill	Tab pages line, where there are no labels.
							*hl-TabLineSel*
TabLineSel	Tab pages line, active tab page label.
							*hl-Title*
Title		Titles for output from ":set all", ":autocmd" etc.
							*hl-Visual*
Visual		Visual mode selection.
