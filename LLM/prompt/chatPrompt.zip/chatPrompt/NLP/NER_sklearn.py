#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report


# In[2]:


df = pd.read_csv('ner_dataset.csv', encoding = "ISO-8859-1")
df = df[:100000]
df.head()


# In[3]:


df.isnull().sum()


# In[4]:


df = df.fillna(method='ffill')


# We have 4,544 sentences that contain 10,922 unique words and tagged by 17 tags.

# In[5]:


df['Sentence #'].nunique(), df.Word.nunique(), df.Tag.nunique()


# In[10]:


df.head()


# In[11]:


df.groupby('Tag').size().reset_index(name='counts')


# In[6]:


X = df.drop('Tag', axis=1)
X.head()


# In[7]:


X.columns


# In[8]:


v = DictVectorizer(sparse=False)
X = v.fit_transform(X.to_dict('records'))
X.shape


# In[9]:


y = df.Tag.values


# In[10]:


classes = np.unique(y)


# In[11]:


classes = classes.tolist()
classes


# In[12]:


X.shape, y.shape


# In[13]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.33, random_state=0)


# In[14]:


X_train.shape, y_train.shape


# ### Perceptron

# In[15]:


new_classes = classes.copy()
new_classes.pop()
new_classes


# In[16]:


per = Perceptron(verbose=10, n_jobs=-1, max_iter=5)
per.partial_fit(X_train, y_train, classes)


# In[17]:


print(classification_report(y_pred=per.predict(X_test), y_true=y_test, labels=new_classes))


# ### Linear classifiers with SGD training

# In[18]:


sgd = SGDClassifier()
sgd.partial_fit(X_train, y_train, classes)


# In[19]:


print(classification_report(y_pred=sgd.predict(X_test), y_true=y_test, labels=new_classes))


# ### Naive Bayes classifier for multinomial models

# In[20]:


nb = MultinomialNB(alpha=0.01)
nb.partial_fit(X_train, y_train, classes)


# In[21]:


print(classification_report(y_pred=nb.predict(X_test), y_true=y_test, labels = new_classes))


# ### Passive Aggressive Classifier

# In[22]:


pa =PassiveAggressiveClassifier()
pa.partial_fit(X_train, y_train, classes)


# In[23]:


print(classification_report(y_pred=pa.predict(X_test), y_true=y_test, labels=new_classes))


# ### Conditional Random Fields (CRFs)

# In[24]:


import sklearn_crfsuite
from sklearn_crfsuite import scorers
from sklearn_crfsuite import metrics


# #### Get sentences

# In[25]:


class SentenceGetter(object):
    
    def __init__(self, data):
        self.n_sent = 1
        self.data = data
        self.empty = False
        agg_func = lambda s: [(w, p, t) for w, p, t in zip(s['Word'].values.tolist(), 
                                                           s['POS'].values.tolist(), 
                                                           s['Tag'].values.tolist())]
        self.grouped = self.data.groupby('Sentence #').apply(agg_func)
        self.sentences = [s for s in self.grouped]
        
    def get_next(self):
        try: 
            s = self.grouped['Sentence: {}'.format(self.n_sent)]
            self.n_sent += 1
            return s 
        except:
            return None


# In[26]:


getter = SentenceGetter(df)


# In[28]:


sent = getter.get_next()
print(sent)


# In[29]:


sentences = getter.sentences


# #### Features extraction
# 
# Next, we extract more features (word parts, simplified POS tags, lower/title/upper flags, features of nearby words) and convert them to sklear-crfsuite format - each sentence should be converted to a list of dicts.

# In[31]:


def word2features(sent, i):
    word = sent[i][0]
    postag = sent[i][1]
    
    features = {
        'bias': 1.0, 
        'word.lower()': word.lower(), 
        'word[-3:]': word[-3:],
        'word[-2:]': word[-2:],
        'word.isupper()': word.isupper(),
        'word.istitle()': word.istitle(),
        'word.isdigit()': word.isdigit(),
        'postag': postag,
        'postag[:2]': postag[:2],
    }
    if i > 0:
        word1 = sent[i-1][0]
        postag1 = sent[i-1][1]
        features.update({
            '-1:word.lower()': word1.lower(),
            '-1:word.istitle()': word1.istitle(),
            '-1:word.isupper()': word1.isupper(),
            '-1:postag': postag1,
            '-1:postag[:2]': postag1[:2],
        })
    else:
        features['BOS'] = True
    if i < len(sent)-1:
        word1 = sent[i+1][0]
        postag1 = sent[i+1][1]
        features.update({
            '+1:word.lower()': word1.lower(),
            '+1:word.istitle()': word1.istitle(),
            '+1:word.isupper()': word1.isupper(),
            '+1:postag': postag1,
            '+1:postag[:2]': postag1[:2],
        })
    else:
        features['EOS'] = True

    return features

def sent2features(sent):
    return [word2features(sent, i) for i in range(len(sent))]

def sent2labels(sent):
    return [label for token, postag, label in sent]

def sent2tokens(sent):
    return [token for token, postag, label in sent]


# The above code were taken from sklearn-crfsuite official site.

# Split train and test sets.

# In[32]:


X = [sent2features(s) for s in sentences]
y = [sent2labels(s) for s in sentences]


# In[33]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=0)


# In[34]:


crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    c1=0.1,
    c2=0.1,
    max_iterations=100,
    all_possible_transitions=True
)
crf.fit(X_train, y_train)


# In[35]:


y_pred = crf.predict(X_test)
metrics.flat_f1_score(y_test, y_pred, average='weighted', labels=new_classes)


# In[36]:


print(metrics.flat_classification_report(y_test, y_pred, labels = new_classes))


# In[40]:


import scipy.stats
from sklearn.metrics import make_scorer
from sklearn.grid_search import RandomizedSearchCV

crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    max_iterations=100,
    all_possible_transitions=True
)
params_space = {
    'c1': scipy.stats.expon(scale=0.5),
    'c2': scipy.stats.expon(scale=0.05),
}

# use the same metric for evaluation
f1_scorer = make_scorer(metrics.flat_f1_score,
                        average='weighted', labels=new_classes)

# search
rs = RandomizedSearchCV(crf, params_space,
                        cv=3,
                        verbose=1,
                        n_jobs=-1,
                        n_iter=50,
                        scoring=f1_scorer)
rs.fit(X_train, y_train)


# In[41]:


print('best params:', rs.best_params_)
print('best CV score:', rs.best_score_)
print('model size: {:0.2f}M'.format(rs.best_estimator_.size_ / 1000000))


# In[45]:


crf = rs.best_estimator_
y_pred = crf.predict(X_test)
print(metrics.flat_classification_report(y_test, y_pred, labels=new_classes))


# In[46]:


from collections import Counter

def print_transitions(trans_features):
    for (label_from, label_to), weight in trans_features:
        print("%-6s -> %-7s %0.6f" % (label_from, label_to, weight))

print("Top likely transitions:")
print_transitions(Counter(crf.transition_features_).most_common(20))

print("\nTop unlikely transitions:")
print_transitions(Counter(crf.transition_features_).most_common()[-20:])


# It is very likely that the beginning of a geographical entity (B-geo) will be followed by a token inside geographical entity (I-geo), but transitions to inside of an organization name (I-org) from tokens with other labels are penalized hugely.

# In[47]:


def print_state_features(state_features):
    for (attr, label), weight in state_features:
        print("%0.6f %-8s %s" % (weight, label, attr))

print("Top positive:")
print_state_features(Counter(crf.state_features_).most_common(30))

print("\nTop negative:")
print_state_features(Counter(crf.state_features_).most_common()[-30:])


# Observations: 
# 
# 1). __```5.183603 B-tim word[-3]:day```__
# The model learns that if a nearby word was “day” then the token is likely a part of a Time indicator.
# 
# 2). __```3.370614 B-per word.lower():president```__
# The model learns that token "president" is likely to be at the beginning of a person name.
# 
# 3). __```-3.521244 O postag:NNP```__
# The model learns that proper nouns are often entities.
# 
# 4). __```-3.087828 O word.isdigit()```__
# Digits are likely entities.
# 
# 5). __```-3.233526 O word.istitle()```__
# TitleCased words are likely entities.

# ### ELI5

# ELI5 is a Python package which helps to debug machine learning classifiers and explain their predictions. ELI5 allows to check weights of sklearn_crfsuite.CRF models.

# In[52]:


import eli5

eli5.show_weights(crf, top=10)


# It does make sense that I-entity must follow B-entity, such as I-geo follows B-geo, I-org follows B-org, I-per follows B-per, and so on. 
# 
# We can also see that it is not common in this dataset to have a person right after an organization name (B-org -> I-per has a large negative weight).

# If we regularize CRF more, we can expect that only features which are generic will remain, and memoized tokens will go. Let’s check what effect does regularization have on CRF weights:

# In[54]:


crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    c1=200,
    c2=0.1,
    max_iterations=20,
    all_possible_transitions=False,
)
crf.fit(X_train, y_train)
eli5.show_weights(crf, top=10)


# In[55]:


crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    c1=0.1,
    c2=0.1,
    max_iterations=100,
    all_possible_transitions=True,
)
crf.fit(X_train, y_train);
eli5.show_weights(crf, top=5, show=['transition_features'])


# The model learned large negative weights for impossible transitions like O -> I-geo, O -> I-org and O -> I-tim, and so on.

# In order to easy to read, we can check only a subset of tags.

# In[58]:


eli5.show_weights(crf, top=10, targets=['O', 'B-org', 'I-per'])


# Or check only some of the features for all tags.

# In[59]:


eli5.show_weights(crf, top=10, feature_re='^word\.is',
                  horizontal_layout=False, show=['targets'])

