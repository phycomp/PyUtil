fin=open('demoXJS2.md')
CHN=[]
def rtrvJS():
  for line in fin:
    line=line[:-1]
    if not line:continue
    _, chn=line.split()
    if not CHN.count(chn):CHN.append(chn)
    else:print(chn)
rtrvJS()
