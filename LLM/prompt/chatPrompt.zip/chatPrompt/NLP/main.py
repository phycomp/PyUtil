#!/usr/bin/env python
# coding: utf-8

# <a href="https://colab.research.google.com/github/raquibaS/Sentiment-Analysis/blob/main/main.ipynb" target="_parent"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/></a>

# # Steps to finetune a model:
# 1. Load the dataset
# 2. Preprocess:
#     a) define tokenizer
#     b) map tokenizer with the dataset
#     c) Padding the data with Datacollator
# 3. Fine Tune:
#     a) Define the model (Load pretrained model from Huggingface)
#     b) Define training hyper parameters
#     c) Pass the training arguments to Trainer along with model, dataset, tokenizer and data collator
#     d) Call train() to fine tune the model
# 

# Important Sources that I followed:
# 1. Exploratory Data Analysis: https://medium.com/m2mtechconnect/detecting-headline-sarcasm-with-machine-learning-4c3523104cdf#d58f

# ## Install transformers and other things

# In[138]:


#!pip install -U transformers


# In[139]:


get_ipython().system('pip install transformers')


# In[140]:


get_ipython().system('pip install pyyaml')


# In[141]:


get_ipython().system('pip install numpy')


# In[142]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split


# ## Load the dataset

# In[143]:


get_ipython().system('pip install datasets')


# In[144]:


#!pip install folium==0.2.1


# ## Activate GPU

# In[145]:


# Checking if GPU and NVIDIA are available
get_ipython().system('nvidia-smi')


# ### Specifying CUDA as the device for torch

# In[146]:


import torch

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
device


# In[147]:


n_gpu = torch.cuda.device_count()
torch.cuda.get_device_name(0)


# ## Initialize dataset

# In[148]:


df = pd.read_json(r'Sarcasm_Headlines_Dataset_v2.json', lines=True)
df = df.drop(['article_link'], axis=1)
df.head()


# In[149]:


df = df.rename(columns={'is_sarcastic':'label', 'headline':'text'})


# In[150]:


df


# In[151]:


first_column = df.pop('text')
df.insert(0,'text',first_column)


# In[152]:


df.head()


# In[153]:


#Now we can take a look at the full text of the first few headlines:\

for i in range(0, 5):
    print(df.iloc[i]["text"], '\n')


# ## Exploratory Data Analysis

# In[154]:


df.label.value_counts()


# In[155]:


df.text.value_counts()


# In[156]:


df.info()


# In[157]:


df.label.dtypes


# In[158]:


df.text.dtypes


# We have 26709 samples and no missing values in this dataset.
# For further analysis, group our dataset by class:

# In[159]:


groups = df.groupby('label')


# In[160]:


groups.get_group(0)


# In[161]:


groups.get_group(1)


# We can check the number of samples per class:

# In[162]:


num_sarcastic = len(groups.get_group(1))
num_nonsarcastic = len(groups.get_group(0))


# In[163]:


print("Total number of sarcastic samples:", num_sarcastic)
print("Total number of nonsarcastic samples:", num_nonsarcastic)


# Now we can check the number of samples per class:

# In[164]:


def get_median_num_words(df):
    """Returns the median number of words in headline per row given dataframe

    # Arguments
        df: dataframe, contains headlines and their labels
    
    # Returns
        int, median number of words per headline
    """
    num_words = [len(s.split()) for s in df.text]
    return np.median(num_words)

# median number of words per sample
num_words_sarcastic = get_median_num_words(groups.get_group(1))
num_words_nonsarcastic = get_median_num_words(groups.get_group(0))
print("Average number of words in sarcastic sentences:",num_words_sarcastic)
print("Average number of words in nonsarcastic sentences:", num_words_nonsarcastic)


# We have 11724 sarcastic samples and 14985 nonsarcastic samples. There is a slight class imbalance, but it’s small enough that I’ll ignore it for this project. As for the median number of words per headline, it is 10 for both classes.
# Here are the plots of the sample length distribution for both sarcastic and nonsarcastic headlines:

# In[165]:


def plot_sample_len_distribution(df):
    """Plots the headline length distribution
    # Arguments
        df: dataframe, contains headlines and their labels
    """
    plt.hist([len(s) for s in df.text],bins=50)
    plt.xlabel('sample length')
    plt.ylabel('Number of samples')
    plt.title('Sample length distribution')
    plt.show()


# Plots the headline length distribution for sarcastic headline

# In[166]:


# Plots the headline length distribution for sarcastic headline
plot_sample_len_distribution(groups.get_group(1))


# Plots the headline length distribution for nonsarcastic headline

# In[167]:


# Plots the headline length distribution for nonsarcastic headline
plot_sample_len_distribution(groups.get_group(0))


# ### Pretraining

# Split the train and test data

# In[168]:


from sklearn.model_selection import train_test_split
train, test = train_test_split(df, test_size=0.2)


# In[169]:


train


# In[170]:


train.dtypes


# In[171]:


#train["label"] = train["label"].apply(lambda x: map(int, x))


# In[172]:


train.info


# In[173]:


#Convert the data from pandas dataset
from datasets import Dataset
train_data = Dataset.from_pandas(train, preserve_index=False) # To remove __index_level_0__ column, this column was causing Key_Error
test_data = Dataset.from_pandas(test, preserve_index=False) # To remove __index_level_0__ column, this column was causing Key_Error


# In[174]:


# show the value of train data
train_data


# In[175]:


# show the value of test data
test_data


# In[176]:


train_data[0]


# In[177]:


test_data[0]


# In[178]:


#train_data = train_data.shuffle(seed=42).select([i for i in list(range(3000))])


# In[179]:


train_data


# In[180]:


#test_data = test_data.shuffle(seed=42).select([i for i in list(range(3000))])


# In[181]:


test_data


# Load DistilBERT tokenizer to process the text field:

# In[182]:


from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased", padding=True, truncation=True, max_length=128)


# Create a preprocessing function to tokenize text and truncate sequences to be no longer than DistilBERT’s maximum input length:

# In[183]:


#def preprocess_function(examples):
    #tokenized_batch = PreTrainedTokenizerFast(examples['text'], padding=True, truncation=True, max_length=128)
    #tokenized_batch["label"] = [str_to_int[label] for label in examples["label"]]
    #return tokenized_batch
def preprocess_function(examples):
    return tokenizer(examples["text"])
    #return tokenizer(examples["text"], padding=True, truncation=True, max_length=128)


# In[184]:


tokenized_train = train_data.map(preprocess_function, batched = True)


# In[185]:


tokenized_test = test_data.map(preprocess_function, batched = True)


# Use DataCollatorWithPadding to create a batch of examples. It will also dynamically pad text to the length of the longest element in its batch, so they are a uniform length. While it is possible to pad the text in the tokenizer function by setting padding=True, dynamic padding is more efficient.

# ## Fine-tune with Trainer

# In[186]:


# Load DistilBERT with AutoModelForSequenceClassification along with the number of expected labels:
from transformers import AutoConfig, AutoModel, BertForSequenceClassification
from transformers import AutoModelForSequenceClassification, TrainingArguments, Trainer, AutoModel

model_config = AutoConfig.from_pretrained('distilbert-base-uncased', output_hidden_states=True)
model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased", config=model_config)

#model = AutoModel.from_pretrained("distilbert-base-uncased", config=model_config)
#model = BertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)
#model = AutoConfig.from_pretrained("distilbert-base-uncased")


# In[187]:


from transformers import DataCollatorWithPadding
from transformers import DataCollatorForSeq2Seq, DataCollatorForTokenClassification
data_collator=DataCollatorWithPadding(tokenizer=tokenizer)
#data_collator=DataCollatorWithPadding(tokenizer=tokenizer, padding= True, return_tensors="pt")
#data_collator=DataCollatorWithPadding(tokenizer=tokenizer, padding= True, return_tensors="tf")
#data_collator=DataCollatorForTokenClassification(tokenizer=tokenizer, padding= True, return_tensors="pt")
#data_collator=DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model, return_tensors="tf")


# At this point, only three steps remain:
# 
# 1. Define your training hyperparameters in TrainingArguments.
# 2. Pass the training arguments to Trainer along with the model, dataset, tokenizer, and data collator.
# 3. Call train() to fine-tune your model.

# In[188]:


tokenized_train


# In[189]:


tokenized_test


# In[190]:


tokenized_train[0]


# In[191]:


tokenized_test[0]


# ### Metrics

# In[192]:


import numpy as np
from datasets import load_metric


# In[193]:


def compute_metrics(eval_pred):
    load_accuracy = load_metric("accuracy")
    load_f1 = load_metric("f1")
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)
    accuracy = load_accuracy.compute(predictions=predictions, references=labels)["accuracy"]
    f1 = load_f1.compute(predictions=predictions, references=labels)["f1"]
    return {"accuracy": accuracy, "f1": f1}


# In[194]:


tokenizer


# In[195]:


#Converting dictonary to tensor????

def str_to_list(data):
    # a temporary list to store the string labels
    temp_list=data["text"].list()

    # dictionary that maps integer to its string value
    label_dict = {}

    #list to store integer labels
    int_labels = []

    for i in range(len(temp_list)):
        label_dict[i] = temp_list[i]
        int_labels.append(i)


# In[196]:


tokenized_train


# In[197]:


training_args= TrainingArguments(
    output_dir = "./results",
    learning_rate = 2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs = 5,
    weight_decay = 0.01,
    evaluation_strategy="epoch",
    remove_unused_columns = False,
    optim="adamw_torch"
)
trainer = Trainer(
    model = model,
    args = training_args,
    train_dataset = tokenized_train,
    eval_dataset = tokenized_test,
    tokenizer=tokenizer,
    data_collator=data_collator,
    compute_metrics=compute_metrics,
)

trainer.train()


# In[ ]:





# In[ ]:


for batch in trainer.get_train_dataloader():
    break
batch = {k: v.cuda() for k, v in batch.items()}
outputs = trainer.model(**batch)


# In[ ]:


for batch in trainer.get_train_dataloader():
    print({k: v.shape for k, v in batch.items()})


# In[ ]:


outputs = trainer.model(**batch)
print(outputs)


# ##Pipeline

# In[ ]:


from transformers import pipeline


# In[ ]:


sentiment_analysis = pipeline("sentiment-analysis")

