#!/usr/bin/env python
# coding: utf-8

# In[1]:


from google.colab import drive
drive.mount('/content/drive')


# ### 1) Install Dependencies & Import Them

# In[2]:


get_ipython().system('python -m spacy download en')


# In[3]:


get_ipython().system('pip install bs4')


# In[4]:


get_ipython().system('pip install pandas')


# In[5]:


import re
import csv
import pandas as pd
import bs4
import requests
import spacy
from spacy import displacy
nlp = spacy.load('en_core_web_sm')

from spacy.matcher import Matcher 
from spacy.tokens import Span 

import urllib.request 
from bs4 import BeautifulSoup

import networkx as nx

import matplotlib.pyplot as plt
from tqdm import tqdm

pd.set_option('display.max_colwidth', 200)
get_ipython().run_line_magic('matplotlib', 'inline')


# ### 2) Parse Texts from a Web Article

# In[ ]:


# indicate address for chosen URL
url = "https://www.rigzone.com/news/what_could_omicron_cost_global_oil_market-03-dec-2021-167199-article"


# In[ ]:


# open the URL for reading
html = urllib.request.urlopen(url)


# In[ ]:


# parsing the html file
htmlParse = BeautifulSoup(html, 'html.parser')


# In[ ]:


#this variable shows all the attributes from the site
htmlParse


# In[ ]:


# getting only the text paragraphs (ie: excluding colors, position, images, etc)
for para in htmlParse.find_all("p"):
    print(para.get_text())


# In[ ]:


#store the text paragraphs into a variable
parsed_text_list = []

for para in htmlParse.find_all("p"):
    parsed_text_list.append(para.get_text())


# In[ ]:


#display data
parsed_text_list


# In[ ]:


#store the text paragraphs into a variable
#parsed_text_str = ""
parsed_text = ""

for para in htmlParse.find_all("p"):
    #parsed_text_str += str(para.get_text())
    parsed_text = " ".join((parsed_text, str(para.get_text())))


# In[ ]:


parsed_text


# ### 3) Convert the Text into Sentences & save in CSV format

# In[ ]:


for i in nlp(parsed_text).sents:
    print([i])


# In[ ]:


sentences = [[i] for i in nlp(parsed_text).sents]


# In[ ]:


sentences


# In[ ]:


import csv
myheaders = ['sentence']
myvalues = sentences
filename = 'article_text.csv'
with open(filename, 'w',newline='') as myfile:
    writer = csv.writer(myfile)
    writer.writerow(myheaders)
    writer.writerows(myvalues)


# Good reference for saving data to CSV: https://www.easytweaks.com/write-list-csv-python/

# Data cleaning was done manually by downloading the CSV file and delete the empty columns

# ### 4) Re-Import Cleaned Data

# In[7]:


csv_sentences = pd.read_csv("/content/drive/MyDrive/NLPstuffs/article_text_clean.csv")


# In[ ]:


csv_sentences


# In[9]:


csv_sentences.shape


# In[10]:


csv_sentences['sentence'].sample(5)


# ### 5) Sentence Segmentation

# In[12]:


doc = nlp("My name is Hami.")

for tok in doc:
  print(tok.text, "...", tok.dep_)


# In[13]:


def get_entities(sent):
  ## chunk 1
  ent1 = ""
  ent2 = ""

  prv_tok_dep = ""    # dependency tag of previous token in the sentence
  prv_tok_text = ""   # previous token in the sentence

  prefix = ""
  modifier = ""

  #############################################################
  
  for tok in nlp(sent):
    ## chunk 2
    # if token is a punctuation mark then move on to the next token
    if tok.dep_ != "punct":
      # check: token is a compound word or not
      if tok.dep_ == "compound":
        prefix = tok.text
        # if the previous word was also a 'compound' then add the current word to it
        if prv_tok_dep == "compound":
          prefix = prv_tok_text + " "+ tok.text
      
      # check: token is a modifier or not
      if tok.dep_.endswith("mod") == True:
        modifier = tok.text
        # if the previous word was also a 'compound' then add the current word to it
        if prv_tok_dep == "compound":
          modifier = prv_tok_text + " "+ tok.text
      
      ## chunk 3
      if tok.dep_.find("subj") == True:
        ent1 = modifier +" "+ prefix + " "+ tok.text
        prefix = ""
        modifier = ""
        prv_tok_dep = ""
        prv_tok_text = ""      

      ## chunk 4
      if tok.dep_.find("obj") == True:
        ent2 = modifier +" "+ prefix +" "+ tok.text
        
      ## chunk 5  
      # update variables
      prv_tok_dep = tok.dep_
      prv_tok_text = tok.text
  #############################################################

  return [ent1.strip(), ent2.strip()]


# In[14]:


get_entities("the film had 200 patents")


# In[16]:


get_entities("Hami is a friend of Haziq.")


# In[19]:


entity_pairs = []

for i in tqdm(csv_sentences["sentence"]):
  entity_pairs.append(get_entities(i))


# In[20]:


entity_pairs[10:20]


# In[21]:


def get_relation(sent):

  doc = nlp(sent)

  # Matcher class object 
  matcher = Matcher(nlp.vocab)

  #define the pattern 
  pattern = [{'DEP':'ROOT'}, 
            {'DEP':'prep','OP':"?"},
            {'DEP':'agent','OP':"?"},  
            {'POS':'ADJ','OP':"?"}] 

  matcher.add("matching_1",[pattern]) 

  matches = matcher(doc)
  k = len(matches) - 1

  span = doc[matches[k][1]:matches[k][2]] 

  return(span.text)


# In[23]:


get_relation("Hami created this file")


# In[25]:


relations = [get_relation(i) for i in tqdm(csv_sentences['sentence'])]


# In[26]:


pd.Series(relations).value_counts()[:50]


# In[27]:


# extract subject
source = [i[0] for i in entity_pairs]

# extract object
target = [i[1] for i in entity_pairs]

kg_df = pd.DataFrame({'source':source, 'target':target, 'edge':relations})


# In[28]:


# create a directed-graph from a dataframe
G=nx.from_pandas_edgelist(kg_df, "source", "target", 
                          edge_attr=True, create_using=nx.MultiDiGraph())


# In[29]:


plt.figure(figsize=(12,12))

pos = nx.spring_layout(G)
nx.draw(G, with_labels=True, node_color='skyblue', edge_cmap=plt.cm.Blues, pos = pos)
plt.show()


# In[ ]:





# In[30]:


G=nx.from_pandas_edgelist(kg_df[kg_df['edge']=="composed by"], "source", "target", 
                          edge_attr=True, create_using=nx.MultiDiGraph())

plt.figure(figsize=(12,12))
pos = nx.spring_layout(G, k = 0.5) # k regulates the distance between nodes
nx.draw(G, with_labels=True, node_color='skyblue', node_size=1500, edge_cmap=plt.cm.Blues, pos = pos)
plt.show()


# In[31]:


G=nx.from_pandas_edgelist(kg_df[kg_df['edge']=="written by"], "source", "target", 
                          edge_attr=True, create_using=nx.MultiDiGraph())

plt.figure(figsize=(12,12))
pos = nx.spring_layout(G, k = 0.5)
nx.draw(G, with_labels=True, node_color='skyblue', node_size=1500, edge_cmap=plt.cm.Blues, pos = pos)
plt.show()

