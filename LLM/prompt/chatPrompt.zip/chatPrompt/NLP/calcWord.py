from streamlit import code as stCode
def calcLen(dsetDF):
  dsetWord=dsetDF.split()
  stCode(['dsetWord=', dsetWord, len(dsetWord), len(dsetDF)])
  sum=0
  for idiom in dsetWord:
    sum+=len(idiom)
  avgLen=sum/len(dsetWord)
  return round(avgLen)

