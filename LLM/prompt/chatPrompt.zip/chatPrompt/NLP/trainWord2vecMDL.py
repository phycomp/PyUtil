class SentenceIterator:
    def __init__(self, filepath):
        self.filepath = filepath
    def __iter__(self):
        for line in open(self.filepath):
            yield line.split()

# training the model
sentences = SentenceIterator('/content/drive/MyDrive/rousseau/rousseau_corpus.txt')
model = gensim.models.Word2Vec(sentences, min_count=2) # min_count is for pruning the internal dictionary. Words that appear only once in the corpus are probably uninteresting typos and garbage. In addition, there’s not enough data to make any meaningful training on those words, so it’s best to ignore them
