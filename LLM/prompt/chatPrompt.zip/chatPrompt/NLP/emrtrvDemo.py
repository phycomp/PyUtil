#-*- coding:utf-8 -*
from django.shortcuts import render
from django.db.models import Q
from django.http import JsonResponse, HttpResponse
from django.views import View
from django.template import loader
from django.template.response import TemplateResponse
from django.views.generic import ListView
from django.core.paginator import Paginator
from codeTmpl.models import TechwikiMnpltn
from spacy import load as spcyLoad, displacy
#from django.db.models.expressions import RawSQL

def subSent(sent, subInfos): 
	clnSent=sent 
	for subInfo in subInfos: 
		startPos, endPos, ori, TAG=subInfo#(152, 159, PEG-ELS, 'SIMPLE_CHEMICAL') 
		sent=sent.replace(clnSent[startPos:endPos], f'<mark>{ori}<b>{TAG}</b></mark>') 
	return sent

class EmrParse(View):
	def get(self, request, eid=None):
		fullQuery=f'select * from "PolypRprt" where id={eid};'
        from spacy import load as spcyLoad
        NLP=spcyLoad('en_ner_bionlp13cg_md')
		NLP=spcyLoad('med7')
		emrInfo=TechwikiMnpltn.tchwkQuery.TchwkRawSql('SELECT', fullQuery)[0]
		#medInfo=' '.join(emrInfo[1].split())
		#medParse=NLP(medInfo)
		medParse=NLP(emrInfo[1])
		#for sent in medParse.sents:print(sent.text)
		newSent=''
		for sent in medParse.sents: 
			if sent.ents:
					entInfo=[]
					for ent in sent.ents:
						rawText, sentText=ent.text, sent.text
						startPos=sentText.find(rawText)
						endPos=startPos+len(rawText)
						#entInfo.append((startPos, endPos, ent.label_))
						entInfo.append((startPos, endPos, ent, ent.label_))
					newSent+=subSent(sent.text, entInfo)
					print([sent.text, {'entities':entInfo}])	#startPos, endPos, ent)
			else: newSent+=sent.text
		print(newSent)
		emrCntnt='<div name=medNER>'+newSent+'</div>'
		#emrCntnt=displacy.render(style='ent', jupyter=False)
		#emrCntnt=emrCntnt.replace('</br>', '&nbsp;')
		#emrCntnt=emrCntnt.replace('line-height: 2.5; ', '')
		return render(request, 'emr-parse.html', {'emrInfo':emrCntnt})

class EmrDetail(View):
	def post(self, request, tid=None):
		emrInfo=eval(request.body)
		emrData=emrInfo['emrData']
		NLP=spcyLoad('en_ner_bionlp13cg_md')
        #EMR, NLP=[], spcyLoad('en_core_med7_lg')
		#EMR, NLP=[], spcyLoad('en_core_med7_lg')
		#for id, emr, annotation in emrInfo:
		emrCntnt=displacy.render(NLP(emrData), style='ent', jupyter=False)
		#emrCntnt=emrCntnt.replace('</br>', '')
		#EMR.append(emrCntnt)
		tmpl=loader.get_template('emr-detail.html')
		ctx=tmpl.render({'emrInfo':emrCntnt}, request)
		print(ctx)
		return JsonResponse({'tchwkInfo':ctx})

class EmrRtrv(View):
	def get(self, request, *args, **kwargs):
		fullQuery='select * from "PolypRprt" limit 10;'
		emrInfo=TechwikiMnpltn.tchwkQuery.TchwkRawSql('SELECT', fullQuery)
		#print(ctx)
		return render(request, 'emr-rtrv.html', {'emrInfo':emrInfo})

class showICD9(View):
	def get(self, request, *args, **kwargs):
			curr_file = abspath(dirname(__file__)) #older/folder2/scripts_folder
			csv_fname = path_join(curr_file, 'copoRprtAnn.csv')	#sdate, num_of_report, num_of_people
			df = read_csv(csv_fname)
			df = df.rename(columns={'sdate': 'SDATE', 'count.1': 'No.Report'})
			nlarge = 20
			x = range(1, nlarge+1)
			fig = figure(figsize=[20, 10])
			df1 = df.sort_values(by=['count'], ascending=False).nlargest(nlarge,'count')
			bar(x, df1['count'])
			ax = gca()
			ax.set_xlabel('SDATE')
			ax.set_ylabel('No. of Reports')
			ax.set_title('2010 - 2018')
			ax.set_xticks(x)
			xticks(rotation='vertical')
			ax.set_xticklabels(df1['sdate'])
			buffer=BytesIO()
			savefig(buffer)
			return HttpResponse(buffer.getvalue(), content_type='image/png')

class CopoCopa(View):
	def post(self, request):
		#tid=eval(request.body)
		rqstPst=request.POST
		APP_PRIVATE_ID, APP_PRIVATE_PASSWD, PUBLIC_APP_USER_SSO_TOKEN=rqstPst['APP_PRIVATE_ID'], rqstPst['APP_PRIVATE_PASSWD'], rqstPst.get('PUBLIC_APP_USER_SSO_TOKEN')
		#APP_PRIVATE_ID, APP_PRIVATE_PASSWD='09332346210e42a59eebf906054c810c', '866ccc10e0024acbba081d5043e628d7'
		jsonData=dict(APP_PRIVATE_ID=APP_PRIVATE_ID, APP_PRIVATE_PASSWD=APP_PRIVATE_PASSWD, PUBLIC_APP_USER_SSO_TOKEN=PUBLIC_APP_USER_SSO_TOKEN)
		response=requests.post('https://eiptest-api.vghtpe.gov.tw/vghtpe/get_login_user_info/', json=jsonData, verify=False)

		ctx=response.content.decode('utf8')
		ctx=eval(ctx).get('VGHTPE_USER_PROFILE')	#
		print(ctx.keys())	#{"APP_USER_LOGIN_ID": "ISC8381A", "APP_USER_EMPNO": "029333", "APP_USER_CHT_NAME": "\u5442\u4fca\u8208", "APP_USER_EMAIL": "chlu10@vghtpe.gov.tw", "APP_USER_TITLE": "", "APP_USER_STATUS": 1}
		#'ERROR_CODE', 'VGHTPE_USER_AUTH', 'VGHTPE_SRC_ADDRESS_NET_OBJECT_LIST', 'VGHTPE_USER_NODE', 'VGHTPE_USER_PROFILE', 'VGHTPE_DEPT_PROFILE_LIST', 'VGHTPE_VUSRNID_INFO_LIST
		#tchwk=TechwikiMnpltn.tchwkQuery.get(id=tid)
		#tmpl=loader.get_template('techwiki-detail.html')
		#ctx=tmpl.render({'tchwk':tchwk}, request)
		return JsonResponse({'rspData':ctx})

class ShowCookies(View):
	def get(self, request, key=None):
		return HttpResponse(request.COOKIES)
		#PUBLIC_APP_USER_SSO_TOKEN
		if key in request.COOKIES: 
			return HttpResponse('%s:%s' % (key,request.COOKIES[key]))
		else:
			return HttpResponse('Cookie 不存在!')

class TchwkModal(View):
	def post(self, request):
		tid=eval(request.body)
		#tchwk=TechwikiMnpltn.tchwkQuery.get(id=tid)
		fullQuery='select * from "BDC_TECH"."BDCRCOPO" where chartid=%s::varchar;'%tid
		tchwk=TechwikiMnpltn.tchwkQuery.TchwkRawSql('SELECT', fullQuery)[0]
		tmpl=loader.get_template('techwiki-detail.html')
		ctx=tmpl.render({'tchwk':tchwk}, request)
		return JsonResponse({'tchwk貼了':True, 'tchwkInfo':ctx})

class TechwikiDetail(View):
	def post(self, request):
		tid=eval(request.body)
		#tchwk=TechwikiMnpltn.tchwkQuery.get(id=tid)
		fullQuery='select * from "BDC_TECH"."BDCRCOPO" where chartid=%s::varchar;'%tid
		tchwk=TechwikiMnpltn.tchwkQuery.TchwkRawSql('SELECT', fullQuery)[0]
		tmpl=loader.get_template('techwiki-detail.html')
		ctx=tmpl.render({'tchwk':tchwk}, request)
		return JsonResponse({'tchwk貼了':True, 'tchwkInfo':ctx})

class TechWiki(ListView):
	#model=TechwikiMnpltn
	#paginate_by=10
	def get(self, request):
		tchwkList=TechwikiMnpltn.tchwkQuery.all()
		paginator = Paginator(tchwkList, 64) # Show 25 contacts per page.
		page_number = request.GET.get('page')
		tchwks = paginator.get_page(page_number)
		return render(request, 'all-techwiki.html', {'tchwks':tchwks})

class CopoCopa(View):
	def post(self, request):
		keyword=request.body.decode('utf-8')
		#if ' or 'in keyword.lower(): searchPttrn='or'
		#keyword=SearchQuery(request.POST)
		#qs=TechwikiMnpltn.objects.filter(內容__search=keyword)
		#"""select f.* from(SELECT "comboValue" u FROM mdctn."rsltTmpl3" where 內容@?%s or "comboValue"@?%s)f ;"""%(, keyword)
		fullQuery="""select * from "BDC_TECH"."BDCRCOPO" where to_tsvector(report)@@to_tsquery('%s');"""%(keyword)
		querySet=sync_to_async(TechwikiMnpltn.tchwkQuery.TchwkRawSql('SELECT', fullQuery))
		querySet.get_current_task()
		#qs = JavaScript.objects.filter(javascript內容=keyword)
		queryRslt=querySet.func
		#titleVector = SearchVector('主旨')
		#contentVector = SearchVector('javascript內容')
		#totalVectors=titleVector+contentVector
		#kws=keyword.split()
		#qs = qs.annotate(search=SearchVector(kws)).filter(search=kws[0])
		#qs=JavaScript.objects.annotate(search=SearchVector('javascript內容')).filter(search='postgres');len(qs)
		#Entry.objects.annotate(search=SearchVector('body_text', 'blog__tagline')).filter(search='Cheese')
		#qs = qs.annotate(rank=SearchRank(searchVectors, query)).order_by('-rank')
		#startDate, endDate, symbol=rqstPst['startDate'], rqstPst['endDate'], rqstPst['symbol']
		#symblEndDateQuery="""'$.%s[*].lastDate?(@<="%s")'"""%(symbol, endDate)
		#symblStartDateQuery="""'$.%s[*].firstDate?(@>="%s")'"""%(symbol, startDate)
		#qSymblDrtn=ComboValue.jsonQuery.ComboValueRawSql('SELECT',fullQuery)
		#print(qSymblDrtn)
		#totalQuery=len(qSymblDrtn)
		if queryRslt:
			tmpl=loader.get_template('search-template.html')
			ctx=tmpl.render({'qs':queryRslt}, request)
		else: ctx=None
		#print(ctx)
		#ctx=ctx.replace('\n','<br>')
		return JsonResponse(dict(srch完成=True, srchInfo=ctx))

class AppTemplate(View):
	def post(self, request):
		appTmpl=[]
		APPs=request.POST.getlist('app')
		for app in APPs:
			app=app.lower()
			tmplInfo=AppTmpl.get(app)
			appTmpl.append(tmplInfo)
		allTmpl='\n\n'.join(appTmpl)
		#commentblog=CommentBlog.objects.get(id=selvID)
		#commentblogBody=commentblog.body
		return JsonResponse(dict(app貼了=True, appTmpl=allTmpl))
