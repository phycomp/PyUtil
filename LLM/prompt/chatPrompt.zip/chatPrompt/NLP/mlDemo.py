from sklearn.datasets import load_iris, make_classification
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
X, y = load_iris(return_X_y=True)
clf = SVC(random_state=0)
cross_val_score(clf, X, y, cv=5, scoring='recall_macro')
from sklearn.metrics import fbeta_score, make_scorer
ftwo_scorer = make_scorer(fbeta_score, beta=2)
from sklearn.model_selection import GridSearchCV
from sklearn.svm import LinearSVC
grid = GridSearchCV(LinearSVC(dual="auto"), param_grid={'C': [1, 10]}, scoring=ftwo_scorer, cv=5)

from numpy import abs as npAbs, log1p as npLog1p
def lossCallback(y_true, y_pred):
    diff = npAbs(y_true - y_pred).max()
    return npLog1p(diff)
# score will negate the return value of my_custom_loss_func,
# which will be np.log(2), 0.693, given the values for X
# and y defined below.
score = make_scorer(lossCallback, greater_is_better=False)
X = [[1], [1]]
y = [0, 1]
from sklearn.dummy import DummyClassifier
clf = DummyClassifier(strategy='most_frequent', random_state=0)
clf = clf.fit(X, y)
lossCallback(y, clf.predict(X))
score(clf, X, y)

from sklearn.model_selection import cross_validate
from sklearn.metrics import confusion_matrix
# A sample toy binary classification dataset
X, y = make_classification(n_classes=2, random_state=0)
svm = LinearSVC(dual="auto", random_state=0)
def confusion_matrix_scorer(clf, X, y):
  y_pred = clf.predict(X)
  cm = confusion_matrix(y, y_pred)
  return {'tn': cm[0, 0], 'fp': cm[0, 1], 'fn': cm[1, 0], 'tp': cm[1, 1]}
cv_results = cross_validate(svm, X, y, cv=5, scoring=confusion_matrix_scorer)
# Getting the test set true positive scores
print(cv_results['test_tp'])
# Getting the test set false negative scores
print(cv_results['test_fn'])

import numpy as np
from sklearn.metrics import accuracy_score
y_pred = [0, 2, 1, 3]
y_true = [0, 1, 2, 3]
accuracy_score(y_true, y_pred)
accuracy_score(y_true, y_pred, normalize=False)


from numpy import array as npArray
from sklearn.metrics import top_k_accuracy_score
y_true = npArray([0, 1, 2, 2])
y_score = npArray([[0.5, 0.2, 0.2], [0.3, 0.4, 0.2], [0.2, 0.4, 0.3], [0.7, 0.2, 0.1]])
top_k_accuracy_score(y_true, y_score, k=2)
# Not normalizing gives the number of "correctly" classified samples
top_k_accuracy_score(y_true, y_score, k=2, normalize=False)


from sklearn import metrics
y_pred = [0, 1, 0, 0]
y_true = [0, 1, 0, 1]
metrics.precision_score(y_true, y_pred)
metrics.recall_score(y_true, y_pred)
metrics.f1_score(y_true, y_pred)
metrics.fbeta_score(y_true, y_pred, beta=0.5)
metrics.fbeta_score(y_true, y_pred, beta=1)
metrics.fbeta_score(y_true, y_pred, beta=2)
metrics.precision_recall_fscore_support(y_true, y_pred, beta=0.5)


from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
y_true = npArray([0, 0, 1, 1])
y_scores = npArray([0.1, 0.4, 0.35, 0.8])
precision, recall, threshold = precision_recall_curve(y_true, y_scores)
average_precision_score(y_true, y_scores)


from sklearn metrics import precision_score, recall_score, f1_score, fbeta_score, precision_recall_fscore_support
y_true = [0, 1, 2, 0, 1, 2]
y_pred = [0, 2, 1, 0, 0, 1]
precision_score(y_true, y_pred, average='macro')
recall_score(y_true, y_pred, average='micro')
f1_score(y_true, y_pred, average='weighted')
fbeta_score(y_true, y_pred, average='macro', beta=0.5)
precision_recall_fscore_support(y_true, y_pred, beta=0.5, average=None)

from numpy import array as np npArray
from sklearn.metrics import jaccard_score
y_true = npArray([[0, 1, 1], [1, 1, 0]])
y_pred = npArray([[1, 1, 1], [1, 0, 0]])
jaccard_score(y_true[0], y_pred[0])


from sklearn svm import LinearSVC
from sklearn.metrics import hinge_loss
X = [[0], [1]]
y = [-1, 1]
est = LinearSVC(dual="auto", random_state=0)
est.fit(X, y)
pred_decision = est.decision_function([[-2], [3], [0.5]])
hinge_loss([-1, 1, 1], pred_decision)
