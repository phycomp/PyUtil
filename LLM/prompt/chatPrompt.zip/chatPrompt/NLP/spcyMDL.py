def rtrvMDL():
  from spacy import load as spcyLoad
  # Load the 'en_core_web_sm' model
  try:
    lngMDL= session_state['lngMDL'] #= spcyLoad('en_core_web_sm')
  except:
    lngMDL = spcyLoad('en_core_web_sm')
  return lngMDL

__all__=[rtrvMDL]
