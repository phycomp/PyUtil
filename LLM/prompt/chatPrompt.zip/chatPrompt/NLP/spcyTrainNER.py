def train(self, label, n_iter=10, batch_size=50):
    # creating an optimizer and selecting a list of pipes NOT to train
    optimizer = self.nlp.create_optimizer()
    other_pipes = [pipe for pipe in self.nlp.pipe_names if pipe != 'ner']

    # adding a named entity label
    ner = self.nlp.get_pipe('ner')
    ner.add_label(label)

    with self.nlp.disable_pipes(*other_pipes):
        for itn in range(n_iter):
            random.shuffle(self.train_data)
            losses = {}

            # batch the examples and iterate over them
            for batch in spacy.util.minibatch(self.train_data, size=batch_size):
                for text, annotations in batch:
                    doc = nlp.make_doc(text)
                    example = Example.from_dict(doc, annotations)
                    nlp.update([example], drop=0.35, sgd=optimizer, losses=losses)
                print(losses)
    print("Final loss: ", losses)
