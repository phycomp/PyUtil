#!/usr/bin/env python
# coding: utf-8

# # New entities recogniser, annotatation with BILUO scheme, using spaCy
# 
#  * Use of pretrained Machine Learning (ML) model is quite prevalent in vision-related problems, where it is tuned for the desired task, nonetheless, last couple of years ([Peters et al.](https://www.aclweb.org/anthology/N18-1202/), [Akbik et al.](https://alanakbik.github.io/papers/coling2018.pdf)) has spurred the use of pretrained Natural Language Processing (NLP) models to do the same for NLP tasks. 
#  
#  * This notebook uses a pretrained [spaCy](https://spacy.io/models/en) model to train for user-specific entities in texts. 
#  
#  * Read [here](https://ruder.io/state-of-transfer-learning-in-nlp/) for the latest state of transfer learning in NLP.
#  
#  * The pretrained [model](https://spacy.io/models/en) used here is convolution neural network (CNN) architecture trained on [OneNotes](https://catalog.ldc.upenn.edu/LDC2013T19) 
#  
#  * The customised entity recogniser is trained on [BILUO](https://spacy.io/api/annotation#biluo) scheme. Note here that the BILUO scheme trains and performs better than IOB scheme. Read faq of [README](README.md) 
#  
#  * This is an extension with explanation for already provided [example](https://github.com/explosion/spaCy/blob/master/examples/training/train_new_entity_type.py) by spaCy.

# In[13]:


## Load a NLP model


# In[14]:


import spacy
import numpy as np
nlp = spacy.load('en') # or any other specific model like 'en_core_web_md' more at https://spacy.io/models/en


# ## Data Annotations
# 
#  * [Using BILUO scheme](#biluo)
#  * [Using offset indices](#offset)
#  * [Custom Doc](#customdoc)

# ### Using BILUO Scheme
# <a id='biluo'> </a>
# 
#  * Annotate your data using [BILUO](https://spacy.io/api/annotation#biluo) scheme where each token is from [doc](https://spacy.io/api) created with model
#  ```
#  text = 'Write your text here.'
#  doc = nlp(text)
#  
#  # for token in doc:
#  # write the token in a file for annotating it later 
#  ```
#  
#  * An example is provided [here](ner-token-per-line.biluo) 
#  
#  * This is less cumbersome process of annotating than offset indices- shown later.  
#  
# 

# In[15]:


# Gor reproducing same results during mutiple run
s = 999
np.random.seed(s)
spacy.util.fix_random_seed(s)

# if Training with GPU also
# cupy.random.seed(s)


# In[16]:


# Load the data from file

import pandas as pd
dpath = 'ner-token-per-line.biluo'
df = pd.read_csv(dpath, sep=',')
words  = df.word.values
ents = df.label.values
text = ' '.join(words)


# ### Add all the new annotations

# In[17]:


# Provide all the extra entity that the model should recognise beyond existing named-entities https://spacy.io/api/annotation#named-entities
add_ents = ['DATED'] # 

# Create a pipe if it does not exist
# Piplines in pretrained model: tagger, parser, ner create new if blank model is to be trained using `spacy.blank('en')`
if "ner" not in nlp.pipe_names:
    ner = nlp.create_pipe("ner") # "architecture": "ensemble" simple_cnn ensemble, bow # https://spacy.io/api/annotation
    nlp.add_pipe(ner)
else:
    ner = nlp.get_pipe("ner")

prev_ents = ner.move_names
print('[Existing Entities] = ', ner.move_names)

for ent in add_ents:
    ner.add_label(ent)
    
new_ents = ner.move_names
# print('\n[All Entities] = ', ner.move_names)

print('\n\n[New Entities] = ', list(set(new_ents) - set(prev_ents)))



# In[18]:


#### Create Dataset
from spacy.gold import GoldParse
doc = nlp.make_doc(text)
g = GoldParse(doc, entities=ents)

# Add examples as avaialble or needed
X = [doc, doc]
Y = [g, g]


# ### Training
# <a id='training'> </a>

# In[19]:


other_pipes = [pipe for pipe in nlp.pipe_names if pipe != "ner"]
print(f'[OtherPipes] = {other_pipes} will be disabled')


# In[20]:


model = None # Since we training a fresh model not a saved model
n_iter = 20
with nlp.disable_pipes(*other_pipes):  # only train ner
    # optimizer = nlp.begin_training()
    if model is None:
        optimizer = nlp.begin_training()
    else:
        optimizer = nlp.resume_training()
    for i in range(n_iter):
        losses = {}
        nlp.update(X, Y,  sgd=optimizer, drop=0.0, losses=losses)
        # nlp.entity.update(d, g)
        print("Losses", losses)


# In[21]:


test_text = ("When Sebastian Thrun started working on self-driving cars at "
        "Google in 2007, few people outside of the company took him "
        "seriously. “I can tell you very senior CEOs of major American "
        "car companies would shake my hand and turn away because I wasn’t "
        "worth talking to,” said Thrun, in an interview with Recode earlier "
        "this week.")
doc = nlp(test_text)
# print("[Entities] in '%s'" % test_text, '\n\n')
for ent in doc.ents:
    print(ent.text, ent.label_)


# ### Using Offset
# <a id='offset'> </a>
# 
#  * Training process is the same as the previous one except data creation is different.
#  * Here annotations are created using offset indices while the scheme is of course still BILUO.
#  * One can see that this is a bit clumsy to use, of course, still works.
#  * I can not make a claim which is better or has similar performance- as one needs to perform experiments to make any claim.

# In[22]:


# For one instance
text = ("When Sebastian Thrun started working on self-driving cars at "
        "Google in 2007, few people outside of the company took him "
        "seriously. “I can tell you very senior CEOs of major American "
        "car companies would shake my hand and turn away because I wasn’t "
        "worth talking to,” said Thrun, in an interview with Recode earlier "
        "this week.")
doc = text
g = {'entities': [(5, 20, 'PERSON'), (61, 67, 'ORG'), (71, 75, 'DATE'), (173, 181, 'NORP'), 
    (271, 276, 'PERSON'), (299, 305, 'ORG'), (306, 323, 'DATED')]}

X = [doc]
Y = [g]


# In[27]:


with nlp.disable_pipes(*other_pipes):  # only train ner
    # optimizer = nlp.begin_training()
    if model is None:
        optimizer = nlp.begin_training()
    else:
        optimizer = nlp.resume_training()
    for i in range(n_iter):
        losses = {}
        nlp.update(X, Y,  sgd=optimizer, drop=0.0, losses=losses) # Please do note here that model is overfit to show that it can learn
        # nlp.entity.update(d, g)
        print("Losses", losses)
doc = nlp(text)
for ent in doc.ents:
    print(ent.text, ent.label_)


# In[39]:


doc = nlp(text)
for ent in doc.ents:
    print(ent.text, ent.label_)


# ## [Visual Display](https://spacy.io/usage/visualizers#ent) 
# 

# In[40]:


from spacy import displacy


# In[44]:


displacy.render(doc, style="ent") # or displacy.serve(doc, style="ent") if not from jupyter notebook


# ### Custom Doc
# <a id='customdoc'> </a>
# 
#  * Typically tokens created by the nlp model splits not only by spaces but also by stop words and special characters. 
#  
#  * We might want to label each word (split only with spaces or something else) rather than for each token as generated by NLP model (`doc = nlp(text)`) then in such case we need to modify a bit.
#  
#  * Please note that while we can have custom doc but a token in the doc can not be space.
#  
#  * In my experiments I did not find this helpful, in fact, it was weaker than other two annotation process. 

# In[24]:


from spacy.tokens import Doc # https://spacy.io/api/doc

import pandas as pd
dpath = 'ner-token-per-line.biluo' # It not necessarily 
df = pd.read_csv(dpath, sep=',')
words  = df.word.values
ents = df.label.values
text = ' '.join(words)

spaces = [True]*len(words)
spaces[-1] = False # so remove space in last
doc = Doc(nlp.vocab, words=words, spaces=spaces) # Custom Doc
g = GoldParse(doc, entities=ents)

# 


# ### Note
#  * Read this paper by [Akbik et al.](https://alanakbik.github.io/papers/coling2018.pdf) should help in understanding the algorithm behind the sequence labelling i.e. multiple word entities. 

# In[ ]:




