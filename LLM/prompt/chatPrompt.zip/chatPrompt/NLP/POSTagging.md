POS Tagging [NLP, Python]
POS tagging is important to get an idea that which parts of speech does tokens belongs to i.e whether it is noun, verb, adverb, conjunction, pronoun, adjective, preposition, interjection, if it is verb then which form and so on….. whether it is plural or singular and many more conditions. In simple words process of finding the sequence of tags which is most likely to have generated a given word sequence.

Significance
POS Tagging are heavily used for building lemmatizers which are used to reduce a word to its root form as we have seen in lemmatization blog,
another use is for building parse trees which are used in building NERs. Also used in grammatical analysis of text, Co-reference resolution, speech recognition. A popular Penn treebank lists the possible tags are generally used to tag these token. Pos tag table and some examples :-

Also learn classic sequence labelling algorithm → Hidden Markov Model and Conditional Random Field. I’ll be writing over Hidden Markov Model soon as it’s application are vast and topic is interesting. Let’s take example sentence “I left the room” and “Left of the room” in 1st sentence “I left the room” →left is VERB and in 2nd sentence ‘Left’ is NOUN.
A POS tagger would help to differentiate between the two meanings of the word ‘left’. Also checkout word sense disambiguation here.

NLTK contains following taggers:
maxent_treebank_pos_tagger(Default) (based on Maximum Entropy (ME) classification principles trained on Wall Street Journal subset of the Penn Tree bank corpus),
BrillTagger(rule-based tagger),
CRFTagger,
HiddenMarkovModelTagger (Based on Hidden Markov Models (HMMs) known for handling sequential data),
and some more like — HunposTagge, PerceptronTagger, StanfordPOSTagger, SequentialBackoffTagger, SennaTagger
The accuracy of part-of-speech tagging algorithms is extremely high. One study found accuracies over 97% across 15 languages from the Universal Dependency (UD) treebank (Wu and Dredze, 2019). Accuracies on various English treebanks are also 97% (no matter the algorithm; HMMs, CRFs, BERT perform similarly). Checkout paper : The Surprising Cross-Lingual Effectiveness of BERT by Shijie Wu and Mark Dredze here.

Let’s try nltk and spacy pos taggers

NLTK pos tagger
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
sentence = "He was being opposed by her without any reason.\
 A plan is being prepared by charles for next project"
for sent in sent_tokenize(sentence):
    wordtokens = word_tokenize(sent)
    print(nltk.pos_tag(wordtokens),end='\n\n')
Output:

[('He', 'PRP'), ('was', 'VBD'), ('being', 'VBG'), ('opposed', 'VBN'), ('by', 'IN'), ('her', 'PRP$'), ('without', 'IN'), ('any', 'DT'), ('reason', 'NN'), ('.', '.')]  #Sentence 1
[('A', 'DT'), ('plan', 'NN'), ('is', 'VBZ'), ('being', 'VBG'), ('prepared', 'VBN'), ('by', 'IN'), ('charles', 'NNS'), ('for', 'IN'), ('next', 'JJ'), ('project', 'NN')]  #Sentence 2
instead of using sent_tokenize you can directly put whole text in nltk.pos_tag

spaCy pos tagger
import spacy
nlp = spacy.load('en_core_web_lg')
sentence = "He was being opposed by her without any reason.\
 A plan is being prepared by charles for next project"
for token in nlp(sentence):
    print(f'{token.text:{10}} {token.tag_:>{10}}\t{spacy.explain(token.tag_):<{50}} {token.pos_:>{5}}')
Output:


Got correct output from both of them.

Let’s train and test Hidden Markov Model (HMM) tagger from NLTK
import nltk
from sklearn.model_selection import train_test_split
tagged_sentences = nltk.corpus.treebank.tagged_sents(tagset='universal')#loading corpus
traindataset , testdataset = train_test_split(tagged_sentences, shuffle=True, test_size=0.2) #Splitting test and train dataset
#Test data size is 20% of whole tagged sentences
#Training HMMModel
HmmModel = nltk.HiddenMarkovModelTagger.train(traindataset)
#Correct labels from test dataset
correct_labels = [tag for sentences in testdataset for word, tag in sentences]
#predicting labels of testdataset
predicted_labels=[]
for sentences in testdataset:
    predicted_labels += [tag for _, tag in HmmModel.tag([word for word, _ in sentences])]
#Classification report
from sklearn.metrics import classification_report
print (classification_report(correct_labels, predicted_labels))
Output:


As you can see we got accuracy of 91% which is quite good. You will get near this if you use same dataset and train-test size. Accuracy also depends upon training and testing size, you can experiment with different datasets and size of test-train data.Go ahead experiment with other pos taggers!!

Visualization of dependency:

Displacy Dependency Visualizer — https://explosion.ai/demos/displacy

you can also visualize in jupyter (try below code)→

import spacy
nlp = spacy.load("en_core_web_sm")
doc = nlp("He was being opposed by her without any reason")
spacy.displacy.serve(doc,style="dep")

As you can see in above image — He is tagged as PRON(proper noun) was as AUX(Auxiliary) opposed as VERB and so on… You should checkout universal tag list here.

Saving this dependency image:

from pathlib import Path
svg = spacy.displacy.render(doc, style="dep",jupyter=False)
output_path = Path("dependency_plot.svg") #path with file name
output_path.open("w", encoding="utf-8").write(svg)
Let’s dive into some advance topic → spaCy custom pos pattern matcher
Let’s say you want some particular patterns to match in corpus like →
you want sentence should be in form “PROPN met anyword? anyword? PROPN”.(? → represents 0 or 1 time and PROPN → Proper Noun). Example — Ram met yogesh. or Elizabeth and Julie met at Karan house.

import spacy
from spacy.matcher import Matcher
nlp = spacy.load("en_core_web_sm") #loading spacy model
making corpus of above list of tagged sentences

frstword = lambda x: x[0] #Func. to take 1st item in iterative item
# Example  [('August', 'NNP'), ('with', 'IN'), ('U.S.', 'NNP')] -->  #['August','with','U.S.']
joiner = lambda x: ' '.join(list(map(frstword,x)))
#joiner will call frstword and joins string like this -->       #'August with U.S.'
corpus = ""
for sentences in traindataset:
    corpus+=joiner(sentences)+'\n'
Now we have whole corpus in corpus keyword. Let’s make out desired pattern. (Remember: traindataset we took it from above Hidden Markov Model section)

doc = nlp(corpus)
matcher = Matcher(doc.vocab)
Our pattern something like (“PROPN met anyword? anyword? PROPN”)

matcher.add('met', [[
dict(TAG='NNP', OP='+'),
dict(IS_ALPHA=True,OP='*'),
dict(LEMMA='meet'),
dict(IS_ALPHA=True, OP='*'),
dict(TAG='NNP', OP='+')
]])
running matcher

matchlist = matcher(doc)
Some pre-processing of output

import pandas as pd
df = pd.DataFrame(matchlist)
df.drop_duplicates(subset=[1], keep='last', inplace=True)
df.drop_duplicates(subset=[2], keep='last', inplace=True)
for _,indx in df[[1,2]].iterrows():
    print(doc[indx[1]:indx[2]],end='\n\n')
Result:
Mr. Nixon met Mr. Bush

Mr. Rapanelli met in August with U.S. Assistant Treasury Secretary David Mulford

Pacific nations will meet in Australia
without above pandas cleaning it would look like trash want to see… here

Now if you want pos tagging to cross check your result on that three above clean sentences then here it is →


You can see it matches pattern mentioned above…

I hope it was useful.
