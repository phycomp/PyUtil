#!/usr/bin/env python
# coding: utf-8

# In[38]:


get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt
plt.style.use('ggplot')


# In[1]:


from itertools import chain

import nltk
import sklearn
import scipy.stats
from sklearn.metrics import make_scorer
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RandomizedSearchCV

import sklearn_crfsuite
from sklearn_crfsuite import scorers
from sklearn_crfsuite import metrics


# ## Let's use CoNLL 2002 data to build a NER system
# 
# CoNLL2002 corpus is available in NLTK. We use Spanish data.

# In[2]:


nltk.corpus.conll2002.fileids()


# In[3]:


#get_ipython().run_cell_magic('time', '', "train_sents = list(nltk.corpus.conll2002.iob_sents('esp.train'))\ntest_sents = list(nltk.corpus.conll2002.iob_sents('esp.testb'))\n")

train_sents = list(nltk.corpus.conll2002.iob_sents('esp.train'))
test_sents = list(nltk.corpus.conll2002.iob_sents('esp.testb'))

# In[4]:


train_sents[0]


# ## Features
# 
# Next, define some features. In this example we use word identity, word suffix, word shape and word POS tag; also, some information from nearby words is used. This makes a simple baseline, but you certainly can add and remove some features to get (much?) better results - experiment with it. sklearn-crfsuite (and python-crfsuite) supports several feature formats; here we use feature dicts.

# In[5]:


def word2features(sent, i):
    word = sent[i][0]
    postag = sent[i][1]
    features = {'bias':1., 'word.lower()':word.lower(), 'word[-3:]':word[-3:], 'word[-2:]':word[-2:], 'word.isupper()':word.isupper(), 'word.istitle()':word.istitle(), 'word.isdigit()':word.isdigit(), 'postag':postag, 'postag[:2]':postag[:2]}
    if i > 0:
        word1 = sent[i-1][0]
        postag1 = sent[i-1][1]
        features.update({'-1:word.lower()':word1.lower(), '-1:word.istitle()':word1.istitle(), '-1:word.isupper()':word1.isupper(), '-1:postag':postag1, '-1:postag[:2]':postag1[:2]})
    else: features['BOS'] = True
    if i < len(sent)-1:
        word1 = sent[i+1][0]
        postag1 = sent[i+1][1]
        features.update({'+1:word.lower()':word1.lower(), '+1:word.istitle()':word1.istitle(), '+1:word.isupper()':word1.isupper(), '+1:postag':postag1, '+1:postag[:2]':postag1[:2]})
    else: features['EOS'] = True
    return features


def sent2features(sent):
    return [word2features(sent, i) for i in range(len(sent))]

def sent2labels(sent):
    return [label for token, postag, label in sent]

def sent2tokens(sent):
    return [token for token, postag, label in sent]


# This is what word2features extracts:

# In[6]:


sent2features(train_sents[0])[0]


# Extract features from the data:

# In[7]:


#get_ipython().run_cell_magic('time', '', '
X_train = [sent2features(s) for s in train_sents]
y_train = [sent2labels(s) for s in train_sents]
X_test = [sent2features(s) for s in test_sents]
y_test = [sent2labels(s) for s in test_sents]

# ## Training
# 
# To see all possible CRF parameters check its docstring. Here we are useing L-BFGS training algorithm (it is default) with Elastic Net (L1 + L2) regularization.

# In[44]:

#get_ipython().run_cell_magic('time', '', "
crf=sklearn_crfsuite.CRF(algorithm='lbfgs', c1=.1, c2=.1, max_iterations=100, all_possible_transitions=True)
crf.fit(X_train, y_train)

# ## Evaluation
# There is much more O entities in data set, but we're more interested in other entities. To account for this we'll use averaged F1 score computed for all labels except for O. ``sklearn-crfsuite.metrics`` package provides some useful metrics for sequence classification task, including this one.

# In[25]:


labels = list(crf.classes_)
labels.remove('O')
labels


# In[26]:


y_pred = crf.predict(X_test)
metrics.flat_f1_score(y_test, y_pred, average='weighted', labels=labels)

# Inspect per-class results in more detail:

# In[27]:


# group B and I results
sorted_labels = sorted( labels, key=lambda name:(name[1:], name[0]))
metrics.flat_classification_report(y_test, y_pred, labels=sorted_labels, digits=3)

# ## Hyperparameter Optimization
# 
# To improve quality try to select regularization parameters using randomized search and 3-fold cross-validation.
# 
# I takes quite a lot of CPU time and RAM (we're fitting a model ``50 * 3 = 150`` times), so grab a tea and be patient, or reduce n_iter in RandomizedSearchCV, or fit model only on a subset of training data.

# In[28]:


get_ipython().run_cell_magic('time', '', "# define fixed parameters and parameters to search\ncrf = sklearn_crfsuite.CRF(\n    algorithm='lbfgs', \n    max_iterations=100, \n    all_possible_transitions=True\n)\nparams_space = {\n    'c1': scipy.stats.expon(scale=0.5),\n    'c2': scipy.stats.expon(scale=0.05),\n}\n\n# use the same metric for evaluation\nf1_scorer = make_scorer(metrics.flat_f1_score, \n                        average='weighted', labels=labels)\n\n# search\nrs = RandomizedSearchCV(crf, params_space, \n                        cv=3, \n                        verbose=1, \n                        n_jobs=-1, \n                        n_iter=50, \n                        scoring=f1_scorer)\nrs.fit(X_train, y_train)\n")


# Best result:

# In[36]:


# crf = rs.best_estimator_
print('best params:', rs.best_params_)
print('best CV score:', rs.best_score_)
print('model size: {:0.2f}M'.format(rs.best_estimator_.size_ / 1000000))


# ### Check parameter space
# 
# A chart which shows which ``c1`` and ``c2`` values have RandomizedSearchCV checked. Red color means better results, blue means worse.

# In[39]:


_x = [s.parameters['c1'] for s in rs.grid_scores_]
_y = [s.parameters['c2'] for s in rs.grid_scores_]
_c = [s.mean_validation_score for s in rs.grid_scores_]

fig = plt.figure()
fig.set_size_inches(12, 12)
ax = plt.gca()
ax.set_yscale('log')
ax.set_xscale('log')
ax.set_xlabel('C1')
ax.set_ylabel('C2')
ax.set_title("Randomized Hyperparameter Search CV Results (min={:0.3}, max={:0.3})".format(
    min(_c), max(_c)
))

ax.scatter(_x, _y, c=_c, s=60, alpha=0.9, edgecolors=[0,0,0])

print("Dark blue => {:0.4}, dark red => {:0.4}".format(min(_c), max(_c)))


# ## Check best estimator on our test data
# 
# As you can see, quality is improved.

# In[45]:


crf = rs.best_estimator_
y_pred = crf.predict(X_test)
print(metrics.flat_classification_report(
    y_test, y_pred, labels=sorted_labels, digits=3
))


# ## Let's check what classifier learned

# In[47]:


from collections import Counter

def print_transitions(trans_features):
    for (label_from, label_to), weight in trans_features:
        print("%-6s -> %-7s %0.6f" % (label_from, label_to, weight))

print("Top likely transitions:")
print_transitions(Counter(crf.transition_features_).most_common(20))

print("\nTop unlikely transitions:")
print_transitions(Counter(crf.transition_features_).most_common()[-20:])


# We can see that, for example, it is very likely that the beginning of an organization name (B-ORG) will be followed by a token inside organization name (I-ORG), but transitions to I-ORG from tokens with other labels are penalized.
# 
# Check the state features:

# In[55]:


def print_state_features(state_features):
    for (attr, label), weight in state_features:
        print("%0.6f %-8s %s" % (weight, label, attr))    

print("Top positive:")
print_state_features(Counter(crf.state_features_).most_common(30))

print("\nTop negative:")
print_state_features(Counter(crf.state_features_).most_common()[-30:])


# 
# 
# Some observations:
# 
#    * **9.385823 B-ORG word.lower():psoe-progresistas** - the model remembered names of some entities - maybe it is overfit, or maybe our features are not adequate, or maybe remembering is indeed helpful;
#    * **4.636151 I-LOC -1:word.lower():calle:** "calle" is a street in Spanish; model learns that if a previous word was "calle" then the token is likely a part of location;
#    * **-5.632036 O word.isupper()**, **-8.215073 O word.istitle()** : UPPERCASED or TitleCased words are likely entities of some kind;
#    * **-2.097561 O postag:NP** - proper nouns (NP is a proper noun in the Spanish tagset) are often entities.
# 
# What to do next
# 
#     * Load 'testa' Spanish data.
#     * Use it to develop better features and to find best model parameters.
#     * Apply the model to 'testb' data again.
# 
# The model in this notebook is just a starting point; you certainly can do better!
# 
# 

# In[ ]:




