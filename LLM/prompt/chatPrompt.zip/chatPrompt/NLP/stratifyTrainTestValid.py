'''
For classification you can use the stratify parameter:

stratify: array-like or None (default=None)

If not None, data is split in a stratified fashion, using this as the class labels.

See sklearn.model_selection.train_test_split. For example:
This will ensure the class distribution is similar between train and test data. (side note: I have tossed the train_size parameter since it will be automatically determined based on test_size) For regression there is, to my knowledge, no current implementation in scikit learn. But you can find a discussion and manual implementation here and here with regards to cross-validation. Split to a validation set it's not implemented in sklearn. But you could do it by tricky way:

1. At first step you split X and y to train and test set.
2. At second step you split your train set from previous step into validation and smaller train set.

x_train, x_test, y_train, y_test = train_test_split(xs, ys, test_size=0.33, random_state=0, stratify=ys)

The answer I can give is that stratifying preserves the proportion of how data is distributed in the target column - and depicts that same proportion of distribution in the train_test_split. Take for example, if the problem is a binary classification problem, and the target column is having proportion of 80% = yes, and 20% = no. Since there are 4 times more yes than no in the target column, by splitting into train and test without stratifying, we might run into the trouble of having only the yes falling into our training set, and all the no falling into our test set.(i.e, the training set might not have no in its target column). by Stratifying, the target column for the training set has 80% of yes and 20% of no, and also, the target column for the test set has 80% of yes and 20% of no respectively. Hence, Stratify makes even distribution of the target(label) in the train and test set - just as it is distributed in the original dataset.

from sklearn.model_selection import train_test_split
X_train, y_train, X_test, y_test = train_test_split(features, target, test-size = 0.25, stratify = target, random_state = 43)

'''
x, xTest, y, yTest = train_test_split(xtrain, labels, test_size=.2, stratify=labels)

X_train, xTest, y_train, yTest = train_test_split(X, y, test_size=.7, random_state=123)

X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.5, random_state=123)
# Defines ratios, w.r.t. whole dataset.
ratioTrain, ratioVal, ratioTest   = .8, .1, .1
# Produces test split.
x_remaining, xTest, y_remaining, yTest = train_test_split(x, y, test_size=ratioTest)

# Adjusts val ratio, w.r.t. remaining dataset.
rRemain = 1 - ratioTest
rValid = ratioVal / rRemain

# Produces train and val splits.
x_train, x_val, y_train, y_val = train_test_split( x_remaining, y_remaining, test_size=rValid)

from sklearn import cross_validation, datasets

iris = datasets.load_iris()

X = iris.data[:,:2]
y = iris.target

x_train, x_test, y_train, y_test = cross_validation.train_test_split(X, y, train_size=.8, stratify=y)
#y_test

import numpy as np
from sklearn.model_selection import train_test_split
X, y = np.arange(10).reshape((5, 2)), range(5)
#X array([[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]])
#list(y) [0, 1, 2, 3, 4]
X_train, X_test, y_train, y_test = train_test_split( X, y, test_size=.33, random_state=42)
#X_train array([[4, 5], [0, 1], [6, 7]])
#y_train [2, 0, 3]
#X_test array([[2, 3], [8, 9]])
#y_test [1, 4]
train_test_split(y, shuffle=False)

X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=5000, test_size=10000, random_state=42

