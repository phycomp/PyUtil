系統環境
系統資訊：Windows 11或Linux CentOS 7
Windows：安裝Docker desktop
CentOS 7：安裝Docker版本20
docker-compose版本2.1X
使用官方提供的docker compose方案Broadsea Github
其中裡面的image會在docker compose時自動pull下來
Postgresql資料庫，需有足夠的儲存空間
Git 用來將Broadsea拉下來
Chrome 瀏覽器
Broadsea介紹
OHDSI Broadsea 2.0 包含開發環境與Atlas服務如下
OHDSI R HADES -RStudio環境與ACHILLES套件
OHDSI Atlas -前端分析呈現介面包括 WebAPI REST

補充官方提供完整的開源內容

流程介紹
0.安裝Broadsea(使用git、docker)
git clone -b V2.0.0 https://github.com/OHDSI/Broadsea.git
cd至Broadsea資料夾執行

docker compose up
查看docker狀態

docker-compose ps
查看各容器狀態Log Files

docker logs ohdsi-atlas
docker logs ohdsi-webapi
docker logs broadsea-hades
1.OMOP CMD(Postgresql資料庫)
ICCA to CMD
步驟一：資料Mapping成OMOP CMD
步驟二：OMOP CDM = DB資料 to CDM + VOCAB
步驟三：建立CDM Datasourse
2.OMOP HADES(ACHILLES分析)
ACHILLES
步驟一：使用HADES對OMOP CMD分析
步驟二：OMOP CMD於ACHILLES分析
步驟三：透過WEB API連線
DQD
資料質量檢驗
3.OMOP ALTAS
ATLAS
步驟一：使用WEB API取得運算結果，
步驟二：呈現出畫面，OMOP CMD分析結果
開發筆記
omop note
