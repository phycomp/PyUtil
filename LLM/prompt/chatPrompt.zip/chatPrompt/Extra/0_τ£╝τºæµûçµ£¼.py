from pandas import DataFrame, read_csv
from streamlit import dataframe, code as stCode, session_state
from re import search, DOTALL, IGNORECASE

try: dfEye=session_state['dfEye']
except:
    session_state['dfEye']=dfEye= read_csv('/home/josh/Downloads/眼科文本.csv').dropna()
dataframe(dfEye)
def rtrvIOP(outcome):
    pttrnIOP=search('(.*)IOP', outcome)
    if pttrnIOP:
        #, pttrnIOP.group(0)
        pass
        #stCode(['IOP left=', pttrnIOP.group(1)])
    else:
        pttrnIOP=search('IOP(.*)', outcome)
        if pttrnIOP:pass    #; stCode(['IOP right=', pttrnIOP.group(1)])
        else:
            pass
            #stCode(['not found=', outcome])  #pttrnIOP.group(0)
            #pttrn.groups(), 
            #pttrnIOP=search('IOP(.*?)', outcome)
            #if pttrnIOP:
            #else: stCode([pttrn.groups(), outcome])
def rtrvODOS(cols):
    #stCode(['cols=', cols[0]])
    outcome=cols[0]
    pttrn=search('^OD(.*?)OS(.*?)IOP(.*)mmhg', outcome, DOTALL|IGNORECASE)
    if pttrn:
        startPos=outcome.find(pttrn.group(1))
        endPos=startPos+len(pttrn.group(1))
        startPosOS=outcome.find(pttrn.group(2))
        endPosOS=startPosOS+len(pttrn.group(2))
        startPosIOP=outcome.find(pttrn.group(3))
        endPosIOP=startPosIOP+len(pttrn.group(3))
        stCode(['right=', outcome, {'entities':[(startPos, endPos, 'OD'), (startPosOS, endPosOS, 'OS'), (startPosIOP, endPosIOP, 'IOP')]}]) #outcome.find(pttrn.group(1))+len(pttrn.group(1)) 'ODOS right, startPos, endPos=', pttrn.groups(), pttrn.group(1), 
        #rtrvIOP(pttrn.group(1))
    else:
        pttrn=search('(.*)OD(.*?)OS.*IOP(.*)mmHg', outcome, DOTALL|IGNORECASE)
        if pttrn:
            startPos=outcome.find(pttrn.group(1))
            endPos=startPos+len(pttrn.group(1))
            startPosOS=outcome.find(pttrn.group(2))
            endPosOS=startPosOS+len(pttrn.group(2))
            startPosIOP=outcome.find(pttrn.group(3))
            endPosIOP=startPosIOP+len(pttrn.group(3))
            stCode(['left=', outcome, {'entities':[(startPos, endPos, 'OD'), (startPosOS, endPosOS, 'OS'), (startPosIOP, endPosIOP, 'IOP')]}])
        else:
            #pass
            rtrvIOP(outcome)
            #stCode(['no found=', outcome])
    #else: stCode([outcome, pttrn])
dfEye.apply(rtrvODOS, axis=1)
