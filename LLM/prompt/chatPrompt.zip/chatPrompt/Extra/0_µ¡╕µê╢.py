import os
from streamlit.components.v1 import declare_component

def run():
  from pandas import DataFrame
  from dbMnpl.strmltPGconn import runQuery
  from streamlit import dataframe as stDataframe, write as stWrite, radio as stRadio, code as stCode, session_state
  年度=['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019']
  眼科病人=[ '39571625', '12482541', '15894185', '24287896', '13224776', '20491503', '1066042', '279038', '20683403', '21351826', '37620658', '37800423', '20178250', '42154187', '35590762', '2733097', '1968485', '29949460', '5266159', '33036941', '24626264', '2971779', '36636803', '29490457', '31781370', '24484331', '36449179', '32145485', '34873977', '18626647', '15912706', '7156867', '6338756', '20549546', '43228337', '21958894', '21406871', '42169313', '28339255', '39001268', '23088064', '21722327' ]
  tblBDC=("BDCNSOAP", "BDCNOPER", "BDCNADMI", "BDCRPATH") #"BDCCCPAR", "BDCNCOPA", "BDCCITAS", "BDCCCCTA", "BDCCPHLM", "BDCCSPEI", "BDCCAFBS", "BDCCCPAV", "BDCCLAUT", "BDCCCIEV", "BDCCEBUS", "BDCCPLRL", "BDCCSPII", "BDCCASCI", "BDCCCPLK", "BDCCLCTL", "BDCCCKUB", "BDCCEKGG", "BDCCPRCD", "BDCCSPOT", "BDCCASPR", "BDCCCRBB", "BDCCLDCB", "BDCCCLDV", "BDCCEUTA", "BDCCPSGN", "BDCCTBNA", "BDCCBCFS", "BDCCCRBL", "BDCCLNAS", "BDCCCLSV", "BDCCFBSC", "BDCCPSGY", "BDCCTEEC", "BDCCBDCCB", "BDCCCRBR", "BDCCLUNG", "BDCCCLTV", "BDCCFFDM", "BDCCRADI", "BDCCTPCY", "BDCCBFBR", "BDCCCRTV", "BDCCMDEC", "BDCCCNBA", "BDCCFUNG", "BDCCRDCB", "BDCCUGIP", "BDCCBRBR", "BDCCCSFC", "BDCCMPST", "BDCCCODR", "BDCCHEST", "BDCCSBIO", "BDCCURIN", "BDCCBRWA", "BDCCCXOB", "BDCCHLAG", "BDCCSGNA", "BDCCWAUT", "BDCCCADC", "BDCCCXOL", "BDCCPALO", "BDCCCOPO", "BDCCIMMU", "BDCCCAPB", "BDCCCXOR", "BDCCPASS", "BDCCSOAP", "BDCCCPAL", "BDCCIMPR", "BDCCCAPP", "BDCCCYTO", "BDCCSONO", "BDCCCPAP", "BDCCINAL", "BDCCCAPV", "BDCCDBAL", "BDCCPFTC", "BDCCSPAL") #"BDCCDERS", "BDCCSMRY",
  #from pydicom import read_file
  from streamlit import sidebar, file_uploader, write as stWrite
  #from matplotlib.pyplot import subplots, axis, cm, imshow, pyplot, gcf
  MENUs=['眼科', '健保資料庫', '檢驗類資料', '病歷文本']  #, 'Annot', 'nerTagger', 'embedding', 'BILUO', 'viterbi', 'Metadata',
  menu = sidebar.radio('Output', MENUs, index=0)
  #from streamlit import text_input
  hist=sidebar.text_input('病歷號32567127')
  stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
  病歷號=sidebar.radio('病歷號', 眼科病人, index=0)
  病歷號=hist if hist else 病歷號
  if menu==MENUs[0]:
    stCode(病歷號)
    #病歷號=stRadio('眼科', 眼科病人)
    if 病歷號:
      fullQuery=f'''select outcome,打針,視力 from "ODOS" where 病歷號='{病歷號}';'''    #日期, 打針, 視力,
      eyeDF=[v for v in runQuery(fullQuery, db='eyeVis') ]#
      #stDataframe(eyeDF)
      eyeDF=DataFrame(eyeDF, columns=['病歷文本', '打針', '視力'], dtype='str')
      stDataframe(eyeDF)
    #lastPage=len(eyeHISTs)-1
  elif menu==MENUs[1]:
    from streamlit import code as stCode
    資料庫=['CD', 'DD', 'DO', 'OO']
    病歷號欄位={'CD':'ARNHIST', 'DD':'BHISTNO', 'DO':'BHISTNO', 'OO':'ARNHIST'}
    from streamlit import radio as stRadio
    健保=stRadio('健保資料庫', 資料庫)
    ann=stRadio('年度', 年度)
    nhirdHIST=病歷號欄位.get(健保)
    qrySQL=f'''select count(*) from nhird."tmpl2{健保}{ann}" where "{nhirdHIST}"='{病歷號}';'''
    stCode(qrySQL)
    #qrySQL=f'select {qrySQL}, sum(num_of_visit), sum(num_of_people) from "COUNT_{nhirdTBL}" group by 1;'
    rslt=runQuery(qrySQL, db='nhird')
    stCode(rslt)
    #configINFO=open('/home/josh/NLP/CONFIG.cfg').read()
    #stCode(configINFO)
  elif menu==MENUs[2]:
    fullQuery=f'''select distinct "RSRTSYM", "PFKEY" from  isc8381."ageGndrSymblPfkeyIIINew";'''
    ann=stRadio('年度', 年度)
    try: symPFKEY=session_state['symPFKEY']
    except:
        session_state['symPFKEY']=symPFKEY=runQuery(fullQuery, db='symblPfkey')
    symbl, pfkey=stRadio('symbol暨收費碼', symPFKEY)
    #病歷號, symbl, pfkey='10913947', 'RTALT', '90111100'
    lbdtQuery=f'''select count(*) from mdctn."rsltTmpl" where "PFKEY"='{pfkey}' and "HISTNO"='{病歷號}' and "SYMBL"='{symbl}';'''
    lbdtRslt=runQuery(lbdtQuery, db='mdctn')
    stCode([lbdtRslt])
    病歷號='10913389'
    fullQuery=f'''select "RSDATE", "cmbValue" from isc8381."ageGndrSymblPfkeyIIINew" where "RSRTSYM"='{symbl}' and "PFKEY"='{pfkey}' and "HISTNO"='{病歷號}';'''  #, string_agg("RSDATE"||'@'||"cmbValue", '%'order by "RSDATE")"cmbValue" group by 1,2,3,4 "PSEX", round("AGE"::numeric/10)"AGE" "RSRTSYM", "PFKEY",
    stCode([fullQuery])
    symPfkeyRslt=runQuery(fullQuery, db='symblPfkey')
    sympfkeyLBDT=DataFrame(symPfkeyRslt, columns=['檢驗日期', '檢驗值'])
    stDataframe(sympfkeyLBDT)
    #stCode([symPfkeyRslt])
  elif menu==MENUs[3]:
    #'內視鏡文本'
    from streamlit import container as stContainer, columns as stColumns, text_input
    cntnr=stContainer()
    bdctbl=stRadio('病歷文本', tblBDC)
    #bdctbl='BDCNSOAP'
    #midPane=stColumns([10])
    #leftPane, midPane, rightPane=stColumns([1,1,1])
    #noPthlgy=stSlider('文本數', 1, 100, step=10)
    #noPthlgy=midPane.slider('文本數', 1, 100, step=10)
    #placeholder=stEmpty()
    #病歷號='11551498'
    #select count(*) from "BDC_TECH"."BDCNSOAP" where "CHARTID"='11551498' and "OUTCOME"~*'Phaco';
    文本SQL=f'''select "OUTCOME" from "BDC_TECH"."{bdctbl}" limit 5;'''    #, sum(n_report), sum(n_people) group by 1
    stCode(文本SQL)
    demo文本=runQuery(文本SQL, db='bdprod')
    df文本=DataFrame(demo文本, columns=['病歷文本'])
    stDataframe(df文本)
    pthlgyTxt=text_input('keyword<-->KEYWORD', 'Phaco')
    #to_tsvector(outcome)@@to_tsquery('keyword<-->KEYWORD')
    stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between}</style>', unsafe_allow_html=True)
    if pthlgyTxt:
        qry文本= f'''to_tsvector("OUTCOME")@@to_tsquery('{pthlgyTxt}')'''
        try:
            qrySQL=f'''select "OUTCOME", "RDATE" from "BDC_TECH"."{bdctbl}" where "CHARTID"='{病歷號}' and {qry文本};'''    #, sum(n_report), sum(n_people) group by 1
            文本Query=runQuery(qrySQL, db='bdprod')
        except:
            qrySQL=f'''select "OUTCOME", "SDATE" from "BDC_TECH"."{bdctbl}" where "CHARTID"='{病歷號}' and {qry文本};'''
            文本Query=runQuery(qrySQL, db='bdprod')
    else:
        try:
            qrySQL=f'''select "OUTCOME", "RDATE" from "BDC_TECH"."{bdctbl}" where "CHARTID"='{病歷號}';'''    #, sum(n_report), sum(n_people) group by 1
            文本Query=runQuery(qrySQL, db='bdprod')
        except:
            qrySQL=f'''select "OUTCOME", "SDATE" from "BDC_TECH"."{bdctbl}" where "CHARTID"='{病歷號}';'''
            文本Query=runQuery(qrySQL, db='bdprod')
    stCode(qrySQL)
    文本df=DataFrame(文本Query, columns=['文本', 'RDATE'])
    stDataframe(文本df) #BDC表格 bdcTBL)
    #ann=sidebar.radio('',  ('年度','年月'), key='ann') #AnnReport
    #bdcTBL=sidebar.radio('', tblBDC, key='病理文本')
run()
