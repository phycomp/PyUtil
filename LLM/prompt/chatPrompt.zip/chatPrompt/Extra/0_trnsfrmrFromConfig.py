from transformers import AutoTokenizer, GPT2LMHeadModel, AutoConfig
from streamlit import session_state, info as stInfo
from transformers import DataCollatorForLanguageModeling

try: trainData=session_state['trainData']
except: pass#trainData=session_state['trainData']
vghTknzr=session_state['vghTknzr']
vocabSize, context_length =30522, 128

from transformers import AutoConfig, AutoTokenizer, AutoModelForMaskedLM

#tokenizer = AutoTokenizer.from_pretrained("tf-tpu/unigram-tokenizer-wikitext")

#config = AutoConfig.from_pretrained("roberta-base")
#config = AutoConfig.from_pretrained("gpt2", vocab_size=vocabSize, n_ctx=context_length) #len(vghTknzr), eos_token_id=vghTknzr.eos_token_id bos_token_id=vghTknzr.bos_token_id,
config = AutoConfig.from_pretrained('gpt2', vocab_size=vghTknzr.get_vocab_size(), n_ctx=context_length)    #"bert-base-cased"
#AutoModelForMaskedLM. Model type should be one of AlbertConfig, BartConfig, BertConfig, BigBirdConfig, CamembertConfig, ConvBertConfig, Data2VecTextConfig, DebertaConfig, DebertaV2Config, DistilBertConfig, ElectraConfig, ErnieConfig, EsmConfig, FlaubertConfig, FNetConfig, FunnelConfig, IBertConfig, LayoutLMConfig, LongformerConfig, LukeConfig, MBartConfig, MegaConfig, MegatronBertConfig, MobileBertConfig, MPNetConfig, MvpConfig, NezhaConfig, NystromformerConfig, PerceiverConfig, QDQBertConfig, ReformerConfig, RemBertConfig, RobertaConfig, RobertaPreLayerNormConfig, RoCBertConfig, RoFormerConfig, SqueezeBertConfig, TapasConfig, Wav2Vec2Config, XLMConfig, XLMRobertaConfig, XLMRobertaXLConfig, XmodConfig, YosoConfig
#config.vocab_size = vghTknzr.vocab_size
#model = AutoModelForMaskedLM.from_config(config)

vghMDL = GPT2LMHeadModel(config)
model_size = sum(t.numel() for t in vghMDL.parameters())
stInfo(f"GPT-2 size: {model_size/1000**2:.1f}M parameters")


#vghTknzr.pad_token = vghTknzr.eos_token
#tokenizers.Tokenizer' object has no attribute 'eos_token'
data_collator = DataCollatorForLanguageModeling(vghTknzr, mlm=False)

        #features = { "input_ids": tf.train.Feature(int64_list=tf.train.Int64List(value=tokenized_data["input_ids"][i])), "attention_mask": tf.train.Feature( int64_list=tf.train.Int64List(value=tokenized_data["attention_mask"][i])) }
        #features = tf.train.Features(feature=features)
        #example = tf.train.Example(features=features)
        #record_bytes = example.SerializeToString()
stInfo(['get_vocab_size', vghTknzr.get_vocab_size()])
#out = data_collator([trainData])    #tokenized_datasets["train"][i] for i in range(5)
#for key in out:
#   print(f"{key} shape: {out[key].shape}")

from transformers import Trainer, TrainingArguments
args = TrainingArguments( output_dir="vghMDLout", per_device_train_batch_size=32, per_device_eval_batch_size=32, evaluation_strategy="steps", eval_steps=5_000, logging_steps=5_000, gradient_accumulation_steps=8, num_train_epochs=1, weight_decay=0.1, warmup_steps=1_000, lr_scheduler_type="cosine", learning_rate=5e-4, save_steps=5_000, fp16=True, push_to_hub=True,)
#
trainer = Trainer( model=vghMDL, tokenizer=tokenizer, args=args, data_collator=data_collator, train_dataset=tokenized_datasets["train"], eval_dataset=tokenized_datasets["valid"])
#Now we can just start the Trainer and wait for training to finish. Depending on whether you run it on the full or a subset of the training set this will take 20 or 2 hours, respectively, so grab a few coffees and a good book to read!
#tokenizer = Tokenizer.from_file("my-tokenizer.json")
#config = AutoConfig.from_pretrained("bert-base-cased", vocab_size=tokenizer.get_vocab_size())
#model = AutoModelForMaskedLM.from_config(config)

#tokenizer.enable_truncation(max_length=model.config.max_position_embeddings)
#dataset = LMDataset(tokenizer, files=['train_1.txt', 'train_2.txt'])
#data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, **cfg.data_collator_kwargs)
