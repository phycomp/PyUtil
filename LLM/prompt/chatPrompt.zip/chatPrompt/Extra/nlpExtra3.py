'''
_RELEASE = False  # on packaging, pass this to True
PORT=3001
if not _RELEASE:
    _component_func = declare_component( "neranntt", url=f"http://10.221.252.12:{PORT}")
else:
    parent_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(parent_dir, "build")
    print('build_dir', build_dir)
    _component_func = declare_component("neranntt", path=build_dir)
    slceSqnc()

def nerAnntt(label, **kwargs):
  #print( _component_func(label=label, **kwargs)) #name=name, key=key, default=0)
  return _component_func(label=label, **kwargs)  #name=name, key=key, default=0
'''


from spacy import blank as spcyBlnk
from spacy.tokens import DocBin
from streamlit import session_state,  text_input
from re import findall
from pandas import read_csv
def 導入文本(fname):
  lngMDL=spcyBlnk('en')
  lngMDL.add_pipe('sentencizer')
  trainData=[]
  #copaDF=read_csv(fname, dtype='str', delimiter='\x06')
  #for nerINFO, outcome in copaDF.values:
  for outcome in open('眼科病理文本'):
    print('outcome', outcome)
    NLP=lngMDL(outcome)
    for sent in NLP.sents:
      sentTxt=sent.text
      #print(sentTxt)
      '''
      nerCntnr=set()
      for posNER in nerINFO.split('@'):
        startEnd, keyTerm, NER=posNER.split('|')
        try:
          startPos, endPos=list(map(lambda x:int(x), startEnd.split(":")))
          if sentTxt.find(keyTerm)!=-1:
            nerCntnr.add((startPos, endPos, NER))
        except:
          pass

      '''
      if nerCntnr: trainData.append([sentTxt, {'entities':list(nerCntnr)}])#{'nerCntnr
  return trainData
#fname='/home/josh/bdcrcopa2.csv'
def trainMDL(trainData):
  nlp = spcyBlnk("en")
  docBin = DocBin()
  for text, annotations in trainData:  #annotations.pop('entities')
    doc = nlp(text)
    ents=[]
    for start, end, label in annotations['entities']:
      span=doc.char_span(start, end, label=label)
      if span:ents.append(span)
    if not doc.ents:
      doc.ents=ents
      docBin.add(doc)
  return docBin

#mdlName="./train.spacy"
try: mdlName=session_state['mdlName']
except:
  session_state['mdlName']=mdlName=text_input('modelName', 'lngMDLnew')
try: trainData=session_state['trainData']
except:
  trainData=導入文本(fname)
  session_state['trainData']=trainData
  session_state['mdlName']=mdlName
MDL=trainMDL(trainData)
session_state['MDL']=MDL
#MDL.to_disk(mdlName)
if menu==MENUs[3]:
#from dcmbdc.sliceSeq import reCnstrctn3D
    from streamlit import session_state, text_area, write as stWrite, radio as stRadio
    from pandas import DataFrame
    from spacy import load as spcyLoad
    from streamlit import dataframe
    mdlType=['last', 'best']
    mdltype=stRadio('model Types', mdlType)
    try: mdlName=session_state['mdlName']
    except: session_state['mdlName']=mdlName
    if mdltype:
      #lngMDLtrain=session_state['MDL']
      lngMDLtrain=spcyLoad(f'/home/josh/NLP/{mdlName}/model-{mdltype}')
    copa='''PATHOLOGICAL DIAGNOSIS:Colon, 70 cm and 15 cm above anal verge, polypectomy--- Tubular adenoma GROSS FINDING:Received in formalin are 2 pieces of tan soft tissue, measuring0.8x0.7x0.4 cm and 0.5x0.5x0.3 cm. Entire specimen is embeddedin one block. (HCF)MICROSCOPIC FINDING:1. Type of adenoma: tubular2. Quality of specimen: poorly orientated3. Dysplasia: Low grade4.'''
    文本=text_area('輸入文本', copa, height=150)
    def showENT(doc):
#print(ent.text, ent.label_)
      rsltENT=[]
      for ent in doc.ents:
        entInfo=('|'.join([ent.text, str(ent.start_char), str(ent.end_char), ent.label_]))  #str(ent.start), str(ent.end), str(ent.label)
        rsltENT.append(entInfo)
      return rsltENT
      #print(ent.text, ent.label_, ent.start_char, ent.end_char)

    if 文本:
      文本=文本.replace('\n', ' ')
      doc=lngMDLtrain(文本)
      stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
      rsltENT=showENT(doc)
      entDF=DataFrame.from_dict({'NER':rsltENT}, columns=None, orient='columns')
      dataframe(entDF)
      #stWrite(rsltENT)

