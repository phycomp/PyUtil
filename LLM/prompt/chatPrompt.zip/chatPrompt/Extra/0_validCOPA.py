from pandas import read_excel
from streamlit import dataframe, radio as stRadio, sidebar, code as stCode, session_state, info as stInfo, write as stWrite
ODS=['BDCRCOPA', 'bdcrcopa2']
stCode(ODS)
from pandas import isna as pndsNA
ods=sidebar.radio('ODS', ODS)
def rtrvPos(cols):
    chartid, mrn1, mrn2, sdate, outcome, annttInfo=cols[:-1]
    #annttInfo, outcome=cols[['annttInfo', 'outcome']]#
    #stInfo([annttInfo, outcome]) #.index.str 
    nerInfo=[]
    #stInfo(['annttInfo', dataframe(cols)])
    if not pndsNA(annttInfo):
        for ann in annttInfo.replace("'", '').split(','):
            try:
                posInfo, seg, NER = ann.split('|')
                posDummy=map( lambda x:int(x)-1, posInfo.split(':'))
                startPos, endPos=list(posDummy)
            except:stInfo(['ann', ann])
            try:
                assert seg==outcome[startPos:endPos]
                nerInfo.append((startPos, endPos, NER))
            except:
                #pass
                #stInfo(cols)
                stWrite(['assert', chartid, startPos, endPos, seg, NER, outcome[startPos:endPos], cols['outcome']])
    #stInfo([outcome, {'entities': nerInfo}])
    #except:stCode(df['annttInfo'])
if ods:
    try: df=session_state[ods]
    except:
        session_state[ods]=df=read_excel(f'{ods}.ods', dtype='str')    #, engine='odfpy'
    session_state[ods]=df=read_excel(f'{ods}.ods', dtype='str')    #, engine='odfpy'
    dataframe(df)
    #df=df.iloc[10]#:
    df.apply(rtrvPos, axis=1)
    #for DF in df.iloc[:]: dataframe(DF)
