import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-medium")
model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")
def generate_response(input_text):
    # encode the user input
    input_ids = tokenizer.encode(input_text + tokenizer.eos_token, return_tensors='pt')

    # generate a response using the pre-trained model
    chatbot_output = model.generate( input_ids=input_ids, max_length=50, do_sample=True, top_p=0.95, top_k=50)

    # decode the generated response
    chatbot_response = tokenizer.decode(chatbot_output[0], skip_special_tokens=True)

    return chatbot_response
while True:
    user_input = input("You: ")

    # exit the loop if the user enters "exit"
    if user_input.lower() == "exit":
        break

    chatbot_response = generate_response(user_input)
    print("Chatbot: " + chatbot_response)

def generate_response(user_input):
    # Tokenize user input
    input_ids = tokenizer.encode(user_input, return_tensors='pt')

    # Generate response using model
    output = model.generate(input_ids=input_ids, max_length=1000, pad_token_id=tokenizer.eos_token_id)

    # Decode output and convert to string
    response = tokenizer.decode(output[0], skip_special_tokens=True)

    return response

# Initialize chatbot
chatbot = MentalHealthChatbot()

# Start chatbot
while True:
    user_input = input('You: ')
    response = chatbot.get_response(user_input)
    print('Chatbot:', response)


