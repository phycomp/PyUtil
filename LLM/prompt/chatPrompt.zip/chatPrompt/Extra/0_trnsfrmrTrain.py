from keras.layers.experimental.preprocessing import TextVectorization
from keras.layers import Embedding, Dense, Dropout, Input, LSTM, GlobalMaxPool1D
from keras.models import Sequential
from streamlit import write as stWrite, sidebar, session_state, code as stCode, info as stInfo
from keras.initializers import Constant
#import tensorflow as tf

MENUs=['transformer', 'AutoTokenizer', 'pretrain', 'keras', 'fastText', 'optimizer','BILUO', 'vocab', 'word2vec'] #EMBEDDING
if menu==MENUs[0]:
    stWrite(list(doc.ents)) #要得出ents
elif menu==MENUs[1]:
    stWrite(list(doc.sents))
    lngMDL='medicalaiClinical'
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(lngMDL, use_fast=True)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(lngMDL)    #"distilbert-base-uncased"

