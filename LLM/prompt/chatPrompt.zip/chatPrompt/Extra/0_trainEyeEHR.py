from streamlit import code as stCode, info as stInfo
eyePthlgy=open('眼科病理文本').read()
#stCode(eyePthlgy)
from spacy import load as spcyLoad
lngMDL=spcyLoad('en_core_web_sm')
#python -m spacy download en_core_web_sm
stInfo(lngMDL)
doc = lngMDL(eyePthlgy)
#stCode(list(doc.sents))
stInfo(doc.ents)

