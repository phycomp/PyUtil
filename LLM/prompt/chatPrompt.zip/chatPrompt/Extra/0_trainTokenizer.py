from tokenizers import ByteLevelBPETokenizer
from streamlit import session_state, info as stInfo, code as stCode, write as stWrite

trainData=session_state['trainData']
#paths = [str(x) for x in Path("./eo_data/").glob("**/*.txt")]

# Initialize a tokenizer
#tokenizer = ByteLevelBPETokenizer()

# Customize training
#tokenizer.train(files=trainData, vocab_size=52_000, min_frequency=2, special_tokens=[ "<s>", "<pad>", "</s>", "<unk>", "<mask>", ])

from tokenizers.models import BPE
from tokenizers.pre_tokenizers import Whitespace
from tokenizers.trainers import BpeTrainer
from tokenizers import Tokenizer, decoders, models, normalizers, pre_tokenizers, trainers
from tokenizers.trainers import WordPieceTrainer

trainer = BpeTrainer(special_tokens=["[UNK]", "[CLS]", "[SEP]", "[PAD]", "[MASK]"])
vghTknzr = Tokenizer(BPE(unk_token="[UNK]"))
#vghTknzr = Tokenizer(models.Unigram())
vghTknzr.normalizer = normalizers.NFKC()
#vghTknzr.pre_tokenizer = pre_tokenizers.ByteLevel()
vghTknzr.pre_tokenizer = Whitespace()
vghTknzr.decoder = decoders.ByteLevel()
#trainer = trainers.UnigramTrainer( vocab_size=20000, initial_alphabet=pre_tokenizers.ByteLevel.alphabet(), special_tokens=["<PAD>", "<BOS>", "<EOS>"])
trnData=map(lambda x:x[0], trainData)
#trainer = WordPieceTrainer(vocab_size=30522, special_tokens=["[UNK]", "[CLS]", "[SEP]", "[PAD]", "[MASK]"])
#tokenizer.train(list(trnData), trainer)
vghTknzr.train_from_iterator(trnData, trainer=trainer)
#vghTknzr.train_from_iterator(xtrn, trainer=trainer)    #xtrnTknzrOutput=
#stInfo(['trainData', len(trainData), 'trnData=', len(list(trnData))])
#vghTknzr.train_from_iterator(trnData, trainer=trainer)
#vghTknzr.train_from_iterator(batch_iterator(), trainer=trainer, length=len(dataset))
#help(vghTknzr)

session_state['vghTknzr']=vghTknzr
stInfo(['vghTknzr=', vghTknzr.to_str()])    #data vocab
#stWrite(['vghTknzr=', vghTknzr.to_str() ])  #to_str, vocab() xtrnTknzrOutput

xTrain=session_state['xTrain']
#help(vghTknzr)
from transformers import PreTrainedTokenizerFast
#from tokenizers import Tokenizer
#vghTknzr = Tokenizer.from_file('your/save/file.json')
context_length = 128
fastTknzr = PreTrainedTokenizerFast(tokenizer_object=vghTknzr)

xtrn=map(lambda x:x[0], xTrain)
trnTknzrOutput=fastTknzr(list(xtrn), truncation=True, max_length=context_length, return_overflowing_tokens=True, return_length=True)
#help(trnTknzrOutput)
stInfo(['trnTknzrOutput=', trnTknzrOutput.data ])  #to_str, vocab()
#outputs = vghTknzr(xTrain, truncation=True, max_length=context_length, return_overflowing_tokens=True, return_length=True)
#vghTknzr==>"input_ids", "token_type_ids", "attention_mask", "length", "overflow_to_sample_mapping"
