from transformers import Trainer

trainer = Trainer( model=model, args=args,
    train_dataset=tokenized_datasets["train"],
    # train_dataset=tokenized_datasets["train"],
    # eval_dataset=tokenized_datasets["validation"],
    data_collator=data_collator,
    # compute_metrics=compute_metrics,
    tokenizer=tokenizer,
)
trainer.train()
trainer.save_model("./models_2345")


