from streamlit import session_state, code as stCode, info as stInfo, write as stWrite
from sklearn.model_selection import train_test_split
#The input variable is very simple: data, seed, split_ratio. data=>source data, seed=>random seed, it can fix our split result, ratio=>we can set train_size or test_size
try:
    trainData=session_state['trainData']
except:pass
#stInfo([trainData])
trnData, tstData = train_test_split(trainData, random_state=777, train_size=.8)
#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.33, random_state=42)
stInfo([]) #.shapearray([[4, 5], [0, 1], [6, 7]])
#y_test [1, 4]
train_test_split(tstData, shuffle=False) #[[0, 1, 2], [3, 4]]

ratioTest, ratioVal=.8, .1
xRemain, xTest= train_test_split(trainData, test_size=ratioTest)

# Adjusts val ratio, w.r.t. remaining dataset.
ratioRemain = 1 - ratioTest
rValAdjusted = ratioVal/ratioRemain
# Produces train and val splits.
xTrain, xVal= train_test_split(xRemain, test_size=rValAdjusted)
session_state['xTrain']=xTrain
session_state['xVal']=xVal
session_state['xVal']=xVal
session_state['xTest']=xTest
stInfo(['xTest', len(xTest), 'xTrain', len(xTrain), 'xVal', len(xVal)]) #.shape[2, 0, 3] >>> X_test array([[2, 3], [8, 9]])
#X=df['Head Size(cm^3)']
#y=df['Brain Weight(grams)']
# using the train test split function
#testSize, trainSize, rndmState=.25, .8, 104
#X_train, X_test, y_train, y_test = train_test_split(tstData, tstData, random_state=rndmState, test_size=testSize, shuffle=True)
#X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=rndmState, train_size=trainSize, shuffle=True)

#arrays: sequence of indexables. Lists, numpy arrays, scipy-sparse matrices, and pandas dataframes are all valid inputs.
#test_size: int or float, by default None. If float, it should be between .0 and 1. and represent the percentage of the dataset to test split. If int is used, it refers to the total number of test samples. If the value is None, the complement of the train size is used. It will be set to .25 if train size is also None.
#train_size: int or float, by default None.
#random_state : int,by default None. Controls how the data is shuffled before the split is implemented. For repeatable output across several function calls, pass an int.
#shuffle: boolean object , by default True. Whether or not the data should be shuffled before splitting. Stratify must be None if shuffle=False.
#stratify: array-like object , by default it is None. If None is selected, the data is stratified using these as class labels.
