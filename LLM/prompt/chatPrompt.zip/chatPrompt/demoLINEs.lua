local lines = require('tabby.feature.lines')
print(lines.tabs)
