--local dummy='檔名':match("^(.+)%.?.+$")
--local dummy='檔名':match("(.+)%..+")
local fname="檔案名稱."
print(fname:find('%.'))
--local dummy="檔名":match("^(.+)%.?.+$")
--print(dummy)
--("^(.+)%..+$"))
--local winName=win.buf_name():match("^(.+)%..+$")
