def read_ner_txt(path, test_mode=False):
  with open(path, 'r') as f:
    text = f.readlines()
    text = [i.rstrip('\n') for i in text]
  tokens_list=[]
  ner_tags_list=[]
  temp_vocab=''
  temp_label=''
  if test_mode:
    print('test mode') # 對test-submit.txt測試資料進行讀取
    for item in text:
      if item=='.' or item=='': # 斷句的條件有2，句號和空行
        if item=='.':
          vocab=item
          temp_vocab = temp_vocab + ' ' + vocab
          temp_label = temp_label + ' ' + 'O' # 為了滿足dataset格式需求，往裡面隨便填充一個NER-tag，之後也不會用到
        tokens_list.append(temp_vocab)
        ner_tags_list.append(temp_label)
        temp_vocab=''
        temp_label=''
      else:
        vocab=item#.split('\n')[0]
        temp_vocab = temp_vocab + ' ' + vocab
        temp_label = temp_label + ' ' + 'O'
    return tokens_list, ner_tags_list
  else:  # 對train.txt測試資料進行讀取
    for item in text:
      if item.split('\t')[0]=='.' or item=='': # 斷句的條件有2，句號和空行
        if item.split('\t')[0]=='.':
          vocab=item.split('\t')[0] # 人工判讀訓練資料，發現token(vocab)在\t符號前
          label=item.split('\t')[1] # 人工判讀訓練資料，發現ner_tag(label))在\t符號後
          temp_vocab += ' ' + vocab
          temp_label += ' ' + label
        tokens_list.append(temp_vocab)
        ner_tags_list.append(temp_label)
        temp_vocab=''
        temp_label=''
      else:
        vocab=item.split('\t')[0]
        label=item.split('\t')[1]
        temp_vocab += ' ' + vocab
        temp_label += ' ' + label
    return tokens_list, ner_tags_list

if __name__=='__main__':
  tokens_list, ner_tags_list = read_ner_txt('train.txt')
  test_tokens_list, test_ner_tags_list = read_ner_txt('test-submit.txt', test_mode=True)

from datasets import Dataset, ClassLabel, Sequence, Features, Value, DatasetDict
from pandas import DataFrame

def list2Dframe(tokens, nerTags):
  df = DataFrame(zip(tokens, nerTags), columns = ['tokens','ner_tags'])
  assert all(i for i in ['tokens', 'ner_tags'] if i in df.columns) # 這兩個欄位名稱不能改，一定要有

  df = df.dropna()  # pre-processing
  df = df.drop(df[df['tokens']==''].index.values, )
  df = df.reset_index(drop=True)
  df['tokens'] = df['tokens'].map(lambda x: x.strip().split(' ')) # 我的token是一串文字，空白做間隔
  df['ner_tags'] = df['ner_tags'].map(lambda x: x.strip().split(' ')) # 我的ner_tags是一串文字，空白做間隔
  # df.head()
  return df

df = list2Dframe(tokens_list, ner_tags_list)
test_df = list_to_dataframe(test_tokens_list, test_ner_tags_list)

tags = ClassLabel(num_classes=len(tag_name), names=tag_name)
nerTkn = {"ner_tags":Sequence(tags), 'tokens': Sequence(feature=Value(dtype='string'))}

def df2Dset(df, columns=['ner_tags', 'tokens']):
  assert set(['ner_tags', 'tokens']).issubset(df.columns)

  ner_tags = df['ner_tags'].map(tags.str2int).values.tolist()
  tokens = df['tokens'].values.tolist()

  assert isinstance(tokens[0], list)
  assert isinstance(ner_tags[0], list)
  d = {'ner_tags':ner_tags, 'tokens':tokens}  #如果有其他欄位例如id, spans請從這裡添加
  # create dataset
  dataset = Dataset.from_dict(features=Features(nerTkn), mapping=d)
  return dataset

