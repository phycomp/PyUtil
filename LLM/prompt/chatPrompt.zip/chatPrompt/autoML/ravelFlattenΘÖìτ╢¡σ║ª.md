numpy中的ravel flatten squeeze 都有將多維數組 轉換爲一維數組的功能 區別
ravel 如果沒有必要 不會產生源數據的副本
flatten 返回源數據的副本
squeeze 只能對維數爲1的維度降維
另外 reshape1也可以拉平多維數組 這裏寫圖片描述 參見官方文檔 ravel flatten squeeze
python numpy中cumsum的用法詳解
主要介紹了python numpy中cumsum的用法詳解 文中通過示例代碼介紹的非常詳細 對大家的學習或者工作具有一定的參考學習價值 需要的朋友們下面隨著小編來一起學習學習吧
numpy中ravel與flatten的區別 練習機器學習中梯度下降的編程學習中 需要扁平化一個array ravel與flatten 兩個扁平化的函數 他們倆的共功能相同 可是到底有什麼區別呢 先看看兩個函數的使用 我們可以看到這兩個函數實現的功能一樣 但我們在平時使用的時候 繼續訪問
a=np.arange(12).reshape(3,4)
print(a.ravel())  #[0 1 2 3 4 5 6 7 8 9 10 11]
print(a.flatten()) #[0 1 2 3 4 5 6 7 8 9 10 11]
一看就懂ravel flatten squeeze reshape的用法與區別 ravel flatten squeeze三個都有將多維數組轉化爲一維數組的功能
ravel 不會產生原來數據的副本
flatten 返回源數據副本
squeeze 只能對維度爲1的維度降維
reshape1 可以拉平多維數組
PyTorch中還有view也有reshape的效果
下面我一個一個來對比 ravel arr nparange12 繼續訪問
NumPy中 ravel 和 flatten 展平數組 對比
共享內存 因此如果您更改其中一個的值 另一個的值也會更改 在副本的情況下 為每個分配內存 因此它們彼此分開處理 到目前為止的示例是針對二維數組的 但是可以用相同的方式展平三維或更多維的多維數組 例如 如果具有指定步長的切片被展平并且內存中的步幅不恒定 則也返回一個副本 您可以指定一個所謂的類數組對象 例如 Python 的內置 在副本的情況下 為每個分配內存 因此它們彼此分開處理 因此如果您更改其中一個的值 另一個的值也會更改 盡可能返回視圖 但在某些情況下 它們會返回副本 在視圖的情況下 它與原始
