sklearn.linear_model.Perceptron參數解釋 用于創建感知機模型時傳遞的參數。

參數名稱參數取值參數解釋
penalty	默認=None，即不加懲罰項，‘l2’（L2正則） or ‘l1’（L1正則） or ‘elasticnet’（混合正則）	懲罰項，加上懲罰項主要爲了避免模型過拟合風險
alpha	默認=0.0001，取值爲浮點數	如果penalty不爲None，則正則化項需要乘上這個數
l1_ratio	默認=0.15，取值在[0,1]	一般只在penalty=elasticnet時用，當l1_ratio =0就是L2正則，當l1_ratio =1就是L1正則，當在(0,1)之間就是混合正則
fit_intercept	bool值，默認=True	是否對參數 截距項b進行估計，若爲False則數據應是中心化的
max_iter	int整數，默認=1000	最大迭代次數，哪怕損失函數依舊大于0
tol	float or None，默認=10^(-3)	迭代停止的標準。如果不爲None，那麼當loss-pre-loss\<tol 的時候，就會停止迭代。因爲當前迭代造成的損失函數下降太小了，迭代下去對loss影響不大了。
shuffle	bool值，默認=True	每輪訓練後是否打亂數據
verbose	取值爲整數，默認=0	verbose = 0 爲不在標準輸出流輸出日志信息，verbose = 1 爲輸出進度條記錄；verbose = 2 爲每個epoch輸出一行記錄
eta0	取值雙精度浮點型double，默認=1	學習率，決定梯度下降時每次參數變化的幅度
n_jobs	取值爲 int or None，默認=None	在多分類時使用的CPU數量，默認爲None（或1），若爲-1則使用所有CPU
random_state	取值爲int, RandomState instance or None，默認=None	當 shuffle =True時，用于打亂訓練數據
n_iter_no_change	取值int，默認=5	在提前停止之前等待驗證分數無改進的迭代次數，用于提前停止迭代
early_stopping	取值bool值，默認=False	當驗證得分不再提高時是否設置提前停止來終止訓練。若設置此項，當驗證得分在n_iter_no_change輪內沒有提升時提前停止訓練
class_weight	取值爲dict, {class_label: weight} 或者 “balanced”或者None，默認=None	用于拟合參數時，每一類的權重是多少。當爲None時，所有類的權重爲1，等權重；當爲balanced時，某類的權重爲該類頻數的反比，當爲字典時，則key爲類的標簽，值爲對應的權重
warm_start	取值爲bool，默認=False	若爲True則調用前一次設置的參數，使用新設置的參數
2. sklearn.linear_model.Perceptron屬性解釋 屬性名稱屬性的類型屬性解釋
classes_	array 一維數組，shape=(k,) ,k爲y的類別數量	放著y所有分類的數組，如感知機是array([-1., 1.])
coef_	array 二維數組	輸出訓練後的模型參數w的數組，不包含截距項b。當爲二分類時，該數組shape=(1,n)，n爲特征數量。當爲多分類時shape=（k, n)
intercept_	array 一維數組	輸出訓練後的模型截距b的數組。當爲二分類時，該數組shape=(1,)。當爲多分類時shape=（k, )
loss_function_	損失函數的類別	即用的哪種損失函數來定義模型輸出值與真實值之間的差異
n_iter_	整數	即模型停止時共迭代的次數
t_	整數	模型訓練時，權重w更新的總次數，等于n_iter_*樣本數量
3. sklearn.linear_model.Perceptron實戰
這裏選取sklearn內置數據庫的iris(鸢尾屬植物)數據集進行實戰演練。

import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
from sklearn.linear_model import Perceptron
# %matplotlib notebook
將數據存儲到dataframe中：

iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['label'] = iris.target
df
結果如下：
在這裏插入圖片描述
總共有4個特征——sepal花萼的長寬以及petal花瓣的長寬，但是爲了更直觀的觀察數據，這裏只取花萼的長寬這兩個特征進行這次練習，并且感知機是二分類模型，所以只選取前100行（只包含0、1兩類）。

df = df.iloc[:100, [0, 1, -1]]
df.columns = ['sepal_length', 'sepal_width', 'label']
df
結果如下:
在這裏插入圖片描述
畫出圖形：

plt.figure()
plt.scatter(df.iloc[:50, 0], df.iloc[:50,1], label='0')
plt.scatter(df.iloc[50:100, 0], df.iloc[50:100,1], label='1')
plt.xlabel('sepal_length')
plt.ylabel('sepal_width')
plt.legend()
在這裏插入圖片描述 直觀上感覺是線性可分的。提取出特征與輸出值,將標簽0改爲-1。

data = np.array(df)
X, y = data[:,:-1], data[:,-1]
y[y==0] = -1
使用sklearn.linear_model.Perceptron創建感知機模型，并求出參數

from sklearn.linear_model import Perceptron
perceptron = Perceptron(fit_intercept=True, max_iter=1000, shuffle=True)
perceptron.fit(X, y)  # 默認學習率爲1
w = perceptron.coef_[0]  # ,注意輸出的是二維數組，加上[0]後， w=[ 23.2 -38.7]
b = perceptron.intercept_  # b=-5
畫出拟合好的圖形，觀察是否正确分類

fig = plt.figure()
x_ticks = np.linspace(4.3,7,10)
ax = plt.subplot(1,1,1)
ax.set_xticks(x_ticks)
ax.set_xlim(4.2,7.1)
ax.set_ylim(1.9,4.5)
ax.set_xlabel('sepal_length')
ax.set_ylabel('sepal_width')
plt.scatter(df.iloc[:50, 0], df.iloc[:50,1], label='0')
plt.scatter(df.iloc[50:100, 0], df.iloc[50:100,1], label='1')
plt.plot(x_ticks, (w[0]*x_ticks + b)/(-w[1]))
plt.legend(loc = 'best')
結果如下：
在這裏插入圖片描述
謝謝閱讀，歡迎大家多多進行交流或指出問題。
