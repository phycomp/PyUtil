  if menu==MENUs[-4]:
    'nerTagger'
    from nlpViterbi.nerTagger import HMM
    from streamlit import text_area, code as stCode, session_state
    text='''20170726 Colonoscopy from retum to cecum showed diverticulosis of whole
colon and a 4cm lateral spreading tumor growth with a small daughter
polyp in transverse colon. The lateral spreading tumor growth was
removed by endoscopic piecemeal mucosal resection. The mucosal defect
was approximated with 9 endoclips.'''
    文本=text_area('文本', text)
    result = nerAnntt( "How many bats?", 文本=文本)
    from nlpViterbi.nerTagger import HMM
    hmm=HMM()
    orgENT, cntxt=[], 文本.replace('\n', ' ')
    hmm.DOC=hmm.nlp(cntxt)
    ENT={'entities':[(9, 20, 'Procedure'), (26, 31, 'Position2'), (35, 40, 'Position2'), (88, 111, 'LSTs'), (141, 146, 'Classification'), (150, 166, 'Position2'), (218, 256, 'pEMR')]}
    for start, end, label in ENT['entities']:
      span = hmm.DOC.char_span(start, end, label=label)  #, alignment_mode="contract"
      if span:
        #orgENT.append((start, end, label))
        orgENT.append(span)
    #stCode(['orgENT', orgENT])
    session_state['docENT']=hmm.DOC.ents=orgENT
    #stCode(['ENT', list(hmm.DOC.ents)])  #])  #'|'.join([ent.text, ent.label_ for ent in doc.ents])
    rsltFmt=[]
    for tkn in hmm.DOC:
      if tkn.ent_type_:
          outFmt='-'.join([tkn.ent_iob_, tkn.ent_type_])
          #print(tkn.text, )#tkn.ent_kb_id, tkn.ent_id, tkn.ent_iob, tkn.ent_type, tkn.ent_kb_id_, tkn.ent_id_, )
      else:
          outFmt=tkn.ent_iob_
      rsltFmt.append(' '.join([tkn.text, outFmt]))
    rsltTkn=''
    for tknInfo in rsltFmt:
      rsltTkn+=tknInfo+'\n'
    hmm.DOC=hmm.nlp(cntxt)
    hmm.tag()
    stCode(['allTag', hmm.allTag])
    stCode(['hmm.tranProb', hmm.tranProb])
    stCode(['hmm.emssnProb', hmm.emssnProb])
    if 文本:
      cntxt=文本.replace('\n', ' ').split()
      stCode(['cntxt', cntxt])
      bckProp=hmm.vertibi(cntxt, hmm.allTag)#hmm.DOC.ents)
      stCode('bckProp', bckProp)
  elif menu==MENUs[-1]:
    '''viterbi'''
    from streamlit import text_area, session_state, code as stCode
    from nlpViterbi.labelRare import prcssRARE
    from io import StringIO
    devCntxt='''The specimen is received in 4 parts. Part (A) consists of an opened colon, measuring 15 x 7 cm, with attached terminal ileum, 4 x 2 cm, appendix, 5 x 0.5 x 0.4 cm. An ulcerative tumor, 5 x 4.5 cm, is noted 4 cm from the distal cut end. Proximal dilatation of the colon is not noted. There is no serosal retraction or fibrosis noted. There is no polyp found in the non-tumor part of the mucosal surface. Parts (B) and (C) consist of two segments of intestines, labelled proximal and distal cut ends respectively. Parts (D) to (I) consist of soft tissue, labelled lymph nodes of area labelled as above. Part (J) consists of a piece of omentum, measuring up to 14 x 6 x 0.6 cm. Representative parts of the specimen are taken for sections in 14 blocks. (AB:Proximal and distal cut ends. C:Appendix. D-G:Tumor, F-for the deepest invasion. H-M:pericolic lymph nodes grouped and labeled by surgeon. N:Omentum. Immunohistochemical stains for BRAF and MMR proteins are performed on F.) (LWY)'''
    devCntxt=text_area('dev文本', devCntxt)
    WORDTAG=session_state['WORDTAG']
    WORDTAG=''.join(WORDTAG)
    emssnBffr=StringIO(WORDTAG)
    rareWord=prcssRARE(emssnBffr)
    stCode(['rareWord', rareWord])
    ngramOut=session_state['ngramOut']
    ngramOut=''.join(ngramOut)
    ngramBuffer=StringIO(ngramOut)
    if devCntxt:
      #session_state['devCntxt']=devCntxt
      devCntxt=devCntxt.replace('\n', ' ')
      devBuffer=StringIO(devCntxt)
      #stCode(devCntxt)
      from nlpViterbi.viterbi import count as vtbCount
      vtbOut=vtbCount(emssnBffr, ngramBuffer, devBuffer)
      stCode(['vtbOut', vtbOut])
  elif menu==MENUs[-2]:
    'BILUO'
    from streamlit import text_area, code as stCode, write as stWrite, session_state
    from spacy import blank as spcyBlnk
    text='''20170726 Colonoscopy from retum to cecum showed diverticulosis of whole
colon and a 4cm lateral spreading tumor growth with a small daughter
polyp in transverse colon. The lateral spreading tumor growth was
removed by endoscopic piecemeal mucosal resection. The mucosal defect
was approximated with 9 endoclips.'''
    文本=text_area('文本', text)
    result = nerAnntt( "How many bats?", 文本=文本)
    orgENT, nlp, cntxt=[], spcyBlnk('en'), 文本.replace('\n', ' ')
    doc=nlp(cntxt)
    ENT={'entities':[(9, 20, 'Procedure'), (26, 31, 'Position2'), (35, 40, 'Position2'), (88, 111, 'LSTs'), (141, 146, 'Classification'), (150, 166, 'Position2'), (218, 256, 'pEMR')]}
    for start, end, label in ENT['entities']:
      span = doc.char_span(start, end, label=label)  #, alignment_mode="contract"
      if span:
        #orgENT.append((start, end, label))
        orgENT.append(span)
    stCode(['orgENT', orgENT])
    session_state['docENT']=doc.ents=orgENT
    stCode(['ENT', list(doc.ents)])  #])  #'|'.join([ent.text, ent.label_ for ent in doc.ents])
    rsltFmt=[]
    for tkn in doc:
      if tkn.ent_type_:
          outFmt='-'.join([tkn.ent_iob_, tkn.ent_type_])
          #print(tkn.text, )#tkn.ent_kb_id, tkn.ent_id, tkn.ent_iob, tkn.ent_type, tkn.ent_kb_id_, tkn.ent_id_, )
      else:
          outFmt=tkn.ent_iob_
          #print(tkn.text, tkn.ent_iob_)
      rsltFmt.append(' '.join([tkn.text, outFmt]))
    #stCode(rsltFmt)
    from nlpViterbi.count_freqs import Hmm
    from io import StringIO
    rsltTkn=''
    for tknInfo in rsltFmt:
      rsltTkn+=tknInfo+'\n'
    stCode(rsltTkn)
    tknBffr=StringIO(rsltTkn)
    hmm = Hmm(3)
    hmm.train(tknBffr)
    wordTag, ngramOut, outFMT=hmm.write_counts()
    session_state['WORDTAG']=wordTag
    session_state['ngramOut']=ngramOut
    session_state['outFMT']=outFMT
    stCode(['wordTag', wordTag])
    stCode(['ngramOut', ngramOut])
    stCode(['ENT', doc.ents])

  elif menu==MENUs[-3]:
    from streamlit import sidebar, text_area, code as stCode, write as stWrite
    #from spacy_streamlit import process_text

    #spacy_model = sidebar.selectbox("Model name", ["en_core_web_sm", "en_core_web_md"])
    cntxt = text_area("Text to analyze", "This is a text")
    #doc = process_text(spacy_model, cntxt)
    from flair.embeddings import WordEmbeddings, FlairEmbeddings, StackedEmbeddings
    from flair.data import Sentence
    # create a StackedEmbedding object that combines glove and forward/backward flair embeddings
    stckedEmbddngs = StackedEmbeddings([WordEmbeddings('glove'), FlairEmbeddings('news-forward'), FlairEmbeddings('news-backward') ])
    #That's it! Now just use this embedding like all the other embeddings, i.e. call the embed() method over your sentences.
    stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)

    from flair.embeddings import WordEmbeddings, DocumentPoolEmbeddings
    gloveEmbddng = WordEmbeddings('glove')
    docEmbddngs = DocumentPoolEmbeddings([gloveEmbddng])
    cntxt=cntxt.replace('<br>', ' ')
    stCode(cntxt)
    #import gensim
    #word_vectors = gensim.models.KeyedVectors.load_word2vec_format('/path/to/fasttext/embeddings.txt', binary=False)
    #word_vectors.save('/path/to/converted')
    from gensim.models import Word2Vec
    from pathlib import Path

    mdl = Word2Vec(sentences=cntxt, vector_size=100, window=5, min_count=1, workers=4)
    absPath=Path(__file__).parent
    crrntFile=str(absPath/"lngMDLtrain.WV.mdl")
    stCode(crrntFile)
    mdl.wv.save_word2vec_format(crrntFile)
    #cstmEmbddng = WordEmbeddings('path/to/your/custom/embeddings.gensim')
    #import gensim
    #word_vectors = gensim.models.KeyedVectors.load_word2vec_format('/path/to/fasttext/embeddings.txt', binary=False)
    #word_vectors.save('/path/to/converted')

    #sentence = Sentence(cntxt)
    # just embed a sentence using the StackedEmbedding as you would with any single embedding.
    #stckedEmbddngs.embed(sentence)
    #document_embeddings.embed(sentence)
    #print(sentence.embedding)
    #emddngInfo=[]
    #for token in sentence:
    #  emddngInfo.append([token, token.embedding])
    #stCode(['sentence.embedding', emddngInfo, sentence.embedding])

  #elif menu==MENUs[-1]:

