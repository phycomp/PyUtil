from sentence_transformers import SentenceTransformer, util
model = SentenceTransformer('distilbert-base-nli-stsb-mean-tokens')

# Two lists of sentences
sentences1 = ['The cat sits outside', 'A man is playing guitar', 'The new movie is awesome']

sentences2 = ['The dog plays in the garden', 'A woman watches TV', 'The new movie is so great']

#Compute embedding for both lists
embeddings1 = model.encode(sentences1, convert_to_tensor=True)
embeddings2 = model.encode(sentences2, convert_to_tensor=True)

#Compute cosine-similarits
cosine_scores = util.pytorch_cos_sim(embeddings1, embeddings2)

#Output the pairs with their score
for i in range(len(sentences1)):
    print("{} \t\t {} \t\t Score: {:.4f}".format(sentences1[i], sentences2[i], cosine_scores[i][i]))

from sentence_transformers import SentenceTransformer, models
from sentence_transformers.models import Transformer, Pooling
wrdMbddngMdl = Transformer('bert-base-uncased', max_seq_length=256)
plngMdl = Pooling(wrdMbddngMdl.get_word_embedding_dimension())
mdlLM = SentenceTransformer(modules=[wrdMbddngMdl, plngMdl])

from sentence_transformers import SentenceTransformer
from sentence_transformers.models import Transformer, Pooling, Dense
from torch.nn import Tanh as trchTanh

wrdMbddngMdl = Transformer('bert-base-uncased', max_seq_length=256)
plngMdl = Pooling(word_embedding_model.get_word_embedding_dimension())
dnseMdl = Dense(in_features=plngMdl.get_sentence_embedding_dimension(), out_features=256, activation_function=trchTanh())
mdlLM = SentenceTransformer(modules=[wrdMbddngMdl, plngMdl, dnseMdl])
