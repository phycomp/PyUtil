from spacy import load
nlp=load('en_ner_bionlp13cg_md')
breastInfo='''PATHOLOGICAL DIAGNOSIS:
1. Breast, right, excisional biopsy
   --- Invasive ductal carcinoma
2. Lymph nodes, right sentinel (2), biopsy
   --- No pathological diagnosis
3. Lymph nodes, sentinel (3), biopsy
   --- No pathological diagnosis (S99-19609)
GROSS FINDING:
The specimen fixed in formalin consists of a piece of stitches
orientated breast tissue, measuring 6x3.5x1.5 cm in size.
There is defective induration, measuring 1.1x0.6x0.5 cm in
size, 0.5 cm from the most close superficial margin.  The
margins are inked (yellow:superficial, purple:base) and taken
as perpendicular sections.  Three tissue labeled lymph node,
3x2x1 cm in size are also submitted.  Representative sections
are taken and labeled as A:3', B:6', C:9', D:12 o'clock margin,
E-H:tumor & breast, I:LN.  Immunohistochemical stains for tau,
MIB-1, neu, estrogen receptor (ER) and progesterone receptor
(PR) are done.  (HCY)'''
doc=nlp(breastInfo)
from spacy import displacy
displacy.render(next(doc.sents), style='dep', jupyter=True)
