
cont = GameLogic.getCurrentController();
obj = cont.getOwner();
mesh = obj.getMesh();
vertex = [0,0,0,0];

## This is a way to get each individual vertex to set the UV mapping

for x in range(4):
    vertex[x] = mesh.getVertex(0,x);

if not hasattr(obj,"spriteWidth"):
    obj.spriteWidth = abs(vertex[0].getUV()[0] - vertex[2].getUV()[0]);
    obj.spriteHeight = abs(vertex[0].getUV()[1] - vertex[1].getUV()[1]);

## I'll generally only use exact squares (e.g. 4 64x64 subimages on a 256x256 image),
## but I've decided to go with both a width and height variable for uneven images.
## The number for each is obtained by dividing the total number of sprite
## frames available on the sprite sheet (the same either way to equal a square
## sheet) by one. For example, if you can fit 4 images on a 64x64 image, and each
## sprite is equal-sized and takes up the most space, then you would end up with
## even 32x32 images, or images whose sizes equal 0.5 each way.

if hasattr(obj,"currentAnim"): ## Note the object won't play if there isn't any "currentAnim" variable to tell it which animation variable to play from
        
    if not obj.currentAnim == "":    
        anim = eval("obj." + obj.currentAnim); ## Note the use of the "eval" function to take the string from the "currentAnim" variable for reading
        
        if obj.subimage &gt; len(anim) - 1:
            obj.subimage = 1;
            
        if obj.spriteSpeed &gt; 0:    ## Note the object must have a "spritePlay" variable to tell if the sprite is playing or paused
            
            if obj.changeWait &gt; 1.0 / (GameLogic.getLogicTicRate() * obj.spriteSpeed):
                
                if obj.subimage &lt; len(anim) - 1: ## If the current sprite frame is less than the finishing one, step through the frame
                    obj.subimage += 1;
                else:                          ## Otherwise, set the frame back to the beginning
                    obj.subimage = 1;
                
                obj.changeWait = 0;
        ## This below is pretty much the only way to get the info from the vertices
        ## When viewing a plane so that the sprite appears straight on:
        ## Vertex 0 = Top-Right
        ## Vertex 1 = Bottom-Right
        ## Vertex 2 = Bottom-Left
        ## Vertex 3 = Top-Left
        ## I believe this has to do with culling, which apparently takes place 
        ## clockwise here
        
        vertex[0].setUV([obj.spriteWidth + (obj.spriteWidth * anim[0]),obj.spriteWidth + (obj.spriteWidth * anim[obj.subimage])]);
        vertex[1].setUV([obj.spriteWidth * anim[0],obj.spriteWidth + (obj.spriteWidth * anim[obj.subimage])]);
        vertex[2].setUV([obj.spriteWidth * anim[0],obj.spriteWidth * anim[obj.subimage]]);
        vertex[3].setUV([obj.spriteWidth + (obj.spriteWidth * anim[0]),obj.spriteWidth * anim[obj.subimage]]);
