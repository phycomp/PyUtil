#!/usr/bin/env python
# coding: utf-8

# # Spacy Classification Model from Scratch

# ## Data Preparation

# In[1]:


get_ipython().run_line_magic('load_ext', 'autoreload')
get_ipython().run_line_magic('autoreload', '2')


# In[2]:


import numpy as np
import pandas as pd
from IPython.display import display
import seaborn as sns
import matplotlib.pyplot as plt
import os

from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split

pd.set_option('max_colwidth',1000)
pd.options.display.float_format = '{:.2f}'.format

get_ipython().run_line_magic('matplotlib', 'inline')


# ### Read in file

# In[3]:


dir_path = '../Playground-dataset/05-Try-out-Spacy-Pretrain-dataset'

df_raw = pd.read_csv(os.path.join(dir_path, 'consumer_complaints.csv'))
df_raw = df_raw[pd.notnull(df_raw['consumer_complaint_narrative'])]

# How's the dataset like?
display(df_raw.info())


# ### Filter on Text and Label

# In[4]:


# Filter on text and label.
df = df_raw[['product','consumer_complaint_narrative']]


# Experiment on smaller subset.
df = df[:5000]
df = df.reset_index(drop=True)


# In[5]:


from UtilTextClassification import plot_freq

# Label distributed fequency.
plot_freq(df, col=['product'], top_classes=30)


# In[6]:


print('Demo of product and its complaint example...')
df.head()


# ### Prepare Train/Valid/Testing Dataset

# In[7]:


print('Unique values of labels...')
display(list(df['product'].unique()))


# In[8]:


from UtilTextClassification import split_size


# Select label and label value.
col = 'product'
col_vals = list(df[col].unique())
text_col = 'consumer_complaint_narrative'

# Select number of data.
train_num, valid_num, test_num = split_size(df, train=0.6, valid=0.2)


# In[9]:


# Prepare test dataset.
train_X, test_X, train_y, test_y = train_test_split(df[text_col],
                                                df[col],
                                                test_size=test_num,
                                                random_state=1,
                                                stratify=df[col])

# Prepare valid dataset.
if valid_num != 0:
    train_X, valid_X, train_y, valid_y = train_test_split(train_X,
                                                  train_y,
                                                  test_size=valid_num,
                                                  random_state=1,
                                                  stratify=train_y)


print('Shape of train_X: {}'.format(train_X.shape))
print('Shape of valid_X: {}'.format(valid_X.shape if 'valid_X' in vars() else (0,0)))
print('Shape of text_X: {}'.format(test_X.shape))


# ## Convert Dataset to Spacy Compatible Format
# 
# <mark>**Label and Text**</mark>

# In[10]:


# One-hard-encode label.
train_y_df = pd.get_dummies(train_y)
valid_y_df = pd.get_dummies(valid_y)
test_y_df = pd.get_dummies(test_y)


# In[11]:


print('One-hard-encoded label...')
display(train_y_df.head())


# In[12]:


from UtilTextClassification import df2list



# Convert to list.
train_ls = df2list(train_X, train_y_df)
valid_ls = df2list(valid_X, valid_y_df)
test_ls = df2list(test_X, test_y_df)


# In[13]:


print('Preview of training list for Spacy...')
display(train_ls[:2])


# ## Separate Text and Label on Valid/Test Dataset
# 
# For the ease of evaluating model's performance later on, I split labels and texts apart on both valid and text set. 

# In[14]:


# Convert valid text and label to list.
valid_text, valid_label = list(zip(*valid_ls))


# In[15]:


# Convert test text and label to list.
test_text, test_label = list(zip(*test_ls))


# In[16]:


print('Demo of how valid_text is like?')
display(valid_text[:1])


# In[17]:


print('Demo of how valid_label is like?')
display(valid_label[:1])


# ## Construct Spacy Classifier

# In[18]:


import spacy
nlp = spacy.load('en_core_web_lg')


# In[19]:


if 'textcat' not in nlp.pipe_names:
    textcat = nlp.create_pipe('textcat')
    nlp.add_pipe(textcat, last=True)
# otherwise, get it, so we can add labels to it
else:
    textcat = nlp.get_pipe('textcat')


# In[20]:


# add label to text classifier
for _, col_val in enumerate(col_vals):
    textcat.add_label(col_val)

print(textcat.labels)


# ## Train

# In[21]:


from spacy.util import minibatch, compounding
from sklearn.metrics import f1_score, accuracy_score, classification_report
import random

import warnings 
warnings.simplefilter('ignore')


# In[22]:


# Path of saved model

output_dir = os.path.join(dir_path,'spacy-saved-model')


# In[23]:


n_iter = 20
print_every= 1
not_improve = 5 




# Train model
other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'textcat']
with nlp.disable_pipes(*other_pipes):  # only train textcat
    optimizer = nlp.begin_training() # initiate a new model with random weights
    print("Training the model...")
    
    score_f1_best = 0
    early_stop = 0
    
    for i in range(n_iter):
        losses = {}
        true_labels = list() # true label
        pdt_labels = list() # predict label
        
        # batch up the examples using spaCy's minibatch
        random.shuffle(train_ls)  # shuffle training data every iteration
        batches = minibatch(train_ls, size=compounding(4., 32., 1.001))
        for batch in batches:
            texts, annotations = zip(*batch)
            nlp.update(texts, annotations, sgd=optimizer, drop=0.2,
                       losses=losses)
            
        with textcat.model.use_params(optimizer.averages): 
            # evaluate on valid_text, valid_label
            docs = [nlp.tokenizer(text) for text in valid_text]
            
            for j, doc in enumerate(textcat.pipe(docs)):
                true_series = pd.Series(valid_label[j]['cats'])
                true_label = true_series.idxmax()  # idxmax() is the new version of argmax() 
                true_labels.append(true_label)
    
                pdt_series = pd.Series(doc.cats)
                pdt_label = pdt_series.idxmax()  # idxmax() is the new version of argmax() 
                pdt_labels.append(pdt_label)
                
            score_f1 = f1_score(true_labels, pdt_labels, average='weighted')
            score_ac = accuracy_score(true_labels, pdt_labels)
            
            if i % print_every == 0:
                print('textcat loss: {:.4f}\tf1 score: {:.3f}\taccuracy: {:.3f}'.format(
                    losses['textcat'],score_f1, score_ac))
            
            if score_f1 > score_f1_best:
                early_stop = 0
                score_f1_best = score_f1
                with nlp.use_params(optimizer.averages):
                    nlp.to_disk(output_dir) # save the model
            else:
                early_stop += 1
            
            if early_stop >= not_improve:
                print('Finished training...')
                break
            
            if i == n_iter:
                print('Finished training...')


# In[ ]:


# Load saved model.
print("Loading from", output_dir)
nlp = spacy.load(output_dir)


# ## Test Model

# In[25]:


from UtilTextClassification import evaluate


# ### On Validation Dataset 

# In[26]:


# Test dataset evaluation.
evaluate(nlp, valid_text, valid_label, label_names=None)


# ### On Test Dataset

# In[28]:


evaluate(nlp, test_text, test_label, label_names=None)


# ### Demo of Prediction

# In[29]:


doc = nlp(test_text[0])
print(doc)


# In[30]:


print('label probabilities...', doc.cats)


# In[31]:


print('true label...', test_label[0])


# # Spacy Model Using Pre-train

# ## Construct Pre-train Spacy Classifier

# In[37]:


import spacy
nlp = spacy.load('en_core_web_lg')


# In[38]:


if 'textcat' not in nlp.pipe_names:
    textcat = nlp.create_pipe('textcat',
                              config={'architecture':'simple_cnn',
                              'exclusive_classes':True})
    nlp.add_pipe(textcat, last=True)
# otherwise, get it, so we can add labels to it
else:
    textcat = nlp.get_pipe('textcat')


# In[39]:


# add label to text classifier
for _, col_val in enumerate(col_vals):
    textcat.add_label(col_val)

print(textcat.labels)


# In[40]:


output_dir = os.path.join(dir_path, 'spacy-saved-model-with-pretrain')
pretrain_model_path = os.path.join(dir_path, 'model500.bin')


# ## Train

# In[41]:


n_iter = 20
print_every= 1
not_improve = 5





# Train model
other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'textcat']
with nlp.disable_pipes(*other_pipes):  # only train textcat
    optimizer = nlp.begin_training() # initiate a new model
    
    with open(pretrain_model_path, 'rb') as file_:
        textcat.model.tok2vec.from_bytes(file_.read()) # load in pre-train word embedding
    
    print("Training the model...")
    
    score_f1_best = 0
    early_stop = 0
    
    for i in range(n_iter):
        losses = {}
        true_labels = list() # true label
        pdt_labels = list() # predict label
        
        random.shuffle(train_ls)  # shuffle training data every iteration
        # batch up the examples using spaCy's minibatch
        batches = minibatch(train_ls, size=compounding(4., 32., 1.001))
        for batch in batches:
            texts, annotations = zip(*batch)
            nlp.update(texts, annotations, sgd=optimizer, drop=0.2,
                       losses=losses)
            
        with textcat.model.use_params(optimizer.averages):
            # evaluate on valid_text and valid_label
            docs = [nlp.tokenizer(text) for text in valid_text]
            for j, doc in enumerate(textcat.pipe(docs)):
                true_series = pd.Series(valid_label[j]['cats'])
                true_label = true_series.idxmax()  # idxmax() is new version of argmax()
                true_labels.append(true_label)
    
                pdt_series = pd.Series(doc.cats)
                pdt_label = pdt_series.idxmax()  # idxmax() is new version of argmax()
                pdt_labels.append(pdt_label)
                
            score_f1 = f1_score(true_labels, pdt_labels, average='weighted')
            score_ac = accuracy_score(true_labels, pdt_labels)
            
            if i % print_every == 0:
                print('textcat loss: {:.3f}\tf1 score: {:.3f}\taccuracy: {:.3f}'.format(
                    losses['textcat'],score_f1, score_ac))
            
            if score_f1 > score_f1_best:
                early_stop = 0
                score_f1_best = score_f1
                with nlp.use_params(optimizer.averages):
                    nlp.to_disk(output_dir) # save the model
            else:
                early_stop += 1
            
            if early_stop >= not_improve:
                print('Finished training...')
                break


# In[ ]:


# Load saved model.
print("Loading from", output_dir)
nlp = spacy.load(output_dir)


# ## Test Model

# ### On Validation Dataset

# In[43]:


# Test dataset evaluation.
evaluate(nlp, valid_text, valid_label, label_names=None)


# ### On Test Dataset

# In[44]:


evaluate(nlp, test_text, test_label, label_names=None)


# # (Appendix) Create Pre-train Dataset for Spacy

# In[45]:


import srsly
import pandas as pd
import os


# In[46]:


# Read in dataset.
dir_path = '../Playground-dataset/05-Try-out-Spacy-Pretrain-dataset'
dataset = pd.read_csv(os.path.join(dir_path,'consumer_complaints_simple.csv'), header=0, index_col=None)
dataset = dataset[['product', 'consumer_complaint_narrative']]
display(dataset.head(n=2))


# In[47]:


# Experiment on smaller subset.
dataset = dataset[:5000]
dataset = dataset.reset_index(drop=True)


# In[48]:



texts = list(dataset['consumer_complaint_narrative'])  # only use training dataset as pre-train dataset
display(texts[:2])


# In[49]:


# Create Spacy compatible format
final_ls = []
for doc in texts:
    final_ls.append({'text':doc})


# In[50]:


final_ls[:2]


# In[51]:


# data = [{"text": "Some text"}, {"text": "More..."}]
srsly.write_jsonl(os.path.join(dir_path,"text.jsonl"), final_ls)


# In[ ]:




