import numpy as np
import csv
import sys
from scipy.spatial.distance import cosine

vec_file = list(csv.reader(open("en_de_model_2.vec"), delimiter=" "))
vec_file = [i[0:-1] for i in vec_file[1:]]

words = [i[0] for i in vec_file]
vectors = [list(map(float, i[1:])) for i in vec_file]

word_vectors = dict(list(zip(words, vectors)))

a = np.array(word_vectors[sys.argv[1]])
b = np.array(word_vectors[sys.argv[2]])
c = np.array(word_vectors[sys.argv[3]])

final_vector = a - b + c
closest_word = ""
closest_score = 10

for word in word_vectors:
    dist = cosine(word_vectors[word], final_vector)
    if dist < closest_score:
        if word == sys.argv[1]:
            continue
        if word == sys.argv[2]:
            continue
        if word == sys.argv[3]:
            continue
        closest_score = dist
        closest_word = word

print "Final word: " + closest_word