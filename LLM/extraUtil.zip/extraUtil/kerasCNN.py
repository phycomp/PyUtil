Step 3 - Flatten 將feature maps攤平放入一個向量中
model.add(Flatten())

Step 4 - Fully Connected Networks
前面一開始建了32個feature maps, 之後conv, max-pool, flatten 後得到大型的vector(有很多input node)，所以這邊隱藏層的node數目不能太小，太小可能模型不好，太大可能會花費巨大運算資源。這篇暫時先設定為128個node。
參數的設定依據不同的任務而調整，提醒大家在 NN 的參數調校中，沒有一個完美的參數配置。由於本次任務是二元分類，辨識是貓或是狗，所以輸出層用sigmoid function，output node 為 1。（註：在[魔法陣系列] 王者誕生：AlexNet 之術式解析中有提到sigmoid的功能。）
model.add(Dense(output_dim = 128, activation = 'relu'))
model.add(Dense(output_dim = 1, activation = 'sigmoid'))

Step 5 - Compiling the CNN
optimizer是選擇優化梯度下降的演算法，使用adam（註：[精進魔法]Optimization：優化深度學習模型的技巧（中）提到Adam是實務上常用的方法。）
loss是選擇loss function，這邊使用binary_crossentropy最後一個是選擇performance metric
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

Step 6 - Fitting the CNN to the images
透過 ImageDataGenerator 做 data augmentation 來減少 overfitting
from keras.preprocessing.image import ImageDataGenerator
train_datagen = ImageDataGenerator(rescale = 1./255, shear_range = .2, zoom_range = .2, horizontal_flip = True)
test_datagen = ImageDataGenerator(rescale = 1./255)
training_set = train_datagen.flow_from_directory('dataset/training_set', target_size = (128, 128), batch_size = 32, class_mode = 'binary')
test_set = test_datagen.flow_from_directory('dataset/test_set', target_size = (128, 128), batch_size = 32, class_mode = 'binary')
model.fit_generator(training_set, samples_per_epoch = 400, nb_epoch = 30, validation_data = test_set, nb_val_samples = 100)

Step 7 - Making new predictions
輸入一張圖，看模型的預測是否正確的程式
import numpy as np
from keras.preprocessing import image
test_image = image.load_img('dataset/single_prediction/cat_or_dog_1.jpg', target_size = (128, 128))
test_image = image.img_to_array(test_image)
test_image = np.expand_dims(test_image, axis = 0)
result = model.predict(test_image)
training_set.class_indices
if result[0][0] == 1: prediction = 'dog'
else: prediction = 'cat'
