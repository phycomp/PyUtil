import spacy
def custom_sentencizer(doc):
    for t in doc:
        # Rules to mark the current token explicit as 'is_sent_start'
        if (t.i == 0) or (                          # First token is always is_sent_start
                t.i < (len(doc) - 1) and            # Last token can't be is_sent_start
                t.nbor(-1).is_punct and             # Previous token is_punct AND
                not t.nbor(-1).is_left_punct and    # Previous token is not is_left_punct AND
                not t.nbor(-1).text == "," and      # Previous token is not a comma AND
                not t.nbor(-1).text == ":" and (    # Previous token is not a colon
                        (t.is_left_punct and        # Token is_left_punct AND
                         t.nbor(1).is_title) or     # Next token is_title
                        ((t.is_title or             # Token is_title OR
                          t.is_upper)))):           # Token is_upper AND
            t.is_sent_start = True
        else:
            t.is_sent_start = False
    
    return doc

test_text = u"“Just to show the results of this custom sentencizer,” says a man, “I will leave this code snipped here.” This is a rule based approach to bypass the issues the English model (meaning 'en_core_web_lg') currently has – “Which will be fixed in future versions.’”, said the developer. “It should include most common “situtaions” one can stumble upon!”"
nlp = spacy.load("en_core_web_lg")

print("Results of default sentencizer:")
for i, s in enumerate(nlp(test_text).sents):
    print(str(i), s)

# Results of default sentencizer:
# 0 “
# 1 Just to show the results of this custom sentencizer,” says a man, “I will leave this code snipped here.
# 2 ”
# 3 This is a rule based approach to bypass the issues the English model (meaning 'en_core_web_lg') currently has – “Which will be fixed in future versions.
# 4 ’
# 5 ”, said the developer.
# 6 “
# 7 It should include most common “situtaions” one can stumble upon!
# 8 ”

nlp.add_pipe(custom_sentencizer, before="parser")

print("\nResults of the custom sentencizer:")
for i, s in enumerate(list(nlp(test_text).sents)):
    print(str(i), s)

# Results of the custom sentencizer:
# 0 “Just to show the results of this custom sentencizer,” says a man, “I will leave this code snipped here.”
# 1 This is a rule based approach to bypass the issues the English model (meaning 'en_core_web_lg') currently has –
# 2 “Which will be fixed in future versions.’”, said the developer.
# 3 “It should include most common “situtaions” one can stumble upon!”
