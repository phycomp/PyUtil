from django_q.tasks import async, result
task_id = async(
    'fruit_shop.tasks.order_fruit',  # func full name
    fruit=fruit, num_fruit=num_fruit
)
ret = result(task_id)  # get result, None if yet run
ret = result(task_id, 200)  # block and wait for 200 ms
from django_q.humanhash import humanize
def order(request):
    fruit = request.POST.get('fruit_type', '')
    num_fruit = int(request.POST.get('num_fruit', '1'))
    task_id = async(...)  # Create async task
    messages.info(request, # Django message as notification
        f'You ordered fruit:s x num_fruit:d (task: {humanize(task_id)})'
    )
