#!/usr/bin/env python
# coding: utf-8

# # 協同過濾(Collaborative Filtering)

# ## download data
# [ml-100k.zip](http://files.grouplens.org/datasets/movielens/ml-100k.zip)

# In[1]:


import pandas as pd


# In[15]:


# Read the input training data
input_data_file_movie = "./ml-100k/u.item"
input_data_file_rating = "./ml-100k/u.data"

movie = pd.read_csv(input_data_file_movie, sep='|', encoding='ISO-8859-1', names=['movie_id', 'movie_title'], usecols = [0,1,])
rating = pd.read_csv(input_data_file_rating, sep='\t', encoding='ISO-8859-1', names=["user_id","movie_id","rating"], usecols = [0,1,2])
print(movie.head())
print(rating.head())


# In[16]:


# then merge movie and rating data
data = pd.merge(movie,rating)
data.head()


# ## USER-ITEM Matrix

# In[17]:


# lets make a pivot table in order to make rows are users and columns are movies. And values are rating
pivot_table = data.pivot_table(index = ["user_id"],columns = ["movie_title"],values = "rating")
pivot_table.head(10)


# ## ITEM-ITEM 協同過濾相似性(Similarity)計算

# In[18]:


movie_watched = pivot_table["Bad Boys (1995)"]
similarity_with_other_movies = pivot_table.corrwith(movie_watched)  # find correlation between "Bad Boys (1995)" and other movies
similarity_with_other_movies = similarity_with_other_movies.sort_values(ascending=False)
similarity_with_other_movies.head()


# ## USER-USER 協同過濾相似性(Similarity)計算

# In[19]:


# lets make a pivot table in order to make rows are users and columns are movies. And values are rating
pivot_table = data.pivot_table(index =["movie_title"],columns =  ["user_id"],values = "rating")
pivot_table.head(10)


# In[22]:


target_user = pivot_table[10]
similarity_with_other_movies = pivot_table.corrwith(target_user)  # find correlation between "Bad Boys (1995)" and other movies
similarity_with_other_movies = similarity_with_other_movies.sort_values(ascending=False)
similarity_with_other_movies.head()


# In[ ]:




