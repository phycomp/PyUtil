import tensorflow as tf
from tensorflow.nn import softmax as nnSoftmax
from tensorflow import reduce_sum as tfReduce_sum, tanh as tfTanh, linspace as tfLinspace
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
logits = tf.random.uniform([1,10], minval=-2, maxval=2)
print("\nuniform出的各种输入数据:")
print(logits)
prob = nnSoftmax(logits, axis=1)
print("\nsoftmax后出现各概率结果:")
print(prob)
print("\n概率和:")
print(tfReduce_sum(prob, axis=1) )
可以清楚地看到，softmax()将各个数据归一化到 [0,1] 内，现在的数据我们可以称为“概率”
最后看概率和，可以知道总和为1
tanh实战一下
import tensorflow as tf
import numpy as np
from numpy import array as npArray
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
a = npArray([-2., -1., 0., 1., 2.])
b = tfTanh(a)
print(b)
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
a = tfLinspace(-1., 1., 10)
print( tf.nn.relu(a) )
print( tf.nn.leaky_relu(a) )
