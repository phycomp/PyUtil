Alright, still a 5. Now let's build our model!

model = tf.keras.models.Sequential()
A sequential model is what you're going to use most of the time. It just means things are going to go in direct order. A feed forward model. No going backwards...for now.

Now, we'll pop in layers. Recall our neural network image? Was the input layer flat, or was it multi-dimensional? It was flat. So, we need to take this 28x28 image, and make it a flat 1x784. There are many ways for us to do this, but keras has a Flatten layer built just for us, so we'll use that.

model.add(tf.keras.layers.Flatten())
This will serve as our input layer. It's going to take the data we throw at it, and just flatten it for us. Next, we want our hidden layers. We're going to go with the simplest neural network layer, which is just a Dense layer. This refers to the fact that it's a densely-connected layer, meaning it's "fully connected," where each node connects to each prior and subsequent node. Just like our image.

model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
This layer has 128 units. The activation function is relu, short for rectified linear. Currently, relu is the activation function you should just default to. There are many more to test for sure, but, if you don't know what to use, use relu to start.

Let's add another identical layer for good measure.

model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
Now, we're ready for an output layer:

model.add(tf.keras.layers.Dense(10, activation=tf.nn.softmax))
This is our final layer. It has 10 nodes. 1 node per possible number prediction. In this case, our activation function is a softmax function, since we're really actually looking for something more like a probability distribution of which of the possible prediction options this thing we're passing features through of is. Great, our model is done.

Now we need to "compile" the model. This is where we pass the settings for actually optimizing/training the model we've defined.

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
Remember why we picked relu as an activation function? Same thing is true for the Adam optimizer. It's just a great default to start with.

Next, we have our loss metric. Loss is a calculation of error. A neural network doesn't actually attempt to maximize accuracy. It attempts to minimize loss. Again, there are many choices, but some form of categorical crossentropy is a good start for a classification task like this.

Now, we fit!

model.fit(x_train, y_train, epochs=3)
Epoch 1/3
60000/60000 [==============================] - 7s 119us/step - loss: 0.2624 - acc: 0.9244
Epoch 2/3
60000/60000 [==============================] - 5s 89us/step - loss: 0.1074 - acc: 0.9675
Epoch 3/3
60000/60000 [==============================] - 5s 89us/step - loss: 0.0715 - acc: 0.9779
<tensorflow.python.keras.callbacks.History at 0x2871a387cf8>
As we train, we can see loss goes down (yay), and accuracy improves quite quickly to 98-99% (double yay!)

Now that's loss and accuracy for in-sample data. Getting a high accuracy and low loss might mean your model learned how to classify digits in general (it generalized)...or it simply memorized every single example you showed it (it overfit). This is why we need to test on out-of-sample data (data we didn't use to train the model).

val_loss, val_acc = model.evaluate(x_test, y_test)
print(val_loss)
print(val_acc)
10000/10000 [==============================] - 0s 34us/step
0.09623032998903655
0.9722
Full code up to this point, with some notes:

As of Dec 21st 2018, there's a known issue with the code. I am going to paste a snippet that you should use to replace the code with, should you be hitting an error:

(x_train, y_train), (x_test, y_test) = mnist.load_data()   # 28x28 numbers of 0-9
x_train = tf.keras.utils.normalize(x_train, axis=1).reshape(x_train.shape[0], -1)
x_test = tf.keras.utils.normalize(x_test, axis=1).reshape(x_test.shape[0], -1)

model = tf.keras.models.Sequential()
#model.add(tf.keras.layers.Flatten())   #Flatten the images! Could be done with numpy reshape
model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu, input_shape= x_train.shape[1:]))
model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
model.add(tf.keras.layers.Dense(10, activation=tf.nn.softmax))   #10 because dataset is numbers from 0 - 9
In [ ]:
import tensorflow as tf  # deep learning library. Tensors are just multi-dimensional arrays

mnist = tf.keras.datasets.mnist  # mnist is a dataset of 28x28 images of handwritten digits and their labels
(x_train, y_train),(x_test, y_test) = mnist.load_data()  # unpacks images to x_train/x_test and labels to y_train/y_test

x_train = tf.keras.utils.normalize(x_train, axis=1)  # scales data between 0 and 1
x_test = tf.keras.utils.normalize(x_test, axis=1)  # scales data between 0 and 1

model = tf.keras.models.Sequential()  # a basic feed-forward model
model.add(tf.keras.layers.Flatten())  # takes our 28x28 and makes it 1x784
model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))  # a simple fully-connected layer, 128 units, relu activation
model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))  # a simple fully-connected layer, 128 units, relu activation
model.add(tf.keras.layers.Dense(10, activation=tf.nn.softmax))  # our output layer. 10 units for 10 classes. Softmax for probability distribution

model.compile(optimizer='adam',  # Good default optimizer to start with
              loss='sparse_categorical_crossentropy',  # how will we calculate our "error." Neural network aims to minimize loss.
              metrics=['accuracy'])  # what to track

model.fit(x_train, y_train, epochs=3)  # train the model

val_loss, val_acc = model.evaluate(x_test, y_test)  # evaluate the out of sample data with model
print(val_loss)  # model's loss (error)
print(val_acc)  # model's accuracy
It's going to be very likely your accuracy out of sample is a bit worse, same with loss. In fact, it should be a red flag if it's identical, or better.

Finally, with your model, you can save it super easily:

model.save('epic_num_reader.model')
Load it back:

new_model = tf.keras.models.load_model('epic_num_reader.model')
finally, make predictions!

predictions = new_model.predict(x_test)
print(predictions)
[[4.2427444e-09 1.6043286e-08 1.2955404e-06 ... 9.9999785e-01
  9.2534069e-09 1.3064107e-07]
 [2.8164232e-08 1.0317165e-04 9.9989593e-01 ... 1.0429282e-09
  2.1738730e-07 3.1334544e-12]
 [2.0918677e-07 9.9984252e-01 2.9539053e-05 ... 5.4588450e-05
  6.1221406e-05 1.4490828e-07]
 ...
 [2.3763378e-09 8.4034167e-07 2.0469349e-08 ... 1.1768799e-05
  4.7667407e-07 1.0428642e-04]
 [4.5215497e-06 6.1512014e-06 4.7418069e-08 ... 1.1381173e-06
  7.6969003e-04 8.6409798e-08]
 [6.3100595e-07 2.5021842e-07 2.4660849e-07 ... 2.5157806e-10
  5.8900000e-08 2.3496944e-09]]
Uwotm8?

That sure doesn't start off as helpful, but recall these are probability distributions. We can get the actual number pretty simply:

import numpy as np

print(np.argmax(predictions[0]))
7
There's your prediction, let's look at the input:

plt.imshow(x_test[0],cmap=plt.cm.binary)
plt.show()
