#!/usr/bin/env python
from epub_conversion.utils import open_book, convert_epub_to_lines

from sys import argv
fname=argv[1]
book = open_book(fname)
lines = convert_epub_to_lines(book)
print(lines)
