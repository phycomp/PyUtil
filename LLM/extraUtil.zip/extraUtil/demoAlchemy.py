# https://github.com/omab/python-social-auth/blob/master/examples/flask_example/models/user.py
from social.apps.flask_app.default.models import init_social
from social.apps.flask_app.default.models import PSABase
from flask.ext.sqlalchemy import SQLAlchemy, itervalues, string_types, BaseQuery, _QueryProperty
from pprint import pprint

class ExtraSQLAlchemy(SQLAlchemy):
    def __init__(self, app=None, use_native_unicode=True, session_options=None):
        super(ExtraSQLAlchemy, self).__init__(app, use_native_unicode, session_options)
        self.external_bases = []

    def get_tables_for_bind(self, bind=None):
        """Returns a list of all tables relevant for a bind."""
        result = []
        for Base in self.bases:
            for table in itervalues(Base.metadata.tables):
                if table.info.get('bind_key') == bind: result.append(table)
        return result

    def _execute_for_all_tables(self, app, bind, operation, skip_tables=False):
        app = self.get_app(app)

        for Base in self.bases:
            if bind == '__all__': binds = [None] + list(app.config.get('SQLALCHEMY_BINDS') or ())
            elif isinstance(bind, string_types) or bind is None: binds = [bind]
            else: binds = bind

            for bind in binds:
                extra = {}
                if not skip_tables:
                    tables = self.get_tables_for_bind(bind)
                    extra['tables'] = tables
                op = getattr(Base.metadata, operation)
                op(bind=self.get_engine(app, bind), **extra)

    @property
    def bases(self):
        return [self.Model] + self.external_bases

    def register_base(self, Base):
        """Register an external raw SQLAlchemy declarative base.
        Allows usage of the base with our session management and
        adds convenience query property using BaseQuery by default.
        """
        self.external_bases.append(Base)
        for c in Base._decl_class_registry.values():
            if isinstance(c, type):
                if not hasattr(c, 'query') and not hasattr(c, 'query_class'):
                    c.query_class = BaseQuery

                if not hasattr(c, 'query'):
                    c.query = _QueryProperty(self)

app = Flask(__name__)
app.config.from_object('config')                        
db = ExtraSQLAlchemy(app)
init_social(app, db.session)
db.register_base(PSABase)

pprint([x.name for x in db.metadata.sorted_tables])
pprint([x.name for x in PSABase.metadata.sorted_tables])

# ['user']
# ['social_auth_nonce', #  'social_auth_association', #  'social_auth_usersocialauth', #  'social_auth_code']
from flask.ext.migrate import Migrate
migrate = Migrate(app, db)
