#!/usr/bin/env python
# coding: utf-8

# In[21]:


from selenium import webdriver
driver = webdriver.Chrome('/usr/bin/chromedriver')
driver.get('https://www.google.com')


# In[22]:


q  = driver.find_element_by_name('q')
q.send_keys('大數軟體')


# In[23]:


from selenium.webdriver.common.keys import Keys
q.send_keys(Keys.RETURN)


# In[25]:


from bs4 import BeautifulSoup
soup = BeautifulSoup(driver.page_source, 'lxml')


# In[27]:


for ele in soup.select('#rso h3 a'):
    print(ele.text)


# In[29]:


driver.find_element_by_link_text('下一頁').click()


# In[ ]:


import time
for p in range(3):
    driver.find_element_by_link_text('下一頁').click()
    soup = BeautifulSoup(driver.page_source, 'lxml')
    for ele in soup.select('#rso h3 a'):
        print(ele.text)
    time.sleep(1)

