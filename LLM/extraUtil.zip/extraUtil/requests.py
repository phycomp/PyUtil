from django.shortcuts import render
from django.http.response import JsonResponse, HttpResponseRedirect, HttpResponse
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.contrib.auth import get_user_model, authenticate, logout as auth_logout, login as auth_login
from django.urls import reverse
import requests

UserModel=get_user_model()

class Index(View):
	def get(self, request, mid=None):
		return render(request, 'index.html')
	@csrf_protect
	#@method_decorator(csrf_exempt, name='dispatch')
	def post(self, request, mid=None):
		return render(request, 'index.html')

def csrf_failure(request, reason=None):
	#rqstPst=request.POST
	#APP_PRIVATE_ID, APP_PRIVATE_PASSWD=rqstPst['APP_PRIVATE_ID'], rqstPst['APP_PRIVATE_PASSWD'], 
	PUBLIC_APP_USER_SSO_TOKEN=request.COOKIES.get('PUBLIC_APP_USER_SSO_TOKEN')
	APP_PRIVATE_ID, APP_PRIVATE_PASSWD='09332346210e42a59eebf906054c810c', '866ccc10e0024acbba081d5043e628d7'
	jsonData=dict(APP_PRIVATE_ID=APP_PRIVATE_ID, APP_PRIVATE_PASSWD=APP_PRIVATE_PASSWD, PUBLIC_APP_USER_SSO_TOKEN=PUBLIC_APP_USER_SSO_TOKEN)
	response=requests.post('https://eiptest-api.vghtpe.gov.tw/vghtpe/get_login_user_info/', json=jsonData, verify=False)

	ctx=response.content.decode('utf8')
	ctx=eval(ctx)
	ctx.pop('ERROR_CODE')
	print(ctx)
	#for key in ctx.keys():
	#	Itm=eval(ctx.get(key))[0]
	#	for k in Itm.keys():
	#		print(k, Itm.get(k))       #{"APP_USER_LOGIN_ID": "ISC8381A", "APP_USER_EMPNO": "029333", "APP_USER_CHT_NAME": "\u5442\u4fca\u8208", "APP_USER_EMAIL": "chlu10@vghtpe.gov.tw", "APP_USER_TITLE": "", "APP_USER_STATUS": 1}
	vup=ctx.get('VGHTPE_USER_PROFILE')
	username, fullname, email=vup.get('APP_USER_LOGIN_ID').lower(), vup.get('APP_USER_CHT_NAME'), vup.get('APP_USER_EMAIL')
	last_name, first_name=fullname[0], fullname[1:]
	me, status=UserModel.objects.get_or_create(username=username, email=email, first_name=first_name, last_name=last_name)
	password=tmplPasswd='12345678'
	me.set_password(tmplPasswd)
	me.is_active=True
	me.save()
	user = authenticate(username=username, password=password)
	if user and user.is_active:
		auth_login(request, user)
		return HttpResponseRedirect(reverse('me'))
#'ERROR_CODE', 'VGHTPE_USER_AUTH', 'VGHTPE_SRC_ADDRESS_NET_OBJECT_LIST', 'VGHTPE_USER_NODE', 'VGHTPE_USER_PROFILE', 'VGHTPE_DEPT_PROFILE_LIST', 'VGHTPE_VUSRNID_INFO_LIST
#tchwk=TechwikiMnpltn.tchwkQuery.get(id=tid)
#tmpl=loader.get_template('techwiki-detail.html')
#ctx=tmpl.render({'tchwk':tchwk}, request)
	return JsonResponse({'rspData':ctx})
	return HttpResponse('CSRF Failure')

