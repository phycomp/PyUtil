#!/usr/bin/env python
# coding: utf-8

# ### Text Summarization with SpaCy
# + Text summarization is the process of distilling the most important information from a source (or sources) to produce an abridged version for a particular user (or users) and task (or tasks).
# +  idea of summarization is to find a subset of data which contains the “information” of the entire set
# + Main Idea
#     - Text Preprocessing(remove stopwords,punctuations).
#     - Frequency table of words/Word Frequency Distribution - how many times each word appears in the document
#     - Score each sentence depending on the words it contains and the frequency table
#     - Build summary by joining every sentence above a certain score limit

# In[1]:


# Load Pkgs
import spacy 


# In[2]:


# Text Preprocessing Pkg
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation


# In[3]:


# Build a List of Stopwords
stopwords = list(STOP_WORDS)


# In[4]:


document1 ="""Machine learning (ML) is the scientific study of algorithms and statistical models that computer systems use to progressively improve their performance on a specific task. Machine learning algorithms build a mathematical model of sample data, known as "training data", in order to make predictions or decisions without being explicitly programmed to perform the task. Machine learning algorithms are used in the applications of email filtering, detection of network intruders, and computer vision, where it is infeasible to develop an algorithm of specific instructions for performing the task. Machine learning is closely related to computational statistics, which focuses on making predictions using computers. The study of mathematical optimization delivers methods, theory and application domains to the field of machine learning. Data mining is a field of study within machine learning, and focuses on exploratory data analysis through unsupervised learning.In its application across business problems, machine learning is also referred to as predictive analytics."""


# In[5]:


document2 = """Our Father who art in heaven, hallowed be thy name. Thy kingdom come. Thy will be done, on earth as it is in heaven. Give us this day our daily bread; and forgive us our trespasses, as we forgive those who trespass against us; and lead us not into temptation, but deliver us from evil
"""


# In[7]:


nlp = spacy.load('en')


# In[8]:


# Build an NLP Object
docx = nlp(document1)


# In[9]:


# Tokenization of Text
mytokens = [token.text for token in docx]


# #### Word Frequency Table
# + dictionary of words and their counts
# + How many times each word appears in the document
# + Using non-stopwords

# In[10]:


# Build Word Frequency
# word.text is tokenization in spacy
word_frequencies = {}
for word in docx:
    if word.text not in stopwords:
            if word.text not in word_frequencies.keys():
                word_frequencies[word.text] = 1
            else:
                word_frequencies[word.text] += 1


# In[11]:


word_frequencies


# #### Maximum Word Frequency
# + find the weighted frequency
# + Each word over most occurring word
# + Long sentence over short sentence

# In[12]:


# Maximum Word Frequency
maximum_frequency = max(word_frequencies.values())


# In[13]:


for word in word_frequencies.keys():  
        word_frequencies[word] = (word_frequencies[word]/maximum_frequency)


# #### Word Frequency Distribution 

# In[14]:


# Frequency Table
word_frequencies


# #### Sentence Score and Ranking of Words in Each Sentence
# + Sentence Tokens
# + scoring every sentence based on number of words
# + non stopwords in our word frequency table

# In[15]:


# Sentence Tokens
sentence_list = [ sentence for sentence in docx.sents ]


# In[16]:


# Example of Sentence Tokenization,Word Tokenization and Lowering All Text
# for t in sentence_list:
#     for w in t:
#         print(w.text.lower())
[w.text.lower() for t in sentence_list for w in t ]


# In[17]:


# Sentence Score via comparrng each word with sentence
sentence_scores = {}  
for sent in sentence_list:  
        for word in sent:
            if word.text.lower() in word_frequencies.keys():
                if len(sent.text.split(' ')) < 30:
                    if sent not in sentence_scores.keys():
                        sentence_scores[sent] = word_frequencies[word.text.lower()]
                    else:
                        sentence_scores[sent] += word_frequencies[word.text.lower()]


# In[ ]:


# Sentence Score via comparrng each word with sentence
# Alternative Method
lowered_sentence_list = [w.text.lower() for t in sentence_list for w in t ]
lowered_sentence_scores = {}  
for sent in lowered_sentence_list:  
        for word in sent:
            if word.text in word_frequencies.keys():
                if len(sent.split(' ')) < 30:
                    if sent not in sentence_scores.keys():
                        lowered_sentence_scores[sent] = word_frequencies[word.text]
                    else:
                        lowered_sentence_scores[sent] += word_frequencies[word.text]


# ##### Get Sentence Score 
# 

# In[18]:


# Sentence Score Table
sentence_scores


# #### Finding Top N Sentence with largest score
# + using heapq

# In[19]:


# Import Heapq 
from heapq import nlargest


# In[20]:


summarized_sentences = nlargest(7, sentence_scores, key=sentence_scores.get)


# In[21]:


summarized_sentences 


# In[ ]:


# Convert Sentences from Spacy Span to Strings for joining entire sentence
for w in summarized_sentences:
    print(w.text)


# In[22]:


# List Comprehension of Sentences Converted From Spacy.span to strings
final_sentences = [ w.text for w in summarized_sentences ]


# ##### Join sentences

# In[23]:


summary = ' '.join(final_sentences)


# In[24]:


summary


# In[25]:


# Length of Summary
len(summary)


# In[26]:


# Length of Original Text
len(document1)


# In[27]:


# Place All As A Function For Reuseability
def text_summarizer(raw_docx):
    raw_text = raw_docx
    docx = nlp(raw_text)
    stopwords = list(STOP_WORDS)
    # Build Word Frequency
# word.text is tokenization in spacy
    word_frequencies = {}  
    for word in docx:  
        if word.text not in stopwords:
            if word.text not in word_frequencies.keys():
                word_frequencies[word.text] = 1
            else:
                word_frequencies[word.text] += 1


    maximum_frequncy = max(word_frequencies.values())

    for word in word_frequencies.keys():  
        word_frequencies[word] = (word_frequencies[word]/maximum_frequncy)
    # Sentence Tokens
    sentence_list = [ sentence for sentence in docx.sents ]

    # Calculate Sentence Score and Ranking
    sentence_scores = {}  
    for sent in sentence_list:  
        for word in sent:
            if word.text.lower() in word_frequencies.keys():
                if len(sent.text.split(' ')) < 30:
                    if sent not in sentence_scores.keys():
                        sentence_scores[sent] = word_frequencies[word.text.lower()]
                    else:
                        sentence_scores[sent] += word_frequencies[word.text.lower()]

    # Find N Largest
    summary_sentences = nlargest(7, sentence_scores, key=sentence_scores.get)
    final_sentences = [ w.text for w in summary_sentences ]
    summary = ' '.join(final_sentences)
    print("Original Document\n")
    print(raw_docx)
    print("Total Length:",len(raw_docx))
    print('\n\nSummarized Document\n')
    print(summary)
    print("Total Length:",len(summary))
    


# In[28]:


text_summarizer(document2)


# ####  Calculating the Reading Time of A Text
# + Main Principle
# + Total number of words
# + Average Reading Speed of Adults (200-265wpm)

# In[29]:


document1


# In[30]:


# Get Total Word Counts with Tokenization
docx1 = nlp(document1)


# In[31]:


# Tokens
mytokens = [ token.text for token in docx1 ]


# In[32]:


# Total Number or Length of Words
len(mytokens)


# In[33]:


# Reading Time
def readingTime(docs):
    total_words_tokens =  [ token.text for token in nlp(docs)]
    estimatedtime  = len(total_words_tokens)/200
    return '{} mins'.format(round(estimatedtime))
    


# In[34]:


readingTime(document1)


# ##### Using Spacy_Summarizer as A Package

# In[35]:


### Used it as a package
from spacy_summarizer import text_summarizer


# In[36]:


text_summarizer(document2)


# In[ ]:


#### Comparing with Gensim
+ pip install gensim_sum_ext


# In[37]:


from gensim.summarization import summarize


# In[38]:


summarize(document1)


# In[ ]:


## Almost similar to our SpaCy Summarize the highest score


# In[ ]:


# Jesse JCharis
# J-Secur1ty
# Jesus Saves@JCharisTech
# Thanks 

