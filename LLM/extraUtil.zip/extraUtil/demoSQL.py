yrLeap=15
ageRng=[round(v)for v in linspace(10, 100, num=yrLeap)]
lastAge=len(ageRng)-1
ageName, maleAge, femaleAge=None, [], []
startQuery='''select "dvdLbdtVL"(t.i) from (select "RSRTSYM","RSPFKEY",string_agg("cmbValue", '|' order by "RSDATE")i from isc8381."ageGndrSymblPfkeyDemo" where "RSRTSYM"='{symbl}' and "PSEX"='gender' and "AGE"<'{age}' group by 1,2 limit 1)t;'''
midQuery=select "dvdLbdtVL"(t.i) from (select "RSRTSYM","RSPFKEY",string_agg("cmbValue", '|' order by "RSDATE")i from isc8381."ageGndrSymblPfkeyDemo" where "RSRTSYM"='{symbl}' and "PSEX"='gender' and '{prevAge}'<="AGE" and "AGE"<'{age}' group by 1,2 limit 1)t;
endQuery=select "dvdLbdtVL"(t.i) from (select "RSRTSYM","RSPFKEY",string_agg("cmbValue", '|' order by "RSDATE")i from isc8381."ageGndrSymblPfkeyDemo" where "RSRTSYM"='{symbl}' and "PSEX"='gender' and '{age}'<="AGE" group by 1,2 limit 1)t;
for ndx, age in enumerate(ageRng):
  if not ndx:# or ndx==lastAge:
    querySQL=querySQL.replace('gender', 1)
    exec(f"rslt=DbaseMnpl.dbaseRawSQL({querySQL}, db='bdtest')")
    exec(f"ageGrp{age}=dict(ageGrp{age}={rslt})")
    exec(f'maleAge.append(ageGrp{age})')
    
    exec(querySQL.replace('gender', 2))
    exec(f"rslt=DbaseMnpl.dbaseRawSQL({querySQL}, db='bdtest')")
    exec(f"ageGrp{age}=dict(ageGrp{age}={rslt})")
    exec(f'femaleAge.append(ageGrp{age})')
  else:
    prevAge=ageRng[ndx-1]
    exec(midQuery.replace('gender', 1))
    exec(f"rslt=DbaseMnpl.dbaseRawSQL({querySQL}, db='bdtest')")
    exec(f"age{prevAge}Grp{age}=dict(age{prevAge}Grp{age}={rslt})")
    exec(f'maleAge.append(age{prevAge}Grp{age})')
    #exec(f'age{prevAge}Grp{age}=[]')
    exec(midQuery.replace('gender', 2))
    exec(f"rslt=DbaseMnpl.dbaseRawSQL({querySQL}, db='bdtest')")
    exec(f"age{prevAge}Grp{age}=dict(age{prevAge}Grp{age}={rslt})")
    #exec(f'age{prevAge}Grp{age}=[]')
    exec(f'femalAge.append(age{prevAge}Grp{age})')
exec(endQuery.replace('gender', 1))
exec(f"rslt=DbaseMnpl.dbaseRawSQL({querySQL}, db='bdtest')")
exec(f"ageGrp{age}=dict(ageGrp{age}={rslt})")
exec(f'maleAge.append(ageGrp{age})')
exec(endQuery.replace('gender', 2))
exec(f"rslt=DbaseMnpl.dbaseRawSQL({querySQL}, db='bdtest')")
exec(f"ageGrp{age}=dict(ageGrp{age}={rlst})")
exec(f'femaleAge.append(ageGrp{age})')
