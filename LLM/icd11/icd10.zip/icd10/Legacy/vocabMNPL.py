from torchtext.vocab import build_vocab_from_iterator, Vectors
#from torchtext.data import Field, LabelField
from torch import long as trchLong
from torchtext.data.utils import get_tokenizer
UNK_IDX, PAD_IDX, BOS_IDX, EOS_IDX = 0, 1, 2, 3
symNdx=(UNK_IDX, PAD_IDX, BOS_IDX, EOS_IDX )
# Make sure the tokens are in order of their indices to properly insert them in vocab
特殊符 = ['<unk>', '<pad>', '<bos>', '<eos>']
象=dict(zip(特殊符, symNdx))    #象={'<unk>': 0, '<pad>': 1, '<bos>': 2, '<eos>': 3}

def 計算彙(cntxt):
  TEXT = Field(tokenize=tokenizer, use_vocab=True, lower=True, batch_first=True, include_lengths=True)
  LABEL = LabelField(dtype=trchLong, batch_first=True, sequential=False)
  fields = [('text', TEXT), ('label', LABEL)]

  象彙 = get_tokenizer('spacy', language='en_core_web_sm')
  向量 = Vectors(name='glove.6B.50d.txt')
  TEXT.build_vocab(cntxt, vectors=向量, max_size=10000, min_freq=1)
  LABEL.build_vocab(cntxt)
  return TEXT, LABEL

