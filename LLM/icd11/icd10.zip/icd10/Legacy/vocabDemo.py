from re import sub as reSub
from collections import Counter
from torchtext.vocab import build_vocab_from_iterator as 迭代詞表

def vocabIter():
  字表 = 迭代詞表( getTokens(data_pipe,0), min_freq=2, specials= ['<pad>', '<sos>', '<eos>', '<unk>'], special_first=True)
  字表.set_default_index(字表['<unk>'])
  return 字表
"""
  "<pad>": "__PAD__",
  "<s>": "__BEGIN_OF_SENTENCE__",
  "</s>": "__END_OF_SENTENCE__",
  "<unk>": "__UNKNOWN__",
  "<mask>": "__MASK__",
"""

def build_vocab(token):
    counter = Counter(token)
    vocab = build_vocab_from_iterator(counter, specials=["<unk>"])
    vocab.set_default_index(0)
    return vocab

#
# A simple tokenizer that converts the input into a
# sequence of characters
#
def tokenize(text):
    #
    # Remove all unknown characters
    # 
    text = reSub(r"[^A-Za-z0-9 \-\.;,\n\?!]", '', text)
    #
    # Replace linebreaks and multiple spaces by a single space
    #
    text = reSub("\n+", " ", text)
    text = reSub(" +", " ", text)
    #
    # Split into characters
    #
    return [_t for _t in text]

#
# Decode a sequence of ids
#
def decode(indices, vocab):
    return "".join(vocab.lookup_tokens(indices))
