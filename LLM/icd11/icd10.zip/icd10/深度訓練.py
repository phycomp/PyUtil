深度學習在 PyTorch 中的運作原理可以分爲幾個主要部分，從數據準備到模型訓練和推理。以下是一個詳細的概述：

1. 數據準備

#數據加載
- Dataset: PyTorch 提供了 `torch.utils.data.Dataset` 類，用戶可以通過繼承這個類來定義自定義的數據集。數據集的主要任務是實現 `__len__` 和 `__getitem__` 方法，用于返回數據的樣本數量和特定索引的樣本。
- DataLoader: `torch.utils.data.DataLoader` 用于批量加載數據。它結合了 `Dataset`，能夠以指定的批量大小、是否打亂數據、是否使用多線程等方式高效地加載數據。

from torch.utils.data import Dataset, DataLoader

class MyDataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]

# 創建數據集和數據加載器
dataset = MyDataset(data, labels)
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
```

2. 模型定義

#模型結構
- 繼承 `nn.Module`: PyTorch 模型通常通過繼承 `torch.nn.Module` 類來定義。在 `__init__` 方法中定義模型的層，在 `forward` 方法中定義前向傳播的計算過程。

```python
import torch.nn as nn

class MyModel(nn.Module):
    def __init__(self):
        super(MyModel, self).__init__()
        self.fc1 = nn.Linear(10, 50)
        self.fc2 = nn.Linear(50, 2)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = MyModel()
```

3. 損失函數與優化器

#損失函數
- 損失計算: 損失函數用于計算模型預測與實際標簽之間的差異。PyTorch 提供了多種常見的損失函數，如 `nn.CrossEntropyLoss`、`nn.MSELoss` 等。

#優化器
- 優化模型: 優化器用于調整模型的權重以最小化損失函數。常見的優化器包括 `SGD`、`Adam`、`RMSprop` 等。

from torch.optim import SGD
from torch.nn import CrossEntropyLoss

criterion = CrossEntropyLoss()
optimizer = SGD(model.parameters(), lr=0.01)

"""
4. 訓練過程

#前向傳播
- 輸入數據: 將數據輸入到模型中，得到預測結果。

#計算損失
- 損失計算: 使用損失函數計算模型預測結果與實際標簽之間的誤差。

#反向傳播
- 梯度計算: 使用 `loss.backward()` 計算每個參數的梯度。
- 參數更新: 使用優化器的 `optimizer.step()` 方法更新模型的權重。

"""
for epoch in range(num_epochs):
    for inputs, labels in dataloader:
        # 清空之前的梯度
        optimizer.zero_grad()

        # 前向傳播
        outputs = model(inputs)

        # 計算損失
        loss = criterion(outputs, labels)

        # 反向傳播
        loss.backward()

        # 更新參數
        optimizer.step()
"""
5. 模型評估
#測試與驗證
- 評估模型性能: 在測試集或驗證集上評估模型性能，以檢查模型的泛化能力。常用的方法包括計算準确率、F1 分數等。
"""

model.eval()  # 設置模型爲評估模式
with torch.no_grad():
    for inputs, labels in test_loader:
        outputs = model(inputs)
        # 計算評估指標
model.eval()
with torch.no_grad():
    predictions = model(new_data)
"""
6. 推理與部署

#推理
- 模型推理: 使用訓練好的模型進行實際的預測。在推理時通常不需要梯度計算，因此可以使用 `torch.no_grad()` 上下文管理器來節省內存和計算資源。

#部署
- 模型保存和加載: 使用 `torch.save()` 保存模型的狀態字典（`state_dict`），并使用 `torch.load()` 加載模型。可以將模型保存爲文件以便于後續使用。
"""
torch.save(model.state_dict(), 'model.pth')
# 加載模型
model.load_state_dict(torch.load('model.pth'))
model.eval()
"""
7. 其他高級特性

- 自動求導（Autograd）: PyTorch 的自動求導機制 (`torch.autograd`) 能夠自動計算梯度，無需手動推導。它通過構建計算圖來跟蹤操作和計算梯度。
- 動態計算圖: PyTorch 使用動態計算圖（define-by-run），允許在每次前向傳播時生成計算圖，這使得編寫復雜的模型更爲靈活。
- 分布式訓練: PyTorch 支持分布式訓練，使用 `torch.distributed` 模塊可以在多個 GPU 或多台機器上進行訓練。

總的來說，PyTorch 提供了一整套靈活而強大的工具來實現深度學習模型，從數據處理、模型構建到訓練和評估，涵蓋了深度學習工作的各個方面。
"""
