#from torchtext.experimental.functional import vocab_func
from collections import Counter
from operator import itemgetter
#sentences=[['i','have','a','dream'],['we','have','a','world']]
def 字詞序表(Sents):
  字=[]
  for sent in Sents:
    Word=sent.split()
    字+=Word
  彙=Counter(字)
  字頻 = sorted(彙.items(), key=itemgetter(1), reverse=True)
  ndx2word = dict(enumerate(map(lambda x: x[0], 字頻), start=1))
  word2ndx = {字: ndx for ndx, 字 in ndx2word.items()}
  return word2ndx, ndx2word
