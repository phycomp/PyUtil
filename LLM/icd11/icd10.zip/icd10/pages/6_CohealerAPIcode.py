#!/usr/bin/env python
# coding: utf-8

from stUtil import rndrCode
from requests import post as rqstPOST
from json import JSONDecodeError, dumps as jsnDumps, loads as jsnLoads
from markdown import markdown
from bs4 import BeautifulSoup
from streamlit import radio as stRadio, sidebar, text_input, json
#import requests
#from json import JSONDecodeError
#import markdown
#from bs4 import BeautifulSoup

MENU, 表單=[], ['語言模型', 'role'] #, '卦爻辭', '錯綜複雜', '二十四節氣'
url, headers="http://10.221.253.72:30031/api/chat", {"Content-Type":"application/json"}
Role, MDL=['system', 'user'], ['qwen2:72b', 'qwen2:latest', 'llama3:8b']    #'gemma:7b', 
def mkPayload(mdl, cntnt):
  msg={'role':role, 'content':cntnt}
  return {'model':mdl, 'messages':[msg]}
# Define the data for the request
def promptRspns(payload, url=None, headers=None):
  rspns = rqstPOST(url, headers=headers, data=jsnDumps(payload))
# Check if the request was successful
  if rspns.status_code == 200:
    # Handle multiple JSON objects in the rspns
    all_messages = rspns.text.splitlines()
    content = ""
#    rndrCode(['allMSG=', all_messages])
    for message in all_messages:
      try:
        message_json = jsnLoads(message)
        content += message_json["message"]["content"]
      except JSONDecodeError:
        rndrCode(f"Error decoding JSON:{message}")

    content = content.strip()
    html = markdown(content)
    soup = BeautifulSoup(html, 'html.parser')
    paragraph = "".join(soup.stripped_strings)
    #rndrCode(paragraph)
    return paragraph
  else:
    rndrCode([f"Error: {rspns.status_code}", rspns.text])
    return rspns.text

for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #cntnt=text_input('輸入', '')
  role=stRadio('角色', Role, horizontal=True, index=0)
  mdl=stRadio('模型', MDL, horizontal=True, index=0)
if menu==len(表單):
  pass
elif menu==MENU[1]:
  pass
  #tblName='sutra'
  #sutraCLMN=queryCLMN(tblSchm='public', tblName=tblName, db='sutra')
  ##rndrCode(sutraCLMN)
  #fullQuery=f'''select {','.join(sutraCLMN)} from {tblName} where 章節~'中庸';'''
  #rsltQuery=runQuery(fullQuery, db='sutra')
  ##rndrCode([fullQuery, rsltQuery])
  #rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, index=None, columns=sutraCLMN)
  #rsltDF#[rsltDF['章節']=='中庸']
elif menu==MENU[0]:
  #sutraCLMN=['章節', '內容']
  #rsltQuery=runQuery(f'''select {','.join(sutraCLMN)} from ;''', db='fiveClass')
  #rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, columns=sutraCLMN, index=None)
  #sutraDF=session_state['rsltDF']=DataFrame([['', '']], columns=sutraCLMN, index=[0])
  #DF[DF.fiveClass.str.contains('', case=False)]
# Define the URL and headers for the API request
#url = "http://10.221.253.72:30031/api/chat"
#headers = { "Content-Type": "application/json" }
  rsltPrompt=None
  from streamlit import columns as stCLMN, text_area
  leftPane, rightPane=stCLMN([2, 8])
  with leftPane:
    cntnt=text_area('眼科文本', '')
    if cntnt:
      payload=mkPayload(mdl, cntnt)
      #json(payload)
      rsltPrompt=promptRspns(payload, url=url, headers=headers)
      #payload = { "model": "qwen2:72b",
      #"messages": [ #{"role": "system", "content": "我將會給你一個病例,請你simply"},
      #    {"role": "user", "content": "why is the sky blue?"} ] }
  with rightPane:
    if rsltPrompt:
      rndrCode(rsltPrompt)
