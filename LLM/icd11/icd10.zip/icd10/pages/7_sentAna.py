from torch.nn import Module, Embedding, LSTM, Linear, CrossEntropyLoss

class MyModel(Module):
    def __init__(self, vocab_size, embedding_dim):
        super(MyModel, self).__init__()
        self.embeddings = Embedding(vocab_size, embedding_dim)
4. 建立模型 可以選擇不同的模型架構，例如 LSTM、GRU、Transformer 等來進行語意分析。
import torch.nn as nn

class LSTMModel(Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim):
        super(LSTMModel, self).__init__()
        self.embedding = Embedding(vocab_size, embedding_dim)
        self.lstm = LSTM(embedding_dim, hidden_dim)
        self.fc = Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.embedding(x)
        out, _ = self.lstm(x)
        out = self.fc(out[-1])
        return out
5. 訓練模型 使用交叉熵損失函數和優化器（如 Adam）來訓練模型。
from torch.optim import Adam

model = LSTMModel(vocab_size, embedding_dim, hidden_dim)
criterion = CrossEntropyLoss()
優化 = Adam(model.parameters(), lr=0.001)

# 訓練過程
for epoch in range(num_epochs):
    for inputs, labels in dataloader:
        優化.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        優化.step()
