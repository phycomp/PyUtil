from torch import device as trchDevice, cuda as trchCuda
from streamlit import sidebar, session_state, radio as stRadio, write as stWrite, columns as stCLMN, text_area, text_input, multiselect, toggle as stToggle #slider, markdown, dataframe, code as rndrCode, text_input, code as rndrCode  code as rndrCode, cache as stCache, 
from pandas import DataFrame
from rndrCode import rndrCode
MENU, 表單=[], ['bertConfig', 'TKN', 'spacyDoc', 'bert編碼', '詞序表', '字嵌入', '象嵌入', '位置嵌入', '總嵌入', 'vocabIter', 'Padding', 'vocabDemo', 'Vocab', 'inputIDs', 'bertEmdding'] #Uncased, 'fastText', 'csvEye', 'answerQuestion', 'ansQues2', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec', EMBEDDING
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu = stRadio('MENU', MENU, index=0, horizontal=True)
def 編碼表(Sents, 分詞):
    字表 = []   # 添加special tokens 也就是CLS和SEP 設定最大文本長度 pad到最大的長度 返回的類型爲pytorch tensor
    for sent in Sents:
        input_ids = 分詞.encode(sent, add_special_tokens=True, max_length=160, pad_to_max_length=True, return_tensors='pt')
        字表.append(input_ids)
    字表 = torch.cat(字表, dim=0)
    return 字表

def 吐詞表(分詞, doc):
    for sent in doc.sents:
      yield 分詞(sent.text)

if menu==len(MENU[0]):
  pass
elif menu==MENU[8]:
  from bert嵌入 import BertEmbeddings
  bertConfig=session_state['bertConfig']
  bertEmbdding=BertEmbeddings(bertConfig)
  rndrCode(['bertEmbdding=', bertEmbdding])
elif menu==MENU[7]:
  'bert inputIDs'
  Sents=session_state['Sents']
  分詞=session_state['分詞']
  rndrCode(['Sents=', Sents])
  詞=[分詞(sent) for sent in Sents]
  from 字序編碼 import 創建表
  字表, 總字數, 序表=創建表(詞)
  rndrCode(['字ID表, 總字數=', 字表, 總字數])
  rndrCode(['id字典表=', 序表])
  #vocab(['here', 'is', 'an', 'example']) #[475, 21, 30, 5297]
  #from inputIDmnpl import rtrvInputIDs
  #TEXT=session_state['TEXT']
  #inputIDs=rtrvInputIDs(TEXT, bertName='/home/josh/bert-base-uncased')
  #rndrCode(['inputIDs=', inputIDs])
elif menu==MENU[6]:
  from torchtext.vocab import vocab
  from collections import Counter, OrderedDict
  Sents=session_state['Sents']
  總序=[]
  for sent in Sents:
    sent=sent.split()
    cnter = Counter(sent)
    字頻 = sorted(cnter.items(), key=lambda x: x[1], reverse=True)
    序表 = OrderedDict(字頻)
    序表 = vocab(序表)
    總序.append([sent, 序表.get_stoi()])
  #all_input_ids = encode_fn(text_values)
  #labels = torch.tensor(labels)
  from torch import cat as trchCat
  #all_input_ids = torch.cat(all_input_ids, dim=0)
  #總序表 = trchCat(總序, dim=0)
  rndrCode(['v1=', sent, 總序])
elif menu==MENU[5]:
  '遍歷'
  Sents=session_state['Sents']
  詞表, 特殊詞={}, {'[PAD]': 0, '[CLS]': 1, '[SEP]': 2, '[MASK]': 3, '[UNK]':4, '[BOS]':5, '[EOS]':6}
  CLS, SEP, EOS=特殊詞.get('[CLS]'), 特殊詞.get('[SEP]'), 特殊詞.get('[EOS]')
  詞表.update(特殊詞)
  for sent in Sents:
    Word=sent.split()
    for i, word in enumerate(Word):
       詞表[word] = i + len(特殊詞)
       序表 = {ndx: word for ndx, word in enumerate(詞表)}
       詞量 = len(詞表)
  rndrCode(['序表', 特殊詞, Sents, 序表, 詞表, 詞量])
  詞序=[CLS]
  for ndx, sent in enumerate(Sents):
    Word=sent.split()
    for word in Word:
      詞序.append(詞表.get(word))
    if ndx==len(Sents)-1: 詞序.append(EOS)#pass   
    else: 詞序.append(SEP)
  rndrCode(['詞序', Sents, 詞序])
elif menu==MENU[4]:
  '詞序表'
  from 詞序表 import mkInputIDs
  Sents=session_state['Sents']
  詞表, 序表=mkInputIDs(Sents)
  rndrCode(['詞表, 序表=', 詞表, 序表])
elif menu==MENU[3]:
  'bert編碼'
  from transformers import BertTokenizer
  #from bert編碼 import 詞編碼
  Sents=session_state['Sents']
  rndrCode(['Sents=', Sents])
  分詞 = BertTokenizer.from_pretrained('/home/josh/bert-base-uncased') #bert_name bertName
  # 添加special tokens 也就是CLS和SEP
  # 設定最大文本長度
  # pad到最大的長度
  # 返回的類型爲pytorch tensor
  編碼=[]
  for sent in Sents:
    詞碼=分詞.encode(sent, add_special_tokens=True, pad_to_max_length=True, return_tensors='pt')  #max_length=100,
    編碼.append(詞碼)
  rndrCode(['編碼', 編碼])
elif menu==MENU[2]:
  'spacy doc'
  from torchtext.data.utils import get_tokenizer
  from torchtext.vocab import build_vocab_from_iterator
  分詞 = get_tokenizer('basic_english')
  #train_iter = IMDB(split='train')
  #yield_tokens(doc.sents)
  from spacy.lang.en import English # updated
  from torchtext.vocab import build_vocab_from_iterator as 迭代詞表
  TEXT = session_state['TEXT']
  nlp = English()
  #sentczr=nlp.create_pipe('sentencizer')
  #nlp.add_pipe(sentczr)
  nlp.add_pipe('sentencizer')
  doc = nlp(TEXT)
  彙表 = 迭代詞表(吐詞表(分詞, doc), specials=['<unk>'])  #.sents
  #vocab = 迭代詞表(yield_tokens(train_iter), specials=['<unk>'])
  彙表.set_default_index(彙表['<unk>'])
  rndrCode(['vocab=', 彙表.get_stoi(), 彙表._parameters.items()])    #lookup_tokens()
  #'training': True, '_parameters': OrderedDict(), '_buffers': OrderedDict(), '_non_persistent_buffers_set': set(), '_backward_pre_hooks': OrderedDict(), '_backward_hooks': OrderedDict(), '_is_full_backward_hook': None, '_forward_hooks': OrderedDict(), '_forward_hooks_with_kwargs': OrderedDict(), '_forward_hooks_always_called': OrderedDict(), '_forward_pre_hooks': OrderedDict(), '_forward_pre_hooks_with_kwargs': OrderedDict(), '_state_dict_hooks': OrderedDict(), '_state_dict_pre_hooks': OrderedDict(), '_load_state_dict_pre_hooks': OrderedDict(), '_load_state_dict_post_hooks': OrderedDict(), '_modules': OrderedDict(), 'vocab': <torchtext._torchtext.Vocab object at 0x7f7b72335130>}]
  #彙.vocab==>'append_token', 'default_index_', 'get_default_index', 'get_itos', 'get_stoi', 'insert_token', 'itos_', 'lookup_indices', 'lookup_token', 'lookup_tokens', 'set_default_index'
  #from torch.utils.data import DataLoader
  #DataLoader(doc.sents)
  session_state['Sents']=Sents = [sent.text.strip() for sent in doc.sents]
  #rndrCode(['Sents=', Sents])
elif menu==MENU[1]:
  from torchtext.data.utils import get_tokenizer
  try:
    TKN=session_state['TKN']
  except:
    session_state['分詞']=分詞=get_tokenizer('basic_english')
    TEXT=session_state['TEXT']
    session_state['TKN']=TKN=分詞(TEXT)
  rndrCode(['TKN=', TKN])
elif menu==MENU[0]:
  'bertConfig'
  from bertConfig import BertConfig
  try: TEXT=session_state['TEXT']
  except: session_state['TEXT']=TEXT='I did not know how it works before reading this file and frankly, which is a way to receive inputs personally from the user. I think it is an awesome feature in python. Basically, what the input function does is to print the string given to it by input and then request user input. This raw_text then is encoded into tokens using NLP technology.'
  from seqUtil import rtrvMaxsize
  #字數=rtrvMaxsize(TEXT)
  字數=len(TEXT)
  try: bertConfig=session_state['bertConfig']
  except: session_state['bertConfig']=bertConfig=BertConfig(字數)
  rndrCode(['bertConfig=', bertConfig.__dict__])
  #['bertConfig=', {'字數': 330, '嵌向量': 384, '層數': 6, '頭數': 12, '激活': 'softmax', '中間': 1536, '隱藏丟棄': 0.4, '丟棄': 0.4, '位置嵌入': 1024, '分類': 256, 'σ': 0.02}]
