from pandas import read_csv
import torch
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from sklearn.preprocessing import LabelEncoder
from torch.nn import Module, Linear, ReLU, CrossEntropyLoss
from streamlit import text_input

# 1. 加載 ICD-11 數據表和 EHR 數據
icd_data = read_csv('icd10.csv', sep=r'\[SEP\]')  #icd11_codes.csv ICD-11 代碼和描述
#ehr_data = read_csv('ehr_records.csv')  # EHR 記錄文本
#text_input('EHR', 'kdjkfjkd dkjfkdjk kkjdkjdk')
#icdCode
ehrData={'診斷':"""BP: 0 / 0 PP: 0 BH: 160 BW: 0
S:主觀資料
TSCP OS on 20190315
s/p IVIL OD on 1080128, 1080226
s/p IVIE(c) + AC paracentesis OS on 1080104
s/p FGE + IVIA OS 1071210
PDR with NVI OS s/p IVIL(f) OS on 1071120
ocular and head pain OS for 3 days
ever occurred before cataract surgery
PDR with VH OS s/p IVIA(f) OS on 1070903
sudden blurring when wakeup 1 weeks ago , not improved
PDR with TRD , r/o RRD OS s/p VT+MP+R/T+16% C3F8 OS on 1070313
PDR wth vh os s/p IVIE (c) OS 1070102; s/p PRP OD on 1070209
sudden onset of blurry vision os 20+ days ago ,
s/p cataract op ou 7-8 years ago
mother : DM+ under

O:客觀資料
Va 5/60cc od; LP cc OS  ;NCTIOP 21/55 mmHg
1080104 Ref: -0.75-0.5x10/ -0.75
1071218 Ref: -0.25-0.75x1/ +0.5-0.25x70
1071211 Ref: -0.5/error
1071103 Ref: -0.25-0.25x25/ -0.25x156
1070903 Ref: 0.0-0.25x5/err
1070510 Ref: -0.5-0.5x30/ -0.25-0.75x160
1070309 ref -0.25-1.5x1/+1.75-0.25x52
1070126 ref -0.25-0.75*10/err
1070112 Ref: -0.25-2.25x180/ err
1070329 Ref: -0.25-0.75x28/ err
1070419 Ref: -0.0-1.0x20/ +0.5-0.75x75
1070510 CCT= 624/628 um
Slitlamp: NVI OS
cornea microcystic edema OS, A/C deep silent ou lens PCIOL ou with
glistening
indirect fundoscopy: vitreous hemorrahge os, diffuse microaneurysm od,
lipids at parafovea od,  with preretinal H od,
B scan: no RD os, VH OS
1061229 Fd: grossly attached with VH OS . disc can be seens OS
1070112 Fd: grossly attached with VH OS . disc can be seens OS
1070126 Fd: grossly attached with VH OS . disc can be seens OS
1070209 Fd: less VH with disc view OS, diffuse dots hemorhage OD
1070309 Fd+OCT: faint VH OS; preretinal fibrosis over lower arcade with RD
OS; MACULA OFF OS
1070320 Fd: gas full with attached retina OS
1070329 Fd: attached retina with gas 60 %
1070406 Fd: attached retina with gas 40 %
1070419 Fd+OCT: attached retina with residual SRF OS , gas 30 %
1070510 fd+OCT: persistent shallow SRF OS
1070621 Fd+OCT: persistent shallow SRF OS
1070809 Fd+OCT: persistent shallow SRF but less OS
1070903 B-scan: no RD sign OS
1070903 fd: obscured without disc view OS
1070911 fd: obscured without disc view OS
1070925 Fd: VH with dics view, grossly attached  OS
1071103 Fd+color+OCT: attached retina with residual faint VH OS
1071103 Fd+color+OCT: attached retina with residual faint VH OS
1071207 Fd: attached retina with residual faint VH OS; no disc view OS
1071211 Fd: grossly attached retina with disc can be seen OS
1071218 Fd: attached retina OS
1080104 Fd: attached retina with faint VH OS
1080118 Fd: attached retina with subtotal cupping OS
1080226 Fd: faint VH OD
1080122 Fd: attached retina OD, mild SRF OS , VMT OD
1080128 Fd: new retinal hemorrahge over macula with faint VH OD
1080226 Fd: faint VH OD

A:診斷
PDR
NIDDM RETINOPATHY(ADD BDR-362.01,PDR-362.02)
VITREOUS OPACITY/FLOATERS
NVG

 
Type 2 diabetes mellitus with proliferative diabetic retinopathy with macular ed
Type 2 diabetes mellitus with proliferative diabetic retinopathy without macular
Other vitreous opacities, left eye
Other specified glaucoma

P:治療計畫
FU 1w +IOP + dilatation
consider STK if SRF persistent
Bring medication
1061214 HbA1c  12.8 --> 11.0 %--> 9.1 %
keep medication"""}

# 2. 使用 TfidfVectorizer 對 EHR 文本進行特徵提取
vectorizer = TfidfVectorizer(max_features=5000)  # 將文本轉換為特徵向量
X = vectorizer.fit_transform(ehrData['診斷']).toarray()

# 3. 標簽編碼，將 ICD-11 代碼轉換為數字標簽
標簽編碼 = LabelEncoder()   #label_encoder
y = 標簽編碼.fit_transform(ehrData['icdCode'])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.2, random_state=42) # 4. 拆分訓練和測試數據集

class ICD分類(Module): # 5. 定義一個簡單的神經網絡模型來預測 ICD-11 代碼
    def __init__(self, input_size, num_classes):
        super(ICD分類, self).__init__()
        self.fc1 = Linear(input_size, 128)
        self.relu = ReLU()
        self.fc2 = Linear(128, num_classes)

    def forward(self, x):
        out = self.fc1(x)
        out = self.relu(out)
        out = self.fc2(out)
        return out

# 定義超參數
input_size = X_train.shape[1]
類數 = len(label_encoder.classes_)  #num_classes
learningRate, batch_size, num_epochs=.001, 64, 10

from torch import tensor as trchTnsr
# 6. 創建 DataLoader
class EHRDataset(Dataset):
    def __init__(self, X, y):
        self.X = trchTnsr(X, dtype=torch.float32)
        self.y = trchTnsr(y, dtype=torch.long)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

train_dataset = EHRDataset(X_train, y_train)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

# 7. 定義模型、損失函數和優化器

from torch.optim import Adam
model = ICD分類(input_size, 類數)
criterion = CrossEntropyLoss()
optimizer = Adam(model.parameters(), lr=learningRate)

# 8. 訓練模型
#for epoch in range(num_epochs):
LOSS, EPS=1, 1e-6
while LOSS>EPS:
    for inputs, labels in train_loader:
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        LOSS=loss.item()

    rndrCode([f'LOSS: {loss.item():.4f}'])

# 9. 評估模型
from torch import no_grad as trchNograd, max as trchMax
with trchNograd():
    test_inputs = trchTnsr(X_test, dtype=torch.float32)
    test_labels = trchTnsr(y_test, dtype=torch.long)

    outputs = model(test_inputs)
    _, predicted = trchMax(outputs, 1)

    accuracy = (predicted == test_labels).sum().item() / len(test_labels)
    rndrCode([f'Accuracy: {accuracy * 100:.2f}%'])
