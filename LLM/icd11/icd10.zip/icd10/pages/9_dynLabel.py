from torch import tensor as trchTnsr, float32 as trchFloat32, relu as trchRelu, long as trchLong, max as trchMax,  no_grad as trchNograd
from streamlit import session_state, sidebar, stRadio, text_input
from torch.nn import Module, Linear, CrossEntropyLoss
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from numpy import array as npArray
from torch.optimizer import Adam

texts = [
    "機器學習是人工智能的一部分",
    "深度學習是機器學習的一種",
    "自然語言處理是人工智能的重要應用",
    "計算機視覺是機器學習的一個重要領域",
    "強化學習涉及學習最優策略"
] # 示例文本
class TextClassificationModel(Module): # 模型定義
    def __init__(self, input_dim, output_dim):
        super(TextClassificationModel, self).__init__()
        self.fc1 = Linear(input_dim, 128)  # 隱藏層1
        self.fc2 = Linear(128, output_dim)  # 輸出層

    def forward(self, x):
        x = trchRelu(self.fc1(x))  # ReLU激活
        x = self.fc2(x)               # 輸出層
        return x

def trainMDL(model): # 訓練模型
  #num_epochs = 10
  batch_size = 2
  #for epoch in range(num_epochs):
  LOSS, EPS=1, 1e-5
  while LOSS>EPS:
      model.train()
      epoch_loss = 0.0
      for i in range(0, X_train.size(0), batch_size): # Mini-batch 梯度下降
          inputs = X_train[i:i + batch_size]
          labels = y_train[i:i + batch_size]
          outputs = model(inputs) # 前向傳播
          loss = criterion(outputs, labels)
          optimizer.zero_grad() # 反向傳播和優化
          loss.backward()
          optimizer.step()
          epoch_loss += loss.item()
          LOSS=epoch_loss/len(X_train)    #{:.4f}
      #print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {epoch_loss/len(X_train):.4f}")

def evalMDL(model): # 模型評估
  model.eval()  # 進入評估模式
  with trchNograd():
      outputs = model(X_test)
      _, predicted = trchMax(outputs, 1)  # 選擇概率最大的類
      accuracy = (predicted == y_test).float().mean()  # 計算準确率
      print(f"Accuracy: {accuracy:.4f}")

MENU, 表單=[], ['多標籤', '先後天', '卦爻辭', '錯綜複雜', '二十四節氣']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[0]: # 標簽（每個文本對應的單一標簽）
  labels = [0, 0, 1, 1, 2]  # 0: AI, 1: ML, 2: RL
  vectorizer = TfidfVectorizer(max_features=5000) # 使用TfidfVectorizer進行特征提取
  X = vectorizer.fit_transform(texts).toarray()
  Y = npArray(labels) # 轉換標簽爲numpy數組
  X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42) # 畫分訓練集和測試集
  X_train = trchTnsr(X_train, dtype=trchFloat32) # 轉換爲 PyTorch 張量
  X_test = trchTnsr(X_test, dtype=trchloat32)
  y_train = trchTnsr(y_train, dtype=trchLong)  # 需要使用long類型
  y_test = trchTnsr(y_test, dtype=trchLong)
  input_dim = X_train.shape[1]  # 輸入維度是TF-IDF特征的數量 模型參數
  output_dim = len(set(labels))  # 輸出維度是標簽的數量
  model=session_state['model']=TextClassificationModel(input_dim, output_dim) # 創建模型實例

  criterion = CrossEntropyLoss()  # 交叉熵損失 定義損失函數和優化器
  optimizer = Adam(model.parameters(), lr=0.001)
  trainMDL(model)
elif menu==MENU[1]:
  model = session_state['model']
  evalMDL(model)#:
  #tblName='sutra'
  #sutraCLMN=queryCLMN(tblSchm='public', tblName=tblName, db='sutra')
  #rndrCode(sutraCLMN)
  #fullQuery=f'''select {','.join(sutraCLMN)} from {tblName} where 章節~'中庸';'''
  #rsltQuery=runQuery(fullQuery, db='sutra')
  #rndrCode([fullQuery, rsltQuery])
  #rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, index=None, columns=sutraCLMN)
  #rsltDF#[rsltDF['章節']=='中庸']
