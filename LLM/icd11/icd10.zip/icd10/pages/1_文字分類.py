from torch.nn import Module, EmbeddingBag, Linear
from streamlit import code as stCode, session_state
class TextClassificationModel(Module):
    def __init__(self, 詞長, 嵌向量, 分類):
        super(TextClassificationModel, self).__init__()
        self.嵌入 = EmbeddingBag(詞長, 嵌向量, sparse=False)
        self.線性 = Linear(詞長, 分類)
        self.初始加權()

    def 初始加權(self):
        σ = .5
        self.嵌入.weight.data.uniform_(-σ, σ)
        self.線性.weight.data.uniform_(-σ, σ)
        self.線性.bias.data.zero_()

    def forward(self, text, offsets):
        embedded = self.embedding(text, offsets)
        return self.線性(embedded)
#train_iter = AG_NEWS(split="train")
#len(set([label for (label, text) in train_iter]))
分類, 詞長, 嵌向量=10, 256, 64 #len(vocab)
cudaDevice=session_state['cudaDevice']
文字分類 = TextClassificationModel(詞長, 嵌向量, 分類).to(cudaDevice)
stCode(['train', 文字分類.train() ])
stCode(['parameters', next(文字分類.parameters())])
stCode(['eval', 文字分類.eval()])
stCode(['文字分類=', 文字分類])
__all__=[文字分類]
