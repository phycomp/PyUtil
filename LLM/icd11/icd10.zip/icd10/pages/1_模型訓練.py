from torch import device as trchDevice, cuda as trchCuda
from streamlit import code as stCode, sidebar
from streamlit import text_area, session_state, write as stWrite
from torchtext.data.utils import get_tokenizer
from mk本文 import rtrvTXT

表單, MENU=[], ['本文TEXT', '特殊字', '段落', 'counter分詞', '全段落序表', '設定參數', '字嵌入', '位置嵌入', '段落嵌入', '總嵌入', 'vocabIter', 'Padding', 'vocabDemo', 'Vocab', 'inputIDs', 'bertEmdding'] #Uncased, 'fastText', 'csvEye', 'answerQuestion', 'ansQues2', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec', EMBEDDING  '字嵌入', 'TKN', 'spacyDoc', 'bert編碼', '詞序表', 'bert詞序表', 'counter詞序表',       TKN分詞

stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
for ndx, Menu in enumerate(MENU): 表單.append(f'{ndx}{Menu}')
menu = sidebar.radio('MENU', 表單, index=0)
if menu==表單[0]:
  '導入本文'
  TEXT=rtrvTXT()
  stCode(['TEXT總長, TEXT長度=', len(TEXT), len(TEXT.split()), TEXT])
elif menu==表單[8]:
  '段落嵌入'
  全段落字表=session_state['全段落字表']
  stCode(['全段落字表', 全段落字表])
  from torch import zeros_like as trchZerolike, tensor
  input_ids=tensor(全段落字表)
  區段ID= trchZerolike(input_ids)    #區段ID token_type_ids
  stCode(['區段ID', 區段ID])
elif menu==表單[7]:
  '位置嵌入'
elif menu==表單[6]:
  '字嵌入'
  from 字嵌入 import 字嵌入
  全段落字表=session_state['全段落字表']
  字全長=session_state['字全長']
  維度=session_state['維度']
  字向量=字嵌入(字全長, 維度)
  stCode(['字向量=', 字向量])
elif menu==表單[5]:
  '設定參數'
  全段落字表=session_state['全段落字表']
  字全長=session_state['字全長']=len(全段落字表)
  維度=session_state['維度']=100
  stCode(['全段落字表, 字全長, 維度=', 全段落字表, 字全長, 維度])
  #from bert編碼 import 詞編碼
elif menu==表單[4]:
  '全段落序表'
  fullSent=session_state['全段落']
  stCode(['fullSent=', fullSent])
  字表=session_state['字表']
  序表=session_state['序表']
  stCode(['全段落字表', 字表])
  全段落字表=[]
  #全段落序表=[]
  from string import punctuation as 標點符號    #string.punctuation
  for sent in fullSent:
    位序=字表.get(sent)
    if 位序: 全段落字表.append(位序)
    else:
      for word in sent.split():
        word=''.join([CHR for CHR in word if CHR not in 標點符號])
        全段落字表.append(字表.get(word))
  session_state['全段落字表']=全段落字表
  stCode(['全段落字表=', 全段落字表])
  #from 字序編碼 import 字詞序表
  #字表, 序表=字詞序表(Sents)
  #彙表 = 迭代詞表(吐詞表(分詞, doc), specials=['<unk>'])  #.sents
elif menu==表單[3]:
  'Counter分詞' #'Token分詞'
  fullSent=session_state['全段落']
  #TEXT=session_state['TEXT']
  from 字序編碼 import 字詞序表
  特殊彙=session_state['特殊彙']
  字表, 序表=字詞序表(fullSent, 特殊彙)
  session_state['字表']=字表
  session_state['序表']=序表
  stCode(['字表, 序表', 字表, 序表])    #總字數, 
  #分詞 = get_tokenizer('basic_english')
  #TKN=分詞(TEXT)
  #stCode(['torch TKN=', len(TKN), len(set(TKN)), set(TKN)])
elif menu==表單[2]:
  '段落'
  try: fullSent=session_state['全段落']
  except:
    TEXT=rtrvTXT()
    from mk段落 import rtrvSents
    Sents=rtrvSents()
    stCode(['Sents=', Sents])
    fullSent=['[CLS]']
    for ndx, sent in enumerate(Sents):
      fullSent.append(sent)
      if ndx!=len(Sents)-1: fullSent.append('[SEP]')  #最後sent不用加入'[SEP]'
      #else: fullSent.append(sent)
    #fullSent=['CLS']+'[SEP]'.join(Sents)
    session_state['全段落']=fullSent
  stCode(['加入CLS, SEP', fullSent])
  #from string import punctuation as 標點符號    #string.punctuation
  #stCode(['標點符號=', "".join([字 for 字 in TEXT if 字 not in 標點符號])])
elif menu==表單[1]:
  '特殊字'
  from mk特殊字 import 特殊字
  特殊彙=session_state['特殊彙']=特殊字()
  stCode(['特殊字', 特殊彙])
  #'編碼 '
