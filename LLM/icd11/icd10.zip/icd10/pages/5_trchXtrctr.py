from torch import rand as trchRand
import torchvision #.models import resnet18
#from torchvision.models import resnet18
from torchextractor import Extractor

MDL = resnet18()  #torchvision.models.
dummy_input = trchRand(7, 3, 224, 224)

for name, module in MDL.named_modules():
    print(name)

MDL = torchvision.models.resnet18()    #
vghMDL = Extractor(MDL, ["layer1", "layer2", "layer3", "layer4"])

model_output, features = vghMDL(dummy_input)
{name: f.shape for name, f in features.items()}


