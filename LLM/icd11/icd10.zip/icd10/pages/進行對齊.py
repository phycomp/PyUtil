"""
PyTorch tokenizer 進行編碼 得出 labels

在 PyTorch 中，使用 tokenizer 來進行文本編碼（例如 BERT 的 tokenizer）時，常常需要與之對應地生成 labels，以便進行監督學習任務（如分類或序列標注任務）。接下來，我將爲你展示如何使用 tokenizer 對輸入文本進行編碼，同時生成與之對應的 labels，并保持它們的對齊。

示例任務：中文斷詞或序列標注任務 假設我們有一個中文文本任務，例如對句子進行分詞標注（BIO：Begin, Inside, Outside 標注）。我們會將文本通過 tokenizer 進行編碼，然後生成與編碼後的輸入對齊的 labels。

1. 加載 tokenizer 和模型
首先，我們需要一個 tokenizer，這裏我們使用 Hugging Face 的 transformers 庫中的 BERT 模型。

pip install transformers
然後加載 BERT 的 tokenizer：


# 加載預訓練的中文 BERT 模型

"""
from transformers import BertTokenizer
model_name = "bert-base-chinese"
tokenizer = BertTokenizer.from_pretrained(model_name)
"""
2. 準備輸入文本 假設我們有一個簡單的中文文本，并且我們想對該文本進行 BIO 標注。BIO 標注可以是 B（表示詞的開頭）、I（表示詞的內部）、O（表示非詞標記，例如標點符號）。

# 示例文本


"""
text = "今天天氣很好，我想去公園散步。"
segmented_text = ["今天", "天氣", "很好", "，", "我", "想", "去", "公園", "散步", "。"] # 示例分詞結果（人爲標注的分詞）

bio_labels = ["B", "I", "B", "I", "O", "O", "O", "B", "I", "O"] # 對應的 BIO 標簽
# 對文本進行編碼 3. 文本編碼 使用 tokenizer 對文本進行編碼，將文本轉換爲模型可以理解的 input_ids、attention_mask 等。

inputs = tokenizer(text, return_tensors="pt", is_split_into_words=False, truncation=True, padding=True)

# 輸出編碼後的結果
print(inputs)
"""
編碼後的 inputs 是一個包含以下內容的字典：

input_ids: 每個 token 對應的詞匯表中的 ID。
attention_mask: 標記哪些 token 是有效的，哪些是 padding。 可能還包括 token_type_ids 等其他字段。
4. 生成與編碼對齊的 labels 爲了訓練模型，我們需要生成與 input_ids 一一對應的 labels。我們將 BIO 標簽轉換爲數值形式，并确保這些標簽與 input_ids 對齊。 標簽映射到數字：我們需要將 BIO 標簽映射到數值格式，以便模型可以使用。假設我們使用以下映射：

B: 1
I: 2
O: 0
處理特殊字符（如 [CLS], [SEP]）：BERT 模型在編碼時會在句子前後添加特殊標記（如 [CLS] 和 [SEP]），我們需要确保這些標記對應的標簽爲 O。


"""
label_map = {"O": 0, "B": 1, "I": 2} # 標簽映射

labels = [label_map[label] for label in bio_labels] # 根據分詞結果生成 BIO 標簽對應的數值標簽

labels = [0] + labels + [0]  # 對應 [CLS] 和 [SEP] 的標簽爲 0 添加對應的特殊 token 的標簽

"""
現在，labels 已經與 input_ids 對齊，并且我們爲 BERT 特殊標記（例如 [CLS], [SEP]）添加了合適的標簽。

5. 對齊 labels 和 token
因爲 tokenizer 可能會將某些詞分成多個子詞（subword token），例如“今天”可能被編碼成多個 token，所以我們需要确保 labels 和 tokens 的對齊方式一致。
"""

def align_labels_with_tokens(labels, word_ids):
    aligned_labels = []
    previous_word_id = None
    for word_id in word_ids:
        if word_id is None:
            # 對應 [CLS], [SEP] 等特殊標記
            aligned_labels.append(-100)
        elif word_id != previous_word_id:
            # 開始新的詞，分配原本的標簽
            aligned_labels.append(labels[word_id])
        else:
            # 同一個詞的子詞部分，通常繼續分配與詞開頭相同的標簽
            aligned_labels.append(labels[word_id])
        previous_word_id = word_id
    return aligned_labels

word_ids = tokenizer(text).word_ids() # 獲取 word_ids，BERT tokenizer 提供了每個 token 對應的原始 word_id

aligned_labels = align_labels_with_tokens(labels, word_ids) # 對齊後的 labels

labels_tensor = torch.tensor([aligned_labels]) # 將對齊後的 labels 轉換爲 tensor

print(labels_tensor) # 打印對齊後的 labels
"""
6. 模型前向傳播
一旦 inputs 和 labels 都準備好了，就可以將它們傳遞給模型，進行前向傳播并計算損失。


# 加載預訓練的 BERT 模型，num_labels=3 對應 B, I, O

"""
from transformers import BertForTokenClassification
model = BertForTokenClassification.from_pretrained(model_name, num_labels=3)

outputs = model(**inputs, labels=labels_tensor) # 前向傳播

loss = outputs.loss # 提取損失
print(f"Loss: {loss.item()}")

logits = outputs.logits # 提取 logits
print(f"Logits shape: {logits.shape}")
"""
7. 預測 當你訓練好模型後，可以用它來對新的文本進行預測。
文本編碼：使用 tokenizer 將文本轉化爲 input_ids 和其他輸入。
標簽對齊：根據文本中的詞生成相應的 BIO 標簽，并确保這些標簽與編碼後的 token 對齊。
前向傳播與損失計算：通過傳遞 inputs 和 labels，計算模型的損失，并進行訓練。
預測：使用訓練好的模型對新數據進行預測。
這種方法可以用于許多自然語言處理任務，特別是序列標注任務如分詞、命名實體識別等。
"""

with torch.no_grad(): # 進行預測
    outputs = model(**inputs)

logits = outputs.logits # 提取預測的 logits

predicted_labels = torch.argmax(logits, dim=2) # 獲取預測的標簽
print(predicted_labels)
