from transformers import BertTokenizer, BertModel, BertForTokenClassification
from torch import no_grad as trchGrad, tensor as trchTnsr
from torch.optim import AdamW as optimAdamW
from torch.nn import CrossEntropyLoss
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset
from streamlit import text_input, sidebar
from stUtil import rndrCode

# 加載預訓練的BERT模型和分詞器
tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
model = BertForTokenClassification.from_pretrained('bert-base-chinese', num_labels=3)  # 3個標簽: B, I, O

tag2idx = {'B': 0, 'I': 1, 'O': 2} # 標簽映射
idx2tag = {0: 'B', 1: 'I', 2: 'O'}
rndrCode(['tag2idx', tag2idx, 'idx2tag', idx2tag])

class WordSegmentationDataset(Dataset): # 示例數據集
    def __init__(self, texts, labels):
        self.texts = texts
        self.labels = labels
    def __len__(self):
        return len(self.texts)
    def __getitem__(self, idx):
        return self.texts[idx], self.labels[idx]

# 示例輸入文本（已進行BERT tokenization的token ID）
texts = [tokenizer.encode("我愛北京天安門", add_special_tokens=True),  # [CLS]我愛北京天安門[SEP]
    tokenizer.encode("今天天氣很好", add_special_tokens=True)    # [CLS]今天天氣很好[SEP]
]
# 對應標簽
labels = [
    [tag2idx['B'], tag2idx['I'], tag2idx['B'], tag2idx['I'], tag2idx['I'], tag2idx['B'], tag2idx['O']],  # 我 B 愛 I 北京 B 天 I 安 I 門 B
    [tag2idx['B'], tag2idx['I'], tag2idx['B'], tag2idx['I'], tag2idx['O']]  # 今天 B 天 I 氣 B 很 I 好 O
]
rndrCode(['labels', labels, 'texts', texts])
# 數據集與DataLoader
dataset = WordSegmentationDataset(texts, labels)
dataloader = DataLoader(dataset, batch_size=2, shuffle=True)

#3. 構建并訓練模型 損失函數和優化器
optimizer = optimAdamW(model.parameters(), lr=5e-5)
loss_fn = CrossEntropyLoss()

def trainMDL(model): # 訓練模型
  LOSS, EPS=1, 1e-6
  while LOSS>EPS:
    model.train()
    for batch in dataloader:
      輸入, labels = batch
      輸入 = pad_sequence([trchTnsr(t) for t in inputs], batch_first=True)  # 填充序列
      labels = pad_sequence([trchTnsr(l) for l in labels], batch_first=True)  # 填充標簽
      輸出 = model(輸入, labels=labels) # 前向傳播
      loss = 輸出.loss

      optimizer.zero_grad() # 反向傳播和優化
      loss.backward()
      optimizer.step()
      LOSS=loss.item()

  print(f"LOSS: {loss.item()}")

# 推理函數 4. 推理與分詞 在推理階段，給定輸入句子，模型將預測每個字的分詞標簽。
def predict(sentence):
    model.eval()
    with trchGrad():
        tokens = tokenizer.encode(sentence, add_special_tokens=True)
        輸入 = trchTnsr([tokens])
        輸出 = model(輸入).logits
        predictions = 輸出.argmax(dim=-1).tolist()[0]

        # 去掉 [CLS] 和 [SEP] 特殊token的標簽
        predictions = predictions[1:-1]
        tokens = tokenizer.convert_ids_to_tokens(tokens[1:-1])

        # 輸出分詞結果
        segmented_sentence = ""
        for token, tag in zip(tokens, predictions):
            if idx2tag[tag] == 'B':
                segmented_sentence += " " + token
            else:
                segmented_sentence += token
        return segmented_sentence.strip()

# 示例推理
sentence = "我愛北京天安門"
with sidebar:
  sent=text_input('中文句子', sentence)
if sent:
  trainMDL(model)
  segmented_sentence = predict(sentence)
  rndrCode(["分詞結果:", segmented_sentence])
