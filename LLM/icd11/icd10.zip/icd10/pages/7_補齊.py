import random
from stUtil import rndrCode
from torch import from_numpy, tensor, zeros, float64
import numpy as np
from torch.utils.data import Dataset, DataLoader

class DemoDataset(Dataset):
    def __init__(self):
        super().__init__()
        
    def __getitem__(self, idx):

        # create two lists of random length
        a = random.sample(range(1, 100), random.randint(1, 10))
        b = random.sample(range(1, 100), random.randint(1, 10))
        b = list(map(float, b))
        c = np.random.randn(10)
        return { 'A': a, 'B': b,  'C': c }
    def __len__(self):
        return 100
      
def collate_fn(data):
    """
    Parameter
    ----------
    data: list of dict's
      Each list element is a dictionary containing values of unpadded sequences of variable size.
    
    Returns
    ----------
    padded_data: dict
      For each key in the input, the across the input dictionaries are merged into one padded sequence. 
      Further the lengths of the unpadded sequences is returned.
    """
    
    keys = data[0].keys()
    types = [type(data[0][key][0]) for key in keys]
    padded_data = dict()
    
    for ndx, key in enumerate(keys):
        if 'numpy' in str(types[ndx]):
            padded = from_numpy(np.stack([d[key] for d in data]))
        else:
            # get all the lengths for each
            lengths = [len(d[key]) for d in data]
            padded_data[key+'_lengths'] = tensor(lengths).long()

            # pad sequence up to max(lengths)
            padded = zeros(len(lengths), max(lengths))
            for j, (l, d) in enumerate(zip(lengths, data)):
                padded[j, :l] = padded.new_tensor(d[key])

            # map padded sequence to datatype
            # this needs to be adapted/extended to key or different datatypes
            if types[ndx] == int:
                padded = padded.long()
                
        padded_data[key] = padded
        
    return padded_data
    
dataset = DemoDataset()
dataloader = DataLoader(dataset, batch_size=4, collate_fn=collate_fn)
rndrCode(next(iter(dataloader)))

"""
{
'A_lengths': tensor([ 10,   9,   6,   2]), 
'A': tensor([[ 70,  95,  77,  15,   6,  47,  62,  40,  27,  23],
        [ 80,   3,  88,  86,  19,  15,  97,  29,  34,   0],
        [ 19,  83,  50,  61,  31,  21,   0,   0,   0,   0],
        [  2,  55,   0,   0,   0,   0,   0,   0,   0,   0]]), 
'B_lengths': tensor([  8,  10,   4,   5]), 
'B': tensor([[ 16.,  11.,  28.,  94.,  51.,  90.,  17.,  65.,   0.,   0.],
        [ 41.,  80.,  18.,  52.,  83.,  76.,  21.,  51.,   2.,   6.],
        [ 30.,  84.,  46.,  14.,   0.,   0.,   0.,   0.,   0.,   0.],
        [ 95.,  27.,  71.,   8.,  21.,   0.,   0.,   0.,   0.,   0.]]), 
'C': tensor([[ 0.6824, -0.5277, -1.5772, -1.4138, -1.7949,  0.9358,  1.1946,
          0.7383,  1.1186, -1.2569],
        [ 0.8977,  0.5495,  1.5711, -1.6255,  2.3798, -0.2793, -1.5662,
         -0.2867,  1.0533, -0.0723],
        [-0.1341,  0.2721, -0.2921, -0.1147, -0.4918,  0.4252, -2.0790,
          1.1592, -0.4668,  0.4685],
        [-0.1061, -0.0293, -0.6282,  0.5343, -1.0037,  0.2852,  0.2818,
          2.1027, -0.4701,  1.8419]], dtype=float64)
}
"""
