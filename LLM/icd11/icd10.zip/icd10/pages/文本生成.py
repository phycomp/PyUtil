#使用 PyTorch 訓練文本來實現語言模型（Language Model）可以通過以下幾個步驟來完成。這裡，我會演示如何構建一個簡單的字符級（Character-level）語言模型。你可以根據需求進一步擴展。
from stUtil import rndrCode
from torch import tensor as trchTnsr, argmax as trchArgmax
from torch.nn import Module, Embedding, LSTM, Linear, CrossEntropyLoss
from torch.optim import Adam
from torch import zeros as trchZeros
#2. 導入必要的庫
#import torch
#import torch.nn as nn
#import torch.optim as optim
#import numpy as np
#3. 準備數據
#首先，定義我們的文本數據集。我們將文本數據轉換為字符序列，並構建字典來將字符映射到索引。
# 假設我們的訓練數據是一個簡單的文本

text = "hello world"
chars = sorted(list(set(text)))     # 創建字典：字符到索引的映射
char_to_idx = {ch: i for i, ch in enumerate(chars)}
idx_to_char = {i: ch for i, ch in enumerate(chars)}
input_data = [char_to_idx[ch] for ch in text]   #將文本轉換為索引
vocab_size = len(chars)
#4. 定義模型
#定義一個簡單的基於 LSTM 的字符級語言模型。

from torch import device as trchDevice, cuda as trchCuda
device = trchDevice("cuda") if trchCuda.is_available() else trchDevice("cpu")
rndrCode(['device', device])

class CharRNN(Module):
    def __init__(self, vocab_size, hidden_size, num_layers):
        super(CharRNN, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.embed = Embedding(vocab_size, hidden_size) # 定義嵌入層
        self.lstm = LSTM(hidden_size, hidden_size, num_layers, batch_first=True) # 定義LSTM層
        self.fc = Linear(hidden_size, vocab_size) # 定義全連接層
    def forward(self, x, hidden):
        x = self.embed(x)
        out, hidden = self.lstm(x, hidden)
        out = self.fc(out.reshape(out.size(0) * out.size(1), out.size(2)))
        return out, hidden
    def init_hidden(self, batch_size): # 初始化隱藏狀態
        return trchZeros(self.num_layers, batch_size, self.hidden_size).to(device), trchZeros(self.num_layers, batch_size, self.hidden_size).to(device)
hidden_size, num_layers=128, 2  # 定義超參數
model = CharRNN(vocab_size, hidden_size, num_layers).to(device)
#5. 損失函數與優化器
def trainMDL(model):    #6.訓練模型 接下來，我們會使用循環的方式將字符序列餵給模型進行訓練。
  criterion = CrossEntropyLoss()
  optimizer = Adam(model.parameters(), lr=.001)
  num_epochs, seq_length, batch_size=100, 5, 1  # 每次訓練的序列長度
  #for epoch in range(num_epochs):
  LOSS, EPS=1, 1e-5
  while LOSS>EPS:
      hidden = model.init_hidden(batch_size)
      for i in range(0, len(input_data) - seq_length, seq_length):
          輸入 = trchTnsr(input_data[i:i+seq_length]).unsqueeze(0).to(device)
          targets = trchTnsr(input_data[i+1:i+seq_length+1]).to(device)
          optimizer.zero_grad()
          outputs, hidden = model(輸入, hidden)
          hidden = hidden[0].detach(), hidden[1].detach() # 將隱藏狀態從計算圖中分離
          loss = criterion(outputs, targets.view(-1))
          loss.backward()
          optimizer.step()
          LOSS=loss.item()
  rndrCode(f'LOSS: {loss.item()}')
#if (epoch+1) % 10 == 0: print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')
#7. 生成文本 訓練完模型後，我們可以使用它來生成文本。從初始字符開始，依次預測下一個字符，然後使用預測的字符作為下一步的輸入。
def generate_text(model, start_char, predict_len):
    model.eval()  # 設置模型為評估模式
    hidden = model.init_hidden(1)
    輸入 = trchTnsr([char_to_idx[start_char]]).unsqueeze(0).to(device)
    predicted_text = start_char
    for _ in range(predict_len):
        output, hidden = model(輸入, hidden)
        output = trchArgmax(output, dim=1)
        predicted_char = idx_to_char[output.item()]
        predicted_text += predicted_char
        輸入 = output.unsqueeze(0)
    return predicted_text
# 生成文本，從 'h' 開始
start_char = 'h'
trainMDL(model)
rndrCode(generate_text(model, start_char, 50))
