from transformers import BertModel, BertTokenizer #transformers
from streamlit import session_state, code as stCode, write as stWrite, sidebar
lngName='/home/josh/bert-base-uncased'

stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
表單, MENU=[], ['本文TEXT', '特殊字', '段落', 'counter分詞', '全段落序表', '設定參數', '字嵌入', '位置嵌入', '段落嵌入', '總嵌入', 'vocabIter', 'Padding', 'vocabDemo', 'Vocab', 'inputIDs', 'bertEmdding'] #Uncased, 'fastText', 'csvEye', 'answerQuestion', 'ansQues2', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec', EMBEDDING  '字嵌入', 'TKN', 'spacyDoc', 'bert編碼', '詞序表', 'bert詞序表', 'counter詞序表',       TKN分詞
for ndx, Menu in enumerate(MENU): 表單.append(f'{ndx}{Menu}')
menu = sidebar.radio('MENU', 表單, index=0)
if menu==表單[0]:
  '導入本文'
  from mk本文 import rtrvTXT
  TEXT=rtrvTXT()
  #TEXT=session_state['TEXT']
  stCode(['TEXT', TEXT])
  #分詞=BertTokenizer(TEXT)
  session_state['分詞']=分詞=BertTokenizer.from_pretrained(lngName)
  #TKN=分詞(TEXT)     #作出三類=>input_ids, token_type_ids, attention_mask
  編碼文字 = 分詞.encode_plus(TEXT, add_special_tokens=True, max_length=100, pad_to_max_length=True, return_tensors='pt')
  stCode(['input_ids=', 編碼文字.input_ids])
  stCode(['input_ids, token_type_ids, attention_mask長度=', len(編碼文字.input_ids[0]), len(編碼文字.token_type_ids[0]), len(編碼文字.attention_mask[0])])
  #BertModel()
  #input_ids=None, attention_mask=None, token_type_ids=None, position_ids=None, head_mask=None, inputs_embeds=None, encoder_hidden_states=None, encoder_attention_mask=None
elif menu==表單[1]:
  TEXT=session_state['TEXT']
  分詞=session_state['分詞']
  TKN=分詞.tokenize(TEXT)
  stCode(['TEXT, TKN=', TEXT, TKN])

