from tensorflow.keras.optimizers import Adam, SparseCategoricalCrossentropy
from transformers import GPT2Tokenizer, GPT2LMHeadModel, expand_dims, GradientTape
from stUtil import rndrCode
text = [] # 加載文本數據集
with open('text_data.txt', 'r') as f:
    text = f.readlines()
# 建立tokenizer
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
# 將文本數據集轉換為token ids
input_ids = []
attention_masks = []
for line in text:
    encoded_dict = tokenizer.encode_plus( line, add_special_tokens=True, max_length=512, pad_to_max_length=True, return_attention_mask=True)
    
    input_ids.append(encoded_dict['input_ids'])
    attention_masks.append(encoded_dict['attention_mask'])
# 建立模型
model = GPT2LMHeadModel.from_pretrained('gpt2')
# 將模型設置為訓練模式
model.train()
# 設置訓練參數 tf.keras.optimizers. tf.keras.losses.
optimizer = Adam(learning_rate=3e-5, epsilon=1e-08, clipnorm=1.0)
loss_fn = SparseCategoricalCrossentropy(from_logits=True)
# 訓練循環
EPOCHS = 10
for epoch in range(EPOCHS):
    print(f'Epoch {epoch + 1}/{EPOCHS}')
    total_loss = 0
    # 遍歷所有文本 
    for i in range(len(text)):
        inputs = expand_dims(input_ids[i], 0)
        masks = expand_dims(attention_masks[i], 0)
        with GradientTape() as tape:
            logits = model(inputs, attention_mask=masks)
            loss = loss_fn(text[i][1:], logits[0][:-1, 0])
        
        total_loss += loss
        # 反向傳播與更新權重
        grads = tape.gradient(loss, model.trainable_variables)
        optimizer.apply_gradients(zip(grads, model.trainable_variables))
    
    rndrCode(f'Loss: {total_loss / len(text)}')
