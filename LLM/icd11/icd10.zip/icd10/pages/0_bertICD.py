from torch import device as trchDevice, cuda as trchCuda
from streamlit import sidebar, radio as stRadio, text_input
from streamlit import text_area, session_state#, write as stWrite
from stUtil import rndrCode
from seqUtil import rtrvMaxsize

MENU, 表單=[], ['Device', '字嵌入', '分詞', '位置嵌入', '補齊', 'vocabIter', 'Padding', 'vocabDemo', 'Vocab', '分詞'] #Uncased, 'fastText', 'csvEye', 'answerQuestion', 'ansQues2', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec', EMBEDDING 象嵌入 總嵌入
#MENU, 表單=[], ['六十四卦', '先後天', '卦爻辭', '錯綜複雜', '二十四節氣']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')

if menu==len(MENU[-3]):
  pass
elif menu==MENU[8]:
  '分詞'
  from torchtext.data.utils import get_tokenizer
  分詞=get_tokenizer('basic_english')
  TEXT=session_state['TEXT']
  TKN=分詞(TEXT)   #TKN=分詞('which is a way to receive inputs from the user! Personally, I did not know how it works before reading this file and frankly, I think it is an awesome feature in python. Basically, what the input function does is to print the string given to it by input and then request user input. This raw_text then is encoded into tokens using')
  session_state['TKN']=TKN
  rndrCode(['TKN', TKN])    #['which', 'is', 'a', 'way', 'to', 'receive', 'inputs', 'from', 'the', 'user', '!', 'personally', ',', 'i', 'did', 'not', 'know', 'how', 'it', 'works', 'before', 'reading', 'this', 'file', 'and', 'frankly', ',', 'i', 'think', 'it', 'is', 'an', 'awesome', 'feature', 'in', 'python', '.', 'basically', ',', 'what', 'the', 'input', 'function', 'does', 'is', 'to', 'print', 'the', 'string', 'given', 'to', 'it', 'by', 'input', 'and', 'then', 'request', 'user', 'input', '.', 'this', 'raw_text', 'then', 'is', 'encoded', 'into', 'tokens', 'using']
elif menu==MENU[7]:
  'vocabDemo'
elif menu==MENU[6]:
  from mnplVocab import mkVocab
  TKN=session_state['TKN']
  mkVocab(TKN)
elif menu==MENU[5]:
  try: filePath=session_state['filePath']
  except: filePath=session_state['filePath']='vghMDL/'
  特殊符=["<unk>"]
  vocab = build_vocab_from_iterator(yieldTKN(filePath), specials=特殊符)
  rndrCode(['vocab=', vocab])
elif menu==MENU[4]:
  'Padding' #補齊
  from cntxtPadding import 補齊
  from 動態補齊 import DatasetVGH, collateVGH
  from torch.utils.data import DataLoader, Dataset
  TEXT=session_state['TEXT'].split('.')
  rndrCode(['TEXT', TEXT])
  #dset = DatasetVGH(sequences)
  for txt in TEXT:
    dset=DatasetVGH(txt)
    dtLoader = DataLoader(dset, batch_size=3, collate_fn=collateVGH)
    rndrCode(['dtLoader', dtLoader])
    for batch in dtLoader: # 循環輸出每個批次
        rndrCode(batch)
  #補齊(TEXT)
elif menu==MENU[3]:
  from posEmbddng import 位置嵌入
  maxSeqlen=session_state['maxSeqlen']
  隱藏量, 詞最大=30, maxSeqlen
  posEmbddng=位置嵌入(隱藏量, 詞最大)
  rndrCode(['posEmbddng=', posEmbddng])
elif menu==MENU[2]:
  '分詞'    #象嵌入
  import torchtext
  from torchtext.data import get_tokenizer
  分詞 = get_tokenizer("basic_english")
  rndrCode(['分詞', 分詞])
  TEXT=session_state['TEXT']
  TKN = 分詞(TEXT)  #"You can now install TorchText using pip!"
  session_state['TKN']=TKN
  rndrCode(['TKN=', TKN]) #cntxt, 
  #lngMDL = 'bert-base-cased'
  #from bertEmbddng import BertEmbeddings
  #from bertTokenMNPL import bertToken   #rtrvToken 
  #from vocabMNPL import 計算彙
  #TEXT=session_state['TEXT']
  #vghTKN, Label=計算彙(TEXT)
  #編碼=bertToken(lngMDL, TEXT)
  #tknSize=rtrvMaxsize(vghTKN)
  #總嵌入=BertEmbeddings(TEXT)
  #rndrCode(['總嵌入', txtInfo, Label])  #總嵌入
elif menu==MENU[1]:     #'maxSeqlen'
  try:
    TEXT=session_state['TEXT']
  except:
    #info=text_area('cudaDevice', TEXT)
    session_state['TEXT']=TEXT='which is a way to receive inputs from the user! Personally, I did not know how it works before reading this file and frankly, I think it is an awesome feature in python. Basically, what the input function does is to print the string given to it by input and then request user input. This raw_text then is encoded into tokens using'
    #TKN=分詞(cntxt)   #TKN=分詞('')是否可以作成物理', '量子物理'
  rndrCode(['TEXT=', TEXT])    #[text for text in ]
  字最長=rtrvMaxsize(TEXT)
  session_state['maxSeqlen']=字最長
  rndrCode(['maxSeqlen', 字最長])
elif menu==MENU[0]:
  'Device'
  from device import showDevice
  showDevice()
