from stUtil import rndrCode
from sklearn.feature_extraction.text import TfidfVectorizer
#示例文本數據 準備文本數據 這裏假設我們有一些文本數據，例如來自電子健康記錄（EHR）中的診斷描述。
#documents = [ "Patient diagnosed with diabetes mellitus", "Diagnosis of hypertension and heart disease", "No signs of diabetes, but symptoms of hypertension", "Heart disease and diabetes diagnosis confirmed" ]
ehrData={'診斷':"""BP: 0 / 0 PP: 0 BH: 160 BW: 0
S:主觀資料
TSCP OS on 20190315
s/p IVIL OD on 1080128, 1080226
s/p IVIE(c) + AC paracentesis OS on 1080104
s/p FGE + IVIA OS 1071210
PDR with NVI OS s/p IVIL(f) OS on 1071120
ocular and head pain OS for 3 days
ever occurred before cataract surgery
PDR with VH OS s/p IVIA(f) OS on 1070903
sudden blurring when wakeup 1 weeks ago , not improved
PDR with TRD , r/o RRD OS s/p VT+MP+R/T+16% C3F8 OS on 1070313
PDR wth vh os s/p IVIE (c) OS 1070102; s/p PRP OD on 1070209
sudden onset of blurry vision os 20+ days ago ,
s/p cataract op ou 7-8 years ago
mother : DM+ under

O:客觀資料
Va 5/60cc od; LP cc OS  ;NCTIOP 21/55 mmHg
1080104 Ref: -0.75-0.5x10/ -0.75
1071218 Ref: -0.25-0.75x1/ +0.5-0.25x70
1071211 Ref: -0.5/error
1071103 Ref: -0.25-0.25x25/ -0.25x156
1070903 Ref: 0.0-0.25x5/err
1070510 Ref: -0.5-0.5x30/ -0.25-0.75x160
1070309 ref -0.25-1.5x1/+1.75-0.25x52
1070126 ref -0.25-0.75*10/err
1070112 Ref: -0.25-2.25x180/ err
1070329 Ref: -0.25-0.75x28/ err
1070419 Ref: -0.0-1.0x20/ +0.5-0.75x75
1070510 CCT= 624/628 um
Slitlamp: NVI OS
cornea microcystic edema OS, A/C deep silent ou lens PCIOL ou with
glistening
indirect fundoscopy: vitreous hemorrahge os, diffuse microaneurysm od,
lipids at parafovea od,  with preretinal H od,
B scan: no RD os, VH OS
1061229 Fd: grossly attached with VH OS . disc can be seens OS
1070112 Fd: grossly attached with VH OS . disc can be seens OS
1070126 Fd: grossly attached with VH OS . disc can be seens OS
1070209 Fd: less VH with disc view OS, diffuse dots hemorhage OD
1070309 Fd+OCT: faint VH OS; preretinal fibrosis over lower arcade with RD
OS; MACULA OFF OS
1070320 Fd: gas full with attached retina OS
1070329 Fd: attached retina with gas 60 %
1070406 Fd: attached retina with gas 40 %
1070419 Fd+OCT: attached retina with residual SRF OS , gas 30 %
1070510 fd+OCT: persistent shallow SRF OS
1070621 Fd+OCT: persistent shallow SRF OS
1070809 Fd+OCT: persistent shallow SRF but less OS
1070903 B-scan: no RD sign OS
1070903 fd: obscured without disc view OS
1070911 fd: obscured without disc view OS
1070925 Fd: VH with dics view, grossly attached  OS
1071103 Fd+color+OCT: attached retina with residual faint VH OS
1071103 Fd+color+OCT: attached retina with residual faint VH OS
1071207 Fd: attached retina with residual faint VH OS; no disc view OS
1071211 Fd: grossly attached retina with disc can be seen OS
1071218 Fd: attached retina OS
1080104 Fd: attached retina with faint VH OS
1080118 Fd: attached retina with subtotal cupping OS
1080226 Fd: faint VH OD
1080122 Fd: attached retina OD, mild SRF OS , VMT OD
1080128 Fd: new retinal hemorrahge over macula with faint VH OD
1080226 Fd: faint VH OD

A:診斷
PDR
NIDDM RETINOPATHY(ADD BDR-362.01,PDR-362.02)
VITREOUS OPACITY/FLOATERS
NVG

 
Type 2 diabetes mellitus with proliferative diabetic retinopathy with macular ed
Type 2 diabetes mellitus with proliferative diabetic retinopathy without macular
Other vitreous opacities, left eye
Other specified glaucoma

P:治療計畫
FU 1w +IOP + dilatation
consider STK if SRF persistent
Bring medication
1061214 HbA1c  12.8 --> 11.0 %--> 9.1 %
keep medication"""}
#初始化 TfidfVectorizer： 我們可以根據具體需求自定義 TfidfVectorizer 的參數，如 max_features（最大特征數）、ngram_range（使用 n-grams）、stop_words（忽略停用詞）等。
# 初始化 TfidfVectorizer
vectorizer = TfidfVectorizer(max_features=50, stop_words=['english'], ngram_range=(3,5))  # 設置最大特征數為 10 將文本數據轉換為特征矩陣 使用 fit_transform() 方法將文本數據轉換為 TF-IDF 特征矩陣。 使用 fit_transform 將文本轉換為 TF-IDF 特征矩陣
Doc=ehrData['診斷'].split('\n')
rndrCode([Doc])
tfidfM = vectorizer.fit_transform(Doc)
#tfidf_matrix = vectorizer.fit_transform(documents)

# 打印特征矩陣
rndrCode(tfidfM.toarray())  # 將稀疏矩陣轉換為數組格式以便查看 查看特征名： 使用 get_feature_names_out() 可以查看特征矩陣中的詞匯表。
# 查看詞匯表
rndrCode(['featureNames=', Doc, vectorizer.get_feature_names_out()])    #get_feature_names_outug

