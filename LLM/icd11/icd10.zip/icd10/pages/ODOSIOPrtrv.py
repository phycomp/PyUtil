from transformers import BertTokenizer, BertForTokenClassification
from transformers import pipeline
from stUtil import rndrCode
from transformers import AdamW
from torch.utils.data import DataLoader
from torch.optim import SGD
from torch.nn import Module, Linear, CrossEntropyLoss
from torch import relu as trchRELU, argmax as trchArgmax
from streamlit import sidebar, radio as stRadio, text_input, session_state

def predMDL():
  預測 = trchArgmax(outputs.logits, dim=2)  #獲取預測的實體類別
  tokens = tokenizer.convert_ids_to_tokens(輸入["input_ids"].squeeze().tolist()) # 獲取標注的實體名稱
  labels = 預測.squeeze().tolist()
  for token, label in zip(tokens, labels): # 輸出提取的結果
    if label == 1: entity = "OD"
    elif label == 2: entity = "OS"
    elif label == 3: entity = "IOP"
    else: entity = "O"
    rndrCode(f"Token: {token}, Entity: {entity}")

# 加載預訓練的BERT模型和分詞器（帶NER任務）
class CustomNERDataset(Module):
    def __init__(self):
        super(CustomNERDataset, self).__init__()
        self.fc1 = Linear(10, 50)
        self.fc2 = Linear(50, 2)

    def forward(self, x):
        x = trchRELU(self.fc1(x))
        x = self.fc2(x)
        return x

def 準備(model):
  criterion = CrossEntropyLoss()
  sgdOptmzr = SGD(model.parameters(), lr=.01)
  adamOptmzr = AdamW(model.parameters(), lr=5e-5) # 定義優化器
  train_dataset = CustomNERDataset(文本, labels, tokenizer, max_len=128) # 假設我們有一個自定義的數據集
  train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
  model.train() # 訓練過程
def 訓練(model):
  for epoch in range(3):  # 訓練3個epoch
    for batch in train_loader:
      optimizer.zero_grad()
      輸入 = batch['input_ids'].to(device)
      labels = batch['labels'].to(device)
      outputs = model(input_ids=輸入, labels=labels)
      loss = outputs.loss
      loss.backward()
      optimizer.step()
    rndrCode(f"Epoch {epoch + 1} completed.")

MENU, 表單=[], ['輸出輸入', 'ODOSIOP', '微調', '錯綜複雜', '二十四節氣']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[1]:
  pass
  #tblName='sutra'
  #sutraCLMN=queryCLMN(tblSchm='public', tblName=tblName, db='sutra')
  #rndrCode(sutraCLMN)
  #fullQuery=f'''select {','.join(sutraCLMN)} from {tblName} where 章節~'中庸';'''
  #rsltQuery=runQuery(fullQuery, db='sutra')
  #rndrCode([fullQuery, rsltQuery])
  #rsltDF=session_state['rsltDF']=DataFrame(rsltQuery, index=None, columns=sutraCLMN)
  #rsltDF#[rsltDF['章節']=='中庸']
  from transformers import BertTokenizer, BertForTokenClassification
  from torch import no_grad as trchGrad
  tokenizer = BertTokenizer.from_pretrained('../bert-base-cased')
  model = BertForTokenClassification.from_pretrained('../bert-base-cased', num_labels=3)  # 假设你有3个标签：OD, OS, IOP

  文本=session_state['文本']#="Objective: OD 24 mmHg, OS 22 mmHg, IOP within normal limits."
  rndrCode(['文本', 文本])
  輸入=tokenizer(文本, return_tensors="pt", truncation=True, padding=True)
  with trchGrad():
      輸出 = model(**輸入)
  預測=trchArgmax(輸出.logits, dim=2)
  rndrCode(['預測', 預測])
  分詞=tokenizer.convert_ids_to_tokens(輸入["input_ids"].squeeze().tolist())
  for token, label in zip(分詞, 預測[0].tolist()):
    if label == 0: entity = "O"
    elif label == 1: entity = "OD"
    elif label == 2: entity = "OS"
    elif label == 3: entity = "IOP"
    rndrCode(f"Token: {token}, Entity: {entity}")

elif menu==MENU[0]:
  tokenizer = BertTokenizer.from_pretrained("../bert-base-cased")
  model = BertForTokenClassification.from_pretrained("../bert-base-cased", num_labels=3)  # 3表示標簽數量，OD, OS, IOP
  文本=session_state['文本']="Objective: OD 24 mmHg, OS 22 mmHg, IOP within normal limits."   # 示例SOAP文本
  #輸入=tokenizer(文本, return_tensors="pt", truncation=True, padding=True)  #分詞和編碼
  #tkn=tokenizer.tokenize(文本)
  #rndrCode(['輸入', tkn, 輸入])
  #輸出=model(**輸入) # 模型推理
  #rndrCode(['輸出', 輸出])
