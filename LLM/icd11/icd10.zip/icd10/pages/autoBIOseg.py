from transformers import BertTokenizer, BertForTokenClassification
from streamlit import sidebar, text_input, radio as stRadio, session_state
from stUtil import rndrCode
from torch import long as trchLong, no_grad as trchNograd, tensor as trchTnsr
from torch import argmax as trchArgmax

# 將 BIO 標簽映射回詞語 根據 BIO 標注結果，可以將文本拆分成對應的詞語。
def bio_to_words(text, bio_labels):
    words = []
    current_word = ""
    for char, label in zip(text, bio_labels):
        if label == "B":
            if current_word:
                words.append(current_word)
            current_word = char
        elif label == "I":
            current_word += char
        else:
            if current_word:
                words.append(current_word)
            current_word = ""
            words.append(char)
    if current_word:
        words.append(current_word)
    return words

def trainMDL(model, 輸入, 標記量): #5. 訓練與微調模型 在斷詞任務中，模型的訓練過程與其他自然語言處理任務類似。可以使用優化器如 Adam 來更新模型參數，進行多次迭代以提高模型的性能。
  from torch.optim import AdamW
  optimizer = AdamW(model.parameters(), lr=5e-5) # 定義優化器
  #for epoch in range(3):  # 訓練循環 假設訓練 3 個 epoch
  LOSS, EPS=1, 1e-3
  while LOSS>EPS:
      model.train()
      optimizer.zero_grad()
      輸出 = model(**輸入, labels=標記量) # 前向傳播與計算損失
      loss = 輸出.loss
      loss.backward() # 反向傳播與參數更新
      optimizer.step()
      LOSS=loss.item()
  rndrCode(f"Loss: {loss.item()}")
  return 輸出

def 作標記(segmented_text): # 生成 BIO 標注
    labels = []
    for word in segmented_text:
        if len(word) == 1: labels.append("O")
        else:
            labels.append("B")
            labels.extend(["I"] * (len(word) - 1))
    return labels

def 作出預測(輸出, 文本):
  預測 = trchArgmax(輸出.logits, dim=2) # 預測標簽
  預標注 = 預測.squeeze().tolist() # 將預測結果映射回 BIO 標簽
  標籤=session_state['標籤']
  反向標注 = {v: k for k, v in 標籤.items()}
  predicted_bio_labels = [反向標注[label] for label in 預標注]
  rndrCode(f"新標記 Predicted BIO Labels: {predicted_bio_labels}") # 打印預測的 BIO 標簽
  words = bio_to_words(文本, predicted_bio_labels) # 分詞結果
  rndrCode(f"Segmented Words: {words}")

MENU, 表單=[], ['bio標記', '分詞', '訓練', '分詞2標記', '二十四節氣']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #srch=text_input('搜尋', '')
  文本=session_state['文本']=text_input('文本', '位於蘆洲區的馬達加斯加公園')
if menu==len(表單):
  pass
elif menu==MENU[3]:
  segmented_text = ["今天", "天氣", "很好", "，", "我", "想", "去", "公園", "散步", "。"]

  分詞=['位於', '蘆洲區', '的', '馬達加斯加', '公園']
  def generate_bio_labels(segmented_text): # 生成 BIO 標注
      labels = []
      for word in segmented_text:
          if len(word) == 1: labels.append("O")
          else:
              labels.append("B")
              labels.extend(["I"] * (len(word) - 1))
      return labels
  文本=session_state['文本']
  標記=generate_bio_labels(分詞)
  rndrCode([分詞, 標記])
elif menu==MENU[2]:
  model=session_state['模型']
  輸入=session_state['輸入']
  標記量=session_state['標記量']
  文本=session_state['文本']
  輸出=trainMDL(model, 輸入, 標記量)
  作出預測(輸出, 文本)
elif menu==MENU[1]:
  #6. 預測與分詞 在訓練好模型后，可以使用它來對新的中文文本進行分詞預測。
  model=session_state['模型']
  model.eval() # 使用模型進行預測
  輸入=session_state['輸入']
  with trchNograd():
      輸出 = model(**輸入)
  文本=session_state['文本']
  作出預測(輸出, 文本)
elif menu==MENU[0]:
  mdlName = "bert-base-chinese" # 加載中文 BERT 模型和 tokenizer
  tokenizer = BertTokenizer.from_pretrained(mdlName)
  model=session_state['模型']= BertForTokenClassification.from_pretrained(mdlName, num_labels=3)  # 3 類：B, I, O
  #3. 自動生成 BIO 標注
  #為了生成訓練數據的標注，我們需要為每個字標注它在詞語中的角色。假設我們有人工分詞結果為：
  分詞=['位於', '蘆洲區', '的', '馬達加斯加', '公園']# # 已知分詞結果 ["天氣", "很好", "，", "我", "想", "去", "公園", "散步", "。"]
  初步標記=作標記(分詞)
  rndrCode(['初步標記', 初步標記]) #['B', 'I', 'B', 'I', 'I', 'O', 'B', 'I', 'I', 'I', 'I', 'B', 'I']
  #4. 數據編碼和模型訓練 將中文文本分詞，并根據 BIO 標注生成相應的訓練數據。首先需要將文本轉化為 BERT 可以處理的輸入格式。
  assert len(''.join(分詞))==len(文本)
  if 文本:
    輸入=tokenizer(文本, return_tensors="pt", is_split_into_words=False, truncation=True, padding=True)     #對原始文本進行編碼
    rndrCode(['輸入', 輸入, 輸入.input_ids.size()]) #input_ids, token_type_ids, attention_mask
    標映={"O": 0, "B": 1, "I": 2} # BIO 標簽映射為數值
    標值 = [標映[label] for label in 初步標記]
    標值量=session_state['標值量']=trchTnsr([標值], dtype=trchLong) # 將標簽轉化為 tensor
    rndrCode([f'標映:{標映}', f'labels:{標值}', f'標值量:{標值量}'])
    #然后我們可以進行模型的前向傳播，并計算損失。我們會對每個字符進行分類（B, I, O），因此這個任務是一個 Token-Level Classification（標記級分類） 問題。
    # 前向傳播，計算損失
    outputs = model(**輸入, labels=標值量)
    loss = outputs.loss
    logits = outputs.logits
    rndrCode(f"Loss: {loss.item()}")
