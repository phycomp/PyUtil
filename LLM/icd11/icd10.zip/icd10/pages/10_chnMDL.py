from streamlit import stRadio, sidebar, text_input, session_state
#torch 訓練中文語言模型
#訓練中文語言模型可以使用 PyTorch 這個深度學習框架。以下是一個基本的步驟指南，幫助你使用 PyTorch 訓練中文語言模型：
#1. 環境準備 首先，你需要安裝必要的庫：
#pip install torch transformers datasets
#2. 數據集準備 選擇一個中文語料庫，例如中文維基百科或其他文本數據集。你可以使用 Hugging Face 的 datasets 庫來輕鬆下載和使用數據集。

def mkDset():
  from datasets import load_dataset
  dataset = load_dataset('wikipedia', 'zh') # 載入中文文本數據集（例如中文維基百科）

  #3. 數據預處理 將文本數據進行預處理，例如分詞、轉換為 ID 等。你可以使用 transformers 庫中的 Tokenizer。

  from transformers import BertTokenizer
  tokenizer = BertTokenizer.from_pretrained('bert-base-chinese') # 使用 BERT Tokenizer

  def tokenize_function(examples):
      return tokenizer(examples['text']) # 對數據集進行分詞

  tokenized_datasets = dataset.map(tokenize_function, batched=True)

  #4. 訓練模型 使用 transformers 中的 Trainer 來訓練模型。
  from transformers import BertForMaskedLM, Trainer, TrainingArguments

  model = BertForMaskedLM.from_pretrained('bert-base-chinese') # 載入預訓練的模型

  training_args = TrainingArguments( output_dir='./results', evaluation_strategy="epoch", learning_rate=2e-5, per_device_train_batch_size=16, num_train_epochs=3) # 訓練參數設置

  trainer=Trainer(model=model, args=training_args, train_dataset=tokenized_datasets['train'],) # 初始化 Trainer

  trainer.train() # 開始訓練
MENU, 表單=[], ['六十四卦', '先後天', '卦爻辭', '錯綜複雜', '二十四節氣']
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[0]:
  mkDset()
elif menu==MENU[1]:
  #5. 評估和保存模型 訓練完成後，可以評估模型的性能並保存模型。
  trainer.evaluate() # 評估模型
  vghMDL=session_state['vghMDL']='vghMDL'
  model.save_pretrained(vghMDL) # 保存模型
  tokenizer.save_pretrained(vghMDL)

  #6. 使用模型進行預測 可以加載訓練好的模型進行文本生成或其他任務。
  from transformers import pipeline
  model = BertForMaskedLM.from_pretrained(vghMDL) # 加載模型和 Tokenizer
  tokenizer = BertTokenizer.from_pretrained(vghMDL)
  fill_mask = pipeline("fill-mask", model=model, tokenizer=tokenizer) # 創建文本生成管道
  result = fill_mask("今天是[MASK]天。") # 進行預測
  print(result)

