from torch.nn import Module, RNN, Linear, BCEWithLogitsLoss
from torch.optim import Adam
from torch import tensor as trchTnsr
from stUtil import rndrCode

def create_dataset(text):
    # 我們將句子的結尾標註為1，其他字符標註為0
    data, labels=[], []
    for i in range(len(text)):
        data.append(ord(text[i]))  # 將字符轉換為ASCII碼
        if text[i] in ['.', '!', '?']:
            labels.append(1)
        else:
            labels.append(0)
    return trchTnsr(data).unsqueeze(0), trchTnsr(labels).unsqueeze(0)

# 模型
class SentenceSegmentationModel(Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SentenceSegmentationModel, self).__init__()
        self.rnn = RNN(input_size, hidden_size, batch_first=True)
        self.fc = Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.rnn(x)
        out = self.fc(out)
        return out

# 訓練函數
def train_model(model, data, labels, epochs=100, lr=0.001):
    criterion = BCEWithLogitsLoss()  # 用於二分類的損失函數
    rndrCode(['model.parameters', model.parameters()])
    for i in model.parameters():
      rndrCode(['Parameter containing', i])
    optimizer = Adam(model.parameters(), lr=lr)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output.squeeze(-1), labels.float())
        loss.backward()
        optimizer.step()
        
        if (epoch+1) % 10 == 0:
            print(f'Epoch {epoch+1}, Loss: {loss.item()}')

# 測試函數
def test_model(model, data):
    model.eval()
    with torch.no_grad():
        output = model(data)
        preds = torch.sigmoid(output).squeeze(-1) > 0.5  # 二分類，閾值0.5
        return preds

# 示例文本
text = "Hello! How are you? I'm fine. It's a sunny day."
data, labels = create_dataset(text)

# 創建模型
input_size = 1  # 單個字符輸入
hidden_size = 128
output_size = 1  # 二分類問題
model = SentenceSegmentationModel(input_size, hidden_size, output_size)

# 調整輸入數據維度
rndrCode(['model', model])
data = data.unsqueeze(-1).float()  # 增加特徵維度，並轉為float
# 訓練模型
train_model(model, data, labels, epochs=100)

# 測試模型
preds = test_model(model, data)
rndrCode(["Predicted sentence boundaries:", preds])
