from torch.optim import Adam
from torch.utils.data import DataLoader

from dataset.sentiment_dataset_v2 import CLSDataset
from models.bert_sentiment_analysis_v2 import *
from sklearn import metrics
from metrics import *

import tqdm
import pandas as pd
import numpy as np
import configparser
import os
import json


class TrainerICD:# lr=>學習率
    def __init__(self, max_seq_len, batch_size, 學習率, with_cuda=True ):# 是否使用GPU, 如未找到GPU, 則自動切換CPU
        config_ = configparser.ConfigParser()
        config_.read("./config/sentiment_model_config.ini")
        self.config = config_["DEFAULT"]
        self.vocab_size = int(self.config["vocab_size"])
        self.batch_size = batch_size
        self.學習率 = 學習率
        #with open(self.config["word2idx_path"], "r", encoding="utf-8") as f:
        #    self.word2idx = json.load(f) # 加載字典
        cuda_condition = torch.cuda.is_available() and with_cuda # 判斷是否有可用GPU
        self.device = torch.device("cuda:0" if cuda_condition else "cpu")
        self.max_seq_len = max_seq_len # 允許的最大序列長度
        bertconfig = BertConfig(vocab_size=self.vocab_size) # 定義模型超參數
        # 初始化BERT情感分析模型
        self.bert_model = Bert_Sentiment_Analysis(config=bertconfig)
        # 將模型發送到計算設備(GPU或CPU)
        self.bert_model.to(self.device)
        # 聲明訓練數據集, 按照pytorch的要求定義數據集class
        train_dataset = CLSDataset(corpus_path=self.config["train_corpus_path"], word2idx=self.word2idx, max_seq_len=self.max_seq_len, data_regularization=True)
        self.train_dataloader = DataLoader(train_dataset, batch_size=self.batch_size, num_workers=0, collate_fn=lambda x: x )# 這裏爲了動態padding

        # 聲明測試數據集
        test_dataset = CLSDataset(corpus_path=self.config["test_corpus_path"], word2idx=self.word2idx, max_seq_len=self.max_seq_len, data_regularization=False)
        self.test_dataloader = DataLoader(test_dataset, batch_size=self.batch_size, num_workers=0, collate_fn=lambda x: x)
        # 初始化位置編碼
        self.hidden_dim = bertconfig.hidden_size
        self.positional_enc = self.init_positional_encoding()
        # 擴展位置編碼的維度, 留出batch維度,
        # 即positional_enc: [batch_size, embedding_dimension]
        self.positional_enc = torch.unsqueeze(self.positional_enc, dim=0)

        # 聲明需要優化的參數, 并傳入Adam優化器
        self.optim_parameters = list(self.bert_model.parameters())

        # all_parameters = list(self.bert_model.named_parameters())
        # lis_ = ["dense.weight", "dense.bias", "final_dense.weight", "final_dense.bias"]
        # # self.optim_parameters = [i[1] for i in all_parameters if i[0] in lis_]
        # self.optim_parameters = list(self.bert_model.parameters())

        self.init_optimizer(學習率=self.學習率)
        if not os.path.exists(self.config["state_dict_dir"]):
            os.mkdir(self.config["state_dict_dir"])

    def init_optimizer(self, 學習率):
        # 用指定的學習率初始化優化器
        self.optimizer = torch.optim.Adam(self.optim_parameters, 學習率=學習率, weight_decay=1e-3)

    def init_positional_encoding(self):
        position_enc = np.array([
            [pos / np.power(10000, 2 * i / self.hidden_dim) for i in range(self.hidden_dim)]
            if pos != 0 else np.zeros(self.hidden_dim) for pos in range(self.max_seq_len)])

        position_enc[1:, 0::2] = np.sin(position_enc[1:, 0::2])  # dim 2i
        position_enc[1:, 1::2] = np.cos(position_enc[1:, 1::2])  # dim 2i+1
        denominator = np.sqrt(np.sum(position_enc**2, axis=1, keepdims=True))
        # 歸一化
        position_enc = position_enc / (denominator + 1e-8)
        position_enc = torch.from_numpy(position_enc).type(torch.FloatTensor)
        return position_enc


    def load_model(self, model, dir_path="../output", load_bert=False):
        checkpoint_dir = self.find_most_recent_state_dict(dir_path)
        checkpoint = torch.load(checkpoint_dir)
        # 情感分析模型剛開始訓練的時候, 需要載入預訓練的BERT, 這是我們不載入模型原本用于訓練Next Sentence的pooler 而是重新初始化了一個
        if load_bert:
            checkpoint["model_state_dict"] = {k[5:]: v for k, v in checkpoint["model_state_dict"].items() if k[:4] == "bert" and "pooler" not in k}
        model.load_state_dict(checkpoint["model_state_dict"], strict=False)
        torch.cuda.empty_cache()
        model.to(self.device)
        print("{} loaded!".format(checkpoint_dir))

    def train(self, epoch):
        # 一個epoch的訓練
        self.bert_model.train()
        self.iteration(epoch, self.train_dataloader, train=True)

    def test(self, epoch):
        self.bert_model.eval() # 一個epoch的測試, 并返回測試集的auc
        with torch.no_grad():
            return self.iteration(epoch, self.test_dataloader, train=False)

    def padding(self, output_dic_lis):
        """動態padding, 以當前mini batch內最大的句長進行補齊長度"""
        text_input = [i["text_input"] for i in output_dic_lis]
        text_input = torch.nn.utils.rnn.pad_sequence(text_input, batch_first=True)
        label = torch.cat([i["label"] for i in output_dic_lis])
        return {"text_input": text_input, "label": label}

    def iteration(self, epoch, data_loader, train=True, df_name="df_log.pickle"):
        # 初始化一個pandas DataFrame進行訓練日志的存儲
        df_path = self.config["state_dict_dir"] + "/" + df_name
        if not os.path.isfile(df_path):
            df = pd.DataFrame(columns=["epoch", "train_loss", "train_auc", "test_loss", "test_auc" ])
            df.to_pickle(df_path)
            print("log DataFrame created!")

        # 進度條顯示
        str_code = "train" if train else "test"
        data_iter = tqdm.tqdm(enumerate(data_loader), desc="EP_%s:%d" % (str_code, epoch), total=len(data_loader), bar_format="{l_bar}{r_bar}")
        total_loss = 0
        # 存儲所有預測的結果和標記, 用來計算auc
        all_predictions, all_labels = [], []

        for i, data in data_iter:
            # padding
            data = self.padding(data)
            # 將數據發送到計算設備
            data = {key: value.to(self.device) for key, value in data.items()}
            # 根據padding之後文本序列的長度截取相應長度的位置編碼,
            # 并發送到計算設備
            positional_enc = self.positional_enc[:, :data["text_input"].size()[-1], :].to(self.device)

            # 正向傳播, 得到預測結果和loss
            predictions, loss = self.bert_model.forward(text_input=data["text_input"], positional_enc=positional_enc, labels=data["label"])
            # 提取預測的結果和標記, 并存到all_predictions, all_labels裏
            # 用來計算auc
            predictions = predictions.detach().cpu().numpy().reshape(-1).tolist()
            labels = data["label"].cpu().numpy().reshape(-1).tolist()
            all_predictions.extend(predictions)
            all_labels.extend(labels)
            # 計算auc
            fpr, tpr, 閥s = metrics.roc_curve(y_true=all_labels, y_score=all_predictions)
            auc = metrics.auc(fpr, tpr)

            # 反向傳播
            if train:
                self.optimizer.zero_grad() # 清空之前的梯度
                loss.backward()            # 反向傳播, 獲取新的梯度
                self.optimizer.step()      # 用獲取的梯度更新模型參數

            total_loss += loss.item() # 爲計算當前epoch的平均loss

            if train:
                log_dic = { "epoch": epoch, "train_loss": total_loss/(i+1), "train_auc": auc, "test_loss":0, "test_auc":0 }

            else:
                log_dic = { "epoch": epoch, "train_loss": 0, "train_auc": 0, "test_loss": total_loss/(i+1), "test_auc": auc }

            if not i % 10:
                data_iter.write(str({k: v for k, v in log_dic.items() if v != 0}))

        閥_ = find_best_threshold(all_predictions, all_labels)
        print(str_code + " best 閥: " + str(閥_))

        # 將當前epoch的情況記錄到DataFrame裏
        if train:
            df = pd.read_pickle(df_path)
            df = df.append([log_dic])
            df.reset_index(inplace=True, drop=True)
            df.to_pickle(df_path)
        else:
            log_dic = {k: v for k, v in log_dic.items() if v != 0 and k != "epoch"}
            df = pd.read_pickle(df_path)
            df.reset_index(inplace=True, drop=True)
            for k, v in log_dic.items():
                df.at[epoch, k] = v
            df.to_pickle(df_path)
            return auc # 返回auc, 作爲early stop的衡量標準

    def find_most_recent_state_dict(self, dir_path):
        """
        :param dir_path: 存儲所有模型文件的目錄
        :return: 返回最新的模型文件路徑, 按模型名稱最後一位數進行排序
        """
        dic_lis = [i for i in os.listdir(dir_path)]
        if len(dic_lis) == 0:
            raise FileNotFoundError("can not find any state dict in {}!".format(dir_path))
        dic_lis = [i for i in dic_lis if "model" in i]
        dic_lis = sorted(dic_lis, key=lambda k: int(k.split(".")[-1]))
        return dir_path + "/" + dic_lis[-1]

    def save_state_dict(self, model, epoch, state_dict_dir="../output", file_path="bert.model"):
        """存儲當前模型參數"""
        if not os.path.exists(state_dict_dir):
            os.mkdir(state_dict_dir)
        save_path = state_dict_dir + "/" + file_path + ".epoch.{}".format(str(epoch))
        model.to("cpu")
        torch.save({"model_state_dict": model.state_dict()}, save_path)
        print("{} saved!".format(save_path))
        model.to(self.device)


if __name__ == '__main__':
    def init_trainer(學習率, batch_size=24):
        trainer = TrainerICD(max_seq_len=300, batch_size=batch_size, 學習率=學習率, with_cuda=True)
        return trainer, 學習率

    初始幕 = 0
    train_epoches = 9999
    學習率=1e-06
    trainer, 學習率 = init_trainer(學習率, batch_size=24)

    all_auc, 閥=[], 999
    patient, best_loss=10, 999999999
    while 閥 >= patient:
        if not epoch: # epoch == 初始幕 and    第一個epoch的訓練需要加載預訓練的BERT模型
            trainer.load_model(trainer.bert_model, dir_path="./bert_state_dict", load_bert=True)
        #elif epoch == 初始幕: trainer.load_model(trainer.bert_model, dir_path=trainer.config["state_dict_dir"])
        print(f"train with learning rate {學習率}")
        trainer.train(epoch) # 訓練一個epoch
        trainer.save_state_dict(trainer.bert_model, epoch, state_dict_dir=trainer.config["state_dict_dir"], file_path="sentiment.model") # 保存當前epoch模型參數
        auc = trainer.test(epoch)
        all_auc.append(auc)
        best_auc = max(all_auc)
        if all_auc[-1] < best_auc:
            閥 += 1
            學習率 *= 0.8
            trainer.init_optimizer(學習率=學習率)
        else: 閥 = 0 # 如果
        if 閥 >= patient:
            print("epoch {} has the lowest loss".format(初始幕 + np.argmax(np.array(all_auc))))
            print("early stop!")
        epoch+=1
    #for epoch in range(初始幕, 初始幕 + train_epoches):
    #       break
