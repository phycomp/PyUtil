EPOCHS = 10  # epoch
LR = 5  # learning rate
BATCH_SIZE = 64  # batch size for training


from torch.nn import CrossEntropyLoss as 交叉熵
from torch.optim.lr_scheduler import StepLR
#交叉熵 = CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=LR)
#scheduler = torch.optim.lr_scheduler.
scheduler=StepLR(optimizer, 1., gamma=.1)
total_accu = None
train_iter, test_iter = AG_NEWS()
train_dataset = to_map_style_dataset(train_iter)
test_dataset = to_map_style_dataset(test_iter)
num_train = int(len(train_dataset) * .95)
split_train_, split_valid_ = random_split(train_dataset, [num_train, len(train_dataset) - num_train])

train_dataloader = DataLoader(split_train_, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_batch)
valid_dataloader = DataLoader(split_valid_, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_batch)
test_dataloader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_batch)
#total_accu is not None and 
while total_accu > accu_val:
    accu_val = evaluate(valid_dataloader)
    scheduler.step()
    total_accu = accu_val
"""
for epoch in range(1, EPOCHS + 1):
    #epoch_start_time = time.time()
    train(train_dataloader)
    accu_val = evaluate(valid_dataloader)
    if total_accu is not None and total_accu > accu_val:
        scheduler.step()
    else:
        total_accu = accu_val
    print("-" * 59)
    print( f"valid accuracy {accu_val} "   #.format( epoch, time.time() - epoch_start_time ) #"| end of epoch {:3d} | time: {:5.2f}s | "
    )
    #print("-" * 59)

"""
