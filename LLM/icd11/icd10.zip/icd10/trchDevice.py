import torch
with torch.cuda.device('cuda:0'):
    a = torch.zeros(0, device='cuda:1')
    print(a.device)   #cuda:1
    a = a.untyped_storage().resize_(0)
    print(a.device)   #cuda:1
