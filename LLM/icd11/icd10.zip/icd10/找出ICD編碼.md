To automatically extract ICD (International Classification of Diseases) codes from medical text using PyTorch, the task generally involves sequence classification or Named Entity Recognition (NER), where the goal is to match medical conditions or diagnoses in the text with corresponding ICD codes.

Here's how to approach this task using PyTorch:

1. Install Required Libraries
First, ensure that the necessary libraries are installed:

bash
複製程式碼
pip install torch transformers datasets
2. ICD Code Mapping Task
For extracting ICD codes from medical text, you can approach it in two ways:

NER-based approach: Identify entities in the text that correspond to medical conditions and map them to ICD codes.
Classification-based approach: Classify entire sentences or documents into ICD codes.
3. Pre-trained Medical Models
To extract medical conditions or diseases from text, you can leverage BioBERT, ClinicalBERT, or BERT models fine-tuned for the healthcare domain.

4. NER Pipeline for Extracting Medical Conditions and Mapping ICD Codes
You can first extract medical entities (like diseases) from the text and then map these entities to ICD codes using an external lookup dictionary.

Example:
python
複製程式碼
from transformers import AutoTokenizer, AutoModelForTokenClassification
from transformers import pipeline

# Load the BioBERT model for medical NER
model_name = "dmis-lab/biobert-base-cased-v1.1"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# Create an NER pipeline
ner_pipeline = pipeline("ner", model=model, tokenizer=tokenizer)

# Example medical text for ICD extraction
medical_text = "The patient was diagnosed with diabetes mellitus and hypertension."

# Perform NER to extract medical entities
entities = ner_pipeline(medical_text)

# Output identified medical entities
for entity in entities:
    print(entity)
After identifying medical conditions, you can map them to ICD codes using a dictionary.

Example of an ICD code mapping:
python
複製程式碼
# Example mapping of medical entities to ICD codes
icd_code_dict = {
    "diabetes mellitus": "E11",
    "hypertension": "I10"
}

# Map recognized medical entities to ICD codes
for entity in entities:
    term = entity['word'].lower()
    if term in icd_code_dict:
        icd_code = icd_code_dict[term]
        print(f"Term: {term}, ICD Code: {icd_code}")
5. Building a Dictionary for ICD Code Mapping
You'll need a dictionary or database that maps medical terms or diagnoses to their corresponding ICD codes. You can build a custom dictionary from publicly available ICD code datasets (like the ICD-10 dataset).

6. Fine-tuning a Model for ICD Code Prediction (Sentence or Document Classification)
You can also fine-tune a model to predict ICD codes directly from text. For this approach, the input is the medical text (e.g., a clinical note or diagnosis report), and the output is the corresponding ICD code(s).

Fine-tuning a BERT-based model for ICD classification:
Prepare Dataset: You'll need a labeled dataset where each medical text is labeled with its corresponding ICD code(s). You can use datasets like MIMIC-III (Medical Information Mart for Intensive Care) or others with ICD annotations.

Fine-tuning Code:

python
複製程式碼
from transformers import BertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

# Load your dataset
dataset = load_dataset("your_icd_dataset")  # Replace with your dataset containing medical text and ICD codes

# Load a pre-trained BERT model for sequence classification
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=number_of_icd_codes)

# Define training arguments
training_args = TrainingArguments(
    output_dir='./results', 
    num_train_epochs=3, 
    per_device_train_batch_size=16, 
    per_device_eval_batch_size=16,
    evaluation_strategy="epoch",
    logging_dir='./logs',
)

# Define the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset['train'],
    eval_dataset=dataset['test']
)

# Train the model
trainer.train()
Inference: Once the model is trained, you can use it to predict ICD codes for new medical texts.
python
複製程式碼
# Example inference
test_text = "The patient was diagnosed with chronic obstructive pulmonary disease (COPD)."
inputs = tokenizer(test_text, return_tensors="pt")
outputs = model(**inputs)
predicted_icd_code = outputs.logits.argmax(-1).item()

# Print the predicted ICD code
print(f"Predicted ICD Code: {predicted_icd_code}")
7. Datasets for ICD Code Prediction
MIMIC-III: A large, freely available dataset from critical care with ICD codes.
ICD-10 Dataset: Available on the WHO website, contains mappings of diseases to ICD-10 codes.
8. Applications of ICD Code Extraction
Automated Clinical Documentation: Automating the process of assigning ICD codes from clinical notes or discharge summaries.
Medical Billing: Assisting with medical billing by automatically tagging diagnoses with appropriate ICD codes.
Healthcare Analytics: Analyzing patterns in diagnoses and treatments based on ICD codes extracted from large medical datasets.
By leveraging PyTorch and pre-trained models like BioBERT, and possibly fine-tuning on ICD-specific tasks, you can build robust systems to automatically extract and map medical conditions to ICD codes from unstructured medical texts.
