from torch import log as trchLog, tensor as trchTensor
ε = 1e-8
def 計算損失(self, predictions, labels):
    # 將預測和標記的維度展平, 防止出現維度不一致
    predictions = predictions.view(-1)
    labels = labels.float().view(-1)
    loss =-labels * trchLog(predictions + ε) - (trchTensor(1.0) - labels) * trchLog(trchTensor(1.0) - predictions + ε)  # 交叉熵
    損失=torch.mean(loss) # 求均值, 并返回可以反傳的loss loss爲一個實數
    return 損失
