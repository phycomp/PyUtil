model = FeedForwardNeuralNet(input_size, hidden_size, num_classes)
選擇適合的 loss function 和 optimizer
學習率 = .01 # 2) loss and optimizer
交叉熵 = CrossEntropyLoss() # Cross Entropy criterion
optimizer = torch.optim.Adam(model.parameters(), lr=學習率) # adam algorithm 學習率==>learning_rate
# 3) Training loop 開始 Training
n_total_steps = len(train_loader)
for epoch in range(num_epochs):
    for i, (datas, labels) in enumerate(train_loader):
        optimizer.zero_grad() # init optimizer
        # forward -> backward -> update
        outputs = model(datas)
        loss = 交叉熵(outputs, labels)
        loss.backward()
        optimizer.step()
        if (i + 1) % 19 == 0:
            print(f'epoch {epoch+1}/{num_epochs}, step {i+1}/{n_total_steps}, loss = {loss.item():.4f}')
# 4) Testing 那最後再執行 Testing 做檢查
with torch.no_grad():
    n_correct = 0
    n_samples = 0
    for datas, labels in val_loader:
        outputs = model(datas.float())
        _, predictions = torch.max(outputs, 1)
        n_samples += labels.shape[0]
        n_correct += (predictions == labels).sum().item()

    精確度 = 100. * n_correct / n_samples
    print(f'accuracy = {精確度}')

