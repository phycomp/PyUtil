from collections import Counter, OrderedDict
from operator import itemgetter
from string import punctuation as 標點符號    #string.punctuation
def 字詞序表(Sents, 特殊字):
  字=[]
  for sent in Sents:
    if sent in 特殊字: continue
    Word=sent.split()
    for word in Word:
      符="".join([CHR for CHR in word if CHR not in 標點符號])
      字.append(符)
  彙=Counter(字)
  字頻 = sorted(彙.items(), key=itemgetter(1), reverse=True)
  序表 = dict(enumerate(map(lambda x: x[0], 字頻), start=len(特殊字)))
  序表.update({v:k for k, v in 特殊字.items()})
  字表 = {字:ndx for ndx, 字 in 序表.items()}
  #字表.update(特殊字)
  return 字表, 序表

