from torch import no_grad as trchNograd, manual_seed, tensor

manual_seed(42) # 設定隨機數種子，這樣每次結果都相同 假設我們有一個簡單的二次損失函數 L = (x - 3)^2 我們的目標是找到 x 的最小值

x, learning_rate  = tensor([0.0], requires_grad=True), .1  # 初始化變數 x，需要優化的參數, 設定學習率 (步長)

losses = [] # 儲存損失值的列表

for i in range(100): # 執行最速下降 100 步
    loss = (x - 3) ** 2 #計算損失函數 L = (x - 3)^2

    if x.grad: # 清除之前的梯度
        x.grad.zero_()

    loss.backward() # 計算梯度

    # 沿負梯度方向更新參數 x
    with trchNograd():  # 禁用自動微分
        x -= learning_rate * x.grad

    losses.append(loss.item()) # 儲存損失值以便觀察

    print(f'Step {i+1}, x = {x.item()}, Loss = {loss.item()}') # Optional: 打印每一步的結果

print(f'最終結果: x = {x.item()}, {losses}') # 打印最終結果
