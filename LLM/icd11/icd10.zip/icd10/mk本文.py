from streamlit import session_state
def rtrvTXT():
  try: TEXT=session_state['TEXT']
  except: session_state['TEXT']=TEXT='I did not know how it works before reading this file and frankly, which is a way to receive inputs personally from the user. I think it is an awesome feature in python. Basically, what the input function does is to print the string given to it by input and then request user input. This raw_text then is encoded into tokens using NLP technology.'
  return TEXT
