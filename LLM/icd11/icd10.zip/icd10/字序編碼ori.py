from collections import Counter, OrderedDict
#UNK = 0  # 未登錄詞的標識符對應的詞典id
#PAD = 1  # padding占位符對應的詞典id
symNdx= UNK, PAD, BOS, EOS, MASK = 0, 1, 2, 3, 4     #Make sure the tokens are in order of their indices to properly insert them in vocab
特殊符 = ['<unk>', '<pad>', '<bos>', '<eos>', '<mask>']
象=dict(zip(特殊符, symNdx))    #象={'<unk>': 0, '<pad>': 1, '<bos>': 2, '<eos>': 3}
def 字序表(Sents, max_words=50000):
    #傳入load_data構造的分詞後的列表數據 構建詞典(key爲單詞，value爲id值)
    字頻 = Counter() # 對數據中所有單詞進行計數
    for sent in Sents:
      for word in sent:
          字頻[word] += 1
    # 只保留最高頻的前max_words數的單詞構建詞典 并添加上UNK和PAD兩個單詞，對應id已經初始化設置過
    總詞數 = 字頻.most_common(max_words)
    總字數 = len(總詞數) + 2 # 統計詞典的總詞數

    字表 = {w[0]: index + 2 for index, w in enumerate(總詞數)}
    #字表['UNK'] = UNK
    #字表['PAD'] = PAD
    字表.update(象)
    序表 = {v: k for k, v in 字表.items()} # 再構建一個反向的詞典，供id轉單詞使用
    return 字表, 總字數, 序表

from collections import Counter
from operator import itemgetter
#sentences=[['i','have','a','dream'],['we','have','a','world']]
def 字詞序表(Sents):
  字=[]
  for sent in Sents:
    Word=sent.split()
    字+=Word
  彙=Counter(字)
  字頻 = sorted(彙.items(), key=itemgetter(1), reverse=True)
  ndx2word = dict(enumerate(map(lambda x: x[0], 字頻), start=1))
  word2ndx = {字: ndx for ndx, 字 in ndx2word.items()}
  return word2ndx, ndx2word

def 建詞表():
  from torchtext.vocab import build_vocab_from_iterator as 迭代詞表
  from torch.utils.data import DataLoader
  vocab=迭代詞表(吐詞表(遍歷集), specials=['<unk>']) #build_vocab_from_iterator
  vocab.set_default_index(vocab['<unk>'])

def 建立載入器(dset, 束量):
  loader = DataLoader(dataset=dset, batch_size=束量, shuffle=True, pin_memory=True, num_workers=8)
  return loader

def 吐詞表(分詞, 遍歷集):
    for _, text in 遍歷集:
        yield 分詞(text)    #yield吐


def 象嵌入(gloveVec):
  train_iter = AG_NEWS(split = 'train')
  num_class = len(set([label for (label, _) in train_iter]))
  unk_token = "<unk>"
  unk_index = 0
  glove_vectors = GloVe()
  序表 = vocab(glove_vectors.stoi)
  return 序表   #gloVocab
