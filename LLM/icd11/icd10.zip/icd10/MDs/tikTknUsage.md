可以看到 在不同線程數下面 tiktoken處理速度都比HuggingFace快多了 各種條件下都比tokenizer快3-6倍 上述對比是處理1GB數據的結果

tiktoken使用 tiktoken使用方法也很簡單 示例代碼如下

import tiktoken
enc = tiktoken.get_encoding("gpt2") # 字節對編碼過程 我的輸出是[31373, 995]
encoding_res = enc.encode("hello world")
print(encoding_res)
raw_text = enc.decode(encoding_res) # 字節對解碼過程 解碼結果 hello world
print(raw_text)
