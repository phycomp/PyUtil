from torchtext.data.utils import get_tokenizer

tokenizer=get_tokenizer('basic_english')
sen='i have a word!'
token=tokenizer(sen)
print(token)
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。
                        
原文链接：https://blog.csdn.net/qq_38853948/article/details/108966346
