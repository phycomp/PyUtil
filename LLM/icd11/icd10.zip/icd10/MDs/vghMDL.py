from torchtext.data import Dataset
class VGHMdl():
  def __init__(self):
    self.來源=None
    self.目的=None
    self.特徵=None

  def mkDset(self, 訓練集, 評估集):
      self.欄 = [('src', self.來源), ('trg', self.目的), ('feat', self.特徵)]
      self.訓練dset = Dataset(fields=self.欄, examples=訓練集)
      self.評估dset = Dataset(fields=self.欄, examples=評估集)

