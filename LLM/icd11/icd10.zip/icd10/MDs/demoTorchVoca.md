
text_field = tdata.Field(tokenize=lambda x: word_tokenize(x), lower=True, fix_length=512, batch_first=True)
label_field = tdata.LabelField(dtype=torch.int)
text_fields[0].build_vocab(train1_data, vectors=vectors1)
