PRE_TRAINED_MODEL_NAME = 'bert-base-cased'
tokenizer = BertTokenizer.from_pretrained(PRE_TRAINED_MODEL_NAME)
tokens = tokenizer.tokenize(sample_txt)
token_ids = tokenizer.convert_tokens_to_ids(tokens)
tokenizer.cls_token, tokenizer.cls_token_id
tokenizer.pad_token, tokenizer.pad_token_id
tokenizer.unk_token, tokenizer.unk_token_id
encoding = tokenizer.encode_plus( sample_txt, max_length=32, add_special_tokens=True, # Add '[CLS]' and '[SEP]'
  return_token_type_ids=False, pad_to_max_length=True, return_attention_mask=True, return_tensors='pt',  # Return PyTorch tensors)

encoding.keys()   #dict_keys(['input_ids', 'attention_mask'])
encoding['input_ids'][0]
encoding['attention_mask']
tokenizer.convert_ids_to_tokens(encoding['input_ids'][0])
token_lens = []

for txt in df.content:
  tokens = tokenizer.encode(txt, max_length=512)
  token_lens.append(len(tokens))


