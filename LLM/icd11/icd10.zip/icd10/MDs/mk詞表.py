from torchtext.vocab import build_vocab_from_iterator
from torch.utils.data import DataLoader
def 建立載入器(dset, 束量):
  loader = DataLoader(dataset=dset, batch_size=束量, shuffle=True, pin_memory=True, num_workers=8)
  return loader


def 吐詞表(分詞, 遍歷集):
    for _, text in 遍歷集:
        yield 分詞(text)

vocab = build_vocab_from_iterator(吐詞表(遍歷集), specials=['<unk>'])  # 建立词表
vocab.set_default_index(vocab['<unk>'])
