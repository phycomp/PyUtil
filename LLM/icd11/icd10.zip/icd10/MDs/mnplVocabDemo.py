class Vocab
功能：用于創建字典和應用字典
函數： __contains__(token: str) → bool
功能：用于判斷傳入的詞語是否存在于詞典中。

參數：
token：字符串。需要判斷的詞語。
返回值：布爾值。傳入單詞是否在詞典中

__getitem__(token: str) → int

功能：獲得傳入單詞在詞典中的索引。

參數：
token：字符串。需要獲得索引的詞語。
返回值：整型。對應的索引。

__init__(vocab)
功能：構造函數，創建Vocab實例。
參數：
vocab：詞典對象。
注意：一般不通過構造函數創建vocab對象。

__len__() → int
功能：獲得詞典的長度。
返回值：整型。詞典長度。

__prepare_scriptable__()

返回值：一個叫JITable Vocab的對象。

注意：這個方法用途我還沒弄明白，返回的對象可以直接當Vocab對象使用。

append_token(token: str) → None
功能：插入新的詞。
參數：
token：字符串。需要插入詞典的新詞。
forward(tokens: List[str]) → List[int]

功能：調用lookup_indices函數，即將詞列表映射爲字典索引。

參數：
tokens：字符串列表。需要映射爲索引的詞列表。
返回值：整型列表。映射後的列表。

get_default_index() → Optional[int]
功能：返回默認索引，即未登錄詞的索引值。
返回值：若設定，返回相應的索引。否則返回None。

get_itos() → List[str]
功能：獲得記錄在詞典中的詞列表。
返回值：字符串列表。被記錄的詞的列表，在列表中按索引升序順序排列。

get_stoi() → Dict[str, int]
功能：獲得字典的dict對象。
返回值：字典。key爲登錄詞，value爲其對應索引。

insert_token(token: str, index: int) → None
功能：在字典的指定位置插入新詞。
參數：
token：字符串。要插入的新詞。
index：整型。插入的位置。
lookup_indices(tokens: List[str]) → List[int]

功能：將詞語列表映射爲索引列表。
參數：
tokens：字符串列表。需要映射爲索引的詞列表。
返回值：整型列表。映射後的列表。

lookup_token(index: int) → str
功能：獲得索引位置的詞語。
參數：
index：整型。想要獲得的詞的索引。
返回值：字符串。對應的詞。

lookup_tokens(indices: List[int]) → List[str]
功能：將索引列表映射爲詞列表。
參數：
indices：整型列表。需要映射爲此列表的索引列表。
返回值：字符串列表。映射後的詞列表。

set_default_index(index: Optional[int]) → None
功能：設置默認索引，即未登錄詞的索引。
參數：
index：整型。默認的索引。也可以傳入None。
示例：

from torchtext.vocab import Vocab, vocab
from collections import Counter, OrderedDict
cntr = Counter(["a", "b", "b", "b", "c", "c"])
sortedFreq = sorted(cntr.items(), key=lambda x:x[1], reverse=True)
ordrdDict = OrderedDict(sortedFreq)
v1 = vocab(ordrdDict)
print(v1.get_itos()) # get_itos() → List[str] ['b', 'c', 'a']
print(v1.get_stoi()) # get_stoi() → Dict[str, int] {'b': 0, 'c': 1, 'a': 2}
v1.insert_token("d", 1) # insert_token(token: str, index: int) → None
print(v1.get_stoi())    #{'b': 0, 'd': 1, 'c': 2, 'a': 3}
print(v1.lookup_indices(["a", "a", "b", "c", "d"]))     # lookup_indices(tokens: List[str]) → List[int] [3, 3, 0, 2, 1]
print(v1.lookup_token(0))   #b lookup_token(index: int) → str 
print(v1.lookup_tokens([2, 2, 0, 1, 3]))        #['c', 'c', 'b', 'd', 'a'] lookup_tokens(indices: List[int]) → List[str]
print(v1.lookup_token(0))   #b lookup_token(index: int) → str

vocab(ordered_dict: Dict, min_freq: int = 1) → torchtext.vocab.Vocab
功能： 創建Vocab對象的工廠方法。
注意：在構建vocab對象時，將會參照傳入的dict在構建時的鍵值對順序。因此單詞是否按照詞頻排序對用戶來說很重要，推薦用ordered_dict來構建詞典。

參數：
ordered_dirt：字典。用于構建詞典的字典，類型一般爲OrderedDict[str, int]。
min_freq：整型，默認爲1。表示詞典接受的最小詞頻，詞頻表示爲ordered_dirt的值。
返回值：對應的Vocab對象

示例：

from torchtext.vocab import Vocab, vocab
from collections import Counter, OrderedDict
counter = Counter(["a", "b", "b", "b", "c", "c"])
sorted_by_freq_tuples = sorted(counter.items(), key=lambda x:x[1], reverse=True)
sorted_by_freq_tuples

ordered_dict = OrderedDict(sorted_by_freq_tuples)
ordered_dict

v1 = vocab(ordered_dict,  min_freq=2)
print(v1.get_stoi())

tokens = ["e", "d","d","d", "c", "b", "a"]
v2 = vocab(OrderedDict([(token, 1) for token in tokens]))
unk_token = "<unk>"
default_index = -1
if unk_token not in v2: v2.insert_token(unk_token, 0)
print(v2.get_stoi())
示例結果：

{'b': 0, 'c': 1}
{'<unk>': 0, 'e': 1, 'd': 2, 'c': 3, 'b': 4, 'a': 5}
build_vocab_from_iterator(iterator: Iterable, min_freq: int = 1, specials: Optional[List[str]] = None, special_first: bool = True) → torchtext.vocab.Vocab
功能：用迭代器來生成Vocab對象。

參數：

iterator：迭代器。用于創建詞典的yield或詞語迭代器。
min_freq：整型，默認1。最小詞頻，創建時會忽略小于最小詞頻的詞語。
specials：字符串列表，默認None。一些需要加入詞典的特殊符號，加入順序與列表中順序一致。
special_first：布爾，默認True。表示是否將specials中的符號插在詞典最前面。
返回值：對應的Vocab對象

示例：

from torchtext.vocab import build_vocab_from_iterator
tokens = ["e", "d","d","d", "c", "b", "b", "a"]
vocab = build_vocab_from_iterator(tokens, min_freq=2, specials=["<unk>", "<eos>"],  special_first=False)
print(vocab.get_itos())     #['d', 'b', '<unk>', '<eos>']
示例結果：

class Vectors
功能：存儲詞的嵌入向量。

函數：

__init__(name, cache=None, url=None, unk_init=None, max_vectors=None)

功能：構造函數。

參數：

name：字符串。詞嵌入向量文件的路徑。
cache：字符串，默認None。緩存向量目錄。
url：字符串，默認None。下載詞嵌入向量的鏈接。
unk_init：函數。用于初始化未登錄詞。默認情況下，會以全零向量初始化未登錄詞。可以傳入一個參數爲一個Tensor、返回值爲相同階數Tensor的函數來處理未登錄詞。
max_vectors：整型。用于限制預訓練詞向量的個數。由于大多數預訓練詞向量都按詞頻降序排列，因此如內存不足等情況下可以限制一下詞典大小。
get_vecs_by_tokens(tokens, lower_case_backup=False)

功能：將單詞變爲詞嵌入向量。

參數：

tokens：字符串列表。需要轉換爲詞向量的詞列表。
lower_case_backup：布爾，默認False。是否將單詞變爲小寫再獲取詞向量。如果爲False，所有詞都會用輸入的大小寫來查詢詞向量。如果爲True，會先按照原有的大小寫查找詞向量，若找不到，則會轉爲小寫再查找詞向量。
返回值：詞嵌入向量Tensor列表。

示例：

from torchtext.vocab import build_vocab_from_iterator,GloVe,Vectors

vec = Vectors(".vector_cache/glove.6B.50d.txt")
print("hi:", vec["hi"])

examples = ["ChIP", "chip"]
ret = vec.get_vecs_by_tokens(examples, lower_case_backup=True)

print("\n".join(["{}:{}".format(examples[i], ret[i]) for i in range(len(examples))]))
示例結果：

hi: tensor([-0.5431,  0.3443,  0.2713,  1.0487, -1.1642, -1.2722,  0.3578, -0.5653,
        -0.2988,  0.8518,  0.5222, -0.0020, -0.4643,  0.0336,  0.0484,  0.7876,
         0.0760,  0.5158,  0.3478,  0.5380,  0.2830, -0.1313, -0.0738,  0.4261,
         0.0310, -0.5503, -0.9979, -0.2895,  0.3052, -1.1194,  1.2957,  0.9117,
         0.3222,  0.9341, -0.3415, -0.6271, -0.0922,  0.5090,  0.2920, -0.2012,
         0.1961, -0.4588,  1.1099, -0.6874,  1.5724, -0.1045,  0.2359, -0.5659,
         0.4368,  0.9809])
ChIP:tensor([-0.7710, -1.1697,  1.5195,  0.8371,  0.7419, -0.2185, -0.7212, -0.9400,
        -0.0113,  0.5485,  0.4040, -0.1846, -0.4630,  0.2620, -0.6464,  0.3599,
        -0.8610, -0.3869, -0.0271, -1.0254,  0.3280, -0.7500, -0.6859, -0.6912,
         0.3429, -0.6660, -0.2910, -0.6104,  0.3322, -0.4252,  2.4573, -0.8748,
         0.4891,  1.2888,  0.5780, -0.5509, -0.2263,  0.8127,  0.7048, -0.5498,
         0.3620, -0.2171, -0.2991,  0.2917,  1.2260,  0.2446,  1.2133, -0.0967,
         0.0474,  0.1971])
chip:tensor([-0.7710, -1.1697,  1.5195,  0.8371,  0.7419, -0.2185, -0.7212, -0.9400,
        -0.0113,  0.5485,  0.4040, -0.1846, -0.4630,  0.2620, -0.6464,  0.3599,
        -0.8610, -0.3869, -0.0271, -1.0254,  0.3280, -0.7500, -0.6859, -0.6912,
         0.3429, -0.6660, -0.2910, -0.6104,  0.3322, -0.4252,  2.4573, -0.8748,
         0.4891,  1.2888,  0.5780, -0.5509, -0.2263,  0.8127,  0.7048, -0.5498,
         0.3620, -0.2171, -0.2991,  0.2917,  1.2260,  0.2446,  1.2133, -0.0967,
         0.0474,  0.1971])


數據下載地址：http://nlp.stanford.edu/data/glove.6B.zip
設置了lower_case_backup=True後可以看見“ChIP”和“chip”的詞嵌入向量是一樣的。
預訓練詞向量
GloVe torchtext.vocab.GloVe(name='840B', dim=300, **kwargs)

FastText torchtext.vocab.FastText(language='en', **kwargs)

CharNGram torchtext.vocab.CharNGram(**kwargs)

原文鏈接：https://blog.csdn.net/qq_42464569/article/details/120803135
