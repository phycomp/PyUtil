from io import open as IOpen
from torchtext.vocab import build_vocab_from_iterator
def yield_tokens(file_path):
    with IOpen(file_path, encoding = 'utf-8') as fin:
        for line in fin:
            yield line.strip().split()
vocab = build_vocab_from_iterator(yield_tokens(file_path), specials=["<unk>"])
