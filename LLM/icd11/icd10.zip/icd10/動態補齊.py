from torch.utils.data import DataLoader, Dataset
from torch import tensor as trchTnsr
from torch.nn.utils.rnn import pad_sequence as trchPadseq
from stUtil import rndrCode

# 自定義一個簡單的 dataset
class DatasetVGH(Dataset):
    def __init__(self, sequences):
      self.sequences = sequences

    def __len__(self):
      return len(self.sequences)

    def __getitem__(self, idx):
      rndrCode([idx, self.sequences[idx]])
      return trchTnsr(self.sequences[idx])

# 生成不同長度的序列
#sequences = [[1, 2, 3], [14, 15], [4, 5], [6, 11, 12], [7, 8, 9, 10]]

# 創建數據集和數據加載器
def collateVGH(batch):  #動態補齊批次中的序列
    rndrCode([batch])
    batch = [trchTnsr(b) for b in batch]
    return trchPadseq(batch, batch_first=True, padding_value=0)

