from torch.utils.data import DataLoader
def make_loader(dset, 束量):
  loader = DataLoader(dataset=dset, batch_size=束量, shuffle=True, pin_memory=True, num_workers=8)
  return loader

