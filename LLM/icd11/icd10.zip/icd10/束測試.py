lenSent=10
 前, 後= randrange(), randrange(len(sentences))
def 製作束():
   束 = []
   positive = negative = 0
   while positive != 束量/2 or negative != 束量/2:
      #lenSent=len(sentences), len(sentences)
       前, 後= randrange(lenSent), randrange(lenSent)

       前詞, 後詞= TKN[前], TKN[後]

       input_ids = [詞表['[CLS]']] + 前詞 + [詞表['[SEP]']] + 後詞 + [詞表['[SEP]']]
       segment_ids = [0] * (1 + len(前詞) + 1) + [1] * (len(後詞) + 1)
       # MASK LM
       n_pred =  min(max_pred, max(1, int(round(len(input_ids) * 0.15)))) # 15 % of tokens in one sentence
       cand_maked_pos = [i for i, token in enumerate(input_ids)
                         if token != 詞表['[CLS]'] and token != 詞表['[SEP]']]
       shuffle(cand_maked_pos)
       masked_tokens, masked_pos = [], []
       for pos in cand_maked_pos[:n_pred]:
           masked_pos.append(pos)
           masked_tokens.append(input_ids[pos])
           if random() < 0.8:  # 80%
               input_ids[pos] = 詞表['[MASK]'] # make mask
           elif random() < 0.5:  # 10%
               index = randint(0, vocab_size - 1) # random index in vocabulary
               input_ids[pos] = 詞表[number_dict[index]] # replace

       # Zero Paddings
       n_pad = maxlen - len(input_ids)
       input_ids.extend([0] * n_pad)
       segment_ids.extend([0] * n_pad)

       # Zero Padding (100% - 15%) tokens
       if max_pred > n_pred:
           n_pad = max_pred - n_pred
           masked_tokens.extend([0] * n_pad)
           masked_pos.extend([0] * n_pad)

       if 前 + 1 == 後 and positive < 束量/2:
           束量.append([input_ids, segment_ids, masked_tokens, masked_pos, True]) # IsNext
           positive += 1
       elif 前 + 1 != 後 and negative < 束量/2:
           束.append([input_ids, segment_ids, masked_tokens, masked_pos, False]) # NotNext
           negative += 1
   return 束
