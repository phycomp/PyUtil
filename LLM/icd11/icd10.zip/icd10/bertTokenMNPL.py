from transformers import BertTokenizer, AutoModel
#huggingface
#transformers.BertConfig
from streamlit import code as stCode

def bertToken(lngName, cntxt):
  lngMDL = AutoModel.from_pretrained(lngName, local_files_only=False)   #PRE_TRAINED_MODEL_NAME
  #lngMDL.save_pretrained()
  #lngMDL.save_pretrained('vghMDL')
  tokenizer = BertTokenizer.from_pretrained(lngName, local_files_only=False)   #PRE_TRAINED_MODEL_NAME
  TKN=tokenizer.tokenize(cntxt)
  return TKN
  stCode(['TKN=', TKN])
  token_ids=tokenizer.convert_tokens_to_ids(TKN)
  #tokenizer.cls_token, tokenizer.cls_token_id
  #tokenizer.pad_token, tokenizer.pad_token_id
  #tokenizer.unk_token, tokenizer.unk_token_id
  編碼=tokenizer.encode_plus(cntxt, max_length=32,
    add_special_tokens=True, # Add '[CLS]' and '[SEP]'
    return_token_type_ids=False, pad_to_max_length=True, return_attention_mask=True, return_tensors='pt')  # Return PyTorch tensors)

  編碼.keys()   #dict_keys(['input_ids', 'attention_mask'])
  編碼['input_ids'][0]
  編碼['attention_mask']
  tokenizer.convert_ids_to_tokens(編碼['input_ids'][0])
  token_lens = []
  stCode([編碼, 編碼.keys()])
  #for txt in df.content:
  #  TKN = tokenizer.encode(txt, max_length=512)
  #  token_lens.append(len(TKN))

  return 編碼
