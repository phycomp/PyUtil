from torch.nn import CrossEntropyLoss as 交叉熵

def 訓練():

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 獲取到dataset
    train_data = load_data('cnews/cnews.train.txt')
    valid_data = load_data('cnews/cnews.val.txt')
    #test_data = load_data('cnews/cnews.test.txt')

    batch_size = 4
    # 生成Batch
    train_dataloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    valid_dataloader = DataLoader(valid_data, batch_size=batch_size, shuffle=False)
    #test_dataloader = DataLoader(valid_data, batch_size=batch_size, shuffle=False)

    # 讀取BERT的配置文件
    bert_config = BertConfig.from_pretrained('../chinese-bert_chinese_wwm_pytorch')
    bert_config.分類 = 分類

    # 初始化模型
    model = BertClassifier(bert_config)
    model.to(device)

    EPOCHS = 10
    learning_rate = 5e-6    #Learning Rate不宜太大
    optimizer = AdamW(model.parameters(), lr=learning_rate)
    #交叉熵 = nn.CrossEntropyLoss()

    with open('output.txt', 'w') as wf:
        wf.write('Batch Size: ' + str(batch_size) + '\tLearning Rate: ' + str(learning_rate) + '\n')

    best_acc = 0
    # 開始訓練
    for Epoch in range(1, EPOCHS+1):
        losses = 0      # 損失
        accuracy = 0    # 準确率
        print('Epoch:',Epoch)

        model.train()
        for batch_index, batch in enumerate(train_dataloader):
            input_ids = batch[0].to(device)
            attention_mask = batch[1].to(device)
            token_type_ids = batch[2].to(device)
            label_ids = batch[3].to(device)

            output = model(input_ids=input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)# forward

            loss = 交叉熵(output, label_ids)
            losses += loss.item()
            預測 = torch.argmax(output, dim=1)   # 預測出的label
            acc = torch.sum(預測 == label_ids.to(device)).item() / len(預測) #acc
            accuracy += acc

            print('Epoch: %d ｜ Train: | Batch: %d / %d | Acc: %f | Loss: %f' % (Epoch, batch_index+1, len(train_dataloader), acc, loss.item()))

            model.zero_grad()
            loss.backward()
            optimizer.step()


        average_loss = losses / len(train_dataloader)
        average_acc = accuracy / len(train_dataloader)

        print('\tTrain ACC:', average_acc, '\tLoss:', average_loss)
        with open('output.txt', 'a') as rf:
            output_to_file = '\nEpoch: ' + str(Epoch) + '\tTrain ACC:' + str(average_acc) + '\tLoss: ' + str(average_loss)
            rf.write(output_to_file)

        # 驗證
        model.eval()
        losses = 0      # 損失
        accuracy = 0    # 準确率
        for batch_index, batch in enumerate(valid_dataloader):
            input_ids = batch[0].to(device)
            attention_mask = batch[1].to(device)
            token_type_ids = batch[2].to(device)
            label_ids = batch[3].to(device)

            output = model(    # forward
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
            )

            loss = 交叉熵(output, label_ids)
            losses += loss.item()

            預測 = torch.argmax(output, dim=1)   # 預測出的label
            acc = torch.sum(預測 == label_ids.to(device)).item() / len(預測) #acc
            accuracy += acc

        average_loss = losses / len(valid_dataloader)
        average_acc = accuracy / len(valid_dataloader)

        print('\tValid ACC:', average_acc, '\tLoss:', average_loss)
        with open('output.txt', 'a') as rf:
            output_to_file = '\nEpoch: ' + str(Epoch) + '\tValid ACC:' + str(average_acc) + '\tLoss: ' + str(average_loss) + '\n'
            rf.write(output_to_file)

        if average_acc > best_acc:
            best_acc = average_acc
            torch.save(model.state_dict(), 'models/best_model.pkl')
