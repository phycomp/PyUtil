def collateFN(batch):
    data = [item[0] for item in batch]
    target = [item[1] for item in batch]
    return torch.Tensor(data), torch.Tensor(target)
