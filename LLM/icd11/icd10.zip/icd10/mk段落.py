from streamlit import session_state, code as stCode
from sys import path
#stCode(['sysPath=', path])
#from ..mk文本 import rtrvTXT
def rtrvSents():
  try:
    Sents=session_state['Sents']    #=[sent.text for sent in doc.sents]
  except:
    from spacy.lang.en import English
    nlp = English()
    #sentczr=nlp.create_pipe('sentencizer')
    #nlp.add_pipe(sentczr)
  #try: session_state['Sents']=Sents=[sent.text for sent in doc.sents]
    nlp.add_pipe('sentencizer')
    TEXT=session_state['TEXT']
    #TEXT=rtrvTXT()
    doc=nlp(TEXT)
    session_state['Sents']=Sents=[sent.text for sent in doc.sents]
  return Sents
