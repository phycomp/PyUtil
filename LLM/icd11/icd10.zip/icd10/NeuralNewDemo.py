class FeedForwardNeuralNet(nn.Module):

    def __init__(self, input_size, hidden_size, num_classes):
        super(FeedForwardNeuralNet, self).__init__()
        self.l1 = nn.Linear(input_size, hidden_size) # define first layer
        self.relu = nn.ReLU() # activation function
        self.l2 = nn.Linear(hidden_size, num_classes) # define second layer

    def forward(self, x):
        out = self.l1(x)
        out = self.relu(out)
        out = self.l2(out)

        return out


model = FeedForwardNeuralNet(input_size, hidden_size, num_classes)
我們可以看到第一層 Layer 就是接收 input 資料並輸出成 hidden layer 有的神經元數量，然後接了一個 Activation function（後面會再解釋），然後再傳遞給 Output layer，也就是第二層 layer 的狀況
這樣我們就等於建立了 Feedforward network 的結構了，就讓我們看看完整的程式長怎樣吧~
完整 code
import 的部分就是一樣的 torch、torch.nn、Dataset跟Dataloader
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import SubsetRandomSampler
# base data inform and network data 設定基本參數
input_size hidden_size, num_classes = 4, 4, 3
num_epochs, batch_size, 學習率=10, 4, .001
最前面的資料處理部分，就跟之前都一樣，只是這次我們可以把所有三個類別都使用了 這邊提醒一下，資料呈現的方式有點不一樣了，我們希望呈現的樣子會變成類似下面這樣
# tensor([[5.5000, 2.4000, 3.8000, 1.1000],
#         [6.0000, 3.4000, 4.5000, 1.6000],
#         [5.2000, 3.5000, 1.5000, 0.2000],
#         [5.3000, 3.7000, 1.5000, 0.2000]]) tensor([1, 1, 0, 0])
所以我們再 Dataset 裡面有做資料型態跟格式的轉換
# 0) data import and set as pytorch dataset
from sklearn import datasets
from pandas import DataFrame, concat as pndsConcat
from torch import from_numpy
from numpy import array as npArray

class IrisDataset(Dataset):
    def __init__(self): # data loading
        iris = datasets.load_iris()
        feature = DataFrame(iris.data, columns=iris.feature_names)
        target = DataFrame(iris.target, columns=['target'])
        iris_data = pndsConcat([target, feature], axis=1)
        # Data type change and flatten targets
        self.x = from_numpy(npArray(iris_data)[:, 1:].astype(np.float32))
        self.y = from_numpy(npArray(iris_data)[:, [0]].astype(np.longlong).flatten())
        self.n_samples = self.x.shape[0]

    # working for indexing
    def __getitem__(self, index):

        return self.x[index], self.y[index]

    # return the length of our dataset
    def __len__(self):

        return self.n_samples


dataset = IrisDataset()

# create data spliter
def dataSplit(dataset, val_split=0.25, shuffle=False, random_seed=0):

    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    split = int(np.floor(val_split * dataset_size))
    if shuffle:
        np.random.seed(random_seed)
        np.random.shuffle(indices)

    train_indices, val_indices = indices[split:], indices[:split]
    train_sampler = SubsetRandomSampler(train_indices)
    valid_sampler = SubsetRandomSampler(val_indices)

    return train_sampler, valid_sampler

# base split parameters
val_split = 0.25
shuffle_dataset = True
random_seed= 42

train_sampler, valid_sampler = dataSplit(dataset=dataset, val_split=val_split, shuffle=shuffle_dataset, random_seed=random_seed)

train_loader = DataLoader(dataset, batch_size=batch_size, sampler=train_sampler)
val_loader = DataLoader(dataset, batch_size=batch_size, sampler=valid_sampler)
# 1) model build 建立 FeedForward
class FeedForwardNeuralNet(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(FeedForwardNeuralNet, self).__init__()
        self.l1 = nn.Linear(input_size, hidden_size) # define first layer
        self.relu = nn.ReLU() # activation function
        self.l2 = nn.Linear(hidden_size, num_classes) # define second layer

    def forward(self, x):
        out = self.l1(x)
        out = self.relu(out)
        out = self.l2(out)

        return out


model = FeedForwardNeuralNet(input_size, hidden_size, num_classes)
選擇適合的 loss function 和 optimizer
學習率 = .01 # 2) loss and optimizer
交叉熵 = CrossEntropyLoss() # Cross Entropy criterion
optimizer = torch.optim.Adam(model.parameters(), lr=學習率) # adam algorithm 學習率==>learning_rate
# 3) Training loop 開始 Training
n_total_steps = len(train_loader)
for epoch in range(num_epochs):
    for i, (datas, labels) in enumerate(train_loader):
        optimizer.zero_grad() # init optimizer
        # forward -> backward -> update
        outputs = model(datas)
        loss = 交叉熵(outputs, labels)
        loss.backward()
        optimizer.step()
        if (i + 1) % 19 == 0:
            print(f'epoch {epoch+1}/{num_epochs}, step {i+1}/{n_total_steps}, loss = {loss.item():.4f}')
# 4) Testing 那最後再執行 Testing 做檢查
with torch.no_grad():
    n_correct = 0
    n_samples = 0
    for datas, labels in val_loader:
        outputs = model(datas.float())
        _, predictions = torch.max(outputs, 1)
        n_samples += labels.shape[0]
        n_correct += (predictions == labels).sum().item()

    精確度 = 100. * n_correct / n_samples
    print(f'accuracy = {精確度}')

