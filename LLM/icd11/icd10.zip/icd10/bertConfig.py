class BertConfig(object):
    """Configuration class to store the configuration of a `BertModel`.
    """
    def __init__(self, 字數, # vocab_size=字典字數
                 嵌向量=384, #hidden_size嵌向量 隱藏層維度也就是字向量維度
                 層數=6, #num_hidden_layers=層數 transformer block 的個數
                 頭數=12, #num_attention_heads頭數 注意力機制"頭"的個數
                 中間=384*4, #intermediate_size中間 feedforward層線性映射的維度
                 激活="softmax", # hidden_act=激活函數 預設值為gelu
                 丟棄=0.4,     #hidden_dropout_prob丟棄 dropout的概率
                 隱藏丟棄=0.4,  #attention_probs_dropout_prob=隱藏丟棄
                 位置嵌入=512*2, #max_position_embeddings=位置嵌入
                 分類=256,      #type_vocab_size分類 用來做next sentence預測, 這裏預留了256個分類, 其實我們目前用到的只有0和1
                 σ=.02      #initializer_range 用來初始化模型參數的標準差
                 ):
        self.字數 = 字數        #字數=vocab_size    詞長
        self.嵌向量 =嵌向量     #嵌向量=hidden_size 
        self.層數 = 層數        #num_hidden_layers=層數
        self.頭數 = 頭數        #num_attention_heads=頭數
        self.激活 = 激活        #hidden_act=激活
        self.中間 = 中間        #中間=intermediate_size
        self.隱藏丟棄 = 隱藏丟棄        #hidden_dropout_prob=隱藏丟棄
        self.丟棄 = 丟棄 #注意丟棄 =attention_probs_dropout_prob
        self.位置嵌入= 位置嵌入 #位置嵌入=max_position_embeddings
        self.分類=分類  #分類=type_vocab_size
        self.σ = σ      #σ=initializer_range


