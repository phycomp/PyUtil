from torch.nn import Module, RNN, Linear, CrossEntropyLoss
from torch.nn.functional import softmax

class CharRNN(Module):
    def __init__(self, input_size, hidden_size, output_size, n_layers=1):
        super(CharRNN, self).__init__()
        self.hidden_size = hidden_size
        self.n_layers = n_layers
        
        self.rnn = RNN(input_size, hidden_size, n_layers, batch_first=True)
        self.fc = Linear(hidden_size, output_size)
    
    def forward(self, x, hidden):
        out, hidden = self.rnn(x, hidden)
        out = out.contiguous().view(-1, self.hidden_size)
        out = self.fc(out)
        return out, hidden
    
    def init_hidden(self, batch_size):
        return torch.zeros(self.n_layers, batch_size, self.hidden_size)

# 設置參數
input_size = len(chars)
hidden_size = 128
output_size = len(chars)
n_layers = 1

# 創建模型
model = CharRNN(input_size, hidden_size, output_size, n_layers)

def one_hot_encode(arr, n_labels):
    one_hot = np.zeros((arr.size, n_labels), dtype=np.float32)
    one_hot[np.arange(one_hot.shape[0]), arr.flatten()] = 1.0
    one_hot = one_hot.reshape((*arr.shape, n_labels))
    return one_hot

seq_length, batch_size=10, 1  # 訓練數據序列長度

features = one_hot_encode(encoded[:seq_length], len(chars))
features = torch.from_numpy(features).unsqueeze(0)  # 增加 batch 維度
targets = torch.from_numpy(encoded[1:seq_length+1]).unsqueeze(0)

criterion = CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

n_epochs = 1000
for epoch in range(1, n_epochs + 1):
    hidden = model.init_hidden(batch_size)
    
    # 清零梯度
    model.zero_grad()
    
    # 前向傳播
    output, hidden = model(features, hidden)
    
    # 計算損失
    loss = criterion(output, targets.view(-1))
    
    # 反向傳播和更新權重
    loss.backward()
    optimizer.step()
    
    if epoch % 100 == 0:
        print(f'Epoch: {epoch}, Loss: {loss.item()}')

def predict(model, char, h=None):
    x = np.array([[char2int[char]]])
    x = one_hot_encode(x, len(chars))
    x = torch.from_numpy(x)
    
    out, h = model(x, h)
    
    prob = softmax(out, dim=1).data
    char_ind = torch.max(prob, dim=1)[1].item()
    
    return int2char[char_ind], h

def sample(model, start_char, length):
    model.eval()  # 設置模型為評估模式
    
    chars = [start_char]
    h = model.init_hidden(1)
    
    for _ in range(length):
        char, h = predict(model, chars[-1], h)
        chars.append(char)
    
    return ''.join(chars)

# 生成20個字符
print(sample(model, 'h', 20))
