train_iter = AG_NEWS(split='train')
num_class = len(set([label for (label, text) in train_iter]))
vocab_size = len(vocab)
emsize = 64
model = 文字分類(vocab_size, emsize, num_class).to(device)  #定義函數訓練模型并評估結果
import time

def train(dataloader):
    model.train()
    精確, 計數= 0, 0
    log_interval = 500
    #start_time = time.time()

    for idx, (label, text, offsets) in enumerate(dataloader):
        optimizer.zero_grad()
        預測 = model(text, offsets)
        loss = criterion(預測, label)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.1)
        optimizer.step()
        精確 += (預測.argmax(1) == label).sum().item()
        計數+= label.size(0)
        if idx % log_interval == 0 and idx > 0:
            #elapsed = time.time() - start_time
            print(f'| epoch {epoch} | {idx}/{len(dataloader)} batches | accuracy {精確/total_count}')    #.format(, , , )
            精確, 計數= 0, 0
            #start_time = time.time()

def evaluate(dataloader):
    model.eval()
    精確, 計數= 0, 0
    with torch.no_grad():
        for idx, (label, text, offsets) in enumerate(dataloader):
            預測 = model(text, offsets)
            loss = 交叉熵(預測, label)
            精確 += (預測.argmax(1) == label).sum().item()
            計數+= label.size(0)
    return 精確/total_count
