from streamlit import session_state
def 特殊字():
  try:
    特殊字=session_state['特殊字']
  except:
    session_state['特殊字']=特殊字={'[PAD]': 0, '[CLS]': 1, '[SEP]': 2, '[MASK]': 3, '[UNK]':4, '[BOS]':5, '[EOS]':6}
  return 特殊字
