ε = 1e-8
from torch.nn import Embedding, init as 初始化
def 計算嵌入(字最長, vocabSize, 嵌入維度):
  字嵌入 = Embedding(字最長, 嵌入維度)
  象嵌入 = Embedding(vocabSize, 嵌入維度)
  初始化.orthogonal_(字嵌入.weight)
  # nn.init.orthogonal_(position_embeddings.weight)
  初始化.orthogonal_(象嵌入.weight)
  字嵌入.weight.data = 字嵌入.weight.data.div(torch.norm(字嵌入.weight, p=2, dim=1, keepdim=True).data+ε)
  象嵌入.weight.data = 象嵌入.weight.data.div(torch.norm(象嵌入.weight, p=2, dim=1, keepdim=True).data+ε)

def tknWordEmbddng(Cntxt, split=3, overlap=0):
  #with open(data_path) as csv_file:
  #    reader = csv.reader(csv_file, quotechar='"')
  #for idx, line in enumerate(reader):
  fields = []
  for i in range(1, split+1):
      fields.append(('text'+str(i), text_field))
  fields.append(('label', label_field))
  text, 編碼文件 = "", []
  for tx in Cntxt:  #line[1:]
      text += tx              #tx就是一篇文檔
      text += " "
      word_tokens = word_tokenize(text)
      len_text = len(word_tokens)
      for i in range(split):
          真實長度 = int((len_text + overlap*(split-1)) / split) #小文檔的真實長度
          相對長度 = 真實長度 - overlap
          doc = word_tokens[i*相對長度 : (i+1)*相對長度 + overlap]
          編碼文件.append(doc)
  label = int(line[0])
  編碼文件.append(label)
  examples.append(tdata.Example.fromlist(編碼文件, fields))
  return 編碼文件, examples

def rtrvEmbddng(cntxt):
  向量=GloVe(name='6B', dim=300)    #"glove.6B.300d"
  #寰向量= GloVe()   #寰 = GloVe()
  #TEXT = data.Field(sequential=True)

  TEXT.build_vocab(cntxt, vectors=向量)
  #TEXT.build_vocab(cntxt, vectors=)
  寰彙 = vocab(寰向量.stoi)
  寰彙.insert_token("<unk>", unkNdx)
  #this is necessary otherwise it will throw runtime error if OOV token is queried
  寰彙.set_default_index(unkNdx)
  前訓嵌入 = 寰向量.vectors
  前訓嵌入 = trchCat((trchZeros(1, 前訓嵌入.shape[1]), 前訓嵌入))
  num_class = len(set([label for (label, _) in train_iter]))
  嵌入 = Embedding.from_pretrained(寰向量.vectors, freeze=False) # set freeze to false if you want them to be trainable
  return 嵌入
  客嵌入 = vocab.Vectors(name = 'custom_embeddings.txt')
  TEXT.build_vocab(cntxt, vectors = 客嵌入)
  #嵌入 = Embedding.from_pretrained(寰向量.vectors, freeze=True) # set freeze to false if you want them to be trainable
