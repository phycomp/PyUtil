from sklearn import datasets
from pandas import DataFrame, concat as pndsConcat
from torch import from_numpy
from numpy import array as npArray

class IrisDataset(Dataset):
    def __init__(self): # data loading
        iris = datasets.load_iris()
        feature = DataFrame(iris.data, columns=iris.feature_names)
        target = DataFrame(iris.target, columns=['target'])
        iris_data = pndsConcat([target, feature], axis=1)
        # Data type change and flatten targets
        self.x = from_numpy(npArray(iris_data)[:, 1:].astype(np.float32))
        self.y = from_numpy(npArray(iris_data)[:, [0]].astype(np.longlong).flatten())
        self.n_samples = self.x.shape[0]

    # working for indexing
    def __getitem__(self, index):

        return self.x[index], self.y[index]

    # return the length of our dataset
    def __len__(self):

        return self.n_samples


dataset = IrisDataset()

# create data spliter
def dataSplit(dataset, val_split=0.25, shuffle=False, random_seed=0):

    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    split = int(np.floor(val_split * dataset_size))
    if shuffle:
        np.random.seed(random_seed)
        np.random.shuffle(indices)

    train_indices, val_indices = indices[split:], indices[:split]
    train_sampler = SubsetRandomSampler(train_indices)
    valid_sampler = SubsetRandomSampler(val_indices)

    return train_sampler, valid_sampler

