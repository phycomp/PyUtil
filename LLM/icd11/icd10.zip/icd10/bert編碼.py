#from streamlit import code as stCode
from transformers import BertTokenizer

def 詞編碼(cntxt, bertName='/home/josh/bert-base-uncased'): #text = '愿執子手立黃昏 冬日品茗粥尚溫.'
  分詞 = BertTokenizer.from_pretrained(bertName) #bert_name 
  詞碼 = 分詞.encode( cntxt, add_special_tokens=True, # 添加special tokens 也就是CLS和SEP
   max_length=100, # 設定最大文本長度
   pad_to_max_length=True, # pad到最大的長度
   return_tensors='pt' # 返回的類型爲pytorch tensor
   )
  #stCode([inputIDs])
  return 詞碼
