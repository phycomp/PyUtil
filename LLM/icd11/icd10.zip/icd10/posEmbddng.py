from numpy import array as npArray, sin as npSin, cos as npCos, sum as npSum, sqrt as npSqrt, power as npPower, zeros as npZeros
from torch import FloatTensor, from_numpy as trchNumpy
def 位置嵌入(hidden_dim, max_seq_len):
    posEmbddng = npArray([
        [pos / npPower(10000, 2 * i / hidden_dim) for i in range(hidden_dim)]
        if pos != 0 else npZeros(hidden_dim) for pos in range(max_seq_len)])

    posEmbddng[1:, 0::2] = npSin(posEmbddng[1:, 0::2])  # dim 2i
    posEmbddng[1:, 1::2] = npCos(posEmbddng[1:, 1::2])  # dim 2i+1
    denominator = npSqrt(npSum(posEmbddng**2, axis=1, keepdims=True))
    posEmbddng = posEmbddng / (denominator + 1e-8)
    posEmbddng = trchNumpy(posEmbddng).type(FloatTensor)
    return posEmbddng
