
from torch.nn import CrossEntropyLoss as 交叉熵
from torch.optim.lr_scheduler import StepLR
from torch.optim import SGD
#交叉熵 = CrossEntropyLoss()
EPOCHS, LR, 束量=10, 5, 64    # epoch, learning rate, batch size for training

optimizer = SGD(文字分類.parameters(), lr=LR)
#scheduler = torch.optim.lr_scheduler.
scheduler=StepLR(optimizer, 1., gamma=.1)
total_accu = None
train_iter, test_iter = AG_NEWS()
train_dataset = to_map_style_dataset(train_iter)
test_dataset = to_map_style_dataset(test_iter)
num_train = int(len(train_dataset) * .95)
split_train_, split_valid_ = random_split(train_dataset, [num_train, len(train_dataset) - num_train])

train_dataloader = DataLoader(split_train_, batch_size=束量, shuffle=True, collate_fn=collate_batch)
valid_dataloader = DataLoader(split_valid_, batch_size=束量, shuffle=True, collate_fn=collate_batch)
test_dataloader = DataLoader(test_dataset, batch_size=束量, shuffle=True, collate_fn=collate_batch)
#total_accu is not None and
while total_accu > accu_val:
    accu_val = evaluate(valid_dataloader)
    scheduler.step()
    total_accu = accu_val
"""
for epoch in range(1, EPOCHS + 1):
    #epoch_start_time = time.time()
    train(train_dataloader)
    accu_val = evaluate(valid_dataloader)
    if total_accu is not None and total_accu > accu_val:
        scheduler.step()
    else:
        total_accu = accu_val
    print("-" * 59)
    print( f"valid accuracy {accu_val} "   #.format( epoch, time.time() - epoch_start_time ) #"| end of epoch {:3d} | time: {:5.2f}s | "
    )
    #print("-" * 59)

"""

分類 = {1: "World", 2: "Sports", 3: "Business", 4: "Sci/Tec"}
#分類 ag_news_label

def predict(text, text_pipeline):
    with torch.no_grad():
        text = torch.tensor(text_pipeline(text))
        output = model(text, torch.tensor([0]))
        return output.argmax(1).item() + 1

ex_text_str = "MEMPHIS, Tenn. – Four days ago, Jon Rahm was \
    enduring the season’s worst weather conditions on Sunday at The \
    Open on his way to a closing 75 at Royal Portrush, which \
    considering the wind and the rain was a respectable showing. \
    Thursday’s first round at the WGC-FedEx St. Jude Invitational \
    was another story. With temperatures in the mid-80s and hardly any \
    wind, the Spaniard was 13 strokes better in a flawless round. \
    Thanks to his best putting performance on the PGA Tour, Rahm \
    finished with an 8-under 62 for a three-stroke lead, which \
    was even more impressive considering he’d never played the \
    front nine at TPC Southwind."

model = 文字分類.to("cpu")

print("This is a %s news" % ag_news_label[predict(ex_text_str, text_pipeline)])

