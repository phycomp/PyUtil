from torch.nn import Module, Linear, ModuleList, Tanh, Dropout, Softmax, Parameter, init as trchInit

from torch import matmul as trchMatmul
from math import sqrt as SQRT   #as trchSQRT

class BertSelfAttention(Module):
    """自注意力機制層, 見Transformer(一), 講編碼器(encoder)的第2部分"""
    def __init__(self, config):
        super(BertSelfAttention, self).__init__()
        assert config.hidden_size % config.num_attention_heads == 0     #判斷embedding dimension是否可以被num_attention_heads整除
        #if config.hidden_size % config.num_attention_heads != 0: raise ValueError(f"The hidden size {config.hidden_size} is not a multiple of the number of attention heads {config.num_attention_heads}")
        self.頭數 = config.頭數     #頭數=num_attention_heads
        self.頭量 = int(config.嵌向量/config.頭數)    #hidden_size嵌向量 num_attention_heads   attention_head_size==att頭數
        self.all_head_size = self.頭數 * self.頭量   #num_attention_heads頭數, 頭量=attention_head_size
        # Q, K, V線性映射
        self.query = Linear(config.嵌向量, self.嵌向量) #hidden_size嵌向量
        self.key = Linear(config.嵌向量, self.嵌向量)
        self.value = Linear(config.嵌向量, self.嵌向量)
        self.dropout = Dropout(config.隱藏丟棄)  #attention_probs_dropout_prob=隱藏丟棄

    def 轉置(self, x):  #transpose_for_scores=轉置
        # 輸入x爲QKV中的一個 維度為 [束量batch_size, 詞長seq_length, 嵌向量embedding_dim]
        # 輸出的維度經過reshape和轉置: [束量batch_size, 頭數num_heads, 詞長seq_length, 嵌向量embedding_dim/頭數num_heads]
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(self, hidden_states, attention_mask, get_attention_matrices=False):
        # Q, K, V線性映射 Q, K, V的維度爲[batch_size, seq_length, 頭數num_heads * 嵌向量embedding_dim]
        mixed_query_layer = self.query(hidden_states)
        mixed_key_layer = self.key(hidden_states)
        mixed_value_layer = self.value(hidden_states)
        # 把QKV分割成num_heads份 把維度轉換爲[batch_size, num_heads, seq_length, embedding_dim / num_heads]
        query_layer = self.轉置(mixed_query_layer)  #transpose_for_scores
        key_layer = self.轉置(mixed_key_layer)
        value_layer = self.轉置(mixed_value_layer)

        attention_scores = trchMatmul(query_layer, key_layer.transpose(-1, -2)) # Take the dot product between "query" and "key" to get the raw attention scores. Q與K求點積 attention_scores: [batch_size, num_heads, seq_length, seq_length] 除以K的dimension, 開平方根以歸一爲標準正態分布
        #attention_scores=注意值
        注意值 = 注意值 / SQRT(self.注意頭數)   #attention_head_size注意頭數
        # Apply the attention mask is (precomputed for all layers in BertModel forward() function)
        注意值 = 注意值+注意遮    #attention_scores + attention_mask
        # attention_mask 注意力矩陣mask: [batch_size, 1, 1, seq_length]
        # 元素相加後, 會廣播到維度: [batch_size, num_heads, seq_length, seq_length]

        # softmax歸一化, 得到注意力矩陣 Normalize the attention scores to probabilities.
        注意機率 = Softmax(dim=-1)(注意值)    #attention_scores 注意機率=attention_probs_ 
        新機率 = self.dropout(注意機率)   # This is actually dropping out entire tokens to attend to, which might seem a bit unusual, but is taken from the original Transformer paper.
        加權層= trchMatmul(新機率, value_layer) #context_layer 用注意力矩陣加權V
        # 把加權後的V reshape, 得到[batch_size, length, embedding_dimension]
        加權層 = 加權層.permute(0, 2, 1, 3).contiguous()    #context_layer
        新加權= 加權層.size()[:-2] + (self.all_head_size,)    #context_layer new_context_layer_shape新加權
        context_layer = context_layer.view(*新加權) # 輸出attention矩陣用來可視化 new_context_layer_shape
        if get_attention_matrices:
            return context_layer, attention_probs_
        return context_layer, None


