from torchtext.data.utils import get_tokenizer, ngrams_iterator
分詞 = get_tokenizer('basic_english')
from torchtext.vocab import build_vocab_from_iterator as 迭代詞表
#add_special_tokens=True, Add '[CLS]' and '[SEP]' 字嵌入

