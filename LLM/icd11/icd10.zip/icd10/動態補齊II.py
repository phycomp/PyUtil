from torch import tensor
from torch.nn.utils.rnn import pad_sequence

# 假設我們有不同長度的序列
seq1 = torch.tensor([1, 2, 3])
seq2 = torch.tensor([4, 5])
seq3 = torch.tensor([6])

# 把序列放入列表
sequences = [seq1, seq2, seq3]

# 使用 pad_sequence 進行動態補齊
# 動態補齊到該批次內的最大長度（這裡是3）
padded_sequences = pad_sequence(sequences, batch_first=True, padding_value=0)

rndrCode(padded_sequences)

from torch import tensor
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

# 假設我們有補齊後的序列
padded_sequences = tensor([[1, 2, 3], [4, 5, 0], [6, 0, 0]])
sequence_lengths = tensor([3, 2, 1])  # 每個序列的實際長度

# Pack 裝填序列，讓 RNN 忽略補齊部分
packed_input = pack_padded_sequence(padded_sequences, sequence_lengths, batch_first=True, enforce_sorted=False)

from torch.nn import RNN # 定義一個簡單的 RNN
rnn = RNN(input_size=1, hidden_size=10, batch_first=True)

output, hidden = rnn(packed_input)  # 進行前向傳播

output, _ = pad_packed_sequence(output, batch_first=True)   # 解包，恢復為補齊的輸出

rndrCode(output)
