from import 文字分類
def train(dataloader):
    文字分類.train()
    精確度, total_count = 0, 0
    log_interval = 500
    start_time = time.time()

    for idx, (label, text, offsets) in enumerate(dataloader):
        optimizer.zero_grad()
        預測 = 文字分類(text, offsets)
        loss = 交叉熵(預測, label)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(文字分類.parameters(), 0.1)
        optimizer.step()
        精確度 += (預測.argmax(1) == label).sum().item()
        total_count += label.size(0)
        if idx % log_interval == 0 and idx > 0:
            elapsed = time.time() - start_time
            print(
                "| epoch {:3d} | {:5d}/{:5d} batches "
                "| accuracy {:8.3f}".format(
                    epoch, idx, len(dataloader), 精確度 / total_count
                )
            )
            精確度, total_count = 0, 0
            start_time = time.time()


def evaluate(dataloader):
    文字分類.eval()
    精確度, total_count = 0, 0

    with torch.no_grad():
        for idx, (label, text, offsets) in enumerate(dataloader):
            預測 = 文字分類(text, offsets)
            loss = 交叉熵(預測, label)
            精確度 += (預測.argmax(1) == label).sum().item()
            total_count += label.size(0)
    return 精確度 / total_count

