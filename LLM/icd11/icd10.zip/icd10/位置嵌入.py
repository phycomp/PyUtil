from torch.autograd import Variable
from torch.nn import Module, Dropout, Linear
from torch import zeros as trchZeros, arange as trchArange, exp as trchExp, sin as trchSin, cos as trchCos
from math import log as mathLog

class 位置嵌入(Module):
  def __init__(self, 維數, dropout, max_len=5000):
    super(位置嵌入, self).__init__() #位置嵌入PositionalEncoding
    self.dropout = Dropout(p=dropout)
    # 初始化一個size為 max_len(設定的最大長度)×embedding維度 的全零矩陣 來存放所有小于這個長度位置對應的porisional embedding
    位嵌 = trchZeros(max_len, 維數, device=DEVICE)
    # 生成一個位置下標的tensor矩陣(每一行都是一個位置下標)
    #形式如 tensor([[0.], [1.], [2.], [3.], [4.], ...])
    位置 = torch.arange(0., max_len, device=DEVICE).unsqueeze(1)
    # 這裏冪運算太多 我們使用exp和log來轉換實現公式中pos 下面要除以的分母（由于是分母 要注意帶負號）
    div_term = trchExp(trchArange(0., 維數, 2, device=DEVICE) * -(mathLog(10000.) / 維數))
    # 得到各個位置在各embedding維度上的位置紋理值 存放到pe位嵌矩陣中
    位嵌[:, 0::2] = trchSin(位置 * div_term)
    位嵌[:, 1::2] = trchCos(位置 * div_term)
    # 加1個維度，使得pe維度變為：1×max_len×embedding維度
    # 方便後續與一個batch的句子所有詞的embedding批量相加
    位嵌 = 位嵌.unsqueeze(0)
    self.register_buffer('pe', 位嵌) #將pe位嵌矩陣 以持久的buffer狀態存下(不會作為要訓練的參數)

  def forward(self, x):
    # 將一個batch的句子所有詞的embedding 與已構建好的位置嵌入positional embeding相加
    # 這裏按照該批次數據的最大句子長度 來取對應需要的那些位置嵌入positional embedding值
    x = x + Variable(self.位嵌[:, :x.size(1)], requires_grad=False)
    return self.dropout(x)

