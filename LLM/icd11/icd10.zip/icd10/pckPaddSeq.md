為什麼要用pack_padded_sequence
在使用深度學習特別是LSTM進行文本分析時，經常會遇到文本長度不一樣的情況，此時就需要對同一個batch中的不同文本使用padding的方式進行文本長度對齊，方便將訓練數據輸入到LSTM模型進行訓練，同時為了保證模型訓練的精度，應該同時告訴LSTM相關padding的情況，此時，pytorch中的pack_padded_sequence就有了用武之地。

直接從文本處理開始
假設我們有如下四段文字：

1.To the world you may be one person, but to one person you may be the world. 
2.No man or woman is worth your tears, and the one who is, won’t make you cry. 
3.Never frown, even when you are sad, because you never know who is falling in love with your smile. 
4.We met at the wrong time, but separated at the right time. The most urgent is to take the most beautiful scenery; the deepest wound was the most real emotions.
將文本存儲為test.txt，使用如下腳本轉換成padding之後的矩陣：

from wordfreq import tokenize
from numpy import zeros as npZero

vocab, token_id, 長度 ={}, 1, []

with open('test.txt', 'r') as f:
    for l in f:
        tokens = tokenize(l.strip(), 'en')
        長度.append(len(tokens))
        for tkn in tokens:
            if tkn not in vocab:
                vocab[tkn] = token_id
                token_id += 1

x = npZero((len(lengths), max(lengths)))
l_no = 0
with open('test.txt', 'r') as f:
    for l in f:
        tokens = tokenize(l.strip(), 'en')
        for i in range(len(tokens)):
            x[l_no, i] = vocab[tokens[i]]
        l_no += 1
我們可以看到文本已經被轉換成token_id矩陣，其中0為padding值。接下來就是需要用到pack_padded_sequence的地方：

import torch
import torch.nn as nn
from torch.autograd import Variable

from torch import Tensor, sort
from torch.nn.utils.rnn import pack_padded_sequence
x = Variable(x)
lengths = Tensor(lengths)
_, idx_sort = sort(Tensor(lengths), dim=0, descending=True)
_, idx_unsort = sort(idx_sort, dim=0)

x = x.index_select(0, idx_sort)
lengths = list(lengths[idx_sort])
x_packed = pack_padded_sequence(input=x, lengths=lengths, batch_first=True)
需要注意的是，pack_padded_sequence函數的參數，lengths需要從大到小排序，x為已根據長度大小排好序，batch_first如果設置為true，則x的第一維為batch_size，第二維為seq_length，否則相反。 打印x_packed如下：

可以看到，x的前二維已被合并成一維，同時原來x中的padding值0已經被消除，多出的batch_sizes可以看成是原來x中第二維即seq_length在第一維即batch_size中不為padding值的個數。

使用pad_packed_sequence 那麼問題來了，x_packed經後續的LSTM處理之後，如何轉換回padding形式呢？沒錯，這就是pad_packed_sequence的用處。 假設x_packed經LSTM網絡輸出後仍為x_packed（注：一般情況下，經LSTM網絡輸出應該有第三維，但方便起見，x_packed的第三維的維度可看成是1），則相應轉換如下：
from torch.nn.utils.rnn import pad_packed_sequence, PackedSequence

x_padded = pad_packed_sequence(x_packed, batch_first=True)
output = x_padded[0].index_select(0, idx_unsort)
需要注意的是，idx_unsort的作用在于將batch中的序列調整為原來的順序。
打印output：
可以看出，與原來的x一樣。

from torch.nn.functional import dropout
PackedSequence的用處 其實很簡單，當之前的x_packed需要經過dropout等函數處理時，需要傳入的是x_packed.data，是一個tensor，經過處理後，要將其重新封裝成PackedSequence，再傳入LSTM網絡，示例如下：

dropout_output = dropout(x_packed.data, p=0.6, training=True)
x_dropout = PackedSequence(dropout_output, x_packed.batch_sizes)
參考

一個更直觀的解釋，來自博客
為什麼有pad和pack操作？先看一個例子，這個batch中有5個sample 如果不用pack和pad操作會有一個問題，什麼問題呢？比如上圖，句子Yes只有一個單詞，但是padding了多余的pad符號，這樣會導致LSTM對它的表示通過了非常多無用的字符，這樣得到的句子表示就會有誤差，更直觀的如下圖：
那麼我們正确的做法應該是怎麼樣呢？在上面這個例子，我們想要得到的表示僅僅是LSTM過完單詞"Yes"之後的表示，而不是通過了多個無用的Pad得到的表示：如下圖：
from torch.nn.utils.rnn import pack_padded_sequence

pack_padded_sequence()
這裏的pack，理解成壓緊比較好。 將一個 填充過的變長序列壓緊。（填充時候，會有冗余，所以壓緊一下）

其中pack的過程為：（注意pack的形式，不是按行壓，而是按列壓）
（下面方框內為PackedSequence對象，由data和batch_sizes組成）

pack之後，原來填充的 PAD（一般初始化為0）占位符被刪掉了。

輸入的形狀可以是(T×B×* )。T是最長序列長度，B是batch size，*代表任意維度(可以是0)。如果batch_first=True的話，那麼相應的 input size 就是 (B×T×*)。 Variable中保存的序列，應該按序列長度的長短排序，長的在前，短的在後。即input[:,0]代表的是最長的序列，input[:,B-1]保存的是最短的序列。
NOTE： 只要是維度大于等于2的input都可以作為這個函數的參數。你可以用它來打包labels，然後用RNN的輸出和打包後的labels來計算loss。通過PackedSequence對象的.data屬性可以獲取 Variable。

參數說明:

input (Variable) – 變長序列 被填充後的 batch
lengths (list[int]) – Variable 中 每個序列的長度。
batch_first (bool, optional) – 如果是True，input的形狀應該是B*T*size。
返回值:

一個PackedSequence 對象。
torch.nn.utils.rnn.pad_packed_sequence()
填充packed_sequence。

上面提到的函數的功能是將一個填充後的變長序列壓緊。 這個操作和pack_padded_sequence()是相反的。把壓緊的序列再填充回來。填充時會初始化為0。

返回的Varaible的值的size是 T×B×*, T 是最長序列的長度，B 是 batch_size,如果 batch_first=True,那麼返回值是B×T×*。

Batch中的元素將會以它們長度的逆序排列。

參數說明:

sequence (PackedSequence) – 將要被填充的 batch
batch_first (bool, optional) – 如果為True，返回的數據的格式為 B×T×*。
返回值: 一個tuple，包含被填充後的序列，和batch中序列的長度列表

一個例子：
在這裏插入圖片描述
輸出：（這個輸出結果能較為清楚地看到中間過程）
在這裏插入圖片描述
此時PackedSequence對象輸入RNN後，輸出RNN的還是PackedSequence對象

（最後一個unpacked沒有用batch_first, 所以。。。）
