model.train()
model.parameters()
model.eval()
model.to("cpu")
  def yield_tokens(dataIter):
      for _, text in dataIter:
          yield 分詞(text)
