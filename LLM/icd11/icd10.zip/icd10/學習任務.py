#原理 學習任務 本質上是 的 端 在預訓練時最基本的任務就是 判斷輸入的兩個句子是否真的相鄰 預測被 掉的單詞 通過這兩種任務的約束 可以讓 真正學到 上下句子之間的語義關系的關聯關系 一個句子中不同單詞之間的上下文關系 所以通過 在大量文本中有針對的學習之後 可以真正做到對給定的句子進行語義層面的編碼 所以他才能被廣泛用于下遊任務 是 不需要大量人工標注數據的 這也是為什麼他可以大規模訓練預訓練模型 對于第一種訓練任務 我們只需要在給定的段落中隨機挑選兩句相鄰的句子就可以組成正樣本 而隨機挑選兩個不相鄰的句子就可以組成負樣本 對于第二種訓練任務 只需要對于給定的句子語料 對其中的單詞按照一定比例的 操作即可 因為 的部分只是模型不知道其存在 但是我們還是知道 的部分的真實標簽的 所以還是可以做監督學習的任務 而且還是自監督
from torch.utils.data import Dataset
import tqdm
import torch
import random


class BERTDataset(Dataset):
    def __init__(self, corpus_path, vocab, seq_len, encoding="utf-8", corpus_lines=None, on_memory=True):
        self.vocab = vocab # 構建詞表
        self.seq_len = seq_len # 當前句子的長度

        self.on_memory = on_memory
        self.corpus_lines = corpus_lines # 語料庫長度
        self.corpus_path = corpus_path # 語料庫路徑
        self.encoding = encoding # 編碼方式

        with open(corpus_path, "r", encoding=encoding) as f:
            if self.corpus_lines is None and not on_memory:
                for _ in tqdm.tqdm(f, desc="Loading Dataset", total=corpus_lines):
                    self.corpus_lines +=
            if on_memory:
                self.lines = [line[:-1].split("\t")
                              for line in tqdm.tqdm(f, desc="Loading Dataset", total=corpus_lines)]
                self.corpus_lines = len(self.lines)

        if not on_memory:
            self.file = open(corpus_path, "r", encoding=encoding)
            self.random_file = open(corpus_path, "r", encoding=encoding)

            for _ in range(random.randint(self.corpus_lines if self.corpus_lines < 1000 else 1000)):
                self.random_file.__next__()

    def __len__(self):
        return self.corpus_lines

    def __getitem__(self, item):
    	# item 是 index
    	# random_sent 就是根據 index 獲取兩個句子：t1，t2，并給出這兩個句子是否是相鄰的（標簽），這個過程中我們要保證用于訓練的數據集中相鄰和不相鄰的句子 1:1 也就是正負樣本要均衡
        t1, t2, is_next_label = self.random_sent(item)
		# 當選出 t1 和 t2 之後，在這兩個句子中按照一定的比例進行 MASK，而且同時將他們轉換成數值型變量 t1_random 和 t2_random； t1 label 和 t2 label 則是那些被 MASK 的值真正的標簽。具體的邏輯下面的函數再講
        t1_random, t1_label = self.random_word(t1)
        t2_random, t2_label = self.random_word(t2)

		# SOS 就是 start of the sentence 句子開始符號，這裏是用 [CLS] 放在句子開頭
		# EOS 就是 end of the sentences 句子結束符號在，這裏用 [EOS] 放在句尾
        # [CLS] tag = SOS tag, [SEP] tag = EOS tag

		# 得到 t1 和 t2 的數字化向量表示之後，需要人爲地給他們加上 [CLS], [SEP] 標簽：[CLS] 句子1 [SEP]  句子2 [SEP]
        t1 = [self.vocab.sos_index] + t1_random + [self.vocab.eos_index]
        t2 = t2_random + [self.vocab.eos_index]

		#  同樣的，t1_label 和 t2_label 也需要相應的填充，但這個的目的不是爲了分隔，而是爲了保持和 t1 t2 的序列一樣的長度
        t1_label = [self.vocab.pad_index] + t1_label + [self.vocab.pad_index]
        t2_label = t2_label + [self.vocab.pad_index]

		# segment label 表示當前的句子屬于第一個句子還是第二個句子，長度也和 t1+t2 長度一致；
		# 由于模型訓練的時候可能會限制輸入的最大長度，所以對以下三種輸入數據進行長度限制
        segment_label = ([1 for _ in range(len(t1))] + [2 for _ in range(len(t2))])[:self.seq_len]
        bert_input = (t1 + t2)[:self.seq_len]
        bert_label = (t1_label + t2_label)[:self.seq_len]

		# 如果輸入的句子并沒有達到最大長度，那麼就通過 pad 符號補全到最大長度；bert input, bert label 和 segment label 的長度是一致的
        padding = [self.vocab.pad_index for _ in range(self.seq_len - len(bert_input))]
        bert_input.extend(padding), bert_label.extend(padding), segment_label.extend(padding)

        output = {"bert_input": bert_input,
                  "bert_label": bert_label,
                  "segment_label": segment_label,
                  "is_next": is_next_label}  # isNext 表示當前的 t1, t2 是否是相鄰的句子

        return {key: torch.tensor(value) for key, value in output.items()} # 轉成張量

    def random_word(self, sentence):
    # 因爲這裏是英文任務，所以 sentence.split 是將一個句子切成單個的 token；漢語任務需要另外的處理方式
        tokens = sentence.split()
        output_label = []

        for i, token in enumerate(tokens):
        	# 隨機一個 0-1 之間的值，如果這個值 < 0.15 那麼執行下面操作，這句話的本質就是我們選擇 15% 的詞進行 MASK
            prob = random.random()
            if prob < 0.15:
                prob /= 0.
                # 80% randomly change token to mask token 在選出的 15% mask 的詞中使用 80% 進行真正的 mask
                if prob < 0.8:
                    tokens[i] = self.vocab.mask_index
                # 10% randomly change token to random token 10% 隨機選擇一個 word 進行替換（引入噪聲，故意錯誤的答案）
                elif prob < 0.9:
                    tokens[i] = random.randrange(len(self.vocab))

                # 10% randomly change token to current token 最後 10%，就是什麼也不做，相當于考試填空題直接給你把答案寫在卷面上
                else:
                    tokens[i] = self.vocab.stoi.get(token, self.vocab.unk_index)

				# 這些是上面被 mask 的詞對應的 label 標簽
                output_label.append(self.vocab.stoi.get(token, self.vocab.unk_index))

            else:
            # 剩余的 85% 的內容不做遮掩
                tokens[i] = self.vocab.stoi.get(token, self.vocab.unk_index)
                # 這個 output_label 自然也毫無意義，因此全給 0 即可
                output_label.append(0)

		# 假設目前這句話是 '[CLS]我喜歡吃青菜，[SEP]你呢？[SEP]'
		"""
		如果在那 15% 要被 mask 且在 80% 真正被 mask 的概率中，那麼進行 mask 之後變成 -> '[CLS]我[MASK]歡吃青菜,[SEP]你呢？[SEP]'
		假設 token 經過查找 vocab 之後的向量是 [0,2769,1,3614,1391,7471,5831,8024,2,872,1450,8043,2];
		output_label 應該是 [0,0,1599, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
		"""
		"""
		如果在那 15% 要被 mask 但是在 10% 摻雜噪聲的概率中，那麼 mask 之後可能變成 -> '[CLS]我喜歡吃毛菜,[SEP]你呢？[SEP]'
		假設 token 經過查找 vocab 之後的向量是 [0,2769,1599,3614,1391, 581,5831,8024,2,872,1450,8043,2];
		output_label 應該是 [0,0,0, 0, 0, 7471, 0, 0, 0, 0, 0, 0, 0]
		"""
		"""
		如果在那 15% 要被 mask 但是在最後 10% 的概率中，那麼 mask 之後可能變成 -> '[CLS]我喜歡吃毛菜,[SEP]你呢？[SEP]'
		假設 token 經過查找 vocab 之後的向量是 [0,2769,1599,3614,1391, 581,5831,8024,2,872,1450,8043,2]; （假設被選中的詞是 “你”）
		output_label 應該是 [0,0, 0, 0, 0, 0, 0, 0, 0, 0, 1450, 0, 0]
		"""
        return tokens, output_label

    def random_sent(self, index):
        t1, t2 = self.get_corpus_line(index)

        # output_text, label(isNotNext:0, isNext:1)
        # 0.5 的概率獲得兩個相鄰的句子
        if random.random() > 0.5:
            return t1, t2,         else:
        # 另外 0.5 的概率獲得不相鄰的句子
            return t1, self.get_random_line(),
    def get_corpus_line(self, item):
    	# 根據 index （item）返回一對相鄰的句子
        if self.on_memory:
            return self.lines[item][0], self.lines[item][1]
        else:
            line = self.file.__next__()
            if line is None:
                self.file.close()
                self.file = open(self.corpus_path, "r", encoding=self.encoding)
                line = self.file.__next__()

            t1, t2 = line[:-1].split("\t")
            return t1, t
    def get_random_line(self):
    # 隨機返回一個句子
        if self.on_memory:
            return self.lines[random.randrange(len(self.lines))][1]

        line = self.file.__next__()
        if line is None:
            self.file.close()
            self.file = open(self.corpus_path, "r", encoding=self.encoding)
            for _ in range(random.randint(self.corpus_lines if self.corpus_lines < 1000 else 1000)):
                self.random_file.__next__()
            line = self.random_file.__next__()
        return line[:-1].split("\t")[1]
​
代碼重寫
因爲原作者的代碼是通過自己構建了一個 vocab 詞表；而我想的是，使用一個預訓練 Bert 模型的 tokenizer 直接用來準備數據集，可能更加方便快捷。 所以我把相關部分的代碼更改了一下：
"""
 @Time    : 2022/10/ @Author  : Peinuan qin
 """

from torch.utils.data import Dataset, DataLoader
import torch
import random
import tqdm
import re
from transformers import BertTokenizer,BertModel, BertConfig
from utils import generate_random




class BERTDataset(Dataset):
    def __init__(self
                 , corpus_path
                 , tokenizer=None
                 , seq_len=                 , encoding='utf-8'
                 , lang='cn'
                 , corpus_lines=None
                 ):
        """

        :param corpus_path:
        :param vocab:
        :param seq_len:
        :param encoding:
        :param lang:
        :param corpus_lines:
        :param tokenizer:
        """
        assert tokenizer is not None, "please give a tokenizer"
        self.corpus_path = corpus_path
        self.tokenizer = tokenizer
        self.seq_len = seq_len
        self.vocab = self.tokenizer.vocab
        self.encoding = encoding
        self.lang = lang
        self.corpus_lines = corpus_lines
        if tokenizer:
            self.id2word = {k: v for v, k in tokenizer.vocab.items()}

        self.get_sentences()

    def __len__(self):
        return self.corpus_lines

    def __getitem__(self, index):
        t1, t2, isNext = self.get_two_sentence(index)
        t1, t1_mask_labels = self.mask_word(t1)
        t2, t2_mask_labels = self.mask_word(t2)

        # concate the t1 t2 with [CLS], [SEP], etc. special words,
        # convert all tokens to number values
        # padding the whole vector to fixed sequence length
        outputs = self.process(t1, t2, t1_mask_labels, t2_mask_labels)
        outputs['is_next'] = torch.tensor(isNext)

        return outputs

    def get_sentences(self):
        if self.lang == 'cn':
            with open("./corpus_chinese.txt", 'r', encoding='utf-8') as f:
                sentences = f.readlines()

                self.lines = [re.split('。|！|\!|\.|？|\?|,|，', sentence)
                              for sentence in (sentences)]
            # delete the spaces, such as [a, b, c, ""] -> [a, b, c]
            for i in range(len(self.lines)):
                self.lines[i] = [sep for sep in self.lines[i] if sep.strip() != '']

            self.corpus_lines = len(self.lines)

        if self.lang == 'en':
            with open(self.corpus_path, "r", encoding=self.encoding) as f:
                self.lines = [line[:-1].split("\t") for line in f]
                self.corpus_lines = len(self.lines)

        print(f"data lines are: \n {self.lines}")
        print(f"The number of data lines is: \n {self.corpus_lines}")

    def get_two_sentence(self, index):
        t1, t2 = self.lines[index]
        if random.random() > 0.5:
            return t1, t2,         else:
            t2 = self.get_random_sentence(index)
            return t1, t2,
    def get_random_sentence(self, index):
        random_index = random.randrange(self.corpus_lines)
        # cannot select the sentence in the t1's line
        while (random_index == index):
            random_index = random.randrange(self.corpus_lines)

        t2 = self.lines[random_index][1]
        return t
    def mask_word(self, sentence: str):
        if self.lang == 'en': tokens = sentence.split()
        if self.lang == 'cn': tokens = list(sentence)

        mask_labels = []

        for i, token in enumerate(tokens):
            prob = generate_random()

            if prob < 0.15:

                new_prob = generate_random()

                if new_prob < 0.8:
                    tokens[i] = self.tokenizer.mask_token

                elif new_prob < 0.9:
                    tokens[i] = self.id2word[random.randrange(len(self.vocab))]

                else:
                    pass

                mask_labels.append(tokens[i])

            else:
                mask_labels.append(self.tokenizer.pad_token)

        return tokens, mask_labels

    def process(self, t1, t2, mask_labels_1, mask_labels_2):

        data = self.tokenizer.encode_plus(t1, t2, add_special_tokens=True)
        PAD = self.tokenizer.pad_token
        label = [PAD] + mask_labels_1 + [PAD] + mask_labels_2 + [PAD]

        data_ = {k: v for k, v in data.items()}
        label_ = self.tokenizer.encode(label)

        segment_labels = data_['token_type_ids']
        input_ids = data_['input_ids']
        mask_labels = label_

        assert (len(segment_labels) == len(input_ids) == len(mask_labels))

        if self.seq_len:
            # if the setence is longer than sequence length, truncate it
            paddings = [self.tokenizer.pad_token_id for _ in range(self.seq_len)]
            input_ids = (input_ids + paddings)[:self.seq_len]
            segment_labels = (segment_labels + paddings)[:self.seq_len]
            mask_labels = (mask_labels + paddings)[:self.seq_len]

            # if it is shorter than the sequence length, pad it
            paddings = [self.tokenizer.pad_token_id for _ in range(self.seq_len - len(input_ids))]
            input_ids.extend(paddings)
            segment_labels.extend(paddings)
            mask_labels.extend(paddings)

        output = {'input_ids': input_ids,
                  'mask_labels': mask_labels,
                  'segment_labels': segment_labels}

        return {k: torch.tensor(v) for k, v in output.items()}


if __name__ == '__main__':
    corpus_path = "./corpus.txt"
    model_name = '../bert_pretrain_base/'

    config = BertConfig.from_pretrained(model_name)
    tokenizer = BertTokenizer.from_pretrained(model_name)
    model = BertModel.from_pretrained(model_name)

    dataset = BERTDataset(corpus_path=corpus_path
                          , seq_len=None
                          , tokenizer=tokenizer
                          , lang='cn')

    print(dataset[0])

因爲我使用了 huggingface 平台提供的 bert 預訓練模型和他附帶的 tokenizer，因此大家只需要去下載相關的文件使用就行

