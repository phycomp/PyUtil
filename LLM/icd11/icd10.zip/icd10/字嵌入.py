from torch.nn import Embedding, Module, Linear, ModuleList, Tanh, Dropout, Softmax, Parameter, init as trchInit
from torch import norm as trchNorm

def 字嵌入(字數, 維度=100, ε=1e-8): #epsilon
  字向量 = Embedding(字數, 維度, padding_idx=0)
  trchInit.orthogonal_(字向量.weight) # embedding矩陣初始化
  字向量.weight.data=字向量.weight.data.div(trchNorm(字向量.weight, p=2, dim=1, keepdim=True).data+ε)
  #trchInit.orthogonal_(詞嵌入.weight)
  #詞嵌入.weight.data=self.詞嵌入.weight.data.div(trchNorm(self.詞嵌入.weight, p=2, dim=1, keepdim=True).data+self.ε) #embedding矩陣進行歸一化
  return 字向量

