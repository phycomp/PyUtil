def 訓練(epoch, data_loader, train=True, df_name="df_log.pickle"): # 初始化一個pandas DataFrame進行訓練日志的存儲
    #疊代df_path = self.config["state_dict_dir"] + "/" + df_name
    #if not os.path.isfile(df_path):
    #    df = pd.DataFrame(columns=["epoch", "train_loss", "train_auc", "test_loss", "test_auc" ])
    #    df.to_pickle(df_path)
    #    print("log DataFrame created!")

    # 進度條顯示
    #str_code = "train" if train else "test"
    #data_iter = tqdm.tqdm(enumerate(data_loader), desc="EP_%s:%d" % (str_code, epoch), total=len(data_loader), bar_format="{l_bar}{r_bar}")
    total_loss = 0
    # 存儲所有預測的結果和標記, 用來計算auc
    all_predictions, all_labels = [], []

    for i, data in data_iter:
        data = self.padding(data) # padding
        data = {key: value.to(self.device) for key, value in data.items()}
        # 根據padding之後文本序列的長度截取相應長度的位置編碼,
        # 并發送到計算設備 將數據發送到計算設備
        positional_enc = self.positional_enc[:, :data["text_input"].size()[-1], :].to(self.device)

        # 正向傳播 得到預測結果和loss
        predictions, loss = self.bert_model.forward(text_input=data["text_input"], positional_enc=positional_enc, labels=data["label"])
        # 提取預測的結果和標記, 并存到all_predictions, all_labels裏 用來計算auc
        predictions = predictions.detach().cpu().numpy().reshape(-1).tolist()
        labels = data["label"].cpu().numpy().reshape(-1).tolist()
        all_predictions.extend(predictions)
        all_labels.extend(labels)
        # 計算auc
        fpr, tpr, 閥s = metrics.roc_curve(y_true=all_labels, y_score=all_predictions)
        auc = metrics.auc(fpr, tpr)

        # 反向傳播
        if train:
            self.optimizer.zero_grad() # 清空之前的梯度
            loss.backward()            # 反向傳播, 獲取新的梯度
            self.optimizer.step()      # 用獲取的梯度更新模型參數

        total_loss += loss.item() # 爲計算當前epoch的平均loss

        if train:
            log_dic = { "epoch": epoch, "train_loss": total_loss/(i+1), "train_auc": auc, "test_loss":0, "test_auc":0 }

        else:
            log_dic = { "epoch": epoch, "train_loss": 0, "train_auc": 0, "test_loss": total_loss/(i+1), "test_auc": auc }

        if not i % 10:
            data_iter.write(str({k: v for k, v in log_dic.items() if v != 0}))

    閥_ = find_best_threshold(all_predictions, all_labels)
    print(str_code + " best 閥: " + str(閥_))

    # 將當前epoch的情況記錄到DataFrame裏
    if train:
        df = pd.read_pickle(df_path)
        df = df.append([log_dic])
        df.reset_index(inplace=True, drop=True)
        df.to_pickle(df_path)
    else:
        log_dic = {k: v for k, v in log_dic.items() if v != 0 and k != "epoch"}
        df = pd.read_pickle(df_path)
        df.reset_index(inplace=True, drop=True)
        for k, v in log_dic.items():
            df.at[epoch, k] = v
        df.to_pickle(df_path)
        return auc # 返回auc, 作爲early stop的衡量標準
