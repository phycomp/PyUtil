from torch.nn import Module, Linear, Dropout
from torch import FloatTensor, sqrt as trchSQRT, softmax, matmul as trchMatmul
class 多頭注意力(Module):
    # n_heads：多頭注意力的數量
    # hid_dim：每個詞輸出的向量維度
    def __init__(self, 隱向量, 頭數, dropout):
        super(多頭注意力, self).__init__()
        self.隱向量 = 隱向量
        self.頭數 = 頭數

        # 強制 隱向量 必須整除 h
        assert 隱向量 % 頭數 == 0
        self.q = Linear(隱向量, 隱向量)   #定義 Q 矩陣
        self.k = Linear(隱向量, 隱向量)   #定義 K 矩陣
        self.v = Linear(隱向量, 隱向量)   #定義 V 矩陣
        self.fc = Linear(隱向量, 隱向量)
        self.丟棄 = Dropout(dropout)
        # 縮放
        self.scale = trchSQRT(FloatTensor([隱向量 // 頭數]))

    def forward(self, query, key, value, mask=None):
        # K: [64,10,300], batch_size 為 64，有 12 個詞，每個詞的 Query 向量是 300 維
        # V: [64,10,300], batch_size 為 64，有 10 個詞，每個詞的 Query 向量是 300 維
        # Q: [64,12,300], batch_size 為 64，有 10 個詞，每個詞的 Query 向量是 300 維
        bsz = query.shape[0]
        Q = self.q(query)
        K = self.k(key)
        V = self.v(value)
        # 這裏把 K Q V 矩陣拆分為多組注意力，變成了一個 4 維的矩陣
        # 最後一維就是是用 self.隱向量 // self.頭數 來得到的，表示每組注意力的向量長度, 每個 head 的向量長度是：300/6=50
        # 64 表示 batch size，6 表示有 6組注意力，10 表示有 10 詞，50 表示每組注意力的詞的向量長度
        # K: [64,10,300] 拆分多組注意力 -> [64,10,6,50] 轉置得到 -> [64,6,10,50]
        # V: [64,10,300] 拆分多組注意力 -> [64,10,6,50] 轉置得到 -> [64,6,10,50]
        # Q: [64,12,300] 拆分多組注意力 -> [64,12,6,50] 轉置得到 -> [64,6,12,50]
        # 轉置是為了把注意力的數量 6 放到前面，把 10 和 50 放到後面，方便下面計算
        Q = Q.view(bsz, -1, self.頭數, self.隱向量 // self.頭數).permute(0, 2, 1, 3)
        K = K.view(bsz, -1, self.頭數, self.隱向量 // self.頭數).permute(0, 2, 1, 3)
        V = V.view(bsz, -1, self.頭數, self.隱向量 // self.頭數).permute(0, 2, 1, 3)

        # 第 1 步：Q 乘以 K的轉置，除以scale
        # [64,6,12,50] * [64,6,50,10] = [64,6,12,10]
        # attention：[64,6,12,10]
        attention = trchMatmul(Q, K.permute(0, 1, 3, 2)) / self.scale
        # 把 mask 不為空，那麼就把 mask 為 0 的位置的 attention 分數設置為 -1e10
        if mask is not None:
            attention = attention.masked_fill(mask == 0, -1e10)

        # 第 2 步：計算上一步結果的 softmax，再經過 dropout，得到 attention。
        # 注意，這裏是對最後一維做 softmax，也就是在輸入序列的維度做 softmax
        # attention: [64,6,12,10]
        attention = self.丟棄(softmax(attention, dim=-1))

        # 第三步，attention結果與V相乘，得到多頭注意力的結果
        # [64,6,12,10] * [64,6,10,50] = [64,6,12,50]
        # x: [64,6,12,50]
        x = trchMatmul(attention, V)

        # 因為 query 有 12 個詞，所以把 12 放到前面，把 5 和 60 放到後面，方便下面拼接多組的結果
        # x: [64,6,12,50] 轉置-> [64,12,6,50]
        x = x.permute(0, 2, 1, 3).contiguous()
        # 這裏的矩陣轉換就是：把多組注意力的結果拼接起來
        # 最終結果就是 [64,12,300]
        # x: [64,12,6,50] -> [64,12,300]
        x = x.view(bsz, -1, self.頭數 * (self.隱向量 // self.頭數))
        x = self.fc(x)
        return x


from torch import rand as trchRand
# batch_size 為 64，有 12 個詞，每個詞的 Query 向量是 300 維
query = trchRand(64, 12, 300)
# batch_size 為 64，有 12 個詞，每個詞的 Key 向量是 300 維
key = trchRand(64, 10, 300)
# batch_size 為 64，有 10 個詞，每個詞的 Value 向量是 300 維
value = trchRand(64, 10, 300)
attention = 多頭注意力(隱向量=300, 頭數=6, dropout=.1)  #MultiheadAttention
output = attention(query, key, value)
## output: torch.Size([64, 12, 300])
print(output.shape)

