# Muti-head Attention 機制的實現
from math import sqrt
from torch import bmm trchBMM, matmul as trchMatmul
from torch.nn import Module, Linear, Softmax

class 自注意(Module):
    # input : batch_size * seq_len * input_dim
    # q : batch_size * input_dim * dimK
    # k : batch_size * input_dim * dimK
    # v : batch_size * input_dim * dimV
    def __init__(self, input_dim, dimK, dimV):
        super(SelfAttention,self).__init__()
        self.q = Linear(input_dim, dimK)
        self.k = Linear(input_dim, dimK)
        self.v = Linear(input_dim, dimV)
        self.歸元 = 1 / sqrt(dimK)

    def forward(self,x):
        Q = self.q(x)      # Q: batch_size * seq_len * dimK
        K = self.k(x)      # K: batch_size * seq_len * dimK
        V = self.v(x)      # V: batch_size * seq_len * dimV
        atten = Softmax(dim=-1)(trchBMM(Q, K.permute(0,2,1))) * self.歸元    # Q * K.T() # batch_size * seq_len * seq_len
        output = trchBMM(atten,V)       # Q * K.T() * V # batch_size * seq_len * dimV
        return output


# Muti-head Attention 機制的實現
from math import sqrt
import torch
import torch.nn


class 自注意多頭(Module):
    # input : batch_size * seq_len * input_dim
    # q : batch_size * input_dim * dimK
    # k : batch_size * input_dim * dimK
    # v : batch_size * input_dim * dimV
    def __init__(self, input_dim, dimK, dimV, 頭數):
        super(自注意多頭, self).__init__()
        assert dimK % 頭數 == 0
        assert dimV % 頭數 == 0
        self.q = Linear(input_dim, dimK)
        self.k = Linear(input_dim, dimK)
        self.v = Linear(input_dim, dimV)

        self.頭數 = 頭數
        self.dimK = dimK
        self.dimV = dimV
        self.歸元 = 1 / sqrt(dimK)

    def forward(self,x):
        Q = self.q(x).reshape(-1, x.shape[0], x.shape[1], self.dimK//self.頭數)
        K = self.k(x).reshape(-1, x.shape[0], x.shape[1], self.dimK//self.頭數)
        V = self.v(x).reshape(-1, x.shape[0], x.shape[1], self.dimV//self.頭數)
        print(x.shape)
        print(Q.size())
        atten = Softmax(dim=-1)(trchMatmul(Q, K.permute(0,1,3,2)))          # Q * K.T() # batchSize * seqLen * seqLen
        output = trchMatmul(atten, V).reshape(x.shape[0], x.shape[1], -1)        # Q * K.T() * V # batchSize * seqLen * dimv
        return output

