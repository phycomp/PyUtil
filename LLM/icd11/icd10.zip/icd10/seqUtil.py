from torchtext.vocab import build_vocab_from_iterator
from torch.nn import Module, Embedding, EmbeddingBag, Linear
#from torchtext import vocab as trchVocab
from torchtext.vocab import GloVe, vocab as trchVocab
from torchtext import data
#from nltk.tokenize import word_tokenize
from io import open as IOpen
from torchtext.vocab import build_vocab_from_iterator

from torch import cat as trchCat
from torch.nn.utils.rnn import pad_sequence as trchPadseq

def build_dict(self, sentences, max_words=50000): #傳入load_data構造的分詞後的列表數據 構建詞典(key爲單詞，value爲id值)
    字計 = Counter() # 對數據中所有單詞進行計數
    for sentence in sentences:
        for sent in sentence:
            字計[sent] += 1
    詞典 = 字計.most_common(max_words) #只保留最高頻的前max_words數的單詞構建詞典 并添加上UNK和PAD兩個單詞 對應id已經初始化設置過
    總詞數=len(詞典) + 2    #統計詞典的總詞數
    詞表={word[0]: ndx+2 for ndx, word in enumerate(詞典)}
    詞表['UNK']=UNK
    詞表['PAD']=PAD
    序表={v: k for k, v in 詞表.items()} #再構建一個反向的詞典 供id轉單詞使用
    return 詞表, 總詞數, 序表

def txtInputLabel(output_dic_lis):
    """動態padding, 以當前mini batch內最大的句長進行補齊長度"""
    text_input = [i["text_input"] for i in output_dic_lis]
    text_input = torchRNN.trchPadseq(text_input, batch_first=True)
    label = trchCat([i["label"] for i in output_dic_lis])
    return {"text_input": text_input, "label": label}

def yieldTKN(file_path):
    with IOpen(file_path, encoding = 'utf-8') as fin:
        for line in fin:
            yield line.strip().split()

from numpy import array as npArray, concatenate as npConcatenate
def 補齊(X, padding=0): #對一個batch批次(以單詞id表示)的數據進行padding填充對齊長度
    maxSeqsz = max([len(x) for x in X]) # 計算該批次數據各條數據句子長度 獲取該批次數據最大句子長度
    # 對X中各條數據x進行遍歷，如果長度短于該批次數據最大長度ML，則以padding id填充缺失長度ML-len(x) （注意這裏默認padding id是0，相當于是拿<UNK>來做了padding）
    return npArray([
        npConcatenate([x, [padding] * (maxSeqsz - len(x))]) if len(x) < ML else x for x in X ])

def nltkToken():
  from nltk import ne_chunk
  from nltk.chunk import conlltags2tree, tree2conlltags
  neTree = ne_chunk(pos_tag(word_tokenize(ex)))
  iobTagged = tree2conlltags(cs)
  return neTree, iobTagged
  stCode(ne_tree, iob_tagged)

def rtrvMaxsize(cntxt):
  maxSize=max([len(text) for text in cntxt.split()])
  return maxSize
