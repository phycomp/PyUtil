from torch import cat as trchCat
from torch.nn.utils.rnn import pad_sequence as trchPadseq

def 補齊(output_dic_lis):
    """動態padding, 以當前mini batch內最大的句長進行補齊長度"""
    text_input = [i["text_input"] for i in output_dic_lis]
    text_input = torchRNN.trchPadseq(text_input, batch_first=True)
    label = trchCat([i["label"] for i in output_dic_lis])
    return {"text_input": text_input, "label": label}
