import torch
import torch.nn as nn
from transformers import BertTokenizer,BertModel, BertConfig
from Dataset import BERTDataset
from torch.nn import Module, Dropout, Embedding
"""
BERT 的 Embedding BERT 和 Transformer 在 Embedding 的時候有兩個區別 由于BERT采用了兩個句子拼接後作爲一個 sample 的方法 我們需要在輸入的時候 嵌入當前的詞屬于第一句話還是第二句話這個信息 因此我們需要segment embedding
BERT 也需要編碼位置信息 因爲他在這一點繼承了 Transformer 的 self attention 操作 但是BERT的位置信息 既可以和 Transformer 一樣采用位置編碼（Positional encoding）的方法用固定的sin, cos函數來實現 也可以采用將位置信息輸入 embedding 層讓他自己學習出更好的位置表示"""

class 位置嵌入(Embedding): #位置嵌入 PositionalEmbedding
    def __init__(self, d_model, max_len=512):
        super(位置嵌入, self).__init__(max_len, d_model, padding_idx=0)

class 區段嵌入(Embedding):   #SegmentEmbedding 區段嵌入
    def __init__(self, d_model, segement_num=2):
        super(區段嵌入, self).__init__(segement_num, d_model, padding_idx=0)

class 象嵌入(Embedding):    #TokenEmbedding   象嵌入
    def __init__(self, d_model, vocab_size,):
        super(象嵌入, self).__init__(vocab_size, d_model, padding_idx=0)

class 模型嵌入(Module):   #BERTEmbedding
    def __init__(self, 文長, 維度, drop_rate=.1):  #維度d_model 文長vocab_size
        super(模型嵌入, self).__init__()
        # super(模型嵌入, self).__init__()
        self.象嵌=象嵌入(維度, 文長) #象嵌token_embedding   TokenEmbedding
        self.位嵌=位置嵌入(維度)   #position_embedding PositionalEmbedding
        self.區嵌=區段嵌入(維度)    #區嵌segment_embedding SegmentEmbedding
        self.dropout = Dropout(drop_rate)

    def forward(self, sequence, segment_labels, position_ids):
        x = self.象嵌(sequence) + self.區嵌(segment_labels) + self.位嵌(position_ids)  #象嵌token_embedding  位嵌position_embedding 區嵌segment_embedding

        return self.dropout(x)


if __name__ == '__main__':
    model_name = '../bert_pretrain_base/'
    維度= 768  #維度d_model vocab_size 文長
    config = BertConfig.from_pretrained(model_name)
    tokenizer = BertTokenizer.from_pretrained(model_name)
    model = BertModel.from_pretrained(model_name)
    vghMDL=模型嵌入(vocab_size=config.vocab_size, d_model=維度) #d_mode
    dataset = BERTDataset(corpus_path="./corpus_chinese.txt", tokenizer=tokenizer, seq_len=20)
    sample = dataset[0]
    序表= sample['input_ids']   #序表 input_ids
    區段= sample['segment_labels'] #segment_labels
    # 是固定的 [0, ..., seq_len-1]
    位序=torch.tensor([i for i in range(len(input_ids))])     #tensor([0, 1, 2, 3, 4, 5, 6, 7])   位置position_ids
    print(sample)
    x = bert_embedding(序表, 區段, 位序) #序表input_ids 區段segment_labels 位置position_ids
    print(x)
