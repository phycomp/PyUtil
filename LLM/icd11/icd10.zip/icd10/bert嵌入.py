from torch.nn import Embedding, Module, Linear, ModuleList, Tanh, Dropout, Softmax, Parameter, init as trchInit
from apex.normalization.fused_layer_norm import FusedLayerNorm as BertLayerNorm
from torch import matmul as trchMatmul, norm as trchNorm
from math import sqrt as SQRT   #as trchSQRT

class BertEmbeddings(Module):
    """LayerNorm層, 見Transformer(一), 講編碼器(encoder)的第1部分"""
    """Construct the embeddings from word, position and token_type embeddings.
    """
    def __init__(self, config):
        super(BertEmbeddings, self).__init__()
        self.字嵌入 = Embedding(config.字數, config.嵌向量, padding_idx=0)
        self.詞嵌入 = Embedding(config.字數, config.嵌向量)
        trchInit.orthogonal_(self.字嵌入.weight) # embedding矩陣初始化
        trchInit.orthogonal_(self.詞嵌入.weight)
        self.ε = 1e-8    #epsilon
        self.字嵌入.weight.data =  self.字嵌入.weight.data.div(trchNorm(self.字嵌入.weight, p=2, dim=1, keepdim=True).data + self.ε)
        self.詞嵌入.weight.data = self.詞嵌入.weight.data.div(trchNorm(self.詞嵌入.weight, p=2, dim=1, keepdim=True).data + self.ε) # embedding矩陣進行歸一化
        # self.LayerNorm is not snake-cased to stick with TensorFlow model variable name and be able to load any TensorFlow checkpoint file
        self.LayerNorm = BertLayerNorm(config.嵌向量, eps=1e-12)
        self.dropout = Dropout(config.隱藏丟棄)

    def forward(self, input_ids, 位置嵌入, token_type_ids=None):    #positional_enc位置嵌入
        """
        :param input_ids: 維度 [batch_size, sequence_length]
        :param positional_enc: 位置編碼 [sequence_length, embedding_dimension]
        :param token_type_ids: BERT訓練的時候, 第一句是0, 第二句是1
        :return: 維度 [束量batch_size, 詞長sequence_length, 嵌向量embedding_dimension]
        """
        字嵌入 = self.字嵌入(input_ids)     # 字向量查表

        if not token_type_ids:  # is None
            token_type_ids = torch.zeros_like(input_ids)
        詞嵌入 = self.詞嵌入(token_type_ids)
        總嵌入 = 字嵌入+位置嵌入+詞嵌入#words_embeddings + positional_enc + token_type_embeddings
        # embeddings: [batch_size, sequence_length, embedding_dimension]
        總嵌入 = self.LayerNorm(embeddings)
        總嵌入 = self.dropout(embeddings)
        return 總嵌入


