file_path = 'StructureDefinition-AllergyIntolerance-twcore.html'
with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Parse the HTML content
tree = html.fromstring(content)

# XPath to find elements with mustSupport (S symbol in the HTML file)
must_support_elements = tree.xpath('//span[@title="This element must be supported"]/ancestor::tr')

# Iterate through the mustSupport elements and extract ID and Path
for elem in must_support_elements:
    # Extract the ID and Path from the corresponding columns in the table row (tr)
    element_id = elem.xpath('.//td[1]/a/text()')
    element_path = elem.xpath('.//td[1]/a/@href')

    # Print the ID and Path
    print(f"ID: {element_id[0] if element_id else 'N/A'}")
    print(f"Path: {element_path[0] if element_path else 'N/A'}\n")
