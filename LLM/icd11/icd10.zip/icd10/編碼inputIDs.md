inputIDs 在BERT模型及其衍生體中 輸入文本首先經過一個分詞處理流程 其中文本被細分為單詞或子單詞（subwords） 每個分詞隨後映射到一個唯一的整數標識符 這些標識符組成了所謂的inputIDs數組 其代表文本的數字化形式 為了適應模型處理的需要 inputIDs的長度被規範化為一個固定的值 在這個規範化過程中 長度超出預定值的輸入會被截斷 而短于此長度的輸入則通過添加特定的填充標記（[PAD] 通常對應的整數標識符為0）來補齊 這種處理機制确保了模型輸入的一致性 允許模型批量處理不同長度的文本數據

attention_mask 與inputIDs并行的 attention_mask數組 標識了模型應當"關注"的輸入部分 具體而言 attention_mask對于實際文本內容的位置賦值為1 而對于填充部分則賦值為0 這使得模型能夠區分原始文本 與為了長度規範化 而添加的填充內容 從而僅對有意義的文本部分進行分析 attention_mask 在處理可變長文本輸入時尤其關鍵 因為它直接指導模型聚焦于重要的信息 忽視那些無關緊要的填充部分

綜上所述 inputIDs為文本提供了一種高效的數字化表示 而attention_mask則确保模型能夠在處理這些數字化信息時 有效地識別并專注于實質內容 排除無關的填充影響 這兩個參數共同構成了模型處理文本信息的基礎 對于保證模型的性能和分析精度至關重要

舉例假設我們有一句話 “Hello, world!” 我們想要將這句話輸入到BERT模型中 首先 我們需要通過分詞器將這句話轉換成模型能理解的數字表示 假設分詞器將“Hello,”分為[7592] 將“world”分為[2088] 并且特殊標記[CLS]（表示輸入開始）的ID為[101] [SEP]（表示輸入結束）的ID為[102] 以及[PAD]（用于填充的特殊標記）的ID為[0] 
原文鏈接 https://blog.csdn.net/python_plus/article/details/136194789
示例輸入：“Hello, world!”

分詞和轉換爲inputIDs:
分詞後的結果（包括特殊標記）：[CLS] Hello, world [SEP]
對應的inputIDs（數字表示）：[101, 7592, 2088, 102]

填充至固定長度:
假設我們設定輸入長度爲10，這意味著inputIDs需要被擴展到長度爲10。這是通過添加[PAD]標記來實現的。
擴展後的inputIDs：[101, 7592, 2088, 102, 0, 0, 0, 0, 0, 0]
在這個例子中，我們添加了6個[PAD]以達到長度爲10的要求。

生成attention_mask:
對于實際的文本和特殊標記（[CLS]和[SEP]），attention_mask的值爲1。
對于[PAD]填充，attention_mask的值爲0。

因此，對于上述擴展後的inputIDs，attention_mask爲：[1, 1, 1, 1, 0, 0, 0, 0, 0, 0]

tokenizer = RobertaTokenizer.from_pretrained('microsoft/codebert-base-mlm')
model = RobertaForMaskedLM.from_pretrained('microsoft/codebert-base-mlm')
embedding_output = self.embeddings(
        input_ids=inputIDs, position_ids=position_ids,
        token_type_ids=token_type_ids, inputs_embeds=inputs_embeds
        )

編碼outputs = self.encoder(embedding_output,
attention_mask=extended_attention_mask,
head_mask=head_mask,
encoder_hidden_states=encoder_hidden_states,
encoder_attention_mask=encoder_extended_attention_mask,
output_attentions=output_attentions,
output_hidden_states=output_hidden_states,
return_dict=return_dict,
        )
inputIDs = tokenizer.encode("I love China!", add_special_tokens=False)
# print:[100, 657, 436, 328]

# 可以使用 如下轉回原來的詞
tokens= tokenizer.convert_ids_to_tokens(inputIDs)
# print: ['I', 'Ġlove', 'ĠChina', '!']. Note： Ġ 代碼該字符的前面是一個空格
inputIDs = tokenizer(["I love China","I love my family and I enjoy the time with my family"], padding=True)

# {
#'inputIDs': [[0, 100, 657, 436, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1], [0, 100, 657, 127, 284, 8, 38, 2254, 5, 86, 19, 127, 284, 2]],
#'attention_mask': [[1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]
#}
Segment token indices to indicate first and second portions of the inputs.

Indices are selected in ``[0, 1]``:
            - 0 corresponds to a `sentence A` token,
            - 1 corresponds to a `sentence B` token.
