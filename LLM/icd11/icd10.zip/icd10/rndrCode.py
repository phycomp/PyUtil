from streamlit_extras.stylable_container import stylable_container
from streamlit import code as stCode

def rndrCode(cntxtMsg):
  with stylable_container("codeblock", """code{white-space: pre-wrap !important;}"""): stCode(cntxtMsg) #cntnr.write([dsetDF])
