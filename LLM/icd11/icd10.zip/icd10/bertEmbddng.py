try: from apex.normalization.fused_layer_norm import FusedLayerNorm as BertLayerNorm
except ImportError:
  logger.info("Better speed can be achieved with apex installed from https://www.github.com/nvidia/apex .")
from torch.nn import Module
"""
The model is composed of the nn.EmbeddingBag layer plus a linear layer for the classification purpose. nn.EmbeddingBag with the default mode of “mean” computes the mean value of a “bag” of embeddings. Although the text entries here have different lengths, nn.EmbeddingBag module requires no padding here since the text lengths are saved in offsets.

Additionally, since nn.EmbeddingBag accumulates the average across the embeddings on the fly, nn.EmbeddingBag can enhance the performance and memory efficiency to process a sequence of tensors.
"""


class BertEmbeddings(Module):
    """Construct the embeddings from word, position and token_type embeddings.
    """
    def __init__(self, config):
        super(BertEmbeddings, self).__init__()
        self.字嵌入 = nn.Embedding(config.vocab_size, config.hidden_size, padding_idx=0)
        # self.position_embeddings = nn.Embedding(config.max_position_embeddings, config.hidden_size)
        self.象嵌入 = nn.Embedding(config.type_vocab_size, config.hidden_size)
        nn.init.orthogonal_(self.字嵌入.weight)
        # nn.init.orthogonal_(self.position_embeddings.weight)
        nn.init.orthogonal_(self.象嵌入.weight)
        epsilon = 1e-8
        self.字嵌入.weight.data = self.字嵌入.weight.data.div(torch.norm(self.字嵌入.weight, p=2, dim=1, keepdim=True).data+epsilon)
        self.象嵌入.weight.data = self.象嵌入.weight.data.div(torch.norm(self.象嵌入.weight, p=2, dim=1, keepdim=True).data+epsilon)
        # freeze embedding parameters
        # self.字嵌入.weight.requires_grad = False
        # self.象嵌入.weight.requires_grad = False

        # self.LayerNorm is not snake-cased to stick with TensorFlow model variable name and be able to load any TensorFlow checkpoint file
        self.LayerNorm = BertLayerNorm(config.hidden_size, eps=1e-12)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)

    def forward(self, input_ids, positional_enc, token_type_ids=None, ner_probs=None, ensemble_mode=False, num_tags=None):
        """
        :param input_ids:
        :param positional_enc:
        :param token_type_ids:
        :param ner_probs: 是沒有經過argmax的維特比輸出
        :param nre_mode: 訓練nre模型的時候設爲True
        :return:
        """

        字嵌入 = self.字嵌入(input_ids)

        if ensemble_mode:
            象嵌入 = self.象嵌入.weight[2: 2 + num_tags]
            # [num_tags, embed_dim]
            # ner_probs [batch, seq_len, num_tags]
            象嵌入 = torch.matmul(ner_probs, 象嵌入)
        else:
            # if token_type_ids is None:
            #     token_type_ids = torch.zeros_like(input_ids)
            象嵌入 = self.象嵌入(token_type_ids)

        嵌入 = 字嵌入 + positional_enc + 象嵌入
        嵌入 = self.LayerNorm(嵌入)
        嵌入 = self.dropout(嵌入)
        return 嵌入
