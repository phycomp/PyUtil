from torch.nn.functional import cross_entropy as 交叉熵

def train(model, epochs, train_data_loader, val_data_loader, lr = LR, device = "cpu", log_steps = 250):
    losses = []
    optimizer = torch.optim.Adam(model.parameters(), lr = lr)
    steps = 0
    start_logging_period = time.time()
    model.train()

    for epoch in range(epochs):
        start_epoch = time.time()
        for x, y in tqdm.tqdm(train_data_loader,desc = f"Epoch {epoch}"):
            steps += 1
            optimizer.zero_grad()
            f, _ = model(x.to(device))
            V = f.shape[2]
            f = f.view(-1, V)
            y = y.to(device).flatten()
            損失 = 交叉熵(f, y)
            損失.backward()
            optimizer.step()

            losses.append(損失.item())

            if (0 == (steps % log_steps)):
                time_per_step = (time.time() - start_logging_period) / log_steps
                start_logging_period = time.time()
                print(f"Completed {steps} steps ({time_per_step:.3f} seconds per step), current loss is {loss.item()}")

        elapsed_time = time.time() - start_epoch
        #
        # Do validation
        #
        val_loss = 0
        items_in_val = 0
        if val_data_loader is not None:
            model.eval()
            with torch.no_grad():
                for x, y in val_data_loader:
                    f, _ = model(x.to(device))
                    f = f.view(-1, V)
                    y = y.to(device).flatten()
                    val_loss = val_loss + loss_fn(f, y).item()
                    items_in_val += 1
            val_loss = val_loss / items_in_val
            model.train()
        print(f"Completed epoch {epoch}, validation loss is {val_loss}, duration {elapsed_time} seconds, {steps} done in total")

    return losses
