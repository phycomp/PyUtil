from streamlit import session_state
from stUtil import rndrCode

def showDevice():
  from torch import cuda as trchCuda, device as trchDevice
  cudaAvailable = trchCuda.is_available()     # and with_cuda
  try:
    cudaDevice=session_state['cudaDevice']
  except: session_state['cudaDevice']=cudaDevice = trchDevice("cuda:1" if cudaAvailable else "cpu")
  #DEVICE = trchDevice('cuda' if cudaAvailable else 'cpu')
  rndrCode(['device, deviceCount, deviceName=', cudaDevice, trchCuda.device_count(), trchCuda.get_device_name(0)])
  '''
  #['device, deviceCount, deviceName=', device(type='cuda', index=1), 4, 'NVIDIA GeForce RTX 4090'] torch.cuda.device_count() torch.cuda.device_count()
  cudaAvailable = trchCuda.is_available() # and with_cuda # 判斷是否有可用GPU
  device = trchDevice("cuda:2" if cudaAvailable else "cpu")
  cudaCount=trchCuda.device_count()
  stCode(['device, count=', device, cudaCount])
  '''
