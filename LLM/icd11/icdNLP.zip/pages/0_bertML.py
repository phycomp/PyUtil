#from keras.layers.experimental.preprocessing import TextVectorization
#from keras.layers import Embedding, Dense, Dropout, Input, LSTM, GlobalMaxPool1D
#from keras.models import Sequential
#from keras.initializers import Constant
from streamlit import write as stWrite, sidebar, session_state, code as stCode, info as stInfo
from transformers import AutoTokenizer, AutoModel, AutoConfig
from transformers import BertConfig, TFBertModel
#import tensorflow as tf

MENU=['bertML', 'medicalaiClinical'] #EMBEDDING   transformer 'AutoTokenizer', 'pretrain', 'keras', 'fastText', 'optimizer','BILUO', 'vocab', 'word2vec'
menu=sidebar.radio('MENU', MENU)    #, index=-1
lngMDL='bert-base-uncased'  #lngMDL='bert-base-uncased'
if menu==MENU[0]:
  #stWrite(list(doc.ents)) #要得出ents
  vghTknzr = AutoTokenizer.from_pretrained(lngMDL, use_fast=True)
  #vghMDL=AutoModel.from_config(vghCnfg, use_fast=True)
  vghCnfg=AutoConfig.from_pretrained(lngMDL) #distilroberta-base
  #config=AutoConfig.from_pretrained(model_args.model_name_or_path, cache_dir=model_args.cache_dir)
  #tokenizer=AutoTokenizer.from_pretrained(model_args.tokenizer_name, cache_dir=model_args.cache_dir)
  #vghCnfg=BertConfig.from_pretrained(lngMDL)  #"bert-base-uncased" , foo=False , output_attentions=True
    #train_dataset=get_dataset(data_args, tokenizer=tokenizer, cache_dir=model_args.cache_dir) if training_args.do_train else None
    #eval_dataset=get_dataset(data_args, tokenizer=tokenizer, evaluate=True, cache_dir=model_args.cache_dir)
    #trainer=Trainer(model=model, args=training_args, data_collator=data_collator, train_dataset=train_dataset, eval_dataset=eval_dataset, prediction_loss_only=True)
  #model = AutoModel.from_config(vghCnfg)
  #vghMDL=AutoModel.from_pretrained()
  vghMDL = AutoModel.from_pretrained(lngMDL)
  stCode([vghTknzr, vghMDL])
  #model = AutoModelForMaskedLM.from_config(config)
  #3vghMDL = GPT2LMHeadModel(config)
  #vghCnfg = AutoConfig.from_pretrained('bert-base-uncased')
elif menu==MENU[1]:
  #stWrite(list(doc.sents))
  #lngMDL='medicalaiClinical'
  from transformers import AutoTokenizer
  #tokenizer = AutoTokenizer.from_pretrained(lngMDL, use_fast=True)
  vghTknzr = AutoTokenizer.from_pretrained(lngMDL)    #"distilbert-base-uncased"
  #tokenizer = AutoTokenizer.from_pretrained('./test/bert_saved_model/')
  vhgCnfg = BertConfig.from_pretrained('bert-base-uncased')    # Download configuration from S3 and cache.
  vghMDL = AutoModel.from_config(vghCnfg)  # E.g. model was saved using `save_pretrained('./test/saved_model/')`
