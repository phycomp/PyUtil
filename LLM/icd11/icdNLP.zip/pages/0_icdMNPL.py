from pandas import DataFrame, read_csv
from streamlit import write as stWrite, sidebar, session_state, code as stCode, info as stInfo
from st_aggrid import AgGrid, DataReturnMode, GridUpdateMode, GridOptionsBuilder, JsCode

MENUs=['PCS200', 'ICD200']
outCLMN={'PCS200':'OUTCOME', 'ICD200':'DISC_NOTE' }
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
def rtrvDset(dfDSET, clmnOUT):
  from grdOpt import mkGrid
  grdOpt=mkGrid(dfDSET)
  with sidebar:
    agValue = AgGrid(dfDSET, gridOptions=grdOpt, allow_unsafe_jscode=True, theme="balham", reload_data=False, update_mode=GridUpdateMode.SELECTION_CHANGED)
  #ValueError: ALPINE is not valid. Available options: {'STREAMLIT': <AgGridTheme.STREAMLIT: 'streamlit'>, 'ALPINE': <AgGridTheme.ALPINE: 'alpine'>, 'BALHAM': <AgGridTheme.BALHAM: 'balham'>, 'MATERIAL': <AgGridTheme.MATERIAL: 'material'>}
  #selected_rows = agValue['selected_rows']

  #stCode([agValue.selected_rows])
    if agValue.selected_rows:
      rowNDX=agValue.selected_rows[0]['_selectedRowNodeInfo']['nodeRowIndex']#[agValue.selected_rows[0]['outcome']][0]
      dsetDF=session_state['dsetDF']=agValue.selected_rows[0][clmnOUT]  #=session_state['rowNDX']
      return dsetDF
menu = sidebar.radio('Output', MENUs, index=0)
if menu==MENUs[0]:
  try:
    pcsCSV=session_state['pcsCSV']
  except:
    session_state['pcsCSV']=pcsCSV=read_csv('PCS200.csv')
  clmnOUT=outCLMN[menu]
  dsetDF=rtrvDset(pcsCSV, clmnOUT)
  stCode(['dsetDF', dsetDF])
  #stWrite(list(doc.ents)) #要得出ents
  #trainData=session_state['trainData']
  #stInfo([trainData])
elif menu==MENUs[1]:
  try:
    icdCSV=session_state['icdCSV']
  except:
    session_state['icdCSV']=icdCSV=read_csv('ICD200.csv')
  clmnOUT=outCLMN[menu]
  dsetDF=rtrvDset(icdCSV, clmnOUT)
  stCode(['dsetDF', dsetDF])
  #trnCSV=read_csv(f'{menu}.csv')
  #stWrite(list(doc.sents))
  #session_state['dfCOPA']=dfCOPA=read_csv('PCS200.csv', sep='\x06')

