import spacy
from streamlit import write as stWrite, sidebar, session_state, code as stCode, info as stInfo
from spacy.lang.en import English
MENUs=['ENT', 'df2ent', 'SENT', 'getNER']   #'tokenizer', 'punct', 'fastText', 'csvEye', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec']#'answerQuestion', 'ansQues2', ] #EMBEDDING
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
menu = sidebar.radio('Output', MENUs, index=0)
def df2ENT(ROW):
  #stCode(ROW.outcome)
  row=ROW.annttInfo
  entRSLT=[]
  for ent in row.split('@'):
    e=ent.split('|')
    startPos, endPos=e[0].split(':')
    entRSLT.append((startPos, endPos, e[-1] ))
    #try: entRSLT.append((int(startPos), int(endPos), e[-1] )) #pos, pthlgy, NER
    #except: stCode(row)    #pass    #.names dir()
  #for ent in entRSLT: ent.map(lambda x:x[0].split(":"))
  #entRSLT= [['23:28', 'Colon', 'Position1'], ['43:49', 'biopsy', 'Procedure'], ['52:67', 'Tubular adenoma', 'Classification'], ['284:299', 'tubular adenoma', 'Classification']]
  #=[('6/6.7cc od, 6/10cc os IOP: 18/14mmHg\n', {'entities': [(0, 8, 'OD'), (10, 19, 'OS'), (25, 32, 'IOP')]}),
  return ROW.outcome, {'entities':entRSLT}  #[()]
  #print('entRSLT=', entRSLT)

def spcyTknzr(sentence):
    vghTkns = parser(sentence)
    vghTkns = [ word.lemma_.lower().strip() if word.lemma_ != "-PRON-" else word.lower_ for word in vghTkns ]
    vghTkns = [ word for word in vghTkns if word not in stpWrds and word not in PUNCT ]
    return vghTkns

if menu==MENUs[0]:
  from streamlit import dataframe
  from pandas import read_csv
  try:
    dfCOPA=session_state['dfCOPA']
  except:   #pass
    session_state['dfCOPA']=dfCOPA=read_csv('/home/josh/NLP/nlpData/bdcrcopa2.csv', sep='\x06')
  dfCOPA
  #dataframe()
  #trnData=session_state['trnData']
  #stInfo([trnData])
elif menu==MENUs[-6]:
  from spacy.lang.en.stop_words import STOP_WORDS
  try: stpWrds=session_state['STOP_WORDS']
  except: session_state['STOP_WORDS']=stpWrds=list(STOP_WORDS)
  try: lngMDL=session_state['lngMDL']
  except:
      session_state['lngMDL']=lngMDL=spacy.blank("en")
      #nlp = spacy.load('en')
  try: PUNCT=session_state['punct']
  except:
      import string
      session_state['punct']=PUNCT=string.punctuation
  try:parser=session_state['parser']
  except:session_state['parser']=parser=English()
  #nlp = spacy.load("en_core_web_sm")
  #train='''Context: 'Architecturally, the school has a Catholic character. Atop the Main Building\'s gold dome is a golden statue of the Virgin Mary.'''
  #features: ['id', 'title', 'context', 'question', 'answers'], 'ansQues2'
  dfCOPA=session_state['dfCOPA']
  stInfo(dfCOPA)
  #from pandas import DataFrame, read_csv
  #from io import StringIO
  #trnStng=StringIO(train)
#b=ByteIO(train)
  #trnCSV=read_csv(trnStng)
  #dataframe(trnCSV)

elif menu==MENUs[1]:
  from pandas import DataFrame
  from streamlit import dataframe, info as stInfo
  dfCOPA=session_state['dfCOPA']    #=[('6/6.7cc od, 6/10cc os IOP: 18/14mmHg\n', {'entities': [(0, 8, 'OD'), (10, 19, 'OS'), (25, 32, 'IOP')]}),
  entDF=DataFrame()
  dfCOPA['ent']=dfCOPA.apply(df2ENT, axis=1)  #annttInfo., args=(ajcc7, ajcc7Gndr, sexNdx, pristNdx, O3Mndx)
  session_state['ent']=dfCOPA['ent']
  print(dfCOPA[['ent']].iloc[0][:1000])#['ent'], 'outcome'
  #allCncr.apply(AJCC期別, axis=1, args=(ajcc7, ajcc7Gndr, sexNdx, pristNdx, O3Mndx))
  #tknzRslt=spcyTknzr(pthlgyCOPA)
  #stWrite(['tknzRslt', tknzRslt])
elif menu==MENUs[2]:
#MY_PRODUCT = nlp.vocab.add_flag(is_my_product)
#assert doc[2].check_flag(MY_PRODUCT) == True

  from random import shuffle as rndmShffle
  from spacy.util import minibatch, compounding
  from spacy.training import Example
  #db = DocBin()
  try: lngMDL=session_state['lngMDL']
  except:
    lngMDL=spcyBlank('en')
    optimizer=lngMDL.initialize()
  #optimizer=lngMDL.initialize()
  #optimizer=lngMDL.begin_training()
  #optimizer=nlp.initialize()
  trainData=session_state['ent']
  stCode([  trainData ])
  losses=1
  while losses<1E2:
    #optimizer = lngMDL.create_optimizer()
    losses += 1   #{}
    rndmShffle(trainData)
    #batches = minibatch(trainData, size=compounding(4., 32., 1.001)) # batch up the examples using spaCy's minibatch
    #sizes = compounding(4., 500., 1.001)
    #batches = minibatch(trainData, size=sizes)
    #for batch in batches:
      #texts, annotations = zip(*batch)
    for (tid, trnDset) in trainData.items():
      stCode([trnDset])
      text, annotations=trnDset
      stCode([text, annotations])
      #stCode(['text, annotations=', text, annotations])
      doc=lngMDL.make_doc(text)
      example=Example.from_dict(doc, annotations) #.append()
      #lngMDL.update(texts, annotations, drop=.5, losses=losses)
      #stCode(['example=', example])
      lngMDL.update([example], sgd=optimizer) #, drop=.5, losses=losses
      #stCode(['losses=', losses])
      #losses=losses.get('ner')
  stCode(['lngMDL=', lngMDL])
elif menu==MENUs[-5]:
    try: doc=session_state['DOC']
    except:
      session_state['DOC']=doc=lngMDL(pthlgyCntxt)
    #doc = nlp("I like spaCy")
    stWrite(list(doc.sents))
    'fastChat'
elif menu==MENUs[-4]:
    'optimizer'
elif menu==MENUs[-3]:
    ##PUNCT
    stWrite(['PUNCT', PUNCT])
elif menu==MENUs[-2]:
    #tokenizer = AutoTokenizer.from_pretrained(lngMDL)
    #enc = tokenizer.encode_plus(text)
    #enc.keys() #dict_keys(['input_ids', 'attention_mask'])
    #trgtDEST='vghBDC'
    from spacy.vocab import Vocab
    vcbInfo=pthlgyCntxt.split()
    vocab = Vocab(strings=vcbInfo)
    #assert len(nlp.vocab) > 0
    #apple = nlp.vocab.strings["apple"]
    #assert nlp.vocab[apple] == nlp.vocab["apple"]
    #oov = nlp.vocab.strings["dskfodkfos"]
    vocabBytes = vocab.to_bytes()
    #stWrite([pthlgyCntxt])
    stInfo([[x for x in vocab.strings], vocabBytes.decode('utf-8', errors='ignore')])
    #stopWords = [lex for lex in lngMDL.vocab if lex.is_stop]
    #stWrite([list(stopWords)])
    #apple = nlp.vocab.strings["apple"]
    #oov = nlp.vocab.strings["dskfodkfos"]
    #assert apple in nlp.vocab
    #assert oov not in nlp.vocab

elif menu==MENUs[-1]:
    #from gensim.models.word2vec import Text8Corpus, Word2Vec
    #embddgng=Word2Vec(pthlgyCntxt)
    #from gensim.test.utils import common_texts
    from gensim.models import Word2Vec
    import multiprocessing
    try:
        wvMDL=session_state['wvMDL']
    except:
        VECTOR_SIZE, MIN_COUNT, WINDOW, SG=100, 5, 3, 1
        wvMDL = Word2Vec(vector_size=VECTOR_SIZE, window=WINDOW, min_count=MIN_COUNT, sg=SG)   #sentences=pthlgyCntxt,
        #model=Word2Vec(sent, min_count=1, size=50, workers=3, window=3, sg=1)
        #lngMDLwv=Word2Vec(sentences=pthlgyCntxt, vector_size=100, window=5, min_count=1, workers=4)
        #stWrite('wv', lngMDLwv.corpus_count)  #wv.embedding
        cores = multiprocessing.cpu_count() # Count the number of cores in a computer
        stCode(['build_vocab, progress_per=10000, update=False', pthlgyCntxt])
        #for cntxt in pthlgyCntxt.split():
        #    stCode(['cntxt', cntxt])
        #lngMDLwv = Word2Vec(pthlgyCntxt, min_count=4)
        #lngMDLwv = Word2Vec(min_count=1, window=2, epochs=300, sample=6e-5, alpha=.03, min_alpha=.0007, negative=20, workers=cores-1)
# Building the Vocabulary Table: Word2Vec requires us to build the vocabulary table (simply digesting all the words and filtering out the unique words, and doing some basic counts on them):
        #lngMDLwv.build_vocab(pthlgyCntxt, progress_per=10000, update=False)
        wvMDL.build_vocab(pthlgyCntxt, update=False)
        #sentences=pthlgyCntxt,
        wvMDL.train(pthlgyCntxt, total_examples=wvMDL.corpus_count, epochs=30, report_delay=1)
        session_state['wvMDL']=wvMDL
    stWrite([wvMDL.wv.vectors])    #vectors wordEmbedding .__dict__
    #.corpus ', '.join(dir(lngMDLwv)),
    #model.save("word2vec.model")
    #stWrite(embddgng)
    #from fasttext import FastText
    #fstxtMDL = FastText(pthlgyCntxt,  size=4, window=3, min_count=1, iter=10,min_n = 3 , max_n = 6,word_ngrams = 0)
    #fsEmbddng=fstxtMDL.wv.syn0_vocab  # 單詞的向量組 (5, 4)
    #stWrite(['fsEmbddng', fsEmbddng])
    #add_lifecycle_event, add_null_word, alpha, batch_words, build_vocab, build_vocab_from_freq, cbow_mean, comment, compute_loss, corpus_count, corpus_total_words, create_binary_tree, cum_table, effective_min_count, epochs, estimate_memory, get_latest_training_loss, hashfxn, hs, init_sims, init_weights, layer1_size, lifecycle_events, load, make_cum_table, max_final_vocab, max_vocab_size, min_alpha, min_alpha_yet_reached, min_count, negative, ns_exponent, null_word, predict_output_word, prepare_vocab, prepare_weights, random, raw_vocab, reset_from, running_training_loss, sample, save, scan_vocab, score, seed, seeded_vector, sg, shrink_windows, sorted_vocab, syn1neg, total_train_time, train, train_count, update_weights, vector_size, window, workers, wv
    #seed = 666 sg = 0 window_size = 10 vector_size = 100 min_count = 1 workers = 8 epochs = 5 batch_words = 10000
    #train_data = word2vec.LineSentence('wiki_text_seg.txt')
    #model = Word2Vec(train_data, min_count=min_count, vector_size=vector_size, workers=workers, epochs=epochs, window=window_size, sg=sg, seed=seed, batch_words=batch_words)
    #from flair.embeddings import WordEmbeddings, DocumentPoolEmbeddings
    #gloveEmbddng = WordEmbeddings('glove')
    #docEmbddngs = DocumentPoolEmbeddings([gloveEmbddng])
    #stckedEmbddngs.embed(pthlgyCntxt)
    #document_embeddings.embed(pthlgyCntxt)
    #stWrite(pthlgyCntxt.embedding)
    #emddngInfo=[]
    #for token in sentence:
    #  emddngInfo.append([token, token.embedding])
    #stCode(['sentence.embedding', emddngInfo, sentence.embedding])
elif menu==MENUs[3]:
    stWrite(['PUNCT', PUNCT])
elif menu==MENUs[4]:
    #stWrite(['fastText'])
    from gensim.models import FastText
    from gensim.test.utils import common_texts  # some example sentences
    #print(common_texts[0]) ['human', 'interface', 'computer']
    #print(len(common_texts)) 9
    ftMDL = FastText(vector_size=4, window=3, min_count=1)  # instantiate
    ftMDL.build_vocab(corpus_iterable=pthlgyCntxt)
    ftMDL.train(corpus_iterable=pthlgyCntxt, total_examples=len(pthlgyCntxt), epochs=10)  # train
    #sntncCrps = [ pthlgyCntxt.split() ]
    #fstxtMDL = FastText(min_count=1)
    #fstxtMDL.build_vocab(sntncCrps)
    #fstxtMDL.train(sntncCrps, total_examples=fstxtMDL.corpus_count, epochs=fstxtMDL.epochs)
    stInfo(['naked', ftMDL.wv.vectors])  #wordEmbedding .vectors ['naked']
elif menu==MENUs[5]:
    'csvEye'
elif menu==MENUs[6]:
    'answerQuestion'
    train='''id,package_name,review,date,star,version_id
    7bd227d9-afc9-11e6-aba1-c4b301cdf627,com.mantz_it.rfanalyzer,Great app! The new version now works on my Bravia Android TV which is great as it's right by my rooftop aerial cable. The scan feature would be useful...any ETA on when this will be available? Also the option to import a list of bookmarks e.g. from a simple properties file would be useful.,October 12 2016,4,1487
    7bd22905-afc9-11e6-a5dc-c4b301cdf627,com.mantz_it.rfanalyzer,Great It's not fully optimised and has some issues with crashing but still a nice app  especially considering the price and it's open source.,August 23 2016,4,1487
    7bd2299c-afc9-11e6-85d6-c4b301cdf627,com.mantz_it.rfanalyzer,Works on a Nexus 6p I'm still messing around with my hackrf but it works with my Nexus 6p  Trond usb-c to usb host adapter. Thanks!,August 04 2016,5,1487
    7bd22a26-afc9-11e6-9309-c4b301cdf627,com.mantz_it.rfanalyzer,The bandwidth seemed to be limited to maximum 2 MHz or so. I tried to increase the bandwidth but not possible. I purchased this is because one of the pictures in the advertisement showed the 2.4GHz band with around 10MHz or more bandwidth. Is it not possible to increase the bandwidth? If not  it is just the same performance as other free APPs.,July 25 2016,3,1487
    7bd22aba-afc9-11e6-8293-c4b301cdf627,com.mantz_it.rfanalyzer,Works well with my Hackrf Hopefully new updates will arrive for extra functions,July 22 2016,5,1487'''
    from pandas import DataFrame, read_csv
    from streamlit import dataframe
    from io import StringIO
    trnStng=StringIO(train)
#bIO=ByteIO(train)
    trnCSV=read_csv(trnStng)
    dataframe(trnCSV)
#trainDF=DataFrame.from_dict({'眼科':trnCSV})
#dataframe(trainDF)
