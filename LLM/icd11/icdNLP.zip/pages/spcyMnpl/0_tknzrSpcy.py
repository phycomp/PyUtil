from transformers import BertTokenizerFast
from streamlit import code as stCode, write as stWrite, session_state, sidebar, dataframe
from pandas import read_csv

MENUs=['訓練spacy', '成效', 'tknzrSpcy', 'med7', 'tknzrTrain', 'NER', 'vocab']#'tokenizer', 'punct', 'fastText', 'csvEye', 'fastChat', 'optimizer','BILUO', 'vocab', 'jsonViewer'] #EMBEDDING 訓練token
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
menu = sidebar.radio('Output', MENUs, index=0)

def getEnt(NLP, sent):
  ent1, ent2 = "", "" ## chunk 1
  prv_tok_dep = ""    # dependency tag of previous token in the sentence
  prv_tok_text = ""   # previous token in the sentence
  prefix, modifier = "", ""

  for tok in NLP(sent): ## chunk 2
    # if token is a punctuation mark then move on to the next token
    if tok.dep_ != "punct": # check: token is a compound word or not
      if tok.dep_ == "compound":
        prefix = tok.text # if the previous word was also a 'compound' then add the current word to it
        if prv_tok_dep == "compound":
          prefix = prv_tok_text + " "+ tok.text # check: token is a modifier or not
      if tok.dep_.endswith("mod") == True:
        modifier = tok.text # if the previous word was also a 'compound' then add the current word to it
        if prv_tok_dep == "compound":
          modifier = prv_tok_text + " "+ tok.text

      if tok.dep_.find("subj") == True: ## chunk 3
        ent1 = modifier +" "+ prefix + " "+ tok.text
        prefix, modifier = "", ""
        prv_tok_dep, prv_tok_text = "", ""

      if tok.dep_.find("obj") == True: ## chunk 4
        ent2 = modifier +" "+ prefix +" "+ tok.text

      ## chunk 5
      prv_tok_dep = tok.dep_ # update variables
      prv_tok_text = tok.text
  return [ent1.strip(), ent2.strip()]
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
#tokenizer(examples["tokens"], padding="max_length", truncation=True, is_split_into_words=True)
MENUs=['ENT', 'getEnt', 'tokenizer', 'punct', 'fastText', 'csvEye', 'answerQuestion', 'ansQues2', 'fastChat', 'optimizer','BILUO', 'vocab', 'word2vec'] #EMBEDDING
menu = sidebar.radio('Output', MENUs, index=0)
if menu==MENUs[0]:
  from spacy import load as spcyLoad
  try: lngMDL=session_state['lngMDL']
  except: session_state['lngMDL']=lngMDL=spcyLoad('en_core_web_sm')
  try:
    rawDset=session_state['rawDset']
  except:
    pass
  doc=lngMDL(rawDset)
  stCode([(ent.start_char, ent.text, ent.end_char, ent.label_) for ent in doc.ents ])
  #print(token.text, token.start_char, token.end_char, token.label_)

  #stCode(['lngMDL', ])
  #stCode(['getEnt', getEnt(lngMDL, rawDset)])

elif menu==MENUs[-3]:
  from spacy.tokens import DocBin
  from spacy import blank as spcyBlank
  nlp = spcyBlank("en")
  trnData = [
    ("Tokyo Tower is 333m tall.", [(0, 11, "BUILDING")]),
  ]
  # the DocBin will store the example documents
  db = DocBin()
  for text, annotations in trnData:
    doc = nlp(text)
    ents = []
    for start, end, label in annotations:
      span = doc.char_span(start, end, label=label)
      ents.append(span)
    doc.ents = ents
    db.add(doc)

elif menu==MENUs[-1]:
  from streamlit import json as stJson
  from json import loads, load
  from spacy import load as spcyLoad
  nlp=spcyLoad("en_core_web_sm")
  nlp.add_pipe("ner", source=nlp)
  nlp.add_pipe("entity_ruler", before="ner") # insert the entity ruler
  from spacy.vocab import Vocab
  vocab = Vocab(strings=["hello", "world"])
  doc = nlp("This is a sentence.")
  assert len(nlp.vocab) > 0
  apple = nlp.vocab.strings["apple"]
  assert nlp.vocab[apple] == nlp.vocab["apple"]
  stop_words = (lex for lex in nlp.vocab if lex.is_stop)
  apple = nlp.vocab.strings["apple"]
  oov = nlp.vocab.strings["dskfodkfos"]

  #fin=open('/home/josh/Downloads/dev-v2.0.json')
  #jsnOBJ=load(fin)
  #for k in jsnOBJ:
  # stJson(jsnOBJ[k])
elif menu==MENUs[-3]:
  #from spacy.tokenizer import Tokenizer
  #from spacy.lang.en import English
  #nlp = English()
  # Create a blank Tokenizer with just the English vocab
  #tokenizer = Tokenizer(nlp.vocab)
  # Construction 2
  from spacy.lang.en import English
  nlp = English()
  from streamlit import text_area
  try:
    tknzrSpcy=session_state['tknzrSpcy']
  except:
    session_state['tknzrSpcy']=tknzrSpcy=nlp.tokenizer
  rawDset=text_area('medical文本', )
  #tokenizer(examples["tokens"], padding="max_length", truncation=True, is_split_into_words=True)
  if rawDset:
    stCode(tknzrSpcy.explain(rawDset))
    #data = tokenizer.to_bytes(exclude=["vocab", "exceptions"])
    #tokenizer.from_disk("./data", exclude=["token_match"])

  # Create a Tokenizer with the default settings for English
  # including punctuation rules and exceptions
elif menu==MENUs[-4]:
  from spacy import load as spcyLoad
  med7 = spcyLoad("en_core_med7_lg")
  col_dict = {} # create distinct colours for labels
  seven_colours = ['#e6194B', '#3cb44b', '#ffe119', '#ffd8b1', '#f58231', '#f032e6', '#42d4f4']
  for label, colour in zip(med7.pipe_labels['ner'], seven_colours): col_dict[label] = colour
  options = {'ents': med7.pipe_labels['ner'], 'colors':col_dict}
  text = 'A patient was prescribed Magnesium hydroxide 400mg/5ml suspension PO of total 30ml bid for the next 5 days.'
  doc = med7(text)
  spacy.displacy.render(doc, style='ent', jupyter=True, options=options)
  [(ent.text, ent.label_) for ent in doc.ents]

elif menu==MENUs[-2]:
  'NER'
  nlp.begin_training()
  trnData=session_state['trnData']
  losses=True
  while losses:
    random.shuffle(trnData)
    losses = {}
    # batch up the examples using spaCy's minibatch
    batches = minibatch(TRAIN_DATA, size=compounding(4.0, 32.0, 1.001))
    for batch in batches:
        texts, annotations = zip(*batch)
        nlp.update( texts,  # batch of texts
            annotations,  # batch of annotations
            drop=0.5,  # dropout - make it harder to memorise data
            losses=losses
        )
    print("Losses", losses)

    # test the trained model
    for text, _ in TRAIN_DATA:
        doc = nlp(text)
        print("Entities", [(ent.text, ent.label_) for ent in doc.ents])
        print("Tokens", [(t.text, t.ent_type_, t.ent_iob) for t in doc])

    # save model to output directory
    if output_dir is not None:
        output_dir = Path(output_dir)
        if not output_dir.exists():
            output_dir.mkdir()
        nlp.to_disk(output_dir)
elif menu==MENUs[0]:
  from spacy import blank as spcyBlank
  nlp = spcyBlank("en")  # create blank Language class
  try:
    dfCOPA=session_state['dfCOPA']
  except:
    session_state['dfCOPA']=dfCOPA=read_csv('/home/josh/NLP/nlpData/bdcrcopa2.csv', sep='\x06')
  dataframe(dfCOPA)
  from spacy.tokens import DocBin
  db = DocBin() # create a DocBin object
  for text, annot in trnDset: # data in previous format
      doc = nlp.make_doc(text) # create doc object from text
      ents = []
      for start, end, label in annot["entities"]: # add character indexes
          span = doc.char_span(start, end, label=label, alignment_mode="contract")
          if not span:
              stCode("Skipping entity")
          else:
              ents.append(span)
      doc.ents = ents # label the text with the ents
      db.add(doc)
  db.to_disk("./vghSpcyTknzr") # save the docbin object
  session_state['trainData']=dfCOPA['outcome']
  session_state['pthlgyCntxt']=dfCOPA['outcome']
  #rawDset=dfCOPA['outcome']
  try:
    vghBertTknzr=session_state['vghBertTknzr']
  except:
    session_state['vghBertTknzr']=vghBertTknzr=bertTknzr.train_new_from_iterator(text_iterator=pthlgyItrtr(), vocab_size=32)   #_000
  try:
    vghTknzr=session_state['vghTknzr']
  except:
    vghTknzr=session_state['vghTknzr']='vghCOPA'
    vghBertTknzr.save_pretrained(vghTknzr)

  #ner_feature = bertTknzr["ner_tags"] #.features
  stCode(['vghBertTknzr', vghBertTknzr.__dict__ ])
elif menu==MENUs[1]:
  from spacy import load as spcyLoad
  nlp = spcyLoad("en_core_web_sm")
  #read_csv('bdcrcopa2.ods')
  from streamlit import text_area
  from transformers import AutoTokenizer
  import multiprocessing
  try: vghTknzr=session_state['vghTknzr']
  except: session_state['vghTknzr']=vghTknzr='vghtpeCOPA'
  # tokenizer = AutoTokenizer.from_pretrained(f"{user_id}/{tokenizer_id}") load tokenizer
  #tokenizer = AutoTokenizer.from_pretrained(vghTknzr)   #"vghtpeCOPA"
  #num_proc = multiprocessing.cpu_count()
  #print(f"The max length for the tokenizer is: {tokenizer.model_max_length}")
  rawDset=text_area('medical文本', )
  #tokenizer(examples["tokens"], padding="max_length", truncation=True, is_split_into_words=True)
  if rawDset:
    doc=nlp(rawDset)
    stCode(["Noun phrases:", [chunk.text for chunk in doc.noun_chunks]])
    stCode(["Verbs:", [token.lemma_ for token in doc if token.pos_ == "VERB"]])
    for entity in doc.ents:
        stCode([entity.text, entity.label_])
