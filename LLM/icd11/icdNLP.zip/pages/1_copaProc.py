from tokenizers import ByteLevelBPETokenizer
from streamlit import session_state, info as stInfo, code as stCode, write as stWrite, sidebar
from datasets import Dataset
from pandas import DataFrame
from tokenizers.models import BPE
from tokenizers.pre_tokenizers import Whitespace
from tokenizers.trainers import BpeTrainer
from tokenizers import Tokenizer, decoders, models, normalizers, pre_tokenizers, trainers
from tokenizers.trainers import WordPieceTrainer

#paths = [str(x) for x in Path("./eo_data/").glob("**/*.txt")]

# Initialize a tokenizer
#tokenizer = ByteLevelBPETokenizer()

MENUs=['tknzr訓練', 'NER', 'med7', 'dset'] #EMBEDDING, 'punct', 'fastText', 'csvEye', 'fastChat', 'optimizer','BILUO', 'vocab', 'jsonViewer'
# Customize training
#tokenizer.train(files=trainData, vocab_size=52_000, min_frequency=2, special_tokens=[ "<s>", "<pad>", "</s>", "<unk>", "<mask>", ])
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)


#tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
menu = sidebar.radio('Output', MENUs, index=0)
if menu==MENUs[-1]:
    trainData=session_state['trainData']
    session_state['trnDset']=trnDset=Dataset.from_pandas(DataFrame(data=trainData))
    stCode(['trnDset', trnDset])
elif menu==MENUs[-2]:
  #contxt=session_state['contxt']
  #NLP=spcyLoad('en_ner_bionlp13cg_md')
  from spacy import load as spcyLoad
  NLP=spcyLoad('en_core_med7_lg')
  medParse=NLP(contxt)
  for sent in medParse.sents:
    if sent.ents:
        entInfo=[]
        for ent in sent.ents:
          rawText, sentText=ent.text, sent.text
          startPos=sentText.find(rawText)
          endPos=startPos+len(rawText)
          #entInfo.append((startPos, endPos, ent.label_))
          entInfo.append((startPos, endPos, ent, ent.label_))
        newSent+=subSent(sent.text, entInfo)
        stCode([sent.text, {'entities':entInfo}])  #startPos, endPos, ent)
    else: newSent+=sent.text
elif menu==MENUs[0]:
    #stWrite(list(doc.ents)) #要得出ents
    trainData=session_state['trainData']
    stInfo([trainData])
    unkTkn="""["[UNK]", "[CLS]", "[SEP]", "[PAD]", "[MASK]"]"""
    vghTknzr = Tokenizer(BPE(unk_token=unkTkn))
    #vghTknzr = Tokenizer(models.Unigram())
    vghTknzr.normalizer = normalizers.NFKC()
    #vghTknzr.pre_tokenizer = pre_tokenizers.ByteLevel()
    vghTknzr.pre_tokenizer = Whitespace()
    vghTknzr.decoder = decoders.ByteLevel()
    #trainer = trainers.UnigramTrainer( vocab_size=20000, initial_alphabet=pre_tokenizers.ByteLevel.alphabet(), special_tokens=["<PAD>", "<BOS>", "<EOS>"])
    stCode([trainData])
    itrTrnr=map(lambda x:x[0], trainData)
    tknTrnr = BpeTrainer(special_tokens=["[UNK]", "[CLS]", "[SEP]", "[PAD]", "[MASK]"])
    #tknTrnr = WordPieceTrainer(vocab_size=30522, special_tokens=["[UNK]", "[CLS]", "[SEP]", "[PAD]", "[MASK]"])
    #tokenizer.train(list(trnData), trainer)
    vghTknzr.train_from_iterator(itrTrnr, trainer=tknTrnr)
    #vghTknzr.train_from_iterator(xtrn, trainer=trainer)    #xtrnTknzrOutput=
    #stInfo(['trainData', len(trainData), 'trnData=', len(list(trnData))])
    #vghTknzr.train_from_iterator(trnData, trainer=trainer)
    #vghTknzr.train_from_iterator(batch_iterator(), trainer=trainer, length=len(dataset))
    #help(vghTknzr)

    session_state['vghTknzr']=vghTknzr
    stCode(['vghTknzr=', vghTknzr.to_str()])    #data vocab
    #stWrite(['vghTknzr=', vghTknzr.to_str() ])  #to_str, vocab() xtrnTknzrOutput
    #xTrain=session_state['xTrain']
    #help(vghTknzr)
    #from transformers import PreTrainedTokenizerFast
    #from tokenizers import Tokenizer
    #vghTknzr = Tokenizer.from_file('your/save/file.json')
    #context_length = 128
    #fastTknzr = PreTrainedTokenizerFast(tokenizer_object=vghTknzr)

    #xtrn=map(lambda x:x[0], xTrain)
    #trnTknzrOutput=fastTknzr(list(xtrn), truncation=True, max_length=context_length, return_overflowing_tokens=True, return_length=True)
    #help(trnTknzrOutput)
    #stInfo(['trnTknzrOutput=', trnTknzrOutput.data ])  #to_str, vocab()
    #outputs = vghTknzr(xTrain, truncation=True, max_length=context_length, return_overflowing_tokens=True, return_length=True)
    #vghTknzr==>"input_ids", "token_type_ids", "attention_mask", "length", "overflow_to_sample_mapping"
elif menu==MENUs[1]:
    pass
