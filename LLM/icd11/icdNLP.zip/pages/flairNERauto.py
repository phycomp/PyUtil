from flair.embeddings import TransformerWordEmbeddings
from flair.models import SequenceTagger
from flair.trainers import ModelTrainer
  elif menu==MENUs[-2]:
    embeddings = TransformerWordEmbeddings(model=model_args.model_name_or_path, layers=model_args.layers, subtoken_pooling=model_args.subtoken_pooling, fine_tune=True, use_context=flert_args.context_size, respect_document_boundaries=flert_args.respect_document_boundaries)
  elif menu==MENUs[-2]:

    tagger = SequenceTagger( hidden_size=model_args.hidden_size, embeddings=embeddings, tag_dictionary=tag_dictionary, tag_type=tag_type, use_crf=model_args.use_crf, use_rnn=False, reproject_embeddings=False)
    trainer = ModelTrainer(tagger, corpus)

    trainer.fine_tune(data_args.output_dir, learning_rate=training_args.learning_rate, mini_batch_size=training_args.batch_size, mini_batch_chunk_size=training_args.mini_batch_chunk_size, max_epochs=training_args.num_epochs, embeddings_storage_mode=training_args.embeddings_storage_mode, weight_decay=training_args.weight_decay)

    torch.save(model_args, os.path.join(data_args.output_dir, "model_args.bin"))
    torch.save(training_args, os.path.join(data_args.output_dir, "training_args.bin"))

    tagger.print_model_card()
