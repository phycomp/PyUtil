from transformers import pipeline
from streamlit import session_state
from transformers import BertTokenizer, BertModel

unmasker = pipeline('fill-mask', model='bert-base-uncased')
unmasker("Hello I'm a [MASK] model.")
session_state['vghTknzr']=vghTknzr = BertTokenizer.from_pretrained('bert-base-uncased')
vghMDL = BertModel.from_pretrained("bert-base-uncased")
text = "Replace me by any text you'd like."
encoded_input = vghTknzr(text, return_tensors='pt')
output = vghMDL(**encoded_input)

