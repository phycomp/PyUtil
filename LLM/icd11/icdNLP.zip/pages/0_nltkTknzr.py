from streamlit import text_area, code as stCode, write as stWrite, sidebar, session_state
from nltk import word_tokenize, pos_tag, NLTKWordTokenizer
#>>> [s[start:end] for start, end in NLTKWordTokenizer().span_tokenize(s)] == expected
sent='''
PATHOLOGICAL DIAGNOSIS:Colon, labeled B, colonoscopic polypectomy --- Tubular adenomaGROSS FINDING:Received in formalin is a piece of tan soft tissue measuring 0.3x 0.2 x 0.2 cm. Entire specimen is embedded in one block. (WTL)MICROSCOPIC FINDING:1. Type of adenoma: tubular2. Quality of specimen: poorly orientated3. Dysplasia: Low grade4. Status of margins:Lateral margin: cannot be assessedBase(stalk): cannot be assessed
'''
stWrite('<style>div[role=radiogroup]{flex-direction:row; justify-content:space-between} code{white-space: pre-wrap !important;}</style>', unsafe_allow_html=True)
def preproc(sent):
    sent = word_tokenize(sent)
    sent = pos_tag(sent)
    return sent

MENUs=['訓練spacy', '成效', 'tknzrSpcy', 'med7', 'tknzrTrain', 'NER', 'vocab']#'tokenizer', 'punct', 'fastText', 'csvEye', 'fastChat', 'optimizer','BILUO', 'vocab', 'jsonViewer'] #EMBEDDING 訓練token
menu = sidebar.radio('Output', MENUs, index=0)

if menu==MENUs[0]:
  from nltk import RegexpParser
  pttrn = 'NP: {<DT>?<JJ>*<NN>}'
  cpttrn = RegexpParser(pttrn)
  cs = cpttrn.parse(sent.split())
  stCode([cs])
elif menu==MENUs[3]:
  import spacy
  from spacy import displacy
  from collections import Counter
  import en_core_web_sm
  nlp = en_core_web_sm.load()
elif menu==MENUs[2]:
  from nltk import ne_chunk
  from nltk.chunk import conlltags2tree, tree2conlltags
  from pprint import pprint
  ne_tree = ne_chunk(pos_tag(word_tokenize(ex)))
  iob_tagged = tree2conlltags(cs)
  stCode(ne_tree, iob_tagged)
elif menu==MENUs[1]:
  session_state['rawDset']=rawDset=text_area('medical文本', )
  if rawDset:
    spanInfo=[]
    for spn in NLTKWordTokenizer().span_tokenize(rawDset):
      startPos, endPos=spn
      rawSpan=rawDset[startPos:endPos]
      spanInfo.append(rawSpan)
    stCode(rawDset)
    stCode(['spanInfo', spanInfo])
    stCode(['wordTknzr', word_tokenize(rawDset)])    # tknzrSpcy.explain(rawDset))
    stCode(' '.join(spanInfo[:-1]))
    stCode(rawDset[:-1])
    #assert ' '.join(spanInfo[:-1])==rawDset[:-1]
