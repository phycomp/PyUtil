FTYPE={'python':'python', 'html':'html','py':'python', 'md':'markdown', 'vim':'vim', 'lua':'lua', 'txt':'text', 'csh':'sh', 'bash':'sh', 'sh':'sh'}
def setfType(ftype):
    fType=FTYPE.get(ftype, 'text')
    cmd=f'setf {fType}'
    vim.command(cmd)
vim.api.set_keymap('n', '<leader>sft', ':SetfType ', {'noremap':True, 'silent':False})
vim.command(':com! -nargs=* SetfType py3 setfType(<f-args>)')
