#-*- coding:utf-8 -*-
def ridPttrn():
    import pynvim
    from UltiSnips.position import Position
    from UltiSnips.compatibility import col2byte, byte2col
    from UltiSnips.vim_helper import set_cursor_from_pos, get_cursor_pos, escape
    from re import sub
    import vim
    curPos=get_cursor_pos()
    buf = vim.current.buffer
    lastLnum = buf.api.line_count()
    Lnum=1  #vim.api.line(1)
    keyPunct=["：", '；', '、', '，', ';', ',', '。', ':']
    keyQuote=['【', '】', '「', '」', '《', '》', '〈', '〉', '﹝', '﹞', '』', '『', '（', '）', '！', '［', '］', '“', '”']
    keyEscape=['(', ')', '.', '/', '[', ']']
    curLnum, nbyte = vim.current.window.cursor

    curRaw=buf[curLnum-1]
    col = byte2col(curLnum, nbyte)
    pos=Position(curLnum - 1, col)
    try: cword=curRaw[pos.col]
    except: cword=vim.api.get_current_line()
    print('cword=', cword)
    punctSbsttword, punctCword=None, None
    quoteSbsttword, quoteCword=None, None
    escapeSbsttword, escapeCword=None, None
    if cword in keyPunct:
        punctSbsttword=' '
        punctCword=''.join(keyPunct)
        punctCword=f'[{punctCword}]'
    else:
        punctSbsttword=''
    if cword in keyQuote:
        quoteSbsttword=''
        quoteCword=''.join(keyQuote)
        quoteCword=f'[{quoteCword}]'
    if cword in keyEscape:
        #cword=f'\\{cword}'#escape(cword)
        escapeSbsttword=''
        escapeCword='\\'.join(keyEscape)
        escapeCword=f'[{escapeCword}]'
    #print('in keyEscape=', cword in keyEscape)
    #print('cword, escapeCword=', cword, escapeCword, escapeSbsttword)
    vim.command('normal! gg')
    newRaw=None
    while Lnum<=lastLnum:
        curRaw=vim.api.get_current_line()
        #curChar=escape(curRaw)
        if punctCword:
            curRaw=sub(punctCword, punctSbsttword, curRaw)
        if quoteCword:
            curRaw=sub(quoteCword, quoteSbsttword, curRaw)
        if escapeCword:
            if curRaw.find('http')!=-1: pass
            else: curRaw=sub(escapeCword, escapeSbsttword, curRaw)
        else: curRaw=sub(cword, '', curRaw)    #, 'g'
        #curRaw=sub(cword, '', curRaw)    #, 'g'
        vim.api.set_current_line(curRaw)
        if curRaw=='\':vim.api.del_current_line()    #vim.funcs.deletebufline()del buf[Lnum]#
        else: vim.command('normal! j')
        Lnum+=1
    set_cursor_from_pos(curPos)
