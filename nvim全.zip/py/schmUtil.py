vim.api.set_keymap('n', '<leader>scs', ':SetColorSchm ', {'noremap':True, 'silent':False})
def setSchClr(clrSchm):
    if clrSchm.startswith('mur'):
        cmd='exec "colorscheme murphy"'
    elif clrSchm.startswith('elf'):
        cmd='exec "colorscheme elflord"'
    elif clrSchm.startswith('ron'):
        cmd='exec "colorscheme ron"'
    else:
        cmd='exec "colorscheme darkblue"'
    print(f'colorscheme {clrSchm}')
    vim.command(cmd)
vim.command(':com! -nargs=* SetColorSchm py3 setSchClr(<f-args>)')
vim.api.set_keymap('n', '<leader>scl', '<cmd>MergeCMD pyf setColor.py<CR>', {'noremap':True, 'silent':False})
