#Set `let g:jupyter_mapkeys = 0` in your `.vimrc` to prevent the default keybindings from being made.
# Change to directory of current file
vim.command('''
nnoremap <buffer> <silent> <localleader>jpc :JupyterConnect<CR>
nnoremap <buffer> <silent> <localleader>jpd :JupyterDisconnect<CR>
nnoremap <buffer> <silent> <localleader>jpr :JupyterRunFile<CR>
nnoremap <buffer> <silent> <localleader>jpi :PythonImportThisFile<CR>
nnoremap <buffer> <silent> <localleader>jcd :JupyterCd %:p:h<CR>
nnoremap <buffer> <silent> <localleader>jsc :JupyterSendCell<CR>
nnoremap <buffer> <silent> <localleader>jsr :JupyterSendRange<CR>
nmap     <buffer> <silent> <localleader>jrt <Plug>JupyterRunTextObj
vmap     <buffer> <silent> <localleader>jrv <Plug>JupyterRunVisual
nnoremap <buffer> <silent> <localleader>jsm :JupyterStartMonitor
nnoremap <buffer> <silent> <localleader>jsb :PythonSetBreak<CR>
''')
