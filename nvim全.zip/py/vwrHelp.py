from math import ceil as mathCeil
from pynvim.api.nvim import Nvim
def bufESC(bufnr):
  escKeys = ['<Esc>', '<CR>', '<Leader>q']
  for eKey in escKeys:
    vim.api.buf_set_keymap(bufnr, 'n', eKey, '<cmd>close<CR>', {'silent':True, 'nowait':True, 'noremap':True})

def winESC(winnr):
  escKeys = ['<Esc>', '<CR>', '<Leader>q']
  for eKey in escKeys:
    vim.api.set_keymap('n', eKey, '<cmd>close<CR>', {'silent':True, 'nowait':True, 'noremap':True})
    #vim.command('setlocal bufhidden=hide buftype=nofile')
  #escKeys = ['<Esc>', '<CR>', '<Leader>q']
  #for eKey in escKeys:
  # vim.api.buf_set_keymap(bufnr, 'n', eKey, '<cmd>close<CR>', {'silent':True, 'nowait':True, 'noremap':True})

def rtrvOPT():
  width=vim.api.get_option("columns")
  height=vim.api.get_option("lines")
  winHeight=mathCeil(height * .8 - 4)
  winWidth=mathCeil(width * .8)
  row=mathCeil((height - winHeight) / 2 - 1)
  col=mathCeil((width - winWidth) / 2)
  opts ={'style':"minimal", 'relative':"editor", 'width':winWidth, 'height':winHeight, 'row':row, 'col':col, 'border':"rounded"}
  return opts

def openWin():
  opts=rtrvOPT()
  bufnr = vim.api.create_buf(False, True)
  winnr = vim.api.open_win(bufnr, True, opts)
  #vim.api.buf_set_option(buf, "bufhidden", "wipe")
  #vim.api.win_set_option(win, "cursorline", True)
  return bufnr, winnr, opts

def vwrCMD(*args):
  bufnr, winnr, opts=openWin()
  #vim.api.set_current_buf(bufnr)
  #print(vim.api.win_get_config(winnr))    #.relative ~= '' then
  #vim.command('setlocal buftype=help')    #setlocal bufhidden=hide buftype=help  noswapfile nobuflisted
  bufESC(bufnr)
  #vim.api.buf_set_option(buf, "modifiable", False)
  #set buftype=quickfix bufhidden=hide 
  vim.command('setlocal bufhidden=hide buftype=prompt nobuflisted')
  CMD=' '.join(args)
  vim.command(CMD)
  #vim.api.set_current_win(winnr)

def vwrHelp(hlpTrm):
  bufnr, winnr, opts=openWin()
  #print(bufnr, winnr)
  vim.api.set_current_buf(bufnr)
  #vim.api.set_current_win(winnr)
  bufESC(bufnr)
  vim.command('setlocal bufhidden=hide buftype=help')
  print(f'help {hlpTrm}')
  helpCntxt=Nvim().command_output(f'help {hlpTrm}')
  #helpCntxt = self.nvim.command_output(f'help {topic}')
  helpLINE = helpCntxt.splitlines()
  vim.api.buf_set_lines(buf, 0, -1, False, helpLINE)
  #vim.command('setlocal filetype=help')
  #vim.command('setlocal noswapfile')
  #setlocal buftype=help
  #call nvim_set_current_buf(l:buf)
  #filePath = vim.api.get_runtime_file(f'doc/{rtpFile}', False)[0]
  #vim.command(f"read {filePath}")
  #vim.api.buf_set_option(0, "modifiable", False)
  #vim.command(f":h {rtpFile}")
  #vim.command(CMD)
vim.api.set_keymap('n', '<leader>vhp', ":VwrHelp ", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>vcm', ":VwrCmd ", {'noremap':True, 'silent':False})
vim.command(':com! -complete=help -nargs=* VwrHelp py3 vwrHelp(<q-args>)')
vim.command(':com! -complete=command -nargs=* VwrCmd py3 vwrCMD(<q-args>)')
#nargs 選項有 *, ?, +
#vim.api.set_keymap('n', '<leader>fwm', "<cmd>py3 getMark('f-args')<CR>", {'noremap':True, 'silent':False})
