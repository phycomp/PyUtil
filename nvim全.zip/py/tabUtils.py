#py print()
#vim.funcs.tabpagebuflist()
def listTabpages():
  return vim.api.list_tabpages()

def tabRename(tabID, name):
  tabNames={}
  if not tabID:
    tabID = vim.api.get_current_tabpage()
    #vim.api.set_current_Tabpage(name)
    vim.api.set_current_tabpage(name)
    #TabRename pyUtil
  #tabNames[str(tabID)] = name
  print('tabNames=', tabNames)
  vim.command('redrawtabline')
vim.command(':com! -nargs=* TabRename py3 tabRename(0, <f-args>)')
vim.api.set_keymap('n', '<leader>tbr', ':TabRename ', {'noremap':True, 'silent':False})
'''
local function save()
  local names_to_number = {} ---@type table<string, string>
  for tabid, name in pairs(tab_names) do
    local ok, tab_num = pcall(api.get_tab_number, tonumber(tabid))
    if ok then
      names_to_number[tostring(tab_num)] = name
    end
  end
  vim.g.TabbyTabNames = vim.json.encode(names_to_number)
end

local function load()
  local ok, names_to_number = pcall(vim.json.decode, vim.g.TabbyTabNames)
  if not (ok and type(names_to_number) == 'table') then
    return
  end
  for _, tabid in ipairs(api.get_tabs()) do
    local tab_num = api.get_tab_number(tabid)
    local name = names_to_number[tostring(tab_num)]
    if name ~= nil then
      tab_names[tostring(tabid)] = name
    end
  end
end

#tabRename(0, <f-args>)
def echoRange():
for itr in range(50): print(itr)
echoRange()

'''
