--local vimCMD = vim.cmd
--vim.api.nvim_command([[
vim.cmd([[
  "au BufNewFile,BufRead * if &ft == "" | set ft=text | endif
  "au FileType help wincmd L
  set smartcase smarttab smartindent cindent mouse=a title
  set clipboard+=unnamed,unnamedplus
  set splitright
  set swb=usetab
  set hlsearch incsearch
  "ic hls splitbelow 
  set nobackup noswapfile nowritebackup
  syntax enable on
  set expandtab nocompatible showcmd showmatch
  "set wildignore+=*/node_modules/**,obj/**,*.tmp,test.c
  set wildignore+=*/node_modules/**
  "set wildignore+=node_modules/**
  set encoding=utf-8 fileencoding=utf-8
  "set rtp+=/home/josh/GITs/neovim/runtime
  set wrap list
  set is nofoldenable
  set path+=**
  set wildmenu wildmode=full showmode
  "set wildmenu wildmode=lastused,list
  filetype plugin indent on
  filetype detect
  "set listchars=tab:>,space:␣
  "set listchars=tab:>·,space:␣
  "set listchars=eol:↵,trail:~,tab:>-,nbsp:␣
  set nocursorline "cursorline
  set wcm=<C-Z>
  set tabstop=2 shiftwidth=2 linespace=0
  "set number relativenumber
  "highlight WhiteSpaceBol ctermfg=10 ctermbg=red
  "match WhiteSpaceBol / \\+$/
  "colorscheme elflord
  "colo elflord
  "hi TabLineFill ctermfg=LightGreen ctermbg=DarkGreen
  "hi TabLineSel ctermfg=46 ctermbg=DarkRed
  "hi TabLine ctermfg=46 ctermbg=Black
  "highlight Search ctermbg=black ctermfg=red
  let g:mapleader = "\\"
  set cmdheight=1 scrolloff=0 conceallevel=0
  "set autoindent
  set showtabline=2 history=1000
  set updatetime=300 timeoutlen=500 laststatus=0
  set hidden lazyredraw
  "set noshowmode
  "set nobackup
  "set number
  "set ruler noruler 
  "set backspace=start,eol,indent nowrap 
  set wildignore+=*/node_modules/*
  set termguicolors background=dark
  "set guifont="Hack:h24"
  "colorscheme onedark
  au BufNewFile,BufRead *.es6 setf javascript
  au BufNewFile,BufRead *.tsx setf typescriptreact
]])

--vim.o.showtabline = 2
vim.opt.mouse = 'a'
vim.opt.showtabline = 2
vim.opt.sessionoptions = 'curdir,folds,globals,help,tabpages,terminal,winsize'

--local u = require('utils')
--u.create_augroup({
--    { 'BufRead,BufNewFile', '/tmp/nail-*', 'setlocal', 'ft=mail' },
--    { 'BufRead,BufNewFile', '*s-nail-*', 'setlocal', 'ft=mail' },
--}, 'ftmail')
