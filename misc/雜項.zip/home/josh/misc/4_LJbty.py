from stUtil import rndrCode
from dbUtil import dbCLMN, runQuery
from streamlit import multiselect, text_input, sidebar
from pandas import DataFrame
CLMN=dbCLMN(tblName='麗京美學', db='LJbty')
rsltLJ=runQuery('select * from 麗京美學;', db='LJbty')
clmn=multiselect('欄位', CLMN)
dfLJ=DataFrame(rsltLJ, columns=CLMN)
with sidebar:
  srch=text_input('搜尋', '請輸入')
if srch:
  #qrySrch=str(CLMN)
  #for v in CLMN
  CLMNdf=map(lambda x:f'{x}::text', CLMN)
  qrySrch=f"~'{srch}' or ".join(CLMNdf)
  qrySrch+=f"~'{srch}'"
  qryPttrn=f"""select * from "麗京美學" where {qrySrch};"""
  #rndrCode(['qryPttrn', qryPttrn, CLMN])
  rsltLJ=runQuery(qryPttrn, db='LJbty')
  dfLJ=DataFrame(rsltLJ, columns=CLMN)
  dfLJ.T
  #rndrCode(['clmn', rsltLJ])
  #select 
  #newDF=dfLJ[clmn].str.contains(srch)   #dfLJ[]  ##dfLJ[]#dfLJ[]
  #cmbndDF[cmbndDF['Id'].str.contains(核CLMN, regex=True)
  #newDF
  #dfLJ[]
#rndrCode()
