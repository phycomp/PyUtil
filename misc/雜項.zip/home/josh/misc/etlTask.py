import streamlit as st
import tornado.web
from tornado.ioloop import IOLoop
from streamlit import title
from etlUtil import ETLProcessor
# 數據庫配置
DB_CONFIG = {
    "host": "localhost",
    "dbname": "your_db",
    "user": "your_user",
    "password": "your_password"
}

# 定義 ETL 處理對象
etl任務 = ETLProcessor( db_config=DB_CONFIG, fetch_batch_size=500, commit_batch_size=100)

# Streamlit Web 界面
title("ETL Batch Processing Interface")

# 批次大小設置
fetch_batch_size = st.number_input("Fetch Batch Size", min_value=100, max_value=1000, value=500, step=100)
commit_batch_size = st.number_input("Commit Batch Size", min_value=50, max_value=500, value=100, step=50)

# 開始 ETL 任務
if st.button("Start ETL Process"):
    etl任務.fetch_batch_size = fetch_batch_size
    etl任務.commit_batch_size = commit_batch_size
    
    # 運行 ETL 任務
    loop = IOLoop.current()
    loop.add_callback(etl.run_etl)
    st.write("ETL Task Started...")

# 顯示任務進度
st.write("Current Offset:", etl任務.offset)
