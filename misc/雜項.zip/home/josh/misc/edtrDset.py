from streamlit import download_button as dwnldBttn, data_editor, subheader, dataframe, info as stInfo #進階應用實例
"""
st.data_editor 是 Streamlit 的新功能，允許用戶在 Web 界面上直接編輯表格數據。除了基本的數據展示與編輯外，st.data_editor 還支持更多進階功能，如動態行數、不同的列類型、數據校驗等。下面介紹一些 st.data_editor 的進階應用實例。

示例功能：
動態增刪行：允許用戶動態增刪行。
不同的數據類型：展示不同類型的數據（文本、數字、布爾值、選擇框等）。
自動數據驗證：根據數據類型對用戶輸入進行校驗。
列篩選與排序：允許用戶對表格數據進行篩選與排序。
導入與導出：允許用戶上傳文件進行編輯，并提供導出選項。
進階應用示例

"""
import streamlit as st
from pandas import  DataFrame

# 應用標題
st.title("Data Editor 進階應用示例")

# 創建一個示例 DataFrame
data = {
    '姓名': ['張三', '李四', '王五'],
    '年齡': [25, 30, 22],
    '性別': ['男', '男', '女'],
    '城市': ['北京', '上海', '廣州'],
    '是否會員': [True, False, True],
    '評分': [4.5, 3.8, 4.2]
}
df = DataFrame(data)

from streamlit.column_config import NumberColumn, SelectboxColumn
# Data Editor 的進階應用
subheader("編輯表格數據")

edited_df = data_editor(df, num_rows="dynamic",  # 支持動態增加行
    column_config={'姓名':'text',  # 純文本列
        '年齡':NumberColumn('年齡', min_value=18, max_value=100, step=1),  # 數字列，帶有範圍限制
        '性別':SelectboxColumn('性別', options=['男', '女']),  # 使用下拉框選擇性別
        '城市':'text',  # 文本列
        '是否會員':'boolean',  # 布爾值列
        '評分':NumberColumn('評分', min_value=0.0, max_value=5.0, step=0.1),  # 評分列，帶有小數步長
    },
    hide_index=False,  # 顯示行索引
    use_container_width=True  # 適應容器寬度
)

# 顯示用戶編輯後的數據
subheader("編輯後的數據：")
dataframe(edited_df)

# 導出功能，允許用戶下載編輯後的數據
subheader("下載編輯後的數據")
csv = edited_df.to_csv(index=False).encode('utf-8')

dwnldBttn(label="下載 CSV", data=csv, file_name='edited_data.csv', mime='text/csv')

stInfo("提示：您可以通過表格下方的空行添加新行，或通過點擊行號來刪除行。")
"""
提示：用戶可以添加或刪除行
關鍵功能解析：
動態行支持 (num_rows="dynamic")：

允許用戶動態添加或刪除行，適用于需要用戶不斷擴展數據的場景。
不同列類型的配置 (column_config)：

爲不同的列指定類型，如文本列、數字列、布爾值列或選擇框列。比如年齡設置爲 NumberColumn，并設定了最小和最大值，評分支持小數步長。
性別列使用 SelectboxColumn，提供了“男”和“女”的選擇。
隱藏/顯示索引 (hide_index)：

控制是否顯示表格的索引列，通常在編輯數據時索引可能會影響用戶體驗，所以可以選擇隱藏索引。
容器寬度自適應 (use_container_width=True)：

表格將自適應整個容器的寬度，确保在不同的屏幕設備上都能良好展示。
數據導出與下載：

st.download_button 提供下載按鈕，用戶可以將編輯後的數據導出爲 CSV 文件。
實際使用場景：
數據錄入系統：當你有大量數據需要手動輸入并編輯時，可以通過 st.data_editor 實現實時編輯與校驗。
管理界面：在後台管理系統中，管理員可以通過這種方式輕松管理數據，并實時修改保存。
數據清洗：可以用于用戶手動清洗和修復數據，尤其是在不同列類型需要校驗和處理的情況下。
你可以根據實際的需求，自定義更多的列類型和驗證邏輯，也可以根據用戶的行為提供更靈活的增刪行、數據導入導出等功能。
"""
