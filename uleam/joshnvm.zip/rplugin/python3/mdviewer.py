# ~/.config/nvim/rplugin/python3/mdviewer.py

import pynvim
import os
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingMixIn, TCPServer

try:
    import markdown
    MARKDOWN_OK = True
except ImportError:
    MARKDOWN_OK = False

class ThreadedHTTPServer(ThreadingMixIn, TCPServer):
    allow_reuse_address = True

@pynvim.plugin
class MarkdownViewer:
    def __init__(self, nvim):
        self.nvim = nvim
        self.server = None
        self.port = 0
        self.html_body = ""
        self.lock = threading.Lock()
        self.version = 0
        self.template = self._load_template()
        self._find_port()

    def _find_port(self):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("localhost", 0))
        self.port = s.getsockname()[1]
        s.close()

    def _load_template(self):
        return r"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neovim Markdown Preview</title>
    <style>
        :root {
            --bg: #ffffff;
            --fg: #1f2328;
            --border: #d0d7de;
            --code-bg: #f6f8fa;
            --link: #0969da;
            --blockquote: #656d76;
        }
        @media (prefers-color-scheme: dark) {
            :root {
                --bg: #0d1117;
                --fg: #c9d1d9;
                --border: #30363d;
                --code-bg: #161b22;
                --link: #58a6ff;
                --blockquote: #8b949e;
            }
        }
        * { box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", "PingFang TC", Helvetica, Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: var(--fg);
            background: var(--bg);
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 32px;
        }
        h1, h2, h3, h4, h5, h6 { margin-top: 24px; margin-bottom: 16px; font-weight: 600; line-height: 1.25; }
        h1 { font-size: 2em; padding-bottom: 0.3em; border-bottom: 1px solid var(--border); }
        h2 { font-size: 1.5em; padding-bottom: 0.3em; border-bottom: 1px solid var(--border); }
        h3 { font-size: 1.25em; }
        h4 { font-size: 1em; }
        pre {
            background: var(--code-bg);
            padding: 16px;
            overflow: auto;
            border-radius: 6px;
            border: 1px solid var(--border);
            line-height: 1.45;
        }
        code {
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, "Courier New", monospace;
            font-size: 85%;
            background: rgba(175,184,193,0.2);
            padding: 0.2em 0.4em;
            border-radius: 3px;
        }
        pre code { background: transparent; padding: 0; font-size: 100%; }
        blockquote {
            padding: 0 1em;
            color: var(--blockquote);
            border-left: 4px solid var(--border);
            margin: 0 0 16px 0;
        }
        blockquote > :last-child { margin-bottom: 0; }
        table { border-collapse: collapse; width: 100%; margin: 16px 0; }
        th, td { border: 1px solid var(--border); padding: 6px 13px; }
        th { background: var(--code-bg); font-weight: 600; }
        tr:nth-child(2n) { background: rgba(0,0,0,0.02); }
        img { max-width: 100%; height: auto; }
        a { color: var(--link); text-decoration: none; }
        a:hover { text-decoration: underline; }
        ul, ol { padding-left: 2em; }
        li + li { margin-top: 0.25em; }
        hr { height: 2px; padding: 0; margin: 24px 0; background: var(--border); border: 0; }
        .status {
            position: fixed;
            top: 8px;
            right: 16px;
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 12px;
            background: var(--code-bg);
            border: 1px solid var(--border);
            color: var(--blockquote);
            transition: all 0.3s ease;
        }
        .status.update { color: var(--link); border-color: var(--link); }
    </style>
</head>
<body>
    <div class="status" id="status">Connected</div>
    <div id="content">{{CONTENT}}</div>
    <script>
        let lastVer = 0;
        let statusEl = document.getElementById('status');
        async function check() {
            try {
                const r = await fetch('/api/version');
                const v = parseInt(await r.text());
                if (lastVer && v !== lastVer) {
                    const r2 = await fetch('/api/content');
                    const html = await r2.text();
                    document.getElementById('content').innerHTML = html;
                    statusEl.textContent = 'Updated ' + new Date().toLocaleTimeString();
                    statusEl.classList.add('update');
                    setTimeout(() => statusEl.classList.remove('update'), 1000);
                }
                lastVer = v;
            } catch(e) {
                statusEl.textContent = 'Disconnected';
            }
        }
        setInterval(check, 600);
        check();
    </script>
</body>
</html>"""

    def _render(self, text):
        if MARKDOWN_OK:
            md = markdown.Markdown(extensions=["fenced_code", "tables", "toc"])
            return md.convert(text)
        return self._simple_render(text)

    def _simple_render(self, text):
        """Fallback: very basic markdown when `markdown` package is missing."""
        import html as html_lib
        import re

        t = html_lib.escape(text)
        # Code blocks
        t = re.sub(r'```(\w+)?\n(.*?)```', r'<pre><code>\2</code></pre>', t, flags=re.DOTALL)
        t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
        # Headers
        t = re.sub(r'^(#{1,6})\s+(.*?)$', lambda m: f'<h{len(m.group(1))}>{m.group(2)}</h{len(m.group(1))}>', t, flags=re.MULTILINE)
        # Bold/italic
        t = re.sub(r'\*\*\*(.*?)\*\*\*', r'<strong><em>\1</em></strong>', t)
        t = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', t)
        t = re.sub(r'\*(.*?)\*', r'<em>\1</em>', t)
        # Lists
        t = re.sub(r'^\* (.*?)$', r'<li>\1</li>', t, flags=re.MULTILINE)
        t = re.sub(r'((?:<li>.*?</li>\n?)+)', r'<ul>\1</ul>', t, flags=re.DOTALL)
        t = re.sub(r'^\d+\.\s+(.*?)$', r'<li>\1</li>', t, flags=re.MULTILINE)
        # Links
        t = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', t)
        # Paragraphs (skip already wrapped)
        t = re.sub(r'^(?!<[hlu]|<li|<pre|<code|<hr|<table|<blockquote|<img)(.+)$', r'<p>\1</p>', t, flags=re.MULTILINE)
        t = re.sub(r'\n', '', t)
        return t

    def _start_server(self):
        plugin = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                if self.path == "/api/version":
                    self.send_response(200)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    with plugin.lock:
                        self.wfile.write(str(plugin.version).encode())

                elif self.path == "/api/content":
                    self.send_response(200)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.end_headers()
                    with plugin.lock:
                        self.wfile.write(plugin.html_body.encode("utf-8"))

                else:
                    self.send_response(200)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.end_headers()
                    with plugin.lock:
                        body = plugin.html_body
                    html = plugin.template.replace("{{CONTENT}}", body)
                    self.wfile.write(html.encode("utf-8"))

        self.server = ThreadedHTTPServer(("localhost", self.port), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def _update(self, buf=None):
        if buf is None:
            buf = self.nvim.current.buffer
        text = "\n".join(buf[:])
        body = self._render(text)
        with self.lock:
            self.html_body = body
            self.version += 1

    @pynvim.command("MdView", nargs="0", sync=False)
    def md_view(self, args, range):
        """啟動 Markdown 預覽"""
        self._update()
        if self.server is None:
            self._start_server()

        url = f"http://localhost:{self.port}"
        self.nvim.out_write(f"Markdown preview: {url}\n")

        if os.name == "nt":
            os.startfile(url)
        elif sys.platform == "darwin":
            webbrowser.open(url, new=2)
        else:
            webbrowser.open(url, new=2)

    @pynvim.command("MdViewStop", nargs="0", sync=False)
    def md_view_stop(self, args, range):
        """關閉預覽伺服器"""
        if self.server:
            self.server.shutdown()
            self.server = None
            self.nvim.out_write("Markdown preview stopped.\n")

    @pynvim.autocmd("TextChanged,TextChangedI,BufWritePost", sync=False)
    def on_buf_change(self):
        """緩衝區變更時自動更新"""
        if self.server is None:
            return
        ft = self.nvim.eval("&filetype")
        if ft != "markdown":
            return
        self._update()
