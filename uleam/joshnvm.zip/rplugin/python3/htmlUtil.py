import pynvim
import re
import os
import webbrowser
import threading
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer

@pynvim.plugin
class HtmlHelperPlugin(object):
    def __init__(self, nvim):
        self.nvim = nvim
        self.server_thread = None
        self.httpd = None
        self.server_port = 8080
        self.previewing_file = None

    # =========================================================================
    # 功能 1：預設插入 Tags
    # =========================================================================
    @pynvim.command('HtmlInsertTag', nargs=1)
    def insert_tag(self, args):
        """
        插入標籤。
        如果目前有選取文字 (Visual 模式)，會用標籤包覆它；
        若是 Normal 模式，則直接在游標處生成閉合標籤。
        """
        tag_name = args[0]
        mode = self.nvim.api.get_mode()['mode']

        if mode in ['v', 'V', '\x16']:  # Visual 模式
            # 獲取選取範圍的邊界
            self.nvim.api.command('normal! \x1b') # 離開 visual 模式以更新標記
            start_row, start_col = self.nvim.api.buf_get_mark(0, '<')
            end_row, end_col = self.nvim.api.buf_get_mark(0, '>')
            
            # 取得範圍內的文字（目前只處理單行或多行包覆）
            lines = self.nvim.api.buf_get_lines(0, start_row - 1, end_row, False)
            if not lines:
                return
                
            if start_row == end_row:
                # 單行包覆
                line = lines[0]
                selected = line[start_col:end_col + 1]
                new_line = line[:start_col] + f"<{tag_name}>{selected}</{tag_name}>" + line[end_col + 1:]
                self.nvim.api.buf_set_lines(0, start_row - 1, start_row, False, [new_line])
            else:
                # 多行包覆
                lines[0] = lines[0][:start_col] + f"<{tag_name}>" + lines[0][start_col:]
                # 注意字串長度改變對 end_col 的影響，此處採簡單換行包覆處理
                lines[-1] = lines[-1][:end_col + 1] + f"</{tag_name}>" + lines[-1][end_col + 1:]
                self.nvim.api.buf_set_lines(0, start_row - 1, end_row, False, lines)
        else:
            # Normal 模式：在目前游標位置直接插入空標籤，並把游標移到中間
            row, col = self.nvim.api.win_get_cursor(0)
            current_line = self.nvim.api.get_current_line()
            
            opening = f"<{tag_name}>"
            closing = f"</{tag_name}>"
            new_line = current_line[:col] + opening + closing + current_line[col:]
            
            self.nvim.api.set_current_line(new_line)
            # 將游標放到 <tag></tag> 的中間
            self.nvim.api.win_set_cursor(0, (row, col + len(opening)))

    @pynvim.command('HtmlInsertTemplate')
    def insert_template(self):
        """插入標準 HTML5 模板模板"""
        template = [
            "<!DOCTYPE html>",
            "<html lang=\"zh-TW\">",
            "<head>",
            "    <meta charset=\"UTF-8\">",
            "    <title>Document</title>",
            "</head>",
            "<body>",
            "    ",
            "</body>",
            "</html>"
        ]
        # 在游標當前位置覆寫或插入
        row, _ = self.nvim.api.win_get_cursor(0)
        self.nvim.api.buf_set_lines(0, row - 1, row, False, template)
        self.nvim.api.win_set_cursor(0, (row + 7, 4)) # 定位到 body 內部

    # =========================================================================
    # 功能 2：CRUD 操作 Text Objects (以游標所在的 HTML Tag 為主)
    # =========================================================================
    def _find_current_tag_bounds(self):
        """輔助函式：尋找游標當前所在的標籤範圍"""
        row, col = self.nvim.api.win_get_cursor(0)
        line = self.nvim.api.get_current_line()
        
        # 尋找包含游標位置的最內層標籤 (簡式正則，匹配 <div>text</div>)
        # 用於展示 CRUD 概念。生產環境建議使用更精密的 parser
        pattern = r'<([a-zA-Z1-6]+)[^>]*>(.*?)</\1>'
        for match in re.finditer(pattern, line):
            start, end = match.start(), match.end()
            if start <= col <= end:
                tag = match.group(1)
                content = match.group(2)
                content_start = match.start(2)
                content_end = match.end(2)
                return {
                    'tag': tag,
                    'line_str': line,
                    'row': row,
                    'full_start': start,
                    'full_end': end,
                    'content_start': content_start,
                    'content_end': content_end,
                    'content': content
                }
        return None

    @pynvim.command('HtmlReadTagContent')
    def read_tag_content(self):
        """【R】讀取/顯示目前游標所在標籤的內容"""
        bounds = self._find_current_tag_bounds()
        if bounds:
            self.nvim.out_write(f"Tag [{bounds['tag']}] 內容: {bounds['content']}\n")
        else:
            self.nvim.out_write("游標處未偵測到完整的單行 HTML 標籤。\n")

    @pynvim.command('HtmlUpdateTagContent', nargs=1)
    def update_tag_content(self, args):
        """【U】更新/修改目前標籤內部的文字內容"""
        new_text = args[0]
        bounds = self._find_current_tag_bounds()
        if bounds:
            line = bounds['line_str']
            new_line = line[:bounds['content_start']] + new_text + line[bounds['content_end']:]
            self.nvim.api.set_current_line(new_line)
        else:
            self.nvim.out_write("找不到可更新的標籤項目。\n")

    @pynvim.command('HtmlDeleteTagContent')
    def delete_tag_content(self):
        """【D】刪除目前標籤內部的文字內容，保留標籤外殼"""
        self.update_tag_content([""])

    @pynvim.command('HtmlDeleteTagEntire')
    def delete_tag_entire(self):
        """【D】刪除整個標籤（包含外殼與內容）"""
        bounds = self._find_current_tag_bounds()
        if bounds:
            line = bounds['line_str']
            new_line = line[:bounds['full_start']] + line[bounds['full_end']:]
            self.nvim.api.set_current_line(new_line)
        else:
            self.nvim.out_write("找不到可刪除的標籤項目。\n")

    # =========================================================================
    # 功能 3：預覽 Preview 網頁 (背景靜態伺服器 + 瀏覽器聯動)
    # =========================================================================
    @pynvim.command('HtmlPreviewStart')
    def preview_start(self):
        """開啟本地伺服器並在瀏覽器中即時預覽目前 HTML 檔案"""
        file_path = self.nvim.api.buf_get_name(0)
        if not file_path or not file_path.endswith('.html'):
            self.nvim.err_write("請在已儲存的 .html 檔案中執行此命令。\n")
            return

        self.previewing_file = file_path
        file_dir = os.path.dirname(file_path)
        file_name = os.path.basename(file_path)

        # 如果伺服器已經在跑了，就直接打開新網頁
        if self.server_thread and self.server_thread.is_alive():
            url = f"http://localhost:{self.server_port}/{file_name}"
            webbrowser.open(url)
            return

        # 建立一個切換工作目錄的自訂 Handler，鎖定在該 HTML 的資料夾
        class CustomHandler(SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=file_dir, **kwargs)

        def start_server():
            try:
                TCPServer.allow_reuse_address = True
                with TCPServer(("127.0.0.1", self.server_port), CustomHandler) as httpd:
                    self.httpd = httpd
                    self.nvim.async_call(lambda: self.nvim.out_write(f"本地預覽伺服器已啟動於 Port {self.server_port}\n"))
                    httpd.serve_forever()
            except Exception as e:
                self.nvim.async_call(lambda: self.nvim.err_write(f"伺服器啟動失敗: {str(e)}\n"))

        # 背景執行伺服器避免阻斷 Neovim
        self.server_thread = threading.Thread(target=start_server, daemon=True)
        self.server_thread.start()

        # 開啟瀏覽器
        url = f"http://localhost:{self.server_port}/{file_name}"
        webbrowser.open(url)

    @pynvim.command('HtmlPreviewStop')
    def preview_stop(self):
        """關閉預覽伺服器"""
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
            self.nvim.out_write("預覽伺服器已關閉。\n")
        else:
            self.nvim.out_write("伺服器並未執行。\n")

    @pynvim.autocmd('VimEnter', pattern='*.html', sync=True)
    def on_html_enter(self):
        """當進入 HTML 檔案時，在 Python 端綁定快捷鍵，不干擾 Lua"""
        opts = {'silent': True, 'noremap': True, 'buffer': True}
        
        # 1. 快速模板與快速包覆
        self.nvim.api.buf_set_keymap(0, 'n', '<Leader>tmpl', ':HtmlInsertTemplate<CR>', opts)
        self.nvim.api.buf_set_keymap(0, 'n', '<Leader>nsg', ':HtmlInsertTag p<CR>', opts) # 預設插入 p
        self.nvim.api.buf_set_keymap(0, 'v', '<Leader>nsg', ':HtmlInsertTag p<CR>', opts) # Visual 模式包覆 p
        
        # 2. Text_objs CRUD 操作鍵位
        self.nvim.api.buf_set_keymap(0, 'n', 'gcr', ':HtmlReadTagContent<CR>', opts)
        self.nvim.api.buf_set_keymap(0, 'n', 'gcd', ':HtmlDeleteTagContent<CR>', opts)
        self.nvim.api.buf_set_keymap(0, 'n', 'gcx', ':HtmlDeleteTagEntire<CR>', opts)
        # 更新操作因為需要帶參數，可以呼叫命令列等待使用者輸入：
        self.nvim.api.buf_set_keymap(0, 'n', 'gcu', ':HtmlUpdateTagContent ', {'silent': False, 'noremap': True, 'buffer': True})

        # 3. 預覽鍵位
        self.nvim.api.buf_set_keymap(0, 'n', '<Leader>pre', ':HtmlPreviewStart<CR>', opts)
        self.nvim.api.buf_set_keymap(0, 'n', '<Leader>spr', ':HtmlPreviewStop<CR>', opts)
