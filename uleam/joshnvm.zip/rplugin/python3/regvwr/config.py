# ~/.config/nvim/rplugin/python3/registers_viewer/config.py
"""
插件配置管理
"""


class Config:
    """Registers Viewer 配置"""
    
    def __init__(self, nvim):
        self.nvim = nvim
        self._load_config()
        
    def _load_config(self):
        """從 Neovim 變數載入配置"""
        # 預設值
        defaults = {
            'width': 60,
            'height': 30,
            'border_style': 'rounded',  # 'none', 'single', 'double', 'rounded'
            'show_empty': False,
            'max_content_length': 200,
            'auto_close': True,
            'auto_close_delay': 300,  # ms
        }
        
        # 從 g:registers_viewer_config 讀取使用者配置
        try:
            user_config = self.nvim.eval('get(g:, "registers_viewer_config", {})')
        except Exception:
            user_config = {}
            
        # 合併配置
        for key, default in defaults.items():
            value = user_config.get(key, default)
            setattr(self, key, value)
            
    def get(self, key, default=None):
        """取得配置項"""
        return getattr(self, key, default)
