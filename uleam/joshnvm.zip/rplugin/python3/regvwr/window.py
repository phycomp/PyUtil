# ~/.config/nvim/rplugin/python3/registers_viewer/window.py
"""
浮動視窗管理模組
"""

import pynvim


class FloatingWindow:
    """Neovim 浮動視窗管理器"""
    
    def __init__(self, nvim: pynvim.Nvim, config):
        self.nvim = nvim
        self.config = config
        self.bufnr = None
        self.winid = None
        
    def open(self, lines: list, highlights: list = None):
        """開啟浮動視窗"""
        # 建立緩衝區
        self.bufnr = self.nvim.api.create_buf(False, True)
        
        # 設定緩衝區內容
        self.nvim.api.buf_set_lines(self.bufnr, 0, -1, False, lines)
        
        # 設定緩衝區選項
        self.nvim.api.buf_set_option(self.bufnr, 'buftype', 'nofile')
        self.nvim.api.buf_set_option(self.bufnr, 'bufhidden', 'wipe')
        self.nvim.api.buf_set_option(self.bufnr, 'swapfile', False)
        self.nvim.api.buf_set_option(self.bufnr, 'filetype', 'registersviewer')
        
        # 計算視窗大小與位置
        editor_width = self.nvim.api.get_option('columns')
        editor_height = self.nvim.api.get_option('lines')
        
        width = min(self.config.width, editor_width - 4)
        height = min(len(lines), self.config.height, editor_height - 4)
        
        col = (editor_width - width) // 2
        row = (editor_height - height) // 2
        
        # 視窗配置
        win_config = {
            'relative': 'editor',
            'width': width,
            'height': height,
            'col': col,
            'row': row,
            'anchor': 'NW',
            'style': 'minimal',
            'border': self.config.border_style,
            'title': ' Registers ',
            'title_pos': 'center',
        }
        
        # 開啟浮動視窗
        self.winid = self.nvim.api.open_win(self.bufnr, True, win_config)
        
        # 設定視窗選項
        self.nvim.api.win_set_option(self.winid, 'cursorline', True)
        self.nvim.api.win_set_option(self.winid, 'number', False)
        self.nvim.api.win_set_option(self.winid, 'relativenumber', False)
        self.nvim.api.win_set_option(self.winid, 'wrap', True)
        self.nvim.api.win_set_option(self.winid, 'signcolumn', 'no')
        self.nvim.api.win_set_option(self.winid, 'foldcolumn', '0')
        
        # 設定語法高亮
        self._setup_syntax()
        
        # 套用高亮
        if highlights:
            self._apply_highlights(highlights)
        
        # 設定不可修改
        self.nvim.api.buf_set_option(self.bufnr, 'modifiable', False)
        
    def _setup_syntax(self):
        """設定語法高亮群組"""
        # 定義高亮群組
        highlights = {
            'RegistersTitle': {'fg': '#61AFEF', 'bg': '#282C34', 'bold': True},
            'RegistersGroup': {'fg': '#E5C07B', 'bg': '#282C34', 'bold': True},
            'RegistersContent': {'fg': '#ABB2BF', 'bg': '#282C34'},
            'RegistersNumbered': {'fg': '#98C379', 'bg': '#282C34'},
            'RegistersNamed': {'fg': '#C678DD', 'bg': '#282C34'},
            'RegistersReadOnly': {'fg': '#D19A66', 'bg': '#282C34'},
            'RegistersClipboard': {'fg': '#56B6C2', 'bg': '#282C34'},
            'RegistersHint': {'fg': '#5C6370', 'bg': '#282C34', 'italic': True},
        }
        
        for name, attrs in highlights.items():
            gui_attrs = []
            if attrs.get('bold'):
                gui_attrs.append('bold')
            if attrs.get('italic'):
                gui_attrs.append('italic')
            
            gui_str = ','.join(gui_attrs) if gui_attrs else 'NONE'
            
            cmd = (
                f'highlight {name} '
                f'guifg={attrs["fg"]} '
                f'guibg={attrs["bg"]} '
                f'gui={gui_str}'
            )
            self.nvim.command(cmd)
            
    def _apply_highlights(self, highlights: list):
        """套用行高亮"""
        ns_id = self.nvim.api.create_namespace('registers_viewer')
        
        for line_num, hl_group in highlights:
            self.nvim.api.buf_add_highlight(
                self.bufnr, ns_id, hl_group, line_num, 0, -1
            )
            
    def update_content(self, lines: list, highlights: list = None):
        """更新視窗內容"""
        if not self.bufnr:
            return
            
        self.nvim.api.buf_set_option(self.bufnr, 'modifiable', True)
        self.nvim.api.buf_set_lines(self.bufnr, 0, -1, False, lines)
        self.nvim.api.buf_set_option(self.bufnr, 'modifiable', False)
        
        # 清除舊高亮並重新套用
        if highlights:
            ns_id = self.nvim.api.create_namespace('registers_viewer')
            self.nvim.api.buf_clear_namespace(self.bufnr, ns_id, 0, -1)
            self._apply_highlights(highlights)
            
    def close(self):
        """關閉視窗"""
        if self.winid and self.nvim.api.win_is_valid(self.winid):
            self.nvim.api.win_close(self.winid, True)
        self.winid = None
        self.bufnr = None
