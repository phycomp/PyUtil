# ~/.config/nvim/rplugin/python3/registers_viewer/registers.py
"""
暫存器數據收集與處理
"""

import pynvim


class RegisterManager:
    """管理 Neovim 暫存器數據"""
    
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim
        
    def get_all_registers(self) -> dict:
        """取得所有暫存器內容"""
        registers = {}
        
        # 所有暫存器名稱
        all_registers = (
            ['"', '-'] +                           # 特殊
            [str(i) for i in range(10)] +         # 數字
            [chr(i) for i in range(ord('a'), ord('z')+1)] +  # 小寫
            [chr(i) for i in range(ord('A'), ord('Z')+1)] +  # 大寫
            ['.', '%', ':', '#', '/', '='] +      # 唯讀
            ['*', '+', '~', '_']                   # 剪貼簿/黑洞
        )
        
        for reg in all_registers:
            try:
                content = self.nvim.eval(f'getreg("{self._escape(reg)}")')
                if content and content.strip():
                    registers[reg] = content
            except Exception:
                continue
                
        return registers
    
    def get_register(self, name: str) -> str:
        """取得單一暫存器內容"""
        try:
            return self.nvim.eval(f'getreg("{self._escape(name)}")')
        except Exception:
            return ""
    
    def set_register(self, name: str, content: str):
        """設定暫存器內容"""
        escaped = content.replace('"', '\\"').replace('\n', '\\n')
        self.nvim.command(f'let @{name} = "{escaped}"')
    
    def get_register_info(self, name: str) -> dict:
        """取得暫存器詳細資訊"""
        info = {
            'name': name,
            'content': self.get_register(name),
            'type': self.nvim.eval(f'getregtype("{self._escape(name)}")'),
        }
        return info
    
    def _escape(self, reg: str) -> str:
        """轉義暫存器名稱供 eval 使用"""
        # 處理特殊字元
        escapes = {
            '"': '\\"',
            '\\': '\\\\',
            '|': '\\|',
        }
        return escapes.get(reg, reg)
    
    def get_yank_history(self, limit: int = 10) -> list:
        """取得 yank 歷史 (從數字暫存器)"""
        history = []
        for i in range(min(limit, 10)):
            content = self.get_register(str(i))
            if content:
                history.append({
                    'register': str(i),
                    'content': content[:100],  # 截斷顯示
                    'full_content': content,
                })
        return history
