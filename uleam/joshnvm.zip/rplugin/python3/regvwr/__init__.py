# ~/.config/nvim/rplugin/python3/regvwr/__init__.py
import pynvim
from .window import FloatingWindow
from .registers import RegisterManager
from .config import Config


@pynvim.plugin
class RegistersViewer:
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim
        self.config = Config(nvim)
        self.reg_manager = RegisterManager(nvim)
        self.window = None
        self.is_open = False

        # 暫存器分類
        self.register_groups = {
            'unnamed': ['"'],
            'numbered': ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            'named': [chr(i) for i in range(ord('a'), ord('z')+1)],
            'read_only': ['.', '%', ':', '#', '/'],
            'alternate': ['-', '*', '+', '~', '_'],
            'expression': ['='],
            'selection': ['*', '+'],
            'drop': ['~'],
            'search': ['/'],
        }

    # ========== Commands ==========
    @pynvim.command('RegistersView', nargs='0', sync=False)
    def open_registers_view(self, args):
        """開啟暫存器瀏覽視窗"""
        if self.is_open:
            self.close_window()
            return
        self.show_registers()

    @pynvim.command('RegistersClose', nargs='0', sync=False)
    def close_registers_view(self, args):
        """關閉暫存器瀏覽視窗"""
        self.close_window()

    @pynvim.command('RegistersRefresh', nargs='0', sync=False)
    def refresh_registers_view(self, args):
        """重新整理暫存器內容"""
        if self.is_open:
            self.update_content()

    # ========== Functions ==========
    @pynvim.function('RegistersViewerToggle', sync=False)
    def toggle_viewer(self, args):
        """切換視窗顯示/隱藏"""
        if self.is_open:
            self.close_window()
        else:
            self.show_registers()

    @pynvim.function('RegistersViewerSelect', sync=True)
    def select_register(self, args):
        """選擇暫存器並貼上"""
        register = args[0] if args else '"'
        self.close_window()
        self.nvim.command(f'normal! "{register}p')
        self.nvim.out_write(f"Pasted from register '{register}'\n")

    @pynvim.function('RegistersViewerGetContent', sync=True)
    def get_register_content(self, args):
        """取得指定暫存器內容 (原 RegistersViewerHelper 的功能)"""
        reg = args[0] if args else '"'
        return self.nvim.eval(f'getreg("{self._escape_reg(reg)}")')

    # ========== Helper Methods ==========
    def _escape_reg(self, reg: str) -> str:
        """轉義暫存器名稱供 eval 使用"""
        escapes = {'"': '\\"', '\\': '\\\\', '|': '\\|'}
        return escapes.get(reg, reg)

    def show_registers(self):
        """建立並顯示暫存器視窗"""
        try:
            registers_data = self.reg_manager.get_all_registers()
            self.window = FloatingWindow(self.nvim, self.config)
            lines, highlights = self._format_registers(registers_data)
            self.window.open(lines, highlights)
            self.is_open = True
            self._setup_keymaps()
            self._setup_autocmds()
            self.nvim.out_write("Registers viewer opened\n")
        except Exception as e:
            self.nvim.err_write(f"Registers viewer error: {str(e)}\n")

    def _format_registers(self, data: dict) -> tuple:
        """格式化暫存器數據"""
        lines = []
        highlights = []
        line_num = 0

        # 標題
        title = " 📋 REGISTERS "
        lines.append(title + "─" * (self.config.width - len(title) - 2))
        highlights.append((line_num, 'RegistersTitle'))
        line_num += 1

        # Unnamed
        if data.get('"'):
            lines.append("")
            line_num += 1
            lines.append(" ▎ Unnamed (\")")
            highlights.append((line_num, 'RegistersGroup'))
            line_num += 1
            content = self._truncate(data['"'], self.config.width - 8)
            lines.append(f"   {content}")
            highlights.append((line_num, 'RegistersContent'))
            line_num += 1

        # Numbered
        numbered = [f"{k}: {self._truncate(v, self.config.width - 8)}"
                   for k, v in data.items()
                   if k in self.register_groups['numbered'] and v]
        if numbered:
            lines.append("")
            line_num += 1
            lines.append(" ▎ Numbered (0-9)")
            highlights.append((line_num, 'RegistersGroup'))
            line_num += 1
            for item in numbered:
                lines.append(f"   {item}")
                highlights.append((line_num, 'RegistersNumbered'))
                line_num += 1

        # Named
        named = [(k, v) for k, v in data.items()
                if k in self.register_groups['named'] and v]
        if named:
            lines.append("")
            line_num += 1
            lines.append(" ▎ Named (a-z)")
            highlights.append((line_num, 'RegistersGroup'))
            line_num += 1
            for k, v in named:
                content = self._truncate(v, self.config.width - 8)
                lines.append(f"   {k}: {content}")
                highlights.append((line_num, 'RegistersNamed'))
                line_num += 1

        # Read-Only
        readonly = [(k, v) for k, v in data.items()
                   if k in self.register_groups['read_only'] and v]
        if readonly:
            lines.append("")
            line_num += 1
            lines.append(" ▎ Read-Only")
            highlights.append((line_num, 'RegistersGroup'))
            line_num += 1
            for k, v in readonly:
                content = self._truncate(v, self.config.width - 8)
                lines.append(f"   {k}: {content}")
                highlights.append((line_num, 'RegistersReadOnly'))
                line_num += 1

        # Clipboard
        clipboard = [(k, v) for k, v in data.items()
                    if k in ['*', '+'] and v]
        if clipboard:
            lines.append("")
            line_num += 1
            lines.append(" ▎ Clipboard (*, +)")
            highlights.append((line_num, 'RegistersGroup'))
            line_num += 1
            for k, v in clipboard:
                content = self._truncate(v, self.config.width - 8)
                lines.append(f"   {k}: {content}")
                highlights.append((line_num, 'RegistersClipboard'))
                line_num += 1

        # Hint
        lines.append("")
        line_num += 1
        hint = " Press key to paste | <Esc> or q to close | r to refresh "
        lines.append(hint)
        highlights.append((line_num, 'RegistersHint'))

        return lines, highlights

    def _truncate(self, text: str, max_len: int) -> str:
        """截斷過長內容"""
        text = text.replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t')
        if len(text) > max_len:
            return text[:max_len-3] + "..."
        return text

    def _setup_keymaps(self):
        """設定視窗內按鍵映射"""
        bufnr = self.window.bufnr
        self.nvim.command(f'nnoremap <buffer> <silent> <Esc> :RegistersClose<CR>')
        self.nvim.command(f'nnoremap <buffer> <silent> q :RegistersClose<CR>')
        self.nvim.command(f'nnoremap <buffer> <silent> r :RegistersRefresh<CR>')

        all_keys = (self.register_groups['named'] +
                   self.register_groups['numbered'] +
                   ['"', '*', '+', '-', '.', '%', ':', '#', '/'])

        for key in all_keys:
            safe_key = key.replace('"', '\\"').replace('|', '\\|')
            self.nvim.command(
                f'nnoremap <buffer> <silent> {safe_key} '
                f':call RegistersViewerSelect("{safe_key}")<CR>'
            )

    def _setup_autocmds(self):
        """設定自動命令"""
        self.nvim.command('autocmd WinLeave <buffer> ++once RegistersClose')

    def close_window(self):
        """關閉視窗"""
        if self.window:
            self.window.close()
            self.window = None
        self.is_open = False

    def update_content(self):
        """更新視窗內容"""
        if not self.window:
            return
        registers_data = self.reg_manager.get_all_registers()
        lines, highlights = self._format_registers(registers_data)
        self.window.update_content(lines, highlights)
