# ~/.config/nvim/rplugin/python3/help_float.py
import pynvim
from pynvim.api.common import NvimError

@pynvim.plugin
class HelpFloat:
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim

    @pynvim.command("HelpFloat", nargs=1, complete='help', sync=True)
    def help_float(self, args):
        if not args or not isinstance(args, list):
            return
        
        topic = args[0].strip()
        if not topic:
            return

        # 1. 安全地記錄查詢前的狀態
        start_buf = self.nvim.current.buffer

        # 2. 在背景靜默載入說明文件
        try:
            self.nvim.command(f'silent! help {topic}')
        except NvimError:
            self.nvim.err_write(f'Help topic not found: {topic}\n')
            return
        
        # 紀錄原生 help 跳轉後的精確位置與該 buffer 的 handle
        help_win = self.nvim.current.window
        help_buf = self.nvim.current.buffer
        
        # 關鍵修正：win_get_cursor 回傳 [row, col]，在此精確解構
        cursor_row, cursor_col = self.nvim.api.win_get_cursor(help_win.handle)
        
        lines = help_buf[:]

        # 3. 立刻跳回原 buffer，並將產生的後台 help buffer 徹底消滅 (wipeout)
        self.nvim.current.buffer = start_buf
        if help_buf.handle != start_buf.handle:
            self.nvim.command(f'silent! bwipeout! {help_buf.handle}')

        # 4. 建立一個全新、乾淨、獨立的浮動視窗專用 Buffer (不列入 :ls)
        buf = self.nvim.api.create_buf(False, True)
        buf.options['buftype'] = 'nofile'
        buf.options['bufhidden'] = 'wipe'
        buf.options['filetype'] = 'help'  # 保持原生的 help 語法高亮
        buf[:] = lines
        buf.options['modifiable'] = False

        # 5. 計算浮動視窗的尺寸與編輯器置中位置
        columns = self.nvim.eval('&columns')
        win_lines = self.nvim.eval('&lines')
        
        width = min(80, columns - 4)
        height = min(len(lines), win_lines - 4, 30)
        
        opts = {
            'relative': 'editor',
            'width': width,
            'height': height,
            'col': (columns - width) // 2,
            'row': (win_lines - height) // 2,
            'style': 'minimal',
            'border': 'rounded'
        }
        
        # 6. 開啟浮動視窗並將焦點移入
        win = self.nvim.api.open_win(buf, True, opts)

        # 同步游標位置並居中主題
        try:
            # 確保行號是整數比較，並安全設定回浮動視窗
            safe_row = min(cursor_row, len(lines))
            self.nvim.api.win_set_cursor(win, [safe_row, cursor_col])
            self.nvim.command('normal! zz')
        except NvimError:
            pass

        # 7. 功能綁定：為此浮動視窗綁定 q 與 <Esc> 快速關閉
        for k in ['q', '<Esc>']:
            self.nvim.api.buf_set_keymap(
                buf.handle, 'n', k, ':close<CR>',
                {'noremap': True, 'silent': True}
            )

        # 8. 安全機制：滑鼠或焦點意外移開時自動關閉視窗
        self.nvim.api.exec(
            f'autocmd WinLeave <buffer={buf.handle}> ++once silent! call nvim_win_close({win}, 1)',
            False
        )

    @pynvim.autocmd("VimEnter", sync=True)
    def setup_map(self):
        self.nvim.command('nnoremap <leader>flh :HelpFloat ')
