import pynvim

@pynvim.plugin
class ShadaViewer(object):
    def __init__(self, nvim):
        self.nvim = nvim
        self.win_id = None
        self.buf_id = None
        self.line_to_reg = {} 

    @pynvim.autocmd('VimEnter', sync=False)
    def on_vimenter(self):
        # 綁定暫存器檢視器 (<leader>sv)
        self.nvim.api.set_keymap(
            'n', '<leader>sv', ':ShadaView<CR>', 
            {'silent': True, 'noremap': True, 'desc': '開啟 ShaDa 暫存器檢視器'}
        )
        # 綁定歷史紀錄檢視器 (<leader>sh)
        self.nvim.api.set_keymap(
            'n', '<leader>sh', ':ShadaHistory<CR>', 
            {'silent': True, 'noremap': True, 'desc': '開啟 ShaDa 歷史紀錄檢視器'}
        )

    def _create_floating_window(self, title, data, highlight_commands):
        """通用邏輯：建立居中的圓角浮動視窗"""
        if self.win_id and self.nvim.api.win_is_valid(self.win_id):
            self.nvim.api.win_close(self.win_id, True)
            self.win_id = None
            return

        ui = self.nvim.api.list_uis()[0]
        screen_width = ui['width']
        screen_height = ui['height']
        width = int(screen_width * 0.7)
        height = int(screen_height * 0.6)
        row = int((screen_height - height) / 2) - 1
        col = int((screen_width - width) / 2)

        self.buf_id = self.nvim.api.create_buf(False, True)
        self.nvim.api.buf_set_lines(self.buf_id, 0, -1, False, data)

        # 渲染語法高亮
        ns_id = self.nvim.api.create_namespace('shada_viewer_hl')
        for line_idx, start_col, end_col, hl_group in highlight_commands:
            self.nvim.api.buf_add_highlight(
                self.buf_id, ns_id, hl_group, line_idx, start_col, end_col
            )

        win_opts = {
            'relative': 'editor',
            'width': width,
            'height': height,
            'row': row,
            'col': col,
            'style': 'minimal',
            'border': 'rounded',
            'title': f' {title} ',
            'title_pos': 'center'
        }

        self.win_id = self.nvim.api.open_win(self.buf_id, True, win_opts)
        self.nvim.command('setlocal cursorline')

        # 基礎退出快捷鍵
        close_opts = {'silent': True, 'noremap': True}  #, 'buffer': self.buf_id}
        self.nvim.api.buf_set_keymap(self.buf_id, 'n', 'q', ':q<CR>', close_opts)
        self.nvim.api.buf_set_keymap(self.buf_id, 'n', '<Esc>', ':q<CR>', close_opts)

    # ==================== 1. Registers Viewer ====================
    @pynvim.command('ShadaView')
    def shada_view(self):
        registers = ['"', '*', '+', '-'] + [str(i) for i in range(10)] + [chr(i) for i in range(97, 123)]
        shada_data = []
        highlight_commands = []
        self.line_to_reg = {}

        current_line_idx = 0
        for reg in registers:
            try:
                reg_type = self.nvim.funcs.getregtype(reg)
                reg_content = self.nvim.funcs.getreg(reg)
                if reg_content and reg_content.strip():
                    title_text = f' ─── Register [{reg}] ({reg_type}) ───'
                    shada_data.append(title_text)
                    self.line_to_reg[current_line_idx] = reg
                    highlight_commands.append((current_line_idx, 0, len(title_text), 'Identifier'))
                    current_line_idx += 1

                    for line in reg_content.splitlines():
                        content_text = f'  {line}'
                        shada_data.append(content_text)
                        self.line_to_reg[current_line_idx] = reg
                        highlight_commands.append((current_line_idx, 2, len(content_text), 'String'))
                        current_line_idx += 1

                    shada_data.append('')
                    current_line_idx += 1
            except Exception:
                continue

        if not shada_data:
            self.nvim.out_write("沒有找到任何有效的暫存器內容。\n")
            return

        self._create_floating_window("ShaDa Registers Viewer (<CR> to Paste)", shada_data, highlight_commands)
        
        # 綁定暫存器專屬的 Enter 貼上功能
        if self.buf_id:
            self.nvim.api.buf_set_keymap(
                self.buf_id, 'n', '<CR>', ':ShadaPaste<CR>', {'silent': True, 'noremap': True}  #, 'buffer': self.buf_id}
            )

    @pynvim.command('ShadaPaste')
    def shada_paste(self):
        cursor_pos = self.nvim.api.win_get_cursor(self.win_id)
        current_line_idx = cursor_pos[0] - 1
        reg_name = self.line_to_reg.get(current_line_idx)

        if reg_name:
            if self.win_id and self.nvim.api.win_is_valid(self.win_id):
                self.nvim.api.win_close(self.win_id, True)
                self.win_id = None
            keys = self.nvim.api.replace_termcodes(f'"{reg_name}p', True, True, True)
            self.nvim.api.feedkeys(keys, 'n', False)
        else:
            self.nvim.out_write("游標所在位置未偵測到有效的暫存器內容。\n")

    # ==================== 2. History Viewer (新增) ====================
    @pynvim.command('ShadaHistory')
    def shada_history(self):
        history_types = {
            'cmd': ' 指令歷史 (Command History) ',
            'search': ' 搜尋歷史 (Search History) ',
            'expr': ' 表達式歷史 (Expression History) ',
            'input': ' 輸入歷史 (Input History) '
        }
        
        history_data = []
        highlight_commands = []
        current_line_idx = 0

        for h_type, label in history_types.items():
            # 撈取該類型的歷史紀錄清單
            try:
                # gethistory 回傳陣列，我們將其反轉 (reverse) 讓最新的紀錄排在最上面
                records = list(reversed(self.nvim.funcs.gethistory(h_type)))
            except Exception:
                records = []

            if records:
                # 歷史分類大標題
                title_text = f' ❖{label}❖'
                history_data.append(title_text)
                highlight_commands.append((current_line_idx, 0, len(title_text), 'Macro')) # 使用 Macro 高亮群組
                current_line_idx += 1
                
                # 寫入歷史內容 (最多取前 15 筆避免畫面過長，可視需求調整)
                for i, item in enumerate(records[:15]):
                    prefix = f' [{i+1}] '
                    line_text = f'{prefix}{item}'
                    history_data.append(line_text)
                    
                    # 序號高亮用 Comment，內容高亮用 Type
                    highlight_commands.append((current_line_idx, 0, len(prefix), 'Comment'))
                    highlight_commands.append((current_line_idx, len(prefix), len(line_text), 'Type'))
                    current_line_idx += 1
                
                history_data.append('')
                current_line_idx += 1

        if not history_data:
            self.nvim.out_write("沒有找到任何 ShaDa 歷史紀錄。\n")
            return

        # 呼叫視窗生成
        self._create_floating_window("ShaDa History Viewer", history_data, highlight_commands)
