訊息="""
    969  %s/temp_layout/佈局/g
    970  %s/signal_width/訊號寬度/g
    971  %s/font_scale/字型縮放/g
    972  %s/線厚度μ
    973  %s/calculate_layer_positions/各層位置/g
    974  %s/layer_positions/層位置
    975  %s/layer_positions/層位置/g
    976  %s/total_width_mm/線總寬度/g
    977  %s/total_height_mm/線厚度m/g
    978  %s/total_thick_um/線厚度μ/g
    979  %s/signal_width_mm/訊號寬度/g
    980  %s/layout/佈局/g
    981  %s/n_channels/通道數/g
    982  %s/pitch_mm/訊號間距/g
    983  %s/total_width_mm/線總寬/g
"""
from re import search
容器=[]
for line in 訊息.split('\n'):
  if mtch:=search(r'/(\w+)/', line):
    模式=mtch.group(1)
    if not 容器.count(模式):
      print(line.split()[-1])
      容器.append(模式)
print(', '.join(容器))
