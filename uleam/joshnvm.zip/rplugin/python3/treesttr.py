# ============================================================================
# treesitter-float.nvim - pynvim 版本
# Neovim 內建 Tree-sitter 浮動視窗管理插件
# ============================================================================
# 功能：
#   1. 浮動視窗列出所有支援的語言/已安裝的 parser
#   2. 瀏覽語言列表（j/k 上下移動）
#   3. 安裝/移除 parser（i/x 鍵）
#   4. 啟用語言高亮（Enter 鍵，反白當前 buffer）
#   5. 按 ESC/q 關閉浮動視窗
#
# 安裝方式：
#   mkdir -p ~/.config/nvim/rplugin/python3
#   將本文件存為 ~/.config/nvim/rplugin/python3/treesitter_float.py
#   在 Neovim 中執行 :UpdateRemotePlugins
#   重啟 Neovim
#
# 使用方法：
#   :TSFloat              -- 開啟浮動視窗
#   :TSFloatInstall lua   -- 直接安裝指定語言的 parser
#   :TSFloatRemove  lua   -- 直接移除指定語言的 parser
#
# 需求：
#   - Neovim 0.12+
#   - pynvim (pip install pynvim)
#   - tree-sitter CLI（安裝 parser 時需要）
#   - git（安裝 parser 時需要）
#   - C compiler（編譯 parser 時需要）
# ============================================================================

import pynvim
import threading


# Neovim 0.12+ 內建的 parser 列表
BUILTIN_PARSERS = {
    "c": True,
    "lua": True,
    "markdown": True,
    "markdown_inline": True,
    "query": True,
    "vim": True,
    "vimdoc": True,
    "diff": True,
}


@pynvim.plugin
class TreeSitterFloatPlugin:
    """Neovim 內建 Tree-sitter 浮動視窗管理插件"""

    def __init__(self, nvim):
        self.nvim = nvim
        self.config = {
            "width_ratio": 0.70,
            "height_ratio": 0.75,
            "border": "rounded",
            "parser_install_dir": self.nvim.funcs.stdpath("data") + "/site/parser",
            "query_install_dir": self.nvim.funcs.stdpath("config") + "/queries",
            "show_builtin": True,
            "confirm_install": True,
            "confirm_remove": True,
            "repos": {
                "python": "https://github.com/tree-sitter/tree-sitter-python",
                "javascript": "https://github.com/tree-sitter/tree-sitter-javascript",
                "typescript": "https://github.com/tree-sitter/tree-sitter-typescript",
                "tsx": "https://github.com/tree-sitter/tree-sitter-typescript",
                "rust": "https://github.com/tree-sitter/tree-sitter-rust",
                "go": "https://github.com/tree-sitter/tree-sitter-go",
                "bash": "https://github.com/tree-sitter/tree-sitter-bash",
                "html": "https://github.com/tree-sitter/tree-sitter-html",
                "css": "https://github.com/tree-sitter/tree-sitter-css",
                "json": "https://github.com/tree-sitter/tree-sitter-json",
                "yaml": "https://github.com/tree-sitter/tree-sitter-yaml",
                "toml": "https://github.com/tree-sitter/tree-sitter-toml",
                "cpp": "https://github.com/tree-sitter/tree-sitter-cpp",
                "java": "https://github.com/tree-sitter/tree-sitter-java",
                "ruby": "https://github.com/tree-sitter/tree-sitter-ruby",
                "php": "https://github.com/tree-sitter/tree-sitter-php",
                "sql": "https://github.com/tree-sitter/tree-sitter-sql",
                "regex": "https://github.com/tree-sitter/tree-sitter-regex",
                "dockerfile": "https://github.com/camdencheek/tree-sitter-dockerfile",
                "graphql": "https://github.com/tree-sitter/tree-sitter-graphql",
                "scala": "https://github.com/tree-sitter/tree-sitter-scala",
                "kotlin": "https://github.com/tree-sitter/tree-sitter-kotlin",
                "swift": "https://github.com/tree-sitter/tree-sitter-swift",
                "dart": "https://github.com/tree-sitter/tree-sitter-dart",
                "elixir": "https://github.com/tree-sitter/tree-sitter-elixir",
                "haskell": "https://github.com/tree-sitter/tree-sitter-haskell",
                "ocaml": "https://github.com/tree-sitter/tree-sitter-ocaml",
                "zig": "https://github.com/tree-sitter/tree-sitter-zig",
                "nim": "https://github.com/tree-sitter/tree-sitter-nim",
                "julia": "https://github.com/tree-sitter/tree-sitter-julia",
                "r": "https://github.com/tree-sitter/tree-sitter-r",
                "perl": "https://github.com/tree-sitter/tree-sitter-perl",
                "latex": "https://github.com/tree-sitter/tree-sitter-latex",
                "vue": "https://github.com/tree-sitter/tree-sitter-vue",
                "svelte": "https://github.com/tree-sitter/tree-sitter-svelte",
                "astro": "https://github.com/virchau13/tree-sitter-astro",
                "prisma": "https://github.com/victorhqc/tree-sitter-prisma",
                "cmake": "https://github.com/tree-sitter/tree-sitter-cmake",
                "make": "https://github.com/tree-sitter/tree-sitter-make",
            },
        }
        self.state = {
            "float_buf": None,
            "float_win": None,
            "ns_id": None,
            "languages": [],
            "cursor_line": 1,
        }

    # -------------------------------------------------------------------------
    # 工具函數
    # -------------------------------------------------------------------------

    def _notify(self, msg, level="INFO"):
        """透過 vim.notify 顯示訊息"""
        level_map = {
            "INFO": "vim.log.levels.INFO",
            "WARN": "vim.log.levels.WARN",
            "ERROR": "vim.log.levels.ERROR",
        }
        lua_level = level_map.get(level, "vim.log.levels.INFO")
        safe_msg = msg.replace('"', '\\"').replace("\n", "\\n")
        self.nvim.command('lua vim.notify("{}", {})'.format(safe_msg, lua_level))

    def _has_treesitter_cli(self):
        return self.nvim.funcs.executable("tree-sitter") == 1

    def _has_git(self):
        return self.nvim.funcs.executable("git") == 1

    def _is_parser_installed(self, lang):
        parser_path = self.config["parser_install_dir"] + "/" + lang + ".so"
        return self.nvim.funcs.filereadable(parser_path) == 1

    def _get_installed_parsers(self):
        installed = {}
        pattern = self.config["parser_install_dir"] + "/*.so"
        files = self.nvim.funcs.glob(pattern, 0, 1)
        for f in files:
            name = self.nvim.funcs.fnamemodify(f, ":t:r")
            installed[name] = True
        return installed

    def _collect_languages(self):
        langs = []
        seen = {}
        installed = self._get_installed_parsers()

        # 內建 parser
        if self.config["show_builtin"]:
            for lang in BUILTIN_PARSERS:
                seen[lang] = True
                langs.append({
                    "lang": lang,
                    "installed": True,
                    "builtin": True,
                    "repo": None,
                })

        # 配置中的倉庫語言
        for lang, repo in self.config["repos"].items():
            if lang not in seen:
                seen[lang] = True
                langs.append({
                    "lang": lang,
                    "installed": lang in installed,
                    "builtin": lang in BUILTIN_PARSERS,
                    "repo": repo,
                })

        # 已安裝但不在上述列表中的
        for lang in installed:
            if lang not in seen:
                seen[lang] = True
                langs.append({
                    "lang": lang,
                    "installed": True,
                    "builtin": lang in BUILTIN_PARSERS,
                    "repo": None,
                })

        # 排序：已安裝在前，然後按字母排序
        langs.sort(key=lambda x: (not x["installed"], x["lang"]))
        return langs

    # -------------------------------------------------------------------------
    # Float Window
    # -------------------------------------------------------------------------

    def _open_float_window(self):
        editor_width = self.nvim.options["columns"]
        editor_height = self.nvim.options["lines"]

        win_width = int(editor_width * self.config["width_ratio"])
        win_height = int(editor_height * self.config["height_ratio"])
        row = int((editor_height - win_height) / 2)
        col = int((editor_width - win_width) / 2)

        buf = self.nvim.api.create_buf(False, True)
        self.nvim.api.buf_set_option(buf, "buftype", "nofile")
        self.nvim.api.buf_set_option(buf, "bufhidden", "wipe")
        self.nvim.api.buf_set_option(buf, "swapfile", False)
        self.nvim.api.buf_set_option(buf, "modifiable", True)

        title = " 🌳 Tree-sitter Parser Manager "
        footer = " i=install x=remove h=highlight r=refresh q/ESC=close "

        opts = {
            "relative": "editor",
            "width": win_width,
            "height": win_height,
            "row": row,
            "col": col,
            "anchor": "NW",
            "style": "minimal",
            "border": self.config["border"],
            "title": title,
            "title_pos": "center",
            "footer": footer,
            "footer_pos": "center",
            "zindex": 50,
        }

        win = self.nvim.api.open_win(buf, True, opts)

        self.nvim.api.win_set_option(win, "cursorline", True)
        self.nvim.api.win_set_option(win, "number", False)
        self.nvim.api.win_set_option(win, "relativenumber", False)
        self.nvim.api.win_set_option(win, "wrap", False)
        self.nvim.api.win_set_option(win, "signcolumn", "no")
        self.nvim.api.win_set_option(win, "foldcolumn", "0")

        return buf, win

    # -------------------------------------------------------------------------
    # 渲染
    # -------------------------------------------------------------------------

    def _render(self, buf, win):
        lines = []
        win_width = self.nvim.api.win_get_width(win)
        self.state["languages"] = self._collect_languages()

        total = len(self.state["languages"])
        installed_count = sum(1 for l in self.state["languages"] if l["installed"])

        lines.append(
            "  Languages: {} total │ {} installed │ {} available".format(
                total, installed_count, total - installed_count
            )
        )
        lines.append("─" * win_width)

        for item in self.state["languages"]:
            icon = "✓" if item["installed"] else "✗"
            if item["builtin"]:
                tag = "[builtin]"
            elif item["repo"]:
                tag = "[external]"
            else:
                tag = ""
            line = " {:1s} {:20s} {:12s} {}".format(
                icon, item["lang"], tag, item["repo"] or ""
            )
            if len(line) > win_width:
                line = line[: win_width - 3] + "..."
            lines.append(line)

        lines.append("─" * win_width)
        lines.append("  j/k=move i=install x=remove h=highlight r=refresh q=close")

        self.nvim.api.buf_set_lines(buf, 0, -1, False, lines)

        if self.state["ns_id"] is None:
            self.state["ns_id"] = self.nvim.api.create_namespace("treesitter-float")
        self.nvim.api.buf_clear_namespace(buf, self.state["ns_id"], 0, -1)

        # 標題高亮
        self.nvim.api.buf_add_highlight(buf, self.state["ns_id"], "Title", 0, 0, -1)

        # 各行狀態高亮
        for i, item in enumerate(self.state["languages"]):
            row = i + 1  # 跳過標題行（第0行）和分隔線（第1行）
            hl_group = "DiffAdd" if item["installed"] else "Comment"
            self.nvim.api.buf_add_highlight(buf, self.state["ns_id"], hl_group, row, 0, -1)

        # 移動游標到第一個語言（第3行，1-based）
        if self.state["languages"]:
            self.nvim.api.win_set_cursor(win, [3, 0])
            self.state["cursor_line"] = 1

    # -------------------------------------------------------------------------
    # 核心操作
    # -------------------------------------------------------------------------

    def _get_current_lang(self):
        """取得當前游標對應的語言"""
        if not self.state["float_win"]:
            return None
        if not self.nvim.api.win_is_valid(self.state["float_win"]):
            return None
        cursor = self.nvim.api.win_get_cursor(self.state["float_win"])
        line_idx = cursor[0]
        # 第1行=標題, 第2行=分隔線, 語言從第3行開始
        lang_idx = line_idx - 2
        if lang_idx < 1 or lang_idx > len(self.state["languages"]):
            return None
        return self.state["languages"][lang_idx - 1]

    def _install_parser(self, lang):
        """安裝指定語言的 parser"""
        if lang in BUILTIN_PARSERS:
            self._notify("「{}」是內建 parser，無需安裝".format(lang), "INFO")
            return

        if self._is_parser_installed(lang):
            self._notify("Parser '{}' 已安裝".format(lang), "INFO")
            return

        repo = self.config["repos"].get(lang)
        if not repo:
            self._notify("未知的語言 '{}'，請在配置中指定 repo".format(lang), "ERROR")
            return

        if not self._has_git():
            self._notify("需要 git 才能安裝 parser", "ERROR")
            return

        if not self._has_treesitter_cli():
            self._notify("需要 tree-sitter CLI 才能編譯 parser", "ERROR")
            return

        if self.config["confirm_install"]:
            choice = self.nvim.funcs.confirm(
                "安裝 parser '{}' ?".format(lang), "&Yes\n&No", 2
            )
            if choice != 1:
                return

        self._notify("正在安裝 '{}' parser...".format(lang), "INFO")

        def do_install():
            tmpdir = self.nvim.funcs.tempname()
            self.nvim.funcs.mkdir(tmpdir, "p")

            # 1. git clone
            clone_cmd = "git clone --depth 1 {} {} 2>&1".format(repo, tmpdir)
            clone_out = self.nvim.funcs.system(clone_cmd)
            if self.nvim.eval("v:shell_error") != 0:
                self._notify("git clone 失敗: " + clone_out, "ERROR")
                self.nvim.funcs.system(
                    "rm -rf " + self.nvim.funcs.shellescape(tmpdir)
                )
                return

            # 2. tree-sitter build
            build_cmd = "cd {} && tree-sitter build -o parser.so 2>&1".format(
                self.nvim.funcs.shellescape(tmpdir)
            )
            build_out = self.nvim.funcs.system(build_cmd)
            if self.nvim.eval("v:shell_error") != 0:
                self._notify("編譯失敗: " + build_out, "ERROR")
                self.nvim.funcs.system(
                    "rm -rf " + self.nvim.funcs.shellescape(tmpdir)
                )
                return

            # 3. 複製 parser.so
            self.nvim.funcs.mkdir(self.config["parser_install_dir"], "p")
            parser_src = tmpdir + "/parser.so"
            parser_dst = self.config["parser_install_dir"] + "/" + lang + ".so"
            cp_cmd = "cp {} {} 2>&1".format(
                self.nvim.funcs.shellescape(parser_src),
                self.nvim.funcs.shellescape(parser_dst),
            )
            self.nvim.funcs.system(cp_cmd)

            # 4. 複製 query 檔案
            query_src = tmpdir + "/queries"
            if self.nvim.funcs.isdirectory(query_src) == 1:
                query_dst = self.config["query_install_dir"] + "/" + lang
                self.nvim.funcs.mkdir(query_dst, "p")
                self.nvim.funcs.system(
                    "cp -r {}/* {}/ 2>&1".format(
                        self.nvim.funcs.shellescape(query_src),
                        self.nvim.funcs.shellescape(query_dst),
                    )
                )

            # 5. 清理
            self.nvim.funcs.system(
                "rm -rf " + self.nvim.funcs.shellescape(tmpdir)
            )

            self._notify("Parser '{}' 安裝完成！".format(lang), "INFO")

            # 刷新浮動視窗（透過 async_call 在主線程安全更新 UI）
            def refresh():
                if (
                    self.state["float_win"]
                    and self.nvim.api.win_is_valid(self.state["float_win"])
                ):
                    self._render(self.state["float_buf"], self.state["float_win"])

            self.nvim.async_call(refresh)

        # 在背景執行緒執行安裝
        t = threading.Thread(target=do_install)
        t.daemon = True
        t.start()

    def _remove_parser(self, lang):
        """移除指定語言的 parser"""
        if lang in BUILTIN_PARSERS:
            self._notify("無法移除內建 parser '{}'".format(lang), "WARN")
            return

        if not self._is_parser_installed(lang):
            self._notify("Parser '{}' 尚未安裝".format(lang), "WARN")
            return

        if self.config["confirm_remove"]:
            choice = self.nvim.funcs.confirm(
                "移除 parser '{}' ?".format(lang), "&Yes\n&No", 2
            )
            if choice != 1:
                return

        parser_path = self.config["parser_install_dir"] + "/" + lang + ".so"
        self.nvim.funcs.system("rm -f " + self.nvim.funcs.shellescape(parser_path))

        query_path = self.config["query_install_dir"] + "/" + lang
        if self.nvim.funcs.isdirectory(query_path) == 1:
            self.nvim.funcs.system(
                "rm -rf " + self.nvim.funcs.shellescape(query_path)
            )

        self._notify("Parser '{}' 已移除".format(lang), "INFO")

        # 刷新浮動視窗
        if (
            self.state["float_win"]
            and self.nvim.api.win_is_valid(self.state["float_win"])
        ):
            self._render(self.state["float_buf"], self.state["float_win"])

    def _highlight_lang(self, lang):
        """在當前 buffer 啟用指定語言的 Tree-sitter 高亮"""
        safe_lang = lang.replace('"', '\\"')
        cmd = (
            'lua pcall(function() '
            'vim.treesitter.language.add("{}") '
            'vim.treesitter.start(0, "{}") '
            'end)'
        ).format(safe_lang, safe_lang)
        self.nvim.command(cmd)
        self._notify("已啟用 '{}' 的 Tree-sitter 高亮".format(lang), "INFO")

    # -------------------------------------------------------------------------
    # 按鍵映射（使用 nvim_buf_set_keymap）
    # -------------------------------------------------------------------------

    def _setup_keymaps(self, buf):
        """在浮動視窗 buffer 上綁定按鍵"""
        opts = {"silent": True, "nowait": True, "noremap": True}

        # i = 安裝
        self.nvim.api.buf_set_keymap(
            buf, "n", "i", ":TSFloatAction install<CR>", opts
        )

        # x = 移除
        self.nvim.api.buf_set_keymap(
            buf, "n", "x", ":TSFloatAction remove<CR>", opts
        )

        # Enter / h = 高亮
        self.nvim.api.buf_set_keymap(
            buf, "n", "<CR>", ":TSFloatAction highlight<CR>", opts
        )
        self.nvim.api.buf_set_keymap(
            buf, "n", "h", ":TSFloatAction highlight<CR>", opts
        )

        # r = 刷新
        self.nvim.api.buf_set_keymap(
            buf, "n", "r", ":TSFloatAction refresh<CR>", opts
        )

        # q / ESC = 關閉
        self.nvim.api.buf_set_keymap(
            buf, "n", "q", ":TSFloatAction close<CR>", opts
        )
        self.nvim.api.buf_set_keymap(
            buf, "n", "<ESC>", ":TSFloatAction close<CR>", opts
        )

        # 防止意外編輯
        self.nvim.api.buf_set_keymap(buf, "n", "a", "<Nop>", opts)
        self.nvim.api.buf_set_keymap(buf, "n", "o", "<Nop>", opts)
        self.nvim.api.buf_set_keymap(buf, "n", "i", "<Nop>", opts)
        # 注意：上面已經綁定了 i 到安裝，所以這裡不需要再綁 <Nop>
        # 但為了防止其他模式，可以綁定一些無用的鍵
        self.nvim.api.buf_set_keymap(buf, "n", "p", "<Nop>", opts)

    # -------------------------------------------------------------------------
    # 命令處理
    # -------------------------------------------------------------------------

    @pynvim.command("TSFloat", nargs="0", sync=True)
    def tsfloat(self, args):
        """開啟浮動視窗"""
        self.state["float_buf"], self.state["float_win"] = self._open_float_window()
        self._render(self.state["float_buf"], self.state["float_win"])
        self._setup_keymaps(self.state["float_buf"])

    @pynvim.command("TSFloatInstall", nargs="1", sync=False)
    def tsfloat_install(self, args):
        """直接安裝指定語言的 parser"""
        lang = args[0]
        self._install_parser(lang)

    @pynvim.command("TSFloatRemove", nargs="1", sync=False)
    def tsfloat_remove(self, args):
        """直接移除指定語言的 parser"""
        lang = args[0]
        self._remove_parser(lang)

    @pynvim.command("TSFloatAction", nargs="1", sync=False)
    def tsfloat_action(self, args):
        """浮動視窗內的按鍵動作（透過 keymap 觸發）"""
        action = args[0]

        if action == "close":
            if (
                self.state["float_win"]
                and self.nvim.api.win_is_valid(self.state["float_win"])
            ):
                self.nvim.api.win_close(self.state["float_win"], True)
            self.state["float_win"] = None
            self.state["float_buf"] = None

        elif action == "refresh":
            if (
                self.state["float_win"]
                and self.nvim.api.win_is_valid(self.state["float_win"])
            ):
                self._render(self.state["float_buf"], self.state["float_win"])

        elif action == "install":
            item = self._get_current_lang()
            if item:
                self._install_parser(item["lang"])

        elif action == "remove":
            item = self._get_current_lang()
            if item:
                self._remove_parser(item["lang"])

        elif action == "highlight":
            item = self._get_current_lang()
            if item:
                self._highlight_lang(item["lang"])

    @pynvim.command("TSFloatSetup", nargs="0", sync=True)
    def setup(self, args):
        """初始化插件，可透過 g:treesitter_float_config 傳遞配置"""
        try:
            user_config = self.nvim.vars.get("treesitter_float_config", {})
            if user_config:
                self.config.update(user_config)
        except Exception:
            pass
        self.nvim.out_write("TreeSitterFloat plugin loaded!")
