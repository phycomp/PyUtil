import pynvim
import re

@pynvim.plugin
class MyBufferPlugin(object):
    def __init__(self, nvim):
        self.nvim = nvim
        self.float_buf = None
        self.float_win = None
        self.valid_buffers = []

    @pynvim.autocmd('VimEnter', pattern='*', sync=True)
    def on_vim_enter(self):
        """當 Vim 啟動時，自動綁定全域快捷鍵 <Leader>b"""
        opts = {'silent': True, 'noremap': True, 'desc': 'Toggle Buffer Manager'}
        self.nvim.api.set_keymap('n', 'bmgr', ':ToggleBufferManager<CR>', opts)
        self.nvim.api.set_keymap('n', 'bdlt', ':bdelete ', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>bp', '<cmd>bp!<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>bn', '<cmd>bn!<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>bx', '<cmd>bd!<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>bd', '<cmd>bd<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>bh', '<cmd>hide<CR>', {'noremap':True, 'silent':False})
        #self.nvim.command(':com! -nargs=* Bufmvtab py3 buf2Tab(<f-args>)')
        self.nvim.api.set_keymap('n', '<leader>bmt', ':Bufmvtab ', {'noremap': True, 'silent': False})
        #self.nvim.api.set_keymap('n', '<leader>bmt', ':MoveBufToTab ', {'noremap':True, 'silent':False})

    #@pynvim.command('Bufmvtab', nargs=1, sync=True)
    #def buf2Tab(self, tabnr):
    #  #:hide|tabnext tabnr|sbnext bufnr$
    #  bufNR=vim.funcs.bufnr
    #  curbuf=vim.current.buffer
    #  curBufID=bufNR(curbuf)
    #  vim.command(f'hide|tabnext {tabnr}|set switchbuf=usetab|sbuff {curBufID}')
    #  #set switchbuf=usetab

    # 1. 自動在 Vim 啟動或插件載入時綁定快捷鍵
    # 這裡刻意保持 'silent': False，這樣按下快捷鍵時，下方命令列會停留在 ':Bufmvtab ' 讓使用者輸入分頁號碼

    # 2. 註冊命令 :Bufmvtab，允許接收多個參數 (nargs='*')
    @pynvim.command('Bufmvtab', nargs='*')
    def buf_to_tab_cmd(self, args):
        # 如果使用者沒有輸入參數，預設代入空字串（或你可以自訂預設行為）
        tabnr = args[0] if args else ''
        self.buf2tab(tabnr)

    # 3. 核心邏輯處理函式 (改寫自你提供的原始碼)
    def buf2tab(self, tabnr):
        # 獲取當前 Buffer 的 ID (等同於舊版 vim.current.buffer.number)
        current_buf = self.nvim.api.get_current_buf()
        cur_buf_id = current_buf.handle

        # 執行你原本設計的 Vimscript 組合命令
        # 效果：隱藏當前視窗 -> 切換到指定 tab -> 設定 switchbuf -> 在該分頁開啟對應 buffer
        cmd_string = f'hide | tabnext {tabnr} | set switchbuf=usetab | sbuff {cur_buf_id}'
        
        try:
            self.nvim.command(cmd_string)
        except pynvim.api.NvimError as e:
            # 捕捉可能的錯誤（例如：輸入了不存在的 Tab 號碼）
            self.nvim.out_write(f"❌ Bufmvtab 執行失敗: {e}\n")

    @pynvim.command('MoveBufToTab', nargs='?', sync=True)
    def move_buf_to_tab(self, args):
        # 1. 獲取當前正在編輯的 Buffer 编号與視窗 ID
        current_buf = self.nvim.api.get_current_buf()
        current_win = self.nvim.api.get_current_win()
        
        # 2. 判斷使用者是否有輸入目標 Tab 數字
        if args and args[0].isdigit():
            target_tab_num = int(args[0])
            tabs = self.nvim.api.list_tabpages()
            
            # 如果輸入的 Tab 數字在有效範圍內
            if 1 <= target_tab_num <= len(tabs):
                # 切換到目標 Tab
                target_tab = tabs[target_tab_num - 1]
                self.nvim.api.set_current_tabpage(target_tab)
                # 在該 Tab 開啟此 Buffer，並關閉舊視窗的 Buffer 連結
                self.nvim.api.set_current_buf(current_buf)
                self.nvim.api.win_close(current_win, False)
                return
            else:
                self.nvim.out_write(f"❌ 錯誤：找不到第 {target_tab_num} 個分頁！\n")
                return

    @pynvim.command('ToggleBufferManager')
    def toggle_buffer_manager(self):
        """切換顯示/關閉儲存管理浮動視窗"""
        if self.float_win and self.nvim.api.win_is_valid(self.float_win):
            self.close_float_window()
            return

        # 1. 獲取所有列出的正常 buffer
        buffers = self.nvim.api.list_bufs()
        self.valid_buffers = [b for b in buffers if self.nvim.api.buf_get_option(b, 'buflisted')]
        
        if not self.valid_buffers:
            self.nvim.out_write("沒有可顯示的 Buffer。\n")
            return

        # 產生顯示文字列表
        lines = []
        for b in self.valid_buffers:
            name = self.nvim.api.buf_get_name(b)
            name = name.split('/')[-1] if name else '[無名稱]'
            modified = " [修改未存檔]" if self.nvim.api.buf_get_option(b, 'modified') else ""
            lines.append(f" {b.handle}: {name}{modified}")

        # 2. 計算浮動視窗尺寸與位置
        ui = self.nvim.api.list_uis()[0]  # 取得主要 UI 尺寸
        width = min(60, ui['width'] - 10)
        height = min(len(lines), ui['height'] - 4)
        row = (ui['height'] - height) // 2
        col = (ui['width'] - width) // 2

        # 3. 創建建立 Buffer 與 Window
        self.float_buf = self.nvim.api.create_buf(False, True)  # unlisted, scratch
        self.nvim.api.buf_set_lines(self.float_buf, 0, -1, True, lines)
        
        opts = {
            'relative': 'editor',
            'width': width,
            'height': height,
            'row': row,
            'col': col,
            'style': 'minimal',
            'border': 'rounded'
        }
        self.float_win = self.nvim.api.open_win(self.float_buf, True, opts)

        # 4. 設定該浮動視窗專屬的快捷鍵
        map_opts = {'silent': True, 'noremap': True}
        
        # 改為直接對應到外掛註冊的專屬指令，徹底解決 SyntaxError
        self.nvim.api.buf_set_keymap(self.float_buf, 'n', 'd', ':MyBufferPluginDelete<CR>', map_opts)
        self.nvim.api.buf_set_keymap(self.float_buf, 'n', 'q', ':ToggleBufferManager<CR>', map_opts)
        self.nvim.api.buf_set_keymap(self.float_buf, 'n', '<Esc>', ':ToggleBufferManager<CR>', map_opts)
        self.nvim.api.buf_set_keymap(self.float_buf, 'n', '<CR>', ':MyBufferPluginSwitch<CR>', map_opts)
        #self.nvim.api.buf_set_keymap(self.float_buf, 'n', '<leader>bmt', ':MoveBufToTab ', map_opts)

    def close_float_window(self):
        """安全關閉浮動視窗的輔助方法"""
        if self.float_win and self.nvim.api.win_is_valid(self.float_win):
            self.nvim.api.win_close(self.float_win, True)
        self.float_win = None
        self.float_buf = None

    @pynvim.command('MyBufferPluginDelete')
    def _delete_current_line_buf(self):
        """透過指令觸發刪除（避免物件內部路徑解析失敗）"""
        if not self.float_win or not self.nvim.api.win_is_valid(self.float_win):
            return

        cursor = self.nvim.api.win_get_cursor(self.float_win)
        row_idx = cursor[0] - 1  # 修正：win_get_cursor 返回 [row, col]，row 從 1 開始

        if row_idx >= len(self.valid_buffers):
            return

        target_buf = self.valid_buffers[row_idx]
        
        # 檢查未存檔警告
        if self.nvim.api.buf_get_option(target_buf, 'modified'):
            self.nvim.api.command('echohl WarningMsg')
            self.nvim.api.command('echo "警告：該 Buffer 有未存檔的變更！請先存檔。"')
            self.nvim.api.command('echohl None')
            return

        # 執行刪除
        try:
            self.nvim.api.command(f"bdelete {target_buf.handle}")
            # 重新整理介面
            self.close_float_window()
            self.toggle_buffer_manager()
            
            # 恢復游標位置
            new_max_row = len(self.valid_buffers)
            if new_max_row > 0 and self.float_win and self.nvim.api.win_is_valid(self.float_win):
                next_row = min(cursor[0], new_max_row)
                self.nvim.api.win_set_cursor(self.float_win, [next_row, cursor[1]])
        except Exception as e:
            self.nvim.err_write(f"無法刪除 Buffer: {str(e)}\n")

    @pynvim.command('MyBufferPluginSwitch')
    def _switch_to_current_line_buf(self):
        """透過指令觸發跳轉"""
        if not self.float_win or not self.nvim.api.win_is_valid(self.float_win):
            return

        cursor = self.nvim.api.win_get_cursor(self.float_win)
        row_idx = cursor[0] - 1
        
        lines = self.nvim.api.buf_get_lines(self.float_buf, row_idx, row_idx + 1, False)
        if not lines:
            return
            
        current_line = lines[0]
        
        match = re.match(r'^\s*(\d+):', current_line)
        if match:
            buf_id = match.group(1)
            self.close_float_window()
            self.nvim.api.command(f"buffer {buf_id}")

    @pynvim.autocmd('WinEnter', pattern='*')
    def on_win_enter(self):
        """當切換視窗或點擊外部時，自動關閉浮動視窗"""
        if self.float_win and self.nvim.api.win_is_valid(self.float_win):
            current_win = self.nvim.api.get_current_win()
            if current_win.handle != self.float_win.handle:
                self.close_float_window()

    @pynvim.autocmd('BufDelete', pattern='*', eval='expand("<abuf>")')
    def on_buf_delete(self, abuf):
        """監聽全域 Buffer 刪除事件，若未存檔則提出警告"""
        try:
            buf_handle = int(abuf)
            if not self.nvim.api.buf_is_valid(buf_handle):
                return
                
            if self.nvim.api.buf_get_option(buf_handle, 'modified'):
                self.nvim.api.command('echohl WarningMsg')
                self.nvim.api.command(f'echo "警告: Buffer {buf_handle} 尚未儲存變更！"')
                self.nvim.api.command('echohl None')
        except Exception:
            pass
