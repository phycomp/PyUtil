import pynvim
import os
import traceback

@pynvim.plugin
class MapsViewerPlugin(object):
    def __init__(self, nvim):
        self.nvim = nvim
        self.viewer_buf = None
        self.viewer_win = None
        self.keymaps_data = []

    @pynvim.command('MapsViewerInternalDispatch', nargs='*')
    def internal_dispatch(self, args):
        """核心調度器：解析來自 Lua 的按鍵動作並安全轉發"""
        if not args:
            self.nvim.err_write("[MapsViewer Error] 調度器未收到任何參數\n")
            return
            
        try:
            full_args_str = " ".join(args)
            parts = full_args_str.split()
            
            if len(parts) < 2:
                self.nvim.err_write(f"[MapsViewer Error] 參數解析失敗，收到: {parts}\n")
                return
                
            buf_id = int(parts[0])
            action = parts[1]
            
            if self.viewer_buf and buf_id == self.viewer_buf.handle:
                if action == 'close_viewer':
                    self.close_viewer()
                elif action == 'delete_current_map':
                    self.delete_current_map()
                elif action == 'info_current_map':
                    self.info_current_map()
                elif action == 'edit_current_map_source':
                    self.edit_current_map_source()
        except Exception as e:
            error_msg = traceback.format_exc()
            self.nvim.err_write(f"[MapsViewer Dispatch Panic]\n{error_msg}\n")

    @pynvim.command('MapsViewerOpen')
    def open_viewer(self):
        """建立浮動視窗，自動收集多模式快捷鍵並套用高亮"""
        try:
            target_modes = ['n', 'v', 'x', 'i', 'c', 't']
            current_buf = self.nvim.api.get_current_buf()
            
            self.keymaps_data = []
            lines = []
            
            for mode in target_modes:
                buf_maps = self.nvim.api.buf_get_keymap(current_buf, mode)
                for k in buf_maps:
                    k['scope'] = 'buf'
                    k['buf_id'] = current_buf.handle
                    k['display_mode'] = mode.upper()
                    self.keymaps_data.append(k)
                    
                global_maps = self.nvim.api.get_keymap(mode)
                for k in global_maps:
                    k['scope'] = 'global'
                    k['display_mode'] = mode.upper()
                    self.keymaps_data.append(k)

            for idx, k in enumerate(self.keymaps_data):
                mode_str = f"[{k['display_mode']}]".ljust(5)
                scope = "[Buf]" if k['scope'] == 'buf' else "[Glb]"
                lhs = k.get('lhs', '')
                rhs = k.get('rhs', '<Lua Function>') if 'callback' in k else k.get('rhs', '')
                desc = k.get('desc', 'No description')
                lines.append(f"{idx:03d} | {mode_str} {scope} {lhs.ljust(15)} -> {rhs.ljust(35)} | {desc}")

            self.viewer_buf = self.nvim.api.create_buf(False, True)
            self.nvim.api.buf_set_lines(self.viewer_buf, 0, -1, True, lines)
            
            width = int(self.nvim.api.get_option('columns') * 0.85)
            height = int(self.nvim.api.get_option('lines') * 0.75)
            opts = {
                'relative': 'editor',
                'width': width,
                'height': height,
                'row': int((self.nvim.api.get_option('lines') - height) / 2),
                'col': int((self.nvim.api.get_option('columns') - width) / 2),
                'style': 'minimal',
                'border': 'rounded'
            }
            
            self.viewer_win = self.nvim.api.open_win(self.viewer_buf, True, opts)
            self.apply_syntax_highlighting()
            
            self.nvim.command(f"autocmd BufLeave <buffer> ++once lua vim.api.nvim_win_close({self.viewer_win.handle}, true)")
            
            buf_id = self.viewer_buf.handle
            self.nvim.exec_lua("""
                local buf = ...
                local set_key = function(lhs, action_name)
                    vim.keymap.set('n', lhs, function()
                        local cmd_str = string.format("MapsViewerInternalDispatch %d %s", buf, action_name)
                        vim.cmd(cmd_str)
                    end, { buffer = buf, silent = true, noremap = true })
                end

                set_key('d', 'delete_current_map')
                set_key('i', 'info_current_map')
                set_key('<Esc>', 'close_viewer')
                set_key('q', 'close_viewer')
                set_key('<CR>', 'edit_current_map_source')
            """, buf_id)
        except Exception as e:
            self.nvim.err_write(f"[MapsViewer Open Panic] {traceback.format_exc()}\n")

    def apply_syntax_highlighting(self):
        """設定視窗的高亮語法"""
        self.nvim.api.buf_set_option(self.viewer_buf, 'filetype', 'mapsviewer')
        self.nvim.command(r"syntax match MapsIdx /^\d\{3\}/")
        self.nvim.command(r"syntax match MapsMode /\[[NVXICT]\]/")
        self.nvim.command(r"syntax match MapsBufScope /\[Buf\]/")
        self.nvim.command(r"syntax match MapsGlbScope /\[Glb\]/")
        self.nvim.command(r"syntax match MapsLhs /\s\S\+\s\ze->/")
        self.nvim.command(r"syntax match MapsRhs /->\s\zs.\{-}\ze\s*|/")
        
        self.nvim.command("hi def link MapsIdx Comment")
        self.nvim.command("hi def link MapsMode Type")
        self.nvim.command("hi def link MapsBufScope Label")
        self.nvim.command("hi def link MapsGlbScope Debug")
        self.nvim.command("hi def link MapsLhs Function")
        self.nvim.command("hi def link MapsRhs String")

    def _get_current_index(self):
        """安全獲取游標所在行的快捷鍵索引資料"""
        cursor = self.nvim.api.win_get_cursor(self.viewer_win)
        row = cursor[0] - 1
        if row < len(self.keymaps_data):
            return row, self.keymaps_data[row]
        return None, None

    def close_viewer(self):
        """關閉浮動視窗並清理控制項"""
        try:
            if self.viewer_win and self.nvim.api.win_is_valid(self.viewer_win):
                self.nvim.api.win_close(self.viewer_win, True)
            self.viewer_win = None
            self.viewer_buf = None
        except Exception:
            pass

    def edit_current_map_source(self):
        """定位快捷鍵來源，並以 +lnum 安全指令於右側分割視窗開啟編輯"""
        try:
            row, k = self._get_current_index()
            if not k:
                return

            file_path = None
            lnum = 0

            # 策略 1：處理 Lua 寫法的快捷鍵 (透過 Lua 閉包反射 debug.getinfo)
            lua_debug_info = self.nvim.exec_lua("""
                local mode, lhs, scope, buf_id = ...
                local maps
                if scope == "buf" then
                    maps = vim.api.nvim_buf_get_keymap(buf_id, mode)
                else
                    maps = vim.api.nvim_get_keymap(mode)
                end
                
                for _, m in ipairs(maps) do
                    if m.lhs == lhs then
                        if m.callback then
                            local info = debug.getinfo(m.callback)
                            if info and info.source then
                                return {
                                    type = "Lua Callback",
                                    source = info.source,
                                    lnum = info.linedefined or 0
                                }
                            end
                        else
                            return { type = "Standard RHS", rhs = m.rhs, sid = m.sid, lnum = m.lnum }
                        end
                    end
                end
                return nil
            """, k.get('mode', 'n'), k.get('lhs'), k['scope'], k.get('buf_id', 0))

            if lua_debug_info and lua_debug_info.get('type') == "Lua Callback":
                src = lua_debug_info.get('source', '')
                if src.startswith('@'):
                    file_path = src[1:]
                    lnum = lua_debug_info.get('lnum', 0)
            
            elif lua_debug_info and lua_debug_info.get('type') == "Standard RHS":
                lnum = lua_debug_info.get('lnum', 0)

            # 策略 2：新版 Neovim scriptmeta
            if not file_path and 'scriptmeta' in k:
                meta = k['scriptmeta']
                if isinstance(meta, dict) and 'source' in meta:
                    file_path = meta['source']
                    lnum = k.get('lnum', 0)

            # 策略 3：Fallback 傳統 sid
            if not file_path:
                sid = k.get('sid', 0)
                if sid > 0:
                    script_list = self.nvim.call('getscriptinfo', {'id': sid})
                    if script_list and len(script_list) > 0:
                        script_info = script_list
                        if isinstance(script_info, dict) and 'name' in script_info:
                            file_path = script_info['name']
                            lnum = k.get('lnum', 0)

            # 執行視窗切分與安全跳轉
            if file_path:
                if os.path.exists(file_path):
                    # 1. 先關閉彈出的浮動視窗
                    self.close_viewer()
                    
                    # 2. 開啟右側垂直分割視窗
                    self.nvim.command("rightbelow vsplit")
                    
                    # 3. 【核心修正】不使用 win_set_cursor，改用編輯器原生指令「edit +行號 檔案」
                    # 這是最普適、最快且絕對不會引發 out of range 例外的做法
                    if lnum > 0:
                        self.nvim.command(f"edit +{lnum} {file_path}")
                    else:
                        self.nvim.command(f"edit {file_path}")
                    
                    # 4. 讓畫面滾動置中
                    self.nvim.command("normal! zz")
                    return
                else:
                    self.nvim.api.notify(f"檔案存在於快取但硬碟上找不到: {file_path}", 3, {})
                    return
            
            self.nvim.api.notify("找不到此快捷鍵的實體原始碼路徑（可能為命令列動態宣告）。", 2, {})

        except Exception as e:
            self.nvim.err_write(f"[MapsViewer Edit Panic] {traceback.format_exc()}\n")

    def delete_current_map(self):
        """刪除所選快捷鍵項目"""
        row, k = self._get_current_index()
        if not k: return
        mode = k.get('mode', 'n')
        lhs = k.get('lhs')
        try:
            if k['scope'] == 'buf':
                self.nvim.api.buf_del_keymap(k['buf_id'], mode, lhs)
                self.nvim.out_write(f"已刪除 [{mode.upper()}] Buffer 快捷鍵: {lhs}\n")
            else:
                self.nvim.api.del_keymap(mode, lhs)
                self.nvim.out_write(f"已刪除 [{mode.upper()}] 全域快捷鍵: {lhs}\n")
            self.open_viewer()
        except Exception as e:
            self.nvim.err_write(f"刪除失敗: {str(e)}\n")

    def info_current_map(self):
        """查詢所選快捷鍵資訊"""
        row, k = self._get_current_index()
        if not k: return
        info_lines = [f"模式: {k.get('display_mode')}", f"快捷鍵: {k.get('lhs')}"]
        sid = k.get('sid', 0)
        if sid > 0:
            script_list = self.nvim.call('getscriptinfo', {'id': sid})
            if script_list and len(script_list) > 0:
                script_info = script_list
                if isinstance(script_info, dict):
                    info_lines.append(f"來源檔案: {script_info.get('name')}")
                    info_lines.append(f"行號: {k.get('lnum', '未知')}")
        else:
            info_lines.append("來源: [動態 API 宣告]")
        self.nvim.api.notify("\n".join(info_lines), 2, {})
