import pynvim
import re


@pynvim.plugin
class ParenExtractor:
    def __init__(self, nvim):
        self.nvim = nvim
        self._setup_keymaps()

    def _setup_keymaps(self):
        for key in ['<leader>pe', '<leader>px']:
            self.nvim.command(f'silent! nunmap {key}')
            self.nvim.command(f'silent! vunmap {key}')
        self.nvim.command("nnoremap <silent> <leader>pe :ParenExtract<CR>")
        self.nvim.command("vnoremap <silent> <leader>pe :ParenExtract<CR>")

    @pynvim.command('ParenExtract', range='%', nargs='*', sync=True)
    def extract_parens(self, args, range):
        """
        提取 latex(...) / markdown(...) 括弧內的內容，取代整個區塊。
        - 單行：該行直接取代為括弧內容（去掉引號）
        - 跨多行：從函數名稱行到 ) 行的整個區塊取代為括弧內容
        """
        buf = self.nvim.current.buffer
        start, end = range[0] - 1, range[1]
        target_lines = buf[start:end]

        # 從後往前處理，避免行號偏移
        blocks = self._find_func_blocks(target_lines)
        blocks.sort(key=lambda x: x[0], reverse=True)

        extracted_count = 0
        for rel_start, rel_end, content, base_indent in blocks:
            abs_start = start + rel_start
            abs_end = start + rel_end

            formatted = self._normalize_indent(content, base_indent)
            formatted_lines = formatted.split('\n')

            buf[abs_start:abs_end + 1] = formatted_lines
            extracted_count += 1

        self.nvim.out_write(
            f"[ParenExtractor] 提取了 {extracted_count} 個區塊\n"
        )

    def _find_func_blocks(self, lines):
        """
        掃描文本，找到所有 latex(...) / markdown(...) 區塊。
        返回 [(start_line, end_line, content, base_indent), ...]
        """
        results = []
        i = 0
        n = len(lines)

        while i < n:
            line = lines[i]
            # 匹配行首可選縮排 + latex 或 markdown + 可選空白 + (
            match = re.match(r'^(\s*)(latex|markdown)\s*\(', line)
            if not match:
                i += 1
                continue

            base_indent = match.group(1)
            func_name = match.group(2)
            # 定位函數名稱( 後面的位置
            func_pos = line.find(func_name + '(')
            start_col = func_pos + len(func_name + '(')

            # 狀態機追蹤括弧深度與字符串
            depth = 1
            content_parts = []
            in_single = False
            in_double = False
            in_triple_single = False
            in_triple_double = False
            escape = False

            j = i
            while j < n:
                text = lines[j]
                k = start_col if j == i else 0

                while k < len(text):
                    ch = text[k]

                    # 轉義字元
                    if escape:
                        escape = False
                        if depth > 0:
                            content_parts.append(ch)
                        k += 1
                        continue

                    if ch == '\\':
                        escape = True
                        if depth > 0:
                            content_parts.append(ch)
                        k += 1
                        continue

                    # 三引號
                    if k + 2 < len(text):
                        triple = text[k:k+3]
                        if triple in ("'''", '"""'):
                            if triple == "'''":
                                if not in_double and not in_triple_double:
                                    in_triple_single = not in_triple_single
                                    if depth > 0:
                                        content_parts.append("'''")
                                    k += 3
                                    continue
                            else:
                                if not in_single and not in_triple_single:
                                    in_triple_double = not in_triple_double
                                    if depth > 0:
                                        content_parts.append('"""')
                                    k += 3
                                    continue

                    # 單引號
                    if ch == "'" and not in_double and not in_triple_single and not in_triple_double:
                        in_single = not in_single
                        if depth > 0:
                            content_parts.append(ch)
                        k += 1
                        continue

                    # 雙引號
                    if ch == '"' and not in_single and not in_triple_single and not in_triple_double:
                        in_double = not in_double
                        if depth > 0:
                            content_parts.append(ch)
                        k += 1
                        continue

                    # 括弧深度（僅在非字符串狀態）
                    if not (in_single or in_double or in_triple_single or in_triple_double):
                        if ch == '(':
                            depth += 1
                            if depth > 0:
                                content_parts.append(ch)
                            k += 1
                            continue
                        elif ch == ')':
                            depth -= 1
                            if depth == 0:
                                raw_content = ''.join(content_parts)
                                clean_content = self._strip_string_quotes(raw_content)
                                results.append((i, j, clean_content, base_indent))
                                i = j
                                break
                            else:
                                content_parts.append(ch)
                            k += 1
                            continue

                    # 一般字元
                    if depth > 0:
                        content_parts.append(ch)
                    k += 1

                if depth == 0:
                    break

                if depth > 0 and j >= i:
                    content_parts.append('\n')

                j += 1

            i += 1

        return results

    def _strip_string_quotes(self, text):
        """去掉外層 Python 字符串引號，保留純內容"""
        text = text.strip()

        # r'''...''' 或 r"""..."""
        for prefix in ["r'''", 'r"""', "rf'''", 'rf"""']:
            if text.startswith(prefix):
                suffix = "'''" if prefix.endswith("'''") else '"""'
                if text.endswith(suffix):
                    return suffix+text[len(prefix):-3].strip('\n')+suffix

        # '''...''' 或 """..."""
        for prefix in ["'''", '"""']:
            if text.startswith(prefix) and text.endswith(prefix):
                return text[len(prefix):-3].strip('\n')

        # '...'
        if text.startswith("'") and text.endswith("'"):
            return text #[1:-1]

        # "..."
        if text.startswith('"') and text.endswith('"'):
            return text #[1:-1]

        return text

    def _normalize_indent(self, content, base_indent):
        """
        將內容的縮排正規化：
        - 找出內容中非空行的最小縮排
        - 減去該最小縮排（相對縮排歸零）
        - 再加上 base_indent（函數所在行的縮排）
        """
        lines = content.split('\n')
        min_indent = float('inf')

        for line in lines:
            if line.strip():
                indent = len(line) - len(line.lstrip())
                min_indent = min(min_indent, indent)

        if min_indent == float('inf'):
            return content

        result = []
        for line in lines:
            if line.strip():
                relative = line[min_indent:]
                result.append(base_indent + relative)
            else:
                result.append('')

        return '\n'.join(result)
