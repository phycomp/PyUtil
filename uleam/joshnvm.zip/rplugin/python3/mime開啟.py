import os
import mimetypes
import subprocess
import pynvim

@pynvim.plugin
class MimeLauncherPlugin(object):
    def __init__(self, nvim):
        self.nvim = nvim

    @pynvim.command('MimeOpen', nargs='?', sync=False)
    def mime_open_command(self, args):
        # 1. 取得路徑參數，若無則拿當前 buffer 路徑
        if args and len(args) > 0:
            filepath = args[0] if isinstance(args, list) else args
        else:
            filepath = self.nvim.funcs.expand('%:p')
        
        filepath = os.path.abspath(os.path.expanduser(filepath))

        if not filepath or not os.path.exists(filepath):
            self.nvim.err_write(f"找不到有效的檔案路徑: {filepath}\n")
            return

        if os.path.isdir(filepath):
            return

        # 2. 偵測 MIME 類型
        mime_type, _ = mimetypes.guess_type(filepath)
        
        if not mime_type:
            self.nvim.command(f"edit {filepath}")
            return

        # 3. 分流處理：圖片用 chafa，其餘用系統或編輯器開啟
        if mime_type.startswith('image/'):
            self._render_image_in_nvim(filepath)
        elif mime_type.startswith('video/') or mime_type.startswith('audio/') or mime_type == 'application/pdf':
            self._open_with_system(filepath, mime_type)
        else:
            self.nvim.command(f"edit {filepath}")

    def _render_image_in_nvim(self, filepath):
        """核心變更：使用垂直分割視窗 (vnew) 在右側優雅展示 chafa 圖形"""
        # --format=symbols 是最安全的字元畫模式
        cmd = f"chafa --format=symbols '{filepath}'"
        self.nvim.command('vnew') # 使用垂直分割，畫面更適合閱讀
        self.nvim.command(f"terminal {cmd}")
        self.nvim.command('startinsert')

    def _open_with_system(self, filepath, mime_type):
        try:
            if os.name == 'nt':
                os.startfile(filepath)
            elif os.uname().sysname == 'Darwin':
                subprocess.Popen(['open', filepath])
            else:
                subprocess.Popen(['xdg-open', filepath])
        except Exception as e:
            self.nvim.err_write(f"系統開啟失敗: {str(e)}\n")
