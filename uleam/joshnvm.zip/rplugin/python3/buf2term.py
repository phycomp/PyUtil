import pynvim
from tempfile import NamedTemporaryFile
import os

@pynvim.plugin
class Buf2TermStdin:
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim
        self.term_bufnr = None   # 終端 buffer 編號
        self.term_winid = None   # 終端窗口 ID（全局唯一，關閉後不復用）

    @pynvim.command("RunPyTermStdin", nargs=0, sync=True)
    def run_py_term_stdin(self):
        buf = self.nvim.current.buffer
        code = '\n'.join(buf[:])
        current_winnr = self.nvim.current.window.number

        # 寫成臨時檔
        with NamedTemporaryFile(mode='w+', suffix='.py', delete=False) as f:
            f.write(code)
            tmp = f.name

        try:
            # 若已有終端 buffer，強制關閉（連同尚未結束的 job）
            if self.term_bufnr is not None:
                self.nvim.command(f'silent! bwipeout! {self.term_bufnr}')
                self.term_bufnr = None

            # 檢查終端窗口是否仍存在（用戶可能手動關閉了）
            term_exists = (
                self.term_winid is not None
                and self.nvim.funcs.win_id2win(self.term_winid) != 0
            )

            if term_exists:
                # 切換到已有的終端窗口，在同一窗口重新執行
                self.nvim.funcs.win_gotoid(self.term_winid)
            else:
                # 第一次執行，或窗口已被關閉：在原 buffer 右側開垂直分窗
                self.nvim.command('vnew')
                self.term_winid = self.nvim.funcs.win_getid()

            # 在當前窗口啟動終端執行 Python
            self.nvim.command(f'term python - < {tmp}')
            self.term_bufnr = self.nvim.current.buffer.number

            # 切回原編輯窗口
            self.nvim.command(f'{current_winnr}wincmd w')

        finally:
            os.unlink(tmp)

    @pynvim.autocmd("VimEnter", sync=True)
    def setup(self):
        self.nvim.command('nnoremap <leader>tsd :RunPyTermStdin<CR>')
