import pynvim

@pynvim.plugin
class KeymapCheckerPlugin:
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim

    @pynvim.command('CheckLeaderOverlap', nargs=0, sync=True)
    def check_leader_overlap(self):
        # 1. 取得當前的 <leader> 鍵定義，預設為反斜線 '\'
        try:
            leader = self.nvim.g['mapleader']
        except Exception:
            leader = '\\'

        # 2. 獲取 Normal 模式下的所有 keymap
        keymaps = self.nvim.api.get_keymap('n')
        
        leader_maps = []
        for km in keymaps:
            lhs = km.get('lhs', '')
            # 將實際的 leader 鍵轉回標示 '<leader>'，統一處理格式
            normalized_lhs = lhs.replace(leader, '<leader>')
            
            # 僅篩選以 <leader> 開頭的映射
            if normalized_lhs.startswith('<leader>'):
                leader_maps.append(normalized_lhs)

        # 依字串長度排序，確保短的字串在前（方便檢查前綴）
        leader_maps = sorted(list(set(leader_maps)))
        
        overlaps = []
        # 3. 雙重迴圈檢查是否有開頭重疊 (Prefix Overlap)
        for i in range(len(leader_maps)):
            for j in range(i + 1, len(leader_maps)):
                short_map = leader_maps[i]
                long_map = leader_maps[j]
                
                # 如果長的映射以短的映射開頭，代表觸發短映射時會有延遲或衝突
                if long_map.startswith(short_map):
                    overlaps.append((short_map, long_map))

        # 4. 輸出結果至 Neovim 訊息區
        if not overlaps:
            self.nvim.out_write("[Keymap Checker] 恭喜！未發現重疊的 <leader> 快捷鍵。\n")
        else:
            self.nvim.out_write("=== [Keymap Checker] 發現重疊的 <leader> 快捷鍵 ===\n")
            for short_map, long_map in overlaps:
                self.nvim.out_write(f"  衝突: '{short_map}' 會卡住/影響 '{long_map}'\n")
