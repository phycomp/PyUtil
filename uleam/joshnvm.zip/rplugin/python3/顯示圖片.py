import pynvim
import numpy as np
from PIL import Image
import tempfile
import os
import io
import base64

# 終端 ANSI 顏色代碼映射 (256色近似)
def rgb_to_ansi256(r, g, b):
    """將 RGB 轉換為 ANSI 256 色代碼"""
    if r == g == b:
        if r < 8:
            return 16
        if r > 248:
            return 231
        return round((r - 8) / 247 * 24) + 232

    r_idx = round(r / 255 * 5)
    g_idx = round(g / 255 * 5)
    b_idx = round(b / 255 * 5)
    return 16 + (36 * r_idx) + (6 * g_idx) + b_idx


def rgb_to_truecolor(r, g, b):
    """生成 truecolor ANSI 轉義序列"""
    return f"\033[38;2;{r};{g};{b}m"


def image_to_halfblock_text(img, max_width=None, max_height=None):
    """
    使用 Unicode 半塊字符 (▀ ▄) 將圖片轉換為終端文本
    每個字符位置可以顯示上下兩個像素的顏色
    """
    # 計算縮放比例 (終端字符高寬比約為 2:1)
    orig_w, orig_h = img.size

    if max_width is None:
        max_width = 80
    if max_height is None:
        max_height = 40

    # 字符高度是寬度的一半 (因為每個字符代表兩個垂直像素)
    scale_w = min(max_width / orig_w, (max_height * 2) / orig_h)
    new_w = max(1, int(orig_w * scale_w))
    new_h = max(1, int(orig_h * scale_w / 2))

    img_resized = img.resize((new_w, new_h * 2), Image.LANCZOS)
    pixels = np.array(img_resized.convert('RGB'))

    lines = []
    for y in range(0, pixels.shape[0] - 1, 2):
        line = ""
        for x in range(pixels.shape[1]):
            top_r, top_g, top_b = pixels[y, x]
            bot_r, bot_g, bot_b = pixels[y + 1, x]

            # 使用上半塊字符 ▀，前景色為上半部，背景色為下半部
            fg = rgb_to_truecolor(top_r, top_g, top_b)
            bg = rgb_to_truecolor(bot_r, bot_g, bot_b)
            line += f"{fg}{bg}▀"

        lines.append(line + "\033[0m")  # 重置顏色

    return "\n".join(lines)


def image_to_braille_text(img, max_width=80, max_height=40):
    """
    使用 Braille 字符渲染圖片 (更高解析度: 每字符 2x4 像素)
    """
    # Braille Unicode 基礎: U+2800
    # 點位映射:
    # 0 3
    # 1 4
    # 2 5
    # 6 7

    BRAILLE_OFFSET = 0x2800
    BRAILLE_MAP = [
        [0x01, 0x08],
        [0x02, 0x10],
        [0x04, 0x20],
        [0x40, 0x80],
    ]

    orig_w, orig_h = img.size
    scale_w = min(max_width / (orig_w / 2), (max_height * 4) / orig_h)
    new_w = max(1, int(orig_w * scale_w / 2))
    new_h = max(1, int(orig_h * scale_w / 4))

    img_resized = img.resize((new_w * 2, new_h * 4), Image.LANCZOS)
    img_gray = img_resized.convert('L')
    pixels = np.array(img_gray)

    # 計算平均亮度作為閾值
    threshold = pixels.mean()

    lines = []
    for cy in range(new_h):
        line = ""
        for cx in range(new_w):
            code = BRAILLE_OFFSET
            for dy in range(4):
                for dx in range(2):
                    py = cy * 4 + dy
                    px = cx * 2 + dx
                    if py < pixels.shape[0] and px < pixels.shape[1]:
                        if pixels[py, px] < threshold:
                            code |= BRAILLE_MAP[dy][dx]
            line += chr(code)
        lines.append(line)

    return "\n".join(lines)


@pynvim.plugin
class ImageViewerPlugin:
    def __init__(self, nvim):
        self.nvim = nvim
        self.temp_files = []

    def _cleanup_temp(self):
        """清理臨時文件"""
        for f in self.temp_files:
            try:
                os.unlink(f)
            except:
                pass
        self.temp_files.clear()

    def _get_display_size(self):
        """獲取當前終端可顯示區域大小"""
        width = self.nvim.options.get('columns', 80)
        height = self.nvim.options.get('lines', 24)
        # 保留一些空間給狀態列
        return max(20, width - 2), max(10, height - 4)

    def _render_to_buffer(self, text, buf_name="ImageView"):
        """將渲染的文本顯示在新的 buffer 中"""
        self.nvim.command(f"new {buf_name}")
        buf = self.nvim.current.buffer

        # 設置 buffer 選項
        buf.options['buftype'] = 'nofile'
        buf.options['bufhidden'] = 'wipe'
        buf.options['swapfile'] = False
        buf.options['modifiable'] = True

        lines = text.split('\n')
        buf[:] = lines

        # 設置為只讀
        buf.options['modifiable'] = False
        buf.options['modified'] = False

    @pynvim.command("ShowImage", nargs="1", complete="file")
    def cmd_show_image(self, args):
        """顯示圖片文件 (PNG/JPG)"""
        filepath = args[0]

        if not os.path.exists(filepath):
            self.nvim.err_write(f"[ImageViewer] 文件不存在: {filepath}\n")
            return

        try:
            img = Image.open(filepath)
            max_w, max_h = self._get_display_size()

            # 使用半塊字符渲染
            text = image_to_halfblock_text(img, max_width=max_w, max_height=max_h)

            ext = os.path.splitext(filepath)[1].lower()
            buf_name = f"Image:{os.path.basename(filepath)}"
            self._render_to_buffer(text, buf_name)

            self.nvim.out_write(
                f"[ImageViewer] 已顯示: {filepath} "
                f"({img.size[0]}x{img.size[1]})\n"
            )
        except Exception as e:
            self.nvim.err_write(f"[ImageViewer] 錯誤: {str(e)}\n")

    @pynvim.command("ShowImageBraille", nargs="1", complete="file")
    def cmd_show_image_braille(self, args):
        """使用 Braille 字符顯示圖片 (更高解析度)"""
        filepath = args[0]

        if not os.path.exists(filepath):
            self.nvim.err_write(f"[ImageViewer] 文件不存在: {filepath}\n")
            return

        try:
            img = Image.open(filepath)
            max_w, max_h = self._get_display_size()

            text = image_to_braille_text(img, max_width=max_w, max_height=max_h)
            buf_name = f"Image(Braille):{os.path.basename(filepath)}"
            self._render_to_buffer(text, buf_name)

            self.nvim.out_write(f"[ImageViewer] Braille 模式已顯示: {filepath}\n")
        except Exception as e:
            self.nvim.err_write(f"[ImageViewer] 錯誤: {str(e)}\n")

    @pynvim.command("ShowMatplotlib", nargs="*", range="")
    def cmd_show_matplotlib(self, args, range):
        """
        顯示 matplotlib 圖形
        用法: 選中 Python 代碼後執行 :ShowMatplotlib
        或直接在當前 buffer 執行 matplotlib 代碼
        """
        try:
            import matplotlib
            matplotlib.use('Agg')  # 非 GUI 後端
            import matplotlib.pyplot as plt
        except ImportError:
            self.nvim.err_write("[ImageViewer] 需要安裝 matplotlib\n")
            return

        # 獲取當前 buffer 或選中的代碼
        buf = self.nvim.current.buffer

        if range and len(range) == 2:
            # 使用選中的行
            start, end = range
            code = "\n".join(buf[start-1:end])
        else:
            # 使用整個 buffer
            code = "\n".join(buf[:])

        try:
            # 在隔離的環境中執行代碼
            exec_globals = {
                'plt': plt,
                'np': np,
                '__name__': '__main__'
            }
            exec(code, exec_globals)

            # 獲取當前 figure 並保存為圖片
            fig = plt.gcf()

            # 保存到記憶體
            buf_io = io.BytesIO()
            fig.savefig(buf_io, format='png', dpi=100, bbox_inches='tight')
            buf_io.seek(0)

            plt.close(fig)

            # 讀取並渲染
            img = Image.open(buf_io)
            max_w, max_h = self._get_display_size()
            text = image_to_halfblock_text(img, max_width=max_w, max_height=max_h)

            self._render_to_buffer(text, "Matplotlib Output")
            self.nvim.out_write("[ImageViewer] Matplotlib 圖形已渲染\n")

        except Exception as e:
            self.nvim.err_write(f"[ImageViewer] 執行錯誤: {str(e)}\n")

    @pynvim.command("ShowMatplotlibFile", nargs="1", complete="file")
    def cmd_show_matplotlib_file(self, args):
        """執行 Python 文件中的 matplotlib 代碼並顯示結果"""
        filepath = args[0]

        if not os.path.exists(filepath):
            self.nvim.err_write(f"[ImageViewer] 文件不存在: {filepath}\n")
            return

        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt

            with open(filepath, 'r') as f:
                code = f.read()

            exec_globals = {
                'plt': plt,
                'np': np,
                '__name__': '__main__',
                '__file__': filepath
            }
            exec(code, exec_globals)

            fig = plt.gcf()
            buf_io = io.BytesIO()
            fig.savefig(buf_io, format='png', dpi=100, bbox_inches='tight')
            buf_io.seek(0)
            plt.close(fig)

            img = Image.open(buf_io)
            max_w, max_h = self._get_display_size()
            text = image_to_halfblock_text(img, max_width=max_w, max_height=max_h)

            self._render_to_buffer(text, f"Plot:{os.path.basename(filepath)}")
            self.nvim.out_write(f"[ImageViewer] 已顯示: {filepath} 的圖形輸出\n")

        except Exception as e:
            self.nvim.err_write(f"[ImageViewer] 錯誤: {str(e)}\n")

    @pynvim.function("ImageViewerShow", sync=True)
    def func_show_image(self, args):
        """VimL 可調用的函數"""
        if args:
            filepath = args[0]
            try:
                img = Image.open(filepath)
                max_w, max_h = self._get_display_size()
                return image_to_halfblock_text(img, max_width=max_w, max_height=max_h)
            except Exception as e:
                return f"Error: {str(e)}"
        return ""

    @pynvim.autocmd("VimLeavePre", sync=True, pattern="*")
    def on_vim_leave(self):
        """退出時清理"""
        self._cleanup_temp()

