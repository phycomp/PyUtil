import pynvim
import threading
import time

@pynvim.plugin
class StatusViewerPlugin(object):
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim
        self.buf = None
        self.win = None
        self.timer = None
        self.is_running = False
        
        # 效能監測數據
        self.last_render_time_ms = 0.0

        self.setup_global_keymap()

    def setup_global_keymap(self):
        """設定全域開啟面板快捷鍵"""
        opts = {'noremap': True, 'silent': True, 'desc': 'Open Status Viewer Profile'}
        self.nvim.api.set_keymap('n', '<leader>tvwr', ':NvimStatusViewer<CR>', opts)

    @pynvim.command('NvimStatusViewer', sync=True)
    def show_status(self):
        self.create_float_window("Nvim Diagnostic & Status Viewer")
        self.setup_highlights()
        self.setup_buffer_keymaps()

        self.is_running = True
        self.schedule_update()

    def create_float_window(self, title):
        self.buf = self.nvim.api.create_buf(False, True)

        columns = self.nvim.options['columns']
        lines = self.nvim.options['lines']
        width = int(columns * 0.75)
        height = int(lines * 0.75)
        row = int((lines - height) / 2)
        col = int((columns - width) / 2)

        win_opts = {
            'relative': 'editor',
            'width': width,
            'height': height,
            'row': row,
            'col': col,
            'style': 'minimal',
            'border': 'rounded',
            'title': f" {title} ",
            'title_pos': 'center',
        }

        self.win = self.nvim.api.open_win(self.buf, True, win_opts)

        self.nvim.command(
            f"autocmd BufWipeout <buffer={self.buf.handle}> "
            f"python3 _status_viewer_stop()"
        )

    def setup_buffer_keymaps(self):
        opts = {'noremap': True, 'silent': True}
        self.nvim.api.buf_set_keymap(self.buf, 'n', 'q', ':close<CR>', opts)
        self.nvim.api.buf_set_keymap(self.buf, 'n', '<Esc>', ':close<CR>', opts)
        self.nvim.api.buf_set_keymap(
            self.buf, 
            'n', 
            'r', 
            ':python3 _status_viewer_manual_refresh()<CR>', 
            opts
        )

    def setup_highlights(self):
        self.nvim.command("highlight default StatusWarn guifg=#e06c75 gui=bold")
        self.nvim.command("highlight default StatusOk guifg=#98be65 gui=bold")
        self.nvim.command("highlight default StatusTitle guifg=#51afef gui=bold")

        self.nvim.api.buf_set_option(self.buf, 'filetype', 'statusviewer')
        self.nvim.command("syntax match StatusWarn '\\[WARN\\].*'")
        self.nvim.command("syntax match StatusOk '\\[OK\\].*'")
        self.nvim.command("syntax match StatusTitle '^#.*'")

    def diagnose_keymap_slowness(self):
        """核心徵結點診斷邏輯"""
        results = []
        
        # 1. 檢查 timeoutlen 設定 (預設 1000ms，若太長且按鍵有衝突會感覺卡頓)
        timeoutlen = self.nvim.options['timeoutlen']
        if timeoutlen > 500:
            results.append(f"  [WARN] timeoutlen 為 {timeoutlen}ms (偏高)。若按鍵有前綴重疊，Vim 會強制等待 {timeoutlen}ms 才觸發！建議設為 300ms。")
        else:
            results.append(f"  [OK] timeoutlen 設定正常 ({timeoutlen}ms)")

        # 2. 檢查 <leader> 是否有前綴衝突 (例如同時存在 <leader>s 與 <leader>sv)
        leader_maps = self.nvim.api.get_keymap('n')
        sv_conflicts = [m['lhs'] for m in leader_maps if m['lhs'].startswith(self.nvim.eval('g:mapleader') + 's') and m['lhs'] != self.nvim.eval('g:mapleader') + 'sv']
        if sv_conflicts:
            results.append(f"  [WARN] 發現潛在按鍵衝突！與 <leader>sv 前綴重疊的按鍵: {', '.join(sv_conflicts)}")
        else:
            results.append("  [OK] 未發現與 <leader>sv 重疊的按鍵綁定")

        # 3. 檢查目前阻塞式 (sync) 的 Remote Plugins 數量
        rplugins = self.nvim.eval("len(get(g:, 'loaded_remote_plugins', {}))")
        results.append(f"  [OK] 當前已載入 Remote Plugins 節點數量: {rplugins}")

        return results

    def render_content(self):
        if not self.buf or not self.nvim.api.buf_is_valid(self.buf):
            self.stop_timer()
            return

        start_time = time.time()

        lines = [
            "# 🔍 按鍵反應過慢/卡頓 - 徵結點診斷 (Latency & Keymap Diagnostics)",
            ""
        ]

        # 執行診斷測試
        diag_results = self.diagnose_keymap_slowness()
        lines.extend(diag_results)

        lines.extend([
            "",
            "# ⏱ 效能與繪製監測 (Profiling)",
            "-" * 40,
            f"  * 本次 UI 渲染耗時: {self.last_render_time_ms:.2f} ms",
            f"  * 當前開啟 Buffer 總數: {len(self.nvim.buffers)}",
            "",
            f"> 自動更新中 | 上次刷新: {time.strftime('%H:%M:%S')} | [r] 手動刷新 [q] 關閉"
        ])

        self.nvim.api.buf_set_option(self.buf, 'modifiable', True)
        self.nvim.api.buf_set_lines(self.buf, 0, -1, False, lines)
        self.nvim.api.buf_set_option(self.buf, 'modifiable', False)

        # 計算計算耗時 (秒轉毫秒)
        self.last_render_time_ms = (time.time() - start_time) * 1000

    def schedule_update(self):
        if not self.is_running:
            return

        self.nvim.async_call(self.render_content)
        self.timer = threading.Timer(2.0, self.schedule_update)
        self.timer.daemon = True
        self.timer.start()

    def stop_timer(self):
        self.is_running = False
        if self.timer:
            self.timer.cancel()
            self.timer = None

    @pynvim.function('_status_viewer_stop')
    def _status_viewer_stop(self, args):
        self.stop_timer()

    @pynvim.function('_status_viewer_manual_refresh')
    def _status_viewer_manual_refresh(self, args):
        self.render_content()
