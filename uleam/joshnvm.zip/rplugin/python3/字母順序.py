import pynvim


@pynvim.plugin
class LetterShift:
    def __init__(self, nvim):
        self.nvim = nvim
        self._setup_keymaps()

    def _setup_keymaps(self):
        """Normal / Visual 模式自動綁定"""
        # ── 遞增 ──
        self.nvim.command("nnoremap <A-a> :LetterShiftNext<CR>")
        self.nvim.command("vnoremap <A-a> :LetterShiftNextVisual<CR>")
        # ── 遞減 ──
        self.nvim.command("nnoremap <A-x> :LetterShiftPrev<CR>")
        self.nvim.command("vnoremap <A-x> :LetterShiftPrevVisual<CR>")

    # ───────────── 遞增 ─────────────
    @pynvim.command('LetterShiftNext', sync=True)
    def shift_next(self):
        self._shift_single(self._next_letter)

    @pynvim.command('LetterShiftNextVisual', range=True, sync=True)
    def shift_next_visual(self, range):
        self._shift_visual(range, self._next_letter)

    # ───────────── 遞減 ─────────────
    @pynvim.command('LetterShiftPrev', sync=True)
    def shift_prev(self):
        self._shift_single(self._prev_letter)

    @pynvim.command('LetterShiftPrevVisual', range=True, sync=True)
    def shift_prev_visual(self, range):
        self._shift_visual(range, self._prev_letter)

    # ───────────── 核心邏輯 ─────────────
    def _shift_single(self, transform):
        """Normal 模式：只變換游標下的單一字元"""
        buf = self.nvim.current.buffer
        win = self.nvim.current.window
        row, col = win.cursor  # row: 1-based, col: 0-based

        try:
            line = buf[row - 1]
        except IndexError:
            return

        if col >= len(line):
            return

        char = line[col]
        new_char = transform(char)

        if new_char != char:
            buf[row - 1] = line[:col] + new_char + line[col + 1:]

    def _shift_visual(self, range, transform):
        """Visual 模式：變換選取範圍內的所有字母"""
        buf = self.nvim.current.buffer
        start, end = range[0] - 1, range[1]

        new_lines = []
        for line in buf[start:end]:
            new_lines.append(''.join(transform(c) for c in line))

        buf[start:end] = new_lines

    def _next_letter(self, char):
        """字母遞增，z/Z 循環回 a/A"""
        if char == 'z':
            return 'a'
        if char == 'Z':
            return 'A'
        if 'a' <= char <= 'y':
            return chr(ord(char) + 1)
        if 'A' <= char <= 'Y':
            return chr(ord(char) + 1)
        return char

    def _prev_letter(self, char):
        """字母遞減，a/A 循環回 z/Z"""
        if char == 'a':
            return 'z'
        if char == 'A':
            return 'Z'
        if 'b' <= char <= 'z':
            return chr(ord(char) - 1)
        if 'B' <= char <= 'Z':
            return chr(ord(char) - 1)
        return char
