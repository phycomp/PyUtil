def dkjd():
  for ndx in range(10):
    print(ndx)
dkjd()
