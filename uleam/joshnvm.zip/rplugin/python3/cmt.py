import pynvim

# 各種 FileType 對應的單行註解符號設定
COMMENT_MAP = { 'python': '#', 'sh': '#', 'bash': '#', 'zsh': '#',
   'lua': '---', 'vim': '"', 'c': '//', 'cpp': '//', 'tex':'%',
   'javascript': '//', 'typescript': '//', 'go': '//', 'rust': '//',
}

@pynvim.plugin
class CommenterPlugin:
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim

    @pynvim.autocmd('VimEnter', sync=False)
    def on_vimenter(self):
        self.nvim.api.set_keymap('n', '<leader>cmt', ':CommentToggle<CR>', {'silent': True, 'noremap': True, 'desc': '開啟 ShaDa 檢視器'}
        )

    @pynvim.command('CommentToggle', nargs=0, sync=True)
    def toggle_comment(self):
        # 取得當前 buffer 與 filetype
        buffer = self.nvim.current.buffer
        filetype = self.nvim.eval('&filetype')

        # 尋找對應的註解符號，若未設定則預設使用 '#'
        comment_symbol = COMMENT_MAP.get(filetype, '#')

        # 取得游標當前行號 (1-indexed -> 0-indexed)
        cursor_row, _ = self.nvim.current.window.cursor
        line_idx = cursor_row - 1
        line = buffer[line_idx]

        # 計算前導空白（保持縮排）
        stripped = line.lstrip()
        indent = line[:len(line) - len(stripped)]

        # 判斷是否已經有註解，並切換狀態
        # 支援 comment_symbol 後帶有空格的情況，例如 '# ' 或 '--- '
        symbol_with_space = f"{comment_symbol} "

        if stripped.startswith(symbol_with_space):
            # 取消註解（有帶空格）
            # buffer[line_idx] = stripped[len(symbol_with_space):]
            buffer[line_idx] = indent + stripped[len(symbol_with_space):]
        elif stripped.startswith(comment_symbol):
            # 取消註解（無帶空格）
            # buffer[line_idx] = stripped[len(comment_symbol):]
            buffer[line_idx] = indent + stripped[len(comment_symbol):]
        else:
            # 加入註解
            # buffer[line_idx] = f"{comment_symbol}{stripped}"
            buffer[line_idx] = f"{indent}{comment_symbol} {stripped}"
