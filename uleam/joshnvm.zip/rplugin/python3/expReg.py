import pynvim
from re import match as reMatch, search as reSrch
from datetime import datetime
#import vim

@pynvim.plugin
class LineNumberer(object):
    def __init__(self, nvim: pynvim.Nvim):
        self.nvim = nvim

    @pynvim.autocmd("VimEnter", sync=True)
    def setup(self):
        self.nvim.api.set_keymap('n', '<leader>ifn', '<cmd>InsertFileName<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>ict', '<cmd>InsertCurrentTime<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>icd', '<cmd>InsertCurrentDate<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>sln', '<cmd>SeqLineNumber<CR>', {'noremap':True, 'silent':False})
        self.nvim.api.set_keymap('n', '<leader>aln', '<cmd>AbsLineNumber<CR>', {'noremap':True, 'silent':False})

    # 1. 插入絕對行號的命令
    @pynvim.command('AbsLineNumber', range=True)
    def abs_line_number(self, 範圍):
        start_line, end_line = 範圍[0], 範圍[1]
        buf = self.nvim.current.buffer
        for ndx in range(len(buf)):
        #for ndx in range(start_line - 1, end_line):
            line = buf[ndx]
            if reMatch(r'^[0-9]+\.', line): continue
            buf[ndx] = f"{ndx + 1}. {line}"
        self.nvim.out_write(f"已成功加入絕對行號\n")

    # 2. 插入自訂流水號的命令
    @pynvim.command('SeqLineNumber', range=True)
    def seq_line_number(self, 範圍):
        start_line, end_line = 範圍[0], 範圍[1]
        buf = self.nvim.current.buffer
        counter = 1
        for ndx in range(start_line - 1, end_line):
            current_text = buf[ndx]
            buf[ndx] = f"{counter}. {current_text}"
            counter += 1
        self.nvim.out_write(f"已成功加入自訂流水號\n")

    # 3. 新增：動態在游標位置插入當前系統時間
    @pynvim.command('InsertCurrentTime')
    def insert_current_time(self):
        # 取得當前時間字串
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M")
        
        # 取得當前視窗與游標位置 (列, 行)，注意：Vim 行號從 1 開始，列號（字元位置）從 0 開始
        row, col = self.nvim.current.window.cursor
        buf = self.nvim.current.buffer
        
        # 取得目前那一行的文字
        current_line_text = buf[row - 1]
        
        # 將時間字串切片插入到游標所在位置
        new_line_text = current_line_text[:col] + current_time + current_line_text[col:]
        buf[row - 1] = new_line_text
        
        # 移動游標至新插入文字的後方
        self.nvim.current.window.cursor = (row, col + len(current_time))

    # 4. 新增：動態在游標位置插入當前系統日期
    @pynvim.command('InsertCurrentDate')
    def insert_current_time(self):
        # 取得當前時間字串
        current_time = datetime.now().strftime("%Y-%m-%d")
        
        # 取得當前視窗與游標位置 (列, 行)，注意：Vim 行號從 1 開始，列號（字元位置）從 0 開始
        row, col = self.nvim.current.window.cursor
        buf = self.nvim.current.buffer
        
        # 取得目前那一行的文字
        current_line_text = buf[row - 1]
        
        # 將時間字串切片插入到游標所在位置
        new_line_text = current_line_text[:col] + current_time + current_line_text[col:]
        buf[row - 1] = new_line_text
        
        # 移動游標至新插入文字的後方
        self.nvim.current.window.cursor = (row, col + len(current_time))

    # 5. 新增：利用 Lua API 取得當前檔案名並插入游標位置
    @pynvim.command('InsertFileName')
    def insert_file_name(self):
        # 透過 nvim.lua 執行 Lua 表達式，取得僅含副檔名的主檔名 (expand('%:t'))
        file_name = self.nvim.lua.eval("vim.fn.expand('%:t')")
        
        # 如果是新建立且尚未存檔的空白緩衝區，給予預設提示
        if not file_name or file_name == "":
            file_name = "[未命名檔案]"
            
        row, col = self.nvim.current.window.cursor
        buf = self.nvim.current.buffer
        current_line_text = buf[row - 1]
        
        # 插入檔名
        new_line_text = current_line_text[:col] + file_name + current_line_text[col:]
        buf[row - 1] = new_line_text
        
        # 移動游標
        self.nvim.current.window.cursor = (row, col + len(file_name))
