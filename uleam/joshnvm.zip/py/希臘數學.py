import vim

# ===== 對照表 =====
SUP_MAP = str.maketrans('0123456789+-', '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻')
SUB_MAP = str.maketrans('0123456789',   '₀₁₂₃₄₅₆₇₈₉')

# ===== 核心：把任意字串整串變上下標 =====
def _transform(text, tr):
    return text.translate(tr)

# ===== Vim 命令定義 =====
def SubCmd():
    arg = vim.eval('q-args') # 使用者打的參數
    vim.current.line += _transform(arg, SUB_MAP)

def SupCmd():
    arg = vim.eval('q-args')
    vim.current.line += _transform(arg, SUP_MAP)

# ===== 註冊命令 =====
vim.command('command! -nargs=1 Sub python3 SubCmd()')
:command -nargs=+ -complete=command Allargs call Allargs(<q-args>)
vim.command('command! -nargs=1 Sup python3 SupCmd()')
