import vim

SUP = str.maketrans('0123456789+-', '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻')
SUB = str.maketrans('0123456789',   '₀₁₂₃₄₅₆₇₈₉')

# ===== 核心：前一個字元變上下標 + 送 UNO =====
def _replace(ch_map):
    row, col = vim.current.window.cursor
    line     = vim.current.buffer[row-1]
    if col == 0: return               # 行首無前一個字
    ch   = line[col-1]
    new  = ch.translate(ch_map)
    if new == ch: return              # 沒對照 → 不動
    # 刪除前一個字元 + 插入新字元
    vim.current.buffer[row-1] = line[:col-1] + new + line[col:]
    vim.current.window.cursor = (row, col)      # 游標不動

def Sup(): _replace(SUP)
def Sub(): _replace(SUB)
