import re
import pynvim

@pynvim.plugin
class CmdlineEmacsPlugin(object):
    def __init__(self, nvim):
        self.nvim = nvim

    @pynvim.autocmd('VimEnter', sync=False)
    def on_vim_enter(self):
        """當 Neovim 啟動時，直接透過全域 API 綁定鍵位"""
        
        # 1. 回到開頭、行尾
        self._bind_key('<C-a>', 'CmdlineMoveHome')
        self._bind_key('<C-e>', 'CmdlineMoveEnd')
        
        # 2. 往前、往後一字元 char
        self._bind_key('<A-h>', 'CmdlineMoveCharLeft')
        self._bind_key('<A-l>', 'CmdlineMoveCharRight')
        
        # 3. 往前、往後一字 word
        self._bind_key('<A-b>', 'CmdlineMoveWordLeft')
        self._bind_key('<A-f>', 'CmdlineMoveWordRight')
        
        # 4. 刪除一個字 word
        self._bind_key('<C-w>', 'CmdlineDeleteWordLeft')
        
        # 5. 刪除游標處往後所有字元
        self._bind_key('<C-k>', 'CmdlineDeleteToEnd')
        
        # 6. 命令列貼上暫存器 (釋放 C-p, C-n；改用 C-y 與 A-p)
        self._bind_key('<C-y>', 'CmdlinePasteRegisterClip')
        self._bind_key('<A-p>', 'CmdlinePasteRegisterUnnamed')

    def _bind_key(self, shortcut, func_name):
        """使用 <Cmd>call func()<CR> 方式綁定，這樣不會干擾或中斷命令列輸入狀態"""
        rhs = f"<Cmd>call {func_name}()<CR>"
        self.nvim.api.set_keymap('c', shortcut, rhs, {'silent': True, 'noremap': True})

    def _get_info(self):
        """獲取目前命令列文字與游標位置（Vim 游標從 1 開始）"""
        line = self.nvim.call('getcmdline')
        pos = self.nvim.call('getcmdpos') - 1
        return line, pos

    def _update_cmdline(self, new_line, new_pos_0_indexed):
        """更新命令列文字與游標位置"""
        self.nvim.call('setcmdline', new_line)
        self.nvim.call('setcmdpos', new_pos_0_indexed + 1)

    @pynvim.function('CmdlineMoveHome', sync=True)
    def move_home(self, args):
        line, _ = self._get_info()
        self._update_cmdline(line, 0)

    @pynvim.function('CmdlineMoveEnd', sync=True)
    def move_end(self, args):
        line, _ = self._get_info()
        self._update_cmdline(line, len(line))

    @pynvim.function('CmdlineMoveCharLeft', sync=True)
    def move_char_left(self, args):
        line, pos = self._get_info()
        if pos > 0:
            self._update_cmdline(line, pos - 1)

    @pynvim.function('CmdlineMoveCharRight', sync=True)
    def move_char_right(self, args):
        line, pos = self._get_info()
        if pos < len(line):
            self._update_cmdline(line, pos + 1)

    @pynvim.function('CmdlineMoveWordLeft', sync=True)
    def move_word_left(self, args):
        line, pos = self._get_info()
        if pos == 0:
            return
        left_part = line[:pos]
        matches = list(re.finditer(r'\b\w+|\s+', left_part))
        new_pos = matches[-1].start() if matches else 0
        self._update_cmdline(line, new_pos)

    @pynvim.function('CmdlineMoveWordRight', sync=True)
    def move_word_right(self, args):
        line, pos = self._get_info()
        if pos >= len(line):
            return
        right_part = line[pos:]
        match = re.search(r'\w+\b|\s+', right_part)
        new_pos = pos + match.end() if match else len(line)
        self._update_cmdline(line, new_pos)

    @pynvim.function('CmdlineDeleteWordLeft', sync=True)
    def delete_word_left(self, args):
        line, pos = self._get_info()
        if pos == 0:
            return
        left_part = line[:pos]
        matches = list(re.finditer(r'\b\w+|\s+', left_part))
        start_del = matches[-1].start() if matches else 0
        
        new_line = line[:start_del] + line[pos:]
        self._update_cmdline(new_line, start_del)

    @pynvim.function('CmdlineDeleteToEnd', sync=True)
    def delete_to_end(self, args):
        line, pos = self._get_info()
        new_line = line[:pos]
        self._update_cmdline(new_line, pos)

    @pynvim.function('CmdlinePasteRegisterClip', sync=True)
    def paste_register_clip(self, args):
        self._paste_reg('*')

    @pynvim.function('CmdlinePasteRegisterUnnamed', sync=True)
    def paste_register_unnamed(self, args):
        self._paste_reg('"')

    def _paste_reg(self, reg):
        reg_content = self.nvim.call('getreg', reg).replace('\n', ' ')
        line, pos = self._get_info()
        new_line = line[:pos] + reg_content + line[pos:]
        self._update_cmdline(new_line, pos + len(reg_content))
