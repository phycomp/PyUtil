import vim

# ===== 對照表 =====
#上標 = str.maketrans('0123456789+-', '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻')
上標 = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴', '5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','+':'⁺','-':'⁻'}
#SUB_MAP = str.maketrans('0123456789', '₀₁₂₃₄₅₆₇₈₉')   # 數字下標
下標 = {'0':'₀','1':'₁','2':'₂','3':'₃','4':'₄', '5':'₅','6':'₆','7':'₇','8':'₈','9':'₉'}
#下標 = str.maketrans('0123456789',   '₀₁₂₃₄₅₆₇₈₉')
#print(下標)
# 反向表（用來「再按一次」恢復）
上標反查 = {v: k for k, v in 上標.items()}
下標反查 = {v: k for k, v in 下標.items()}

# ===== 核心：置換游標「下方」字元 =====
def _replace(字元表, 反查表):
    """ch_map: 正對照, rev_map: 反對照（用來切回）"""
    #print([字元表, 反查表])
    row, col = vim.current.window.cursor        # 1-based
    line     = vim.current.buffer[row-1]
    if col >= len(line): return                 # 行尾無字元
    #ch = line[col]                             # 游標「下方」字元
    ch  = line[col] if col < len(line) else ''
    #print(f"row={row} col={col} ch='{ch}'")
    #new = ch.translate(ch_map) if ch in ch_map else rev_map.get(ch, ch)
    #new = ch.translate(上標) if ch in 上標 else 上標反查.get(ch, ch)
    new = 字元表.get(ch, 反查表.get(ch, ch))   # 先正表，再反表，再原字
    # 原地置換
    #print(f'{ch}-->{new}')
    vim.current.buffer[row-1] = line[:col] + new + line[col+1:]
    # 游標留在原地
    vim.current.window.cursor = (row, col)

# ===== Vim 命令 =====
def Sup(): _replace(上標, 上標反查)   # 上標
def Sub(): _replace(下標, 下標反查)   # 下標

# ===== 快速鍵（可選） =====
vim.command('nnoremap <leader>sup :python3 Sup()<CR>')
vim.command('nnoremap <leader>sub :python3 Sub()<CR>')
