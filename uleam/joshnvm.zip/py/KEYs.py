#from pynvim import autocmd

#@autocmd('BufEnter,BufNewFile,BufRead', pattern='*.py', eval='expand("<afile>")', sync=True)
#def onBufenter(fname):
# print('testplugin is in ' + fname)

#au BufNewFile,BufRead *.py
#    \ set expandtab       |" replace tabs with spaces
#    \ set autoindent      |" copy indent when starting a new line
#    \ set tabstop=4
#    \ set softtabstop=4
#    \ set shiftwidth=4
#from pathlib import Path
#from os import system
#from os.path import splitext
#from os import system

#@autocmd('FileType,VimEnter,BufRead,BufNewFile', pattern='*', sync=True)

vim.command('vnoremap <C-X> "+x<CR>')
#vim.api.set_keymap('n', '<leader>prnt', '<cmd>!import -window root -pause 4 /tmp/kdjdk.png|gimp /tmp/kdjdk.png&<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>rvs', '<cmd>update<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap("c", "<M-b>", "<S-Left>", {'noremap':True, 'silent':False})
vim.api.set_keymap("c", "<M-f>", "<S-Right>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>new', '<cmd>enew<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>cpn', '<cmd>copen<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>qq', '<cmd>q<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>nwb', '<cmd>new<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>spl', '<cmd>split<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>nhl', '<cmd>nohlsearch<CR>', {'noremap':True, 'silent':False})
##tabUtil
#vim.api.set_keymap('n', '<leader>sc', '<cmd>hi clear Search|hi Search ctermfg=46 ctermbg=DarkRed<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>zz', '<cmd>ZZ<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>trp', '<cmd>term python %<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>chd', "<cmd>CHADopen<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pyf', '<cmd>py3file %<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>dag', '<cmd>%d<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>yag', '<cmd>%y<CR>', {'noremap':True, 'silent':False})
#按下快捷鍵後，命令列會停留並自動帶出 :RemvPttrn 和一個空格，等待您輸入 args
#vim.api.set_keymap('n', '<leader>rmp', ':RemvPttrn ', {
#  'silent':True, #-- 必須設為 false，因為需要讓使用者看見命令列並繼續輸入
#  'desc':"執行 RemvPttrn 註解功能（後續可接 args）"
#})
##substituUtil
vim.api.set_keymap('n', '<leader>urs', '<cmd>call UltiSnips#RefreshSnippets()<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>qa', '<cmd>qa!<CR>', {'noremap':True, 'silent':False})
"""
def EPYS(arg):
    #PYTHON=vim.eval("a:arg")
    import vim
    vim.command(f':edit ~/.config/nvim/py/{arg}.py')
:put =execute('messages')將messages訊息貼上 或是let @* = execute('messages')
"""
