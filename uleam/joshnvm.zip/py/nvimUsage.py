from pynvim import attach
# Create a python API session attached to unix domain socket created above:
nvim = attach('socket', path='/tmp/nvim')
# Now do some work.
buffer = nvim.current.buffer # Get the current buffer
buffer[0] = 'replace first line'
buffer[:] = ['replace whole buffer']
nvim.command('vsplit')
nvim.windows[1].width = 10
nvim.vars['global_var'] = [1, 2, 3]
nvim.eval('g:global_var')

argv = ['nvim', '-u', VIMRC, '--embed', '--headless']
vim = neovim.attach('child', argv=argv)
argv = ['nvim', '-u', VIMRC, '--embed', '--headless']
vim = neovim.attach('child', argv=argv)
return WrappedVim(vim)

