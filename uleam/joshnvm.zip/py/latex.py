vim.api.set_keymap('n', '<leader>ltx', '<cmd>%s/ \\?\\\\[()] \\?/$/g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>blt', '<cmd>%s/\\\\[\\[\\]]/$$/g<CR>', {'noremap':True, 'silent':False})
