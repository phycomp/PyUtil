import vim
#pynvim.vim.set_keymap('n', )
#nnoremap <buffer> <silent> <localleader>R :JupyterRunFile<CR>
#vim.api.set_keymap('n', '<leader>R', "<cmd>JupyterRunFile<CR>", {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>l', "<cmd>PythonImportThisFile<CR>", {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>d', "<cmd>JupyterCd %:p:h<CR>", {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>X', "<cmd>JupyterSendCell<CR>", {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>E', "<cmd>JupyterSendRange<CR>", {'noremap':True, 'silent':False})
vim.command(
'''
  nnoremap <buffer> <silent> <localleader>R :JupyterRunFile<CR>
  nnoremap <buffer> <silent> <localleader>I :PythonImportThisFile<CR>
  " Change to directory of current file
  nnoremap <buffer> <silent> <localleader>d :JupyterCd %:p:h<CR>
  " Send a selection of lines
  nnoremap <buffer> <silent> <localleader>X :JupyterSendCell<CR>
  nnoremap <buffer> <silent> <localleader>E :JupyterSendRange<CR>
  nmap     <buffer> <silent> <localleader>e <Plug>JupyterRunTextObj
  vmap     <buffer> <silent> <localleader>e <Plug>JupyterRunVisual
  " Debugging maps
  nnoremap <buffer> <silent> <localleader>b :PythonSetBreak<CR>
'''
)
