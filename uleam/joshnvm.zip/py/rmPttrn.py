from re import search as reSrch, match as reMatch

def zfill_pttrn(args=2):
    args=int(args)
    buf = vim.current.buffer
    for ndx in range(len(buf)):
        line = buf[ndx]
        if mtch := reMatch(r'(\d+)', line):
          比對=mtch.group(0)
          比對位置=len(比對)
          buf[ndx]=比對.zfill(args)+line[比對位置:]
        #else: pass

def remove_pattern(args='---'):
    buf = vim.current.buffer
    count = 0
    #has_args = args if args else None

    參數 = [arg.lower() for arg in args.split()]+['---'] if args !='---' else args # 將所有傳入參數轉為小寫
    #print(參數)
    for ndx in range(len(buf)): # 逐行掃描並處理
        line = buf[ndx]
        #if not has_args:
        #    # 1. 沒加參數：預設只註解整行只有 "---" 的行 (忽略前後空格)
        #    #if line.strip() == "---":
        #else:
        #    # 2. 有加參數：不分大小寫檢查關鍵字
        該行 = line.lower()
        for pttrn in 參數:
          if reSrch(pttrn, 該行):
            buf[ndx]=f'#{line}'
            count += 1
          #if reSrch('#', line): continue
          #elif reSrch('---', line):
          #  buf[ndx]=f'#{line}'
          #  count += 1

        # 如果符合註解條件，且該行「尚未被註解」，就加上 Markdown 註解

    # 輸出結果提示
    #if has_args: print(f"已註解 {count} 行包含指定關鍵字 {', '.join(args)} 的文字\n")
    #else: print(f"預設模式：已註解 {count} 行包含 --- 的文字\n")

vim.command(':com! -nargs=* ZfillPttrn py3 zfill_pttrn(<f-args>)')
vim.api.set_keymap('n', '<leader>zfp', ":ZfillPttrn ", {'noremap':True, 'silent':False})
vim.command(':com! -nargs=* RmPttrn py3 remove_pattern(<f-args>)')
vim.api.set_keymap('n', '<leader>rmp', ":RmPttrn ", {'noremap':True, 'silent':False})
