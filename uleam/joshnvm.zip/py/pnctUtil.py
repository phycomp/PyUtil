vim.api.set_keymap('n', '<leader>cdd', '<cmd>%s/[:,]/ /g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>str', "<cmd>%s/use_container_width=True/width='stretch'/g<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>cnt', "<cmd>%s/use_container_width=False/width='content'/g<CR>", {'noremap':True, 'silent':False})
#use_container_width=True`, use `width='stretch'`. For `use_container_width=False`, use `width='content
vim.api.set_keymap('n', '<leader>pnct', '<cmd>%s/[■≫❵❴；。：，（）「」]/ /g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>mdd', '/^\\d<S-V>nnkJ\\mb', {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>slb', '<cmd>.s/ //g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>alp', '<cmd>%s/alpha/α/gc<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>spi', '<cmd>%s/pi/π/gc<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>bet', '<cmd>%s/beta/β/gc<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>phi', '<cmd>%s/phi/φ/gc<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>phi', '<cmd>%s/mu/φ/gc<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>dlt', '<cmd>%s/del/Δ/g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>saz', '<cmd>%s/[a-zA-Z]\\+ \\?//g<CR>', {'noremap':True, 'silent':False})  #a-z
vim.api.set_keymap('n', '<leader>spy', '<cmd>%s/```.*\\n//g<CR>', {'noremap':True, 'silent':False})  #a-z
vim.api.set_keymap('n', '<leader>dsh', '<cmd>%s/\\n---\\n//g<CR>', {'noremap':True, 'silent':False})  #a-z
vim.api.set_keymap('n', '<leader>dgt', '<cmd>%s/\\d\\+//g<CR>', {'noremap':True, 'silent':False})   #digit
vim.api.set_keymap('n', '<leader>mts', '<cmd>%s/pmc\\.\\|pn\\.\\|mpatches\\.\\|base64\\.\\|scq\\.\\|squbit\\.\\|binascii\\.\\|ecdsa\\.\\|hashlib\\.\\|px\\.\\|pv\\.\\|pyfirmata2\\.\\|Gtk\\.\\|serial\\.\\|socket\\.\\|argparse\\.\\|signal\\.\\|subprocess\\.\\|threading\\.\\|serial\\.\\|random\\.\\|pywifi\\.\\|yaml\\.\\|rf\\.\\|go\\.\\|sys\\.\\|re\\.\\|pymunk\\.\\|plt\\.\\|st\\.\\|sp\\.\\|pm\\.\\|pd\\.\\|alt\\.\\|np\\.\\|sidebar\\.//g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>sbx', '<cmd>%s/selectbox/radio/g<CR>', {'noremap':True, 'silent':False})
#:%s/\v(st\.selectbox\s*\%(.*\n\){-}.*)\@<=\_s\zs)/, horizontal=True)/g
vim.api.set_keymap('n', '<leader>hes', '<cmd>.s/ //g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>mb', '<cmd>%s/ \\+/ /g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>ll', '<cmd>%s/^$\\n//g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>rq', '<cmd>%s# \\?\\([：；、?。！？﹖◎]\\) \\?#\\1#g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>dga', '<cmd>%s#\\(\\d\\+\\)#\\1.#g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>dm', '<cmd>%s#\#<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>aa', '<cmd>%s#\\([a-zA-Z]\\)#\\1.#g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>add', '<cmd>%s#\\([a-zA-Z0-9]\\)#\\1.#g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>ru', '<cmd>%s#[^\\u4E00-\\u9FFF|，：。；、! ！#0-9:\\?\\.？a-zA-Z\\/」●◆「《》～\\%\\=◎|[:punct:]]##g<CR>', {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>qr', '<cmd>%s/[（）「」]/ /g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>rb', '<cmd>%s/[- ]\\+$//g<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>cmb', '<cmd>%s/ \\+/ /g<CR><cmd>%s/ \\+$//g<CR><cmd>%s# \\=\\([：、?！？]\\) \\=#\\1#g<CR>', {'noremap':True, 'silent':False})
#vim.api.set_keymap('n', '<leader>mts', '<cmd>%s/p\\.\\|sxtwl\\.\\|random\\.\\|pywifi\\.\\|time\\.\\|yaml\\.\\|rf\\.\\|go\\.\\|sys\\.\\|re\\.\\|pymunk\\.\\|plt\\.\\|st\\.\\|sp\\.\\|pm\\.\\|pd\\.\\|alt\\.\\|np\\.\\|sidebar\\.//g<CR>', {'noremap':True, 'silent':False})
