class UltiImporter:
    def gen_ulti_snip_import(self, args):
            # 掃描全檔案
            lines = self.nvim.current.buffer[:]

        content = '\n'.join(lines)

        # 2. 定義要抓的函式庫別名
        lib_map = {'yf':'yfinance', 'dq':'deepquantum', 'pn':'panel', 'bllt':'pybullet', 'mpatches':'mpatches', 're':'re', 'base64':'base64', 'scq':'scq', 'squbit':'squbit', 'binascii':'binascii', 'ecdsa':'ecdsa', 'threading':'threading', 'pv':'pyvista', 'uuid':'uuid', 'hashlib':'hashlib', 'base64':'base64', 'tornado.httpserver':'tornado.httpserver', 'pyfirmata2':'pyfirmata2', 'datetime':'datetime', 'asyncio':'asyncio', 'Gtk':'Gtk', 'gi':'gi', 'signal':'signal', 'serial':'serial', 'socket':'socket', 'argparse':'argparse', 'pathlib':'pathlib', 'pmc':'pymc', 'pm':'pymunk', 'folium':'folium', 'st':'streamlit', 'sp':'sympy', 'alt':'altair', 'go':'plotly.graph_objects', 'plt':'matplotlib.pyplot', 'ast':'ast', 'sxtwl':'sxtwl', 'psycopg':'psycopg', 'threading':'threading', 'np':'numpy', 'random':'random', 'time':'time', 'pywifi':'pywifi', 'bcrypt':'bcrypt', 'glob':'glob', 'pickle':'pickle', 'json':'json', 'pd':'pandas', 'rf':'skrf', 'pywt':'pywt', 'sys':'sys', 'sidebar':'sidebar', 'z2pack':'z2pack', 'yaml':'yaml', 'sxtwl':'sxtwl' }  #plotly.graph_objects

        # 3. 正則找出所有 st.xxx / alt.yyy / plt.zzz
        #    \b 確保是單字邊界，避免抓到字串裡的內容
        pattern = r'\b(' + '|'.join(lib_map.keys()) + r')\.([A-Za-z_]\w*)'
        found = {key: set() for key in lib_map}
        
        for lib_short, attr in re.findall(pattern, content):
            found[lib_short].add(attr)

        # 4. 組合成 import 字串
        imports = []
        for short, full_name in lib_map.items():
            if found[short]:
                attrs = sorted(found[short])  # 排序讓結果穩定
                line = f"from {full_name} import {', '.join(attrs)}"
                imports.append(line)

        # 5. 插入到檔案最上方
        if imports:
            self.nvim.current.buffer.append(imports, index=0)
            # 移動遊標到第一行
            self.nvim.current.window.cursor = (1, 0)
        else:
            self.nvim.echo("沒有找到任何 st/alt/plt 模式")
vim.command('nnoremap <leader>gim :GenUltiSnipImport<CR>') # 全檔案掃描
vim.command(':com! -complete=command -nargs=* GenUltiSnipImport py3 getMark(<f-args>)')
