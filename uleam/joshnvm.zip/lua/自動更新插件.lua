-- ====================================================================
-- 核心功能：不重啟 Neovim，強制殺掉並重載 Python 遠端插件進程
-- ====================================================================
local function reload_python_remote_plugins()
    -- 1. 儲存當前所有檔案（避免未存檔遺失），並更新遠端插件清單
    vim.cmd('silent! wa')
    vim.cmd('UpdateRemotePlugins')

    -- 2. 尋找並終止舊的 python3 RPC 頻道進程
    local found = false
    for _, chan in ipairs(vim.api.nvim_list_chans()) do
        if chan.stream == "job" and chan.client and chan.client.name == "python3" then
            vim.fn.jobstop(chan.id)
            found = true
        end
    end

    -- 3. 提示使用者結果
    if found then
        vim.notify("regMark.py 已成功在線熱重載！", vim.log.levels.INFO)
    else
        vim.notify("未找到執行中的 Python 頻道，已重新初始化清單。", vim.log.levels.WARN)
    end
end

-- ====================================================================
-- 需求 1：將功能綁定為快捷鍵 (這裡以 <leader>rp 為例，意為 Reload Python)
-- ====================================================================
vim.keymap.set('n', '<leader>rp', reload_python_remote_plugins, { 
    desc = "不用重啟 Neovim，即時熱重載 Python 遠端插件" 
})

-- ====================================================================
-- 需求 2：自動偵測 regMark.py 檔案變更並即時重載
-- ====================================================================
local augroup = vim.api.nvim_create_augroup("RemotePluginAutoReload", { clear = true })

vim.api.nvim_create_autocmd("BufWritePost", {
    group = augroup,
    pattern = "*regMark.py", -- 只要檔名是 regMark.py 的檔案寫入/存檔後
    callback = function()
        -- 觸發重載函式
        reload_python_remote_plugins()
    end,
    desc = "當 regMark.py 存檔時自動熱重載 Python 遠端插件",
})
