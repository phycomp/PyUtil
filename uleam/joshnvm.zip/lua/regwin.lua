-- Registers Viewer 配置
vim.g.registers_viewer_config = {
    width = 70,
    height = 35,
    border_style = "rounded",
    show_empty = false,
    auto_close = true,
    auto_close_delay = 300,
}

-- 快捷鍵
-- vim.keymap.set('n', '<Leader>rv', '<cmd>RegistersView<CR>', { silent = true })
vim.keymap.set('n', '<Leader>rvw', '<cmd>RegistersView<CR>', { silent = true })
