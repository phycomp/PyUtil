-- 1. 建立一個 Lua 函式，用來獲取 CHADTree 當前選中的檔案路徑並呼叫 MimeOpen
_G.chadtree_mime_open = function()
  -- CHADTree 提供了內建的 API 來獲取當前游標所在節點的絕對路徑
  local stat = vim.fn['chadtree#get_current_node']()
  
  if stat and stat.path then
    local path = stat.path
    -- 如果是目錄，我們希望保持 CHADTree 原本的展開/折疊功能
    if vim.fn.isdirectory(path) == 1 then
      -- 執行 CHADTree 原本的 primary 行為 (展開/收合)
      vim.api.nvim_feedkeys(vim.api.nvim_replace_termcodes("<CR>", true, false, true), "n", false)
    else
      -- 如果是檔案，呼叫我們的 Python 遠端插件，並帶入路徑參數
      vim.cmd("MimeOpen " .. vim.fn.fnameescape(path))
    end
  end
end

-- 2. 將這個函式綁定到 CHADTree 的自訂金鑰映射中
-- 這裡我們將其綁定到 'o' 鍵（你也可以改綁定到大寫 'O' 或其他不衝突的按鍵）
vim.g.chadtree_settings = {
  keymap = {
    -- v:lua.chadtree_mime_open() 會呼叫上面寫的全域 Lua 函式
    -- <CR> 代表執行
    custom_open = { "o" }
  }
}

-- 3. 設定當進入 CHADTree 視窗時，將 custom_open 對應到該 Lua 函式
vim.api.nvim_create_autocmd("FileType", {
  pattern = "chadtree",
  callback = function()
    -- 為當前 CHADTree buffer 獨立綁定 'o' 鍵
    vim.keymap.set("n", "o", "<cmd>lua _G.chadtree_mime_open()<CR>", { buffer = true, silent = true })
  end,
})
