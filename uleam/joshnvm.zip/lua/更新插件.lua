-- 1. 更新資訊清單
vim.cmd('UpdateRemotePlugins')

-- 2. 找出並砍掉舊的 Python 遠端插件進程，迫使 Neovim 重新載入
for _, chan in ipairs(vim.api.nvim_list_chans()) do
    if chan.stream == "job" and chan.client and chan.client.name == "python3" then
        vim.fn.jobstop(chan.id)
    end
end

print("Python 遠端插件已在不重啟 Neovim 的情況下完成熱重載！")
