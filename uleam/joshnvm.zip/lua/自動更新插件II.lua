-- ====================================================================
-- 核心功能：根據指定的 Pattern（名稱）來殺掉並重啟對應的遠端插件進程
-- ====================================================================
local function reload_remote_plugin_by_pattern(pattern)
    -- 確保有輸入 pattern，若無則預設為 "python3"
    pattern = (pattern and pattern ~= "") and pattern or "python3"
    
    -- 1. 更新遠端插件資訊清單
    vim.cmd('UpdateRemotePlugins')

    -- 2. 尋找符合 pattern 名稱的 RPC 頻道進程並將其終止
    local killed_count = 0
    for _, chan in ipairs(vim.api.nvim_list_chans()) do
        if chan.stream == "job" and chan.client and chan.client.name then
            -- 使用 string.find 進行模糊比對（忽略大小寫）
            if string.find(chan.client.name:lower(), pattern:lower(), 1, true) then
                vim.fn.jobstop(chan.id)
                killed_count = killed_count + 1
            end
        end
    end

    -- 3. 提示使用者結果
    if killed_count > 0 then
        vim.notify(string.format("已成功重置 %d 個符合 '%s' 的插件進程！", killed_count, pattern), vim.log.levels.INFO)
    else
        vim.notify(string.format("未找到名稱符合 '%s' 的執行中插件，已完成清單更新。", pattern), vim.log.levels.WARN)
    end
end

-- ====================================================================
-- 建立自訂指令：:ReloadPlugin [pattern]
-- ====================================================================
vim.api.nvim_create_user_command('ReloadPlugin', function(opts)
    reload_remote_plugin_by_pattern(opts.args)
end, {
    nargs = '?', -- 代表參數是可選的（0 或 1 個參數）
    desc = "輸入 Pattern 重啟指定的遠端插件（例如 :ReloadPlugin python3）",
    -- 提供自動補全，列出當前所有可用的客戶端名稱
    complete = function()
        local names = {}
        for _, chan in ipairs(vim.api.nvim_list_chans()) do
            if chan.client and chan.client.name then
                table.insert(names, chan.client.name)
            end
        end
        return names
    end
})
