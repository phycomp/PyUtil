require("treesitter").setup({
  -- 可選：自訂配置
  confirm_install = true,  -- 安裝前確認
  confirm_remove  = true,  -- 移除前確認
})

