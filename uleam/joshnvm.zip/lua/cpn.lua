-- 載入 copen 插件
-- require('plugins.copen')

-- 設定快捷鍵
vim.keymap.set('n', '<leader>cpn', ':CopenFloat<CR>', { desc = 'Open quickfix in float window' })
vim.keymap.set('n', '<leader>cpn', ':CopenFloat<CR>', { desc = 'Open quickfix in float window' })

-- 可選：自動在 quickfix 更新後開啟
vim.api.nvim_create_augroup('CopenFloatAuto', { clear = true })
vim.api.nvim_create_autocmd('QuickFixCmdPost', {
    group = 'CopenFloatAuto',
    callback = function()
        require('copen').open_copen_float()
    end
})
