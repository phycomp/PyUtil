-- ============================================================================
-- MultiSearch - Neovim 跨 Buffer 多 Pattern 搜索插件
-- ============================================================================
-- 功能：
--   1. 跨所有已加載的 buffer 搜索
--   2. 支持輸入多個 pattern（空格分隔，支援引號包覆含空格的 pattern）
--   3. 結果顯示在 Float Window 中
--   4. 按 Enter 跳轉到對應文件與匹配位置
--
-- 安裝方式：
--   mkdir -p ~/.config/nvim/lua/multisearch
--   將本文件存為 ~/.config/nvim/lua/multisearch/init.lua
--   在 init.lua 中加入：require("multisearch").setup()
--
-- 使用方法：
--   :MultiSearch              -- 彈出輸入框輸入 patterns
--   :MultiSearch foo bar      -- 直接帶參數搜索
--   :MultiSearch "hello world" foo   -- 含空格的 pattern 用引號包覆
-- ============================================================================

local M = {}

-- ---------------------------------------------------------------------------
-- 預設配置
-- ---------------------------------------------------------------------------
M.config = {
  -- Float window 尺寸（相對於 editor 的比例）
  width_ratio  = 0.85,
  height_ratio = 0.75,

  -- 邊框樣式: "none", "single", "double", "rounded", "solid", "shadow"
  border = "rounded",

  -- 輸入提示文字
  prompt = "Patterns (space-separated): ",

  -- 搜索模式: "and" = 所有 pattern 都要匹配, "or" = 任一 pattern 匹配
  match_mode = "and",

  -- 是否使用正則表達式（false = literal match）
  use_regex = false,

  -- 最大結果數量（避免過多結果導致卡頓）
  max_results = 500,

  -- 是否包含無名 buffer（未存檔的新文件）
  include_unnamed = true,
}

-- ---------------------------------------------------------------------------
-- 內部狀態
-- ---------------------------------------------------------------------------
local state = {
  results      = {},   -- 搜索結果列表
  float_buf    = nil,  -- Float window 的 buffer id
  float_win    = nil,  -- Float window 的 window id
  original_win = nil,  -- 呼叫插件前的當前窗口
  ns_id        = nil,  -- namespace id for extmarks
}

-- ---------------------------------------------------------------------------
-- 工具函數
-- ---------------------------------------------------------------------------

--- 解析使用者輸入的多個 pattern
-- 支援用引號包起來的含空格 pattern，例如: "hello world" foo
local function parse_patterns(input)
  local patterns = {}
  local idx = 1
  while idx <= #input do
    local ch = input:sub(idx, idx)
    if ch == '"' or ch == "'" then
      local quote = ch
      local start_idx = idx + 1
      local end_idx = input:find(quote, start_idx, true)
      if end_idx then
        local pat = input:sub(start_idx, end_idx - 1)
        if pat ~= "" then table.insert(patterns, pat) end
        idx = end_idx + 1
      else
        -- 沒有閉合引號，視為一般文字
        local s, e = input:find("%S+", idx)
        if s then
          table.insert(patterns, input:sub(s, e))
          idx = e + 1
        else
          break
        end
      end
    elseif ch:match("%s") then
      idx = idx + 1
    else
      local s, e = input:find("%S+", idx)
      if s then
        table.insert(patterns, input:sub(s, e))
        idx = e + 1
      else
        break
      end
    end
  end
  return patterns
end

--- 檢查一行文字是否匹配所有 pattern
local function line_matches(line, patterns, use_regex, mode)
  if mode == "and" then
    for _, pat in ipairs(patterns) do
      local found
      if use_regex then
        found = line:find(pat)
      else
        found = line:find(vim.pesc(pat), 1, true)
      end
      if not found then return false, nil end
    end
    -- 回傳第一個 pattern 的匹配位置
    local first_pat = patterns[1]
    local pos
    if use_regex then
      pos = line:find(first_pat)
    else
      pos = line:find(vim.pesc(first_pat), 1, true)
    end
    return true, pos or 1
  else -- "or" 模式
    for _, pat in ipairs(patterns) do
      local pos
      if use_regex then
        pos = line:find(pat)
      else
        pos = line:find(vim.pesc(pat), 1, true)
      end
      if pos then return true, pos end
    end
    return false, nil
  end
end

--- 在所有 loaded buffer 中搜索
local function search_all_buffers(patterns, config)
  local results = {}
  local count = 0
  local bufs = vim.api.nvim_list_bufs()

  for _, bufnr in ipairs(bufs) do
    -- 跳過未加載或不可列出的 buffer
    if not vim.api.nvim_buf_is_loaded(bufnr) then goto continue end
    if not vim.bo[bufnr].buflisted then goto continue end

    local bufname = vim.api.nvim_buf_get_name(bufnr)
    if bufname == "" then
      if not config.include_unnamed then goto continue end
      bufname = "[Buffer " .. bufnr .. "]"
    else
      -- 縮短路徑顯示
      bufname = vim.fn.fnamemodify(bufname, ":~:.")
    end

    local lines = vim.api.nvim_buf_get_lines(bufnr, 0, -1, false)

    for lnum, line in ipairs(lines) do
      local matched, col = line_matches(line, patterns, config.use_regex, config.match_mode)
      if matched then
        count = count + 1
        if count > config.max_results then
          vim.notify("Reached max results limit (" .. config.max_results .. ")", vim.log.levels.WARN)
          return results
        end

        table.insert(results, {
          bufnr     = bufnr,
          bufname   = bufname,
          lnum      = lnum,
          col       = col or 1,
          line_text = line,
          patterns  = vim.deepcopy(patterns),
        })
      end
    end

    ::continue::
  end

  return results
end

-- ---------------------------------------------------------------------------
-- Float Window 相關
-- ---------------------------------------------------------------------------

--- 計算並創建 Float Window
local function open_float_window(config)
  local editor_width  = vim.o.columns
  local editor_height = vim.o.lines

  local win_width  = math.floor(editor_width * config.width_ratio)
  local win_height = math.floor(editor_height * config.height_ratio)
  local row = math.floor((editor_height - win_height) / 2)
  local col = math.floor((editor_width - win_width) / 2)

  -- 創建 scratch buffer
  local buf = vim.api.nvim_create_buf(false, true)
  vim.bo[buf].buftype = "nofile"
  vim.bo[buf].bufhidden = "wipe"
  vim.bo[buf].swapfile = false
  vim.bo[buf].modifiable = true

  local title = " 🔍 MultiSearch Results "
  local footer = " <Enter> open │ <ESC>/q close │ j/k navigate "

  local opts = {
    relative   = "editor",
    width      = win_width,
    height     = win_height,
    row        = row,
    col        = col,
    anchor     = "NW",
    style      = "minimal",
    border     = config.border,
    title      = title,
    title_pos  = "center",
    footer     = footer,
    footer_pos = "center",
    zindex     = 50,
  }

  local win = vim.api.nvim_open_win(buf, true, opts)

  -- 窗口選項
  vim.wo[win].cursorline = true
  vim.wo[win].number = false
  vim.wo[win].relativenumber = false
  vim.wo[win].wrap = false
  vim.wo[win].signcolumn = "no"
  vim.wo[win].foldcolumn = "0"

  return buf, win
end

--- 格式化單行結果
local function format_result(result, win_width)
  local text_width = math.max(10, win_width - 42)
  local text = result.line_text
  if #text > text_width then
    text = text:sub(1, text_width - 3) .. "..."
  end
  -- 去掉開頭空白
  text = text:gsub("^%s+", "")

  local bufname = result.bufname
  if #bufname > 30 then
    bufname = "..." .. bufname:sub(-27)
  end

  return string.format(" %-30s │ %4d │ %s", bufname, result.lnum, text)
end

--- 渲染結果到 Float Window buffer
local function render_results(buf, win, results, patterns)
  local lines = {}
  local win_width = vim.api.nvim_win_get_width(win)

  -- 清空
  vim.api.nvim_buf_set_lines(buf, 0, -1, false, {})

  if #results == 0 then
    table.insert(lines, "")
    table.insert(lines, "  ⚠  No matches found for patterns: " .. table.concat(patterns, ", "))
    table.insert(lines, "")
    table.insert(lines, "  Press <ESC> or q to close")
    vim.api.nvim_buf_set_lines(buf, 0, -1, false, lines)
    return
  end

  -- 標題行
  table.insert(lines, string.format("  Found %d result(s) │ Mode: %s │ Patterns: %s",
    #results, M.config.match_mode:upper(), table.concat(patterns, ", ")))
  table.insert(lines, string.rep("─", win_width))

  -- 結果行
  for _, result in ipairs(results) do
    table.insert(lines, format_result(result, win_width))
  end

  -- 底部提示
  table.insert(lines, string.rep("─", win_width))
  table.insert(lines, "  <Enter> Open │ <ESC>/q Close │ j/k Navigate")

  vim.api.nvim_buf_set_lines(buf, 0, -1, false, lines)

  -- 高亮匹配的 pattern
  if not state.ns_id then
    state.ns_id = vim.api.nvim_create_namespace("multisearch")
  end
  vim.api.nvim_buf_clear_namespace(buf, state.ns_id, 0, -1)

  for i, line in ipairs(lines) do
    -- 跳過標題行和分隔線
    if i > 2 and i <= #lines - 2 then
      for _, pat in ipairs(patterns) do
        local search_pat = M.config.use_regex and pat or vim.pesc(pat)
        local start_idx = 1
        while true do
          local s, e = line:find(search_pat, start_idx, not M.config.use_regex)
          if not s then break end
          vim.api.nvim_buf_add_highlight(buf, state.ns_id, "Search", i - 1, s - 1, e)
          start_idx = e + 1
        end
      end
    end
  end

  -- 標題高亮
  vim.api.nvim_buf_add_highlight(buf, state.ns_id, "Title", 0, 0, -1)
end

-- ---------------------------------------------------------------------------
-- 交互與跳轉
-- ---------------------------------------------------------------------------

--- 獲取當前游標對應的結果索引
local function get_result_index()
  local cursor = vim.api.nvim_win_get_cursor(state.float_win)
  local line_idx = cursor[1]
  -- 第1行標題、第2行分隔線，結果從第3行開始
  local result_idx = line_idx - 2
  if result_idx < 1 or result_idx > #state.results then
    return nil
  end
  return result_idx
end

--- 跳轉到選中的結果
local function jump_to_result()
  local idx = get_result_index()
  if not idx then return end

  local result = state.results[idx]

  -- 關閉 float window
  if state.float_win and vim.api.nvim_win_is_valid(state.float_win) then
    vim.api.nvim_win_close(state.float_win, true)
  end
  state.float_win = nil
  state.float_buf = nil

  -- 切換到原始窗口（或當前窗口）
  local target_win = state.original_win
  if not target_win or not vim.api.nvim_win_is_valid(target_win) then
    target_win = vim.api.nvim_get_current_win()
  end
  vim.api.nvim_set_current_win(target_win)

  -- 在新 buffer 中打開並跳轉
  if vim.api.nvim_buf_is_valid(result.bufnr) then
    vim.api.nvim_win_set_buf(target_win, result.bufnr)
  else
    -- buffer 已被刪除，嘗試重新打開文件
    vim.cmd("edit " .. vim.fn.fnameescape(result.bufname))
  end

  -- 移動游標到匹配位置
  local col = math.max(0, result.col - 1)
  vim.api.nvim_win_set_cursor(target_win, { result.lnum, col })

  -- 置中並短暫高亮該行
  vim.cmd("normal! zz")
  local flash_ns = vim.api.nvim_create_namespace("multisearch_flash")
  vim.api.nvim_buf_add_highlight(vim.api.nvim_win_get_buf(target_win), flash_ns, "IncSearch", result.lnum - 1, 0, -1)
  vim.defer_fn(function()
    local b = vim.api.nvim_win_get_buf(target_win)
    if vim.api.nvim_buf_is_valid(b) then
      vim.api.nvim_buf_clear_namespace(b, flash_ns, 0, -1)
    end
  end, 400)
end

--- 關閉 Float Window
local function close_float()
  if state.float_win and vim.api.nvim_win_is_valid(state.float_win) then
    vim.api.nvim_win_close(state.float_win, true)
  end
  state.float_win = nil
  state.float_buf = nil
end

--- 設置 Float Window 按鍵映射
local function setup_float_keymaps(buf)
  local opts = { buffer = buf, silent = true, nowait = true }

  -- Enter: 跳轉
  vim.keymap.set("n", "<CR>", jump_to_result, vim.tbl_extend("force", opts, { desc = "Open result" }))

  -- 關閉
  vim.keymap.set("n", "q", close_float, vim.tbl_extend("force", opts, { desc = "Close" }))
  vim.keymap.set("n", "<ESC>", close_float, vim.tbl_extend("force", opts, { desc = "Close" }))
  vim.keymap.set("n", "<C-c>", close_float, vim.tbl_extend("force", opts, { desc = "Close" }))

  -- 雙擊也跳轉（如果終端支援 mouse）
  vim.keymap.set("n", "<2-LeftMouse>", jump_to_result, vim.tbl_extend("force", opts, { desc = "Open result" }))

  -- 防止在 float window 中意外編輯
  vim.keymap.set("n", "i", "<Nop>", opts)
  vim.keymap.set("n", "a", "<Nop>", opts)
  vim.keymap.set("n", "o", "<Nop>", opts)
  vim.keymap.set("n", "p", "<Nop>", opts)
end

-- ---------------------------------------------------------------------------
-- 主入口
-- ---------------------------------------------------------------------------

--- 啟動搜索（無參數時彈出輸入框）
function M.search(input_patterns)
  local patterns

  if input_patterns and input_patterns ~= "" then
    patterns = parse_patterns(input_patterns)
  else
    local user_input = vim.fn.input(M.config.prompt)
    if user_input == "" then return end
    patterns = parse_patterns(user_input)
  end

  if #patterns == 0 then
    vim.notify("No valid patterns provided", vim.log.levels.WARN)
    return
  end

  -- 保存原始窗口
  state.original_win = vim.api.nvim_get_current_win()

  -- 顯示正在搜索的提示
  vim.notify("Searching for: " .. table.concat(patterns, ", "), vim.log.levels.INFO)

  -- 執行搜索
  state.results = search_all_buffers(patterns, M.config)

  -- 創建 Float Window
  state.float_buf, state.float_win = open_float_window(M.config)

  -- 渲染結果
  render_results(state.float_buf, state.float_win, state.results, patterns)

  -- 設置按鍵映射
  setup_float_keymaps(state.float_buf)

  -- 移動游標到第一個結果（第3行）
  if #state.results > 0 then
    vim.api.nvim_win_set_cursor(state.float_win, { 3, 0 })
  end
end

--- 插件設定
function M.setup(user_config)
  M.config = vim.tbl_deep_extend("force", M.config, user_config or {})

  -- 註冊命令
  vim.api.nvim_create_user_command("MultiSearch", function(opts)
    M.search(opts.args)
  end, {
    nargs = "*",
    desc = "Search across all buffers with multiple patterns",
  })

  -- 可選：設置快捷鍵（使用者可自行覆蓋）
  vim.keymap.set("n", "<leader>ms", ":MultiSearch ", { desc = "MultiSearch" })
end

return M
