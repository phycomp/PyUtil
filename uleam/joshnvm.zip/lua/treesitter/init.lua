-- ============================================================================
-- treesitter-float.nvim
-- Neovim 內建 Tree-sitter 浮動視窗管理插件
-- ============================================================================
-- 功能：
--   1. 浮動視窗列出所有支援的語言/已安裝的 parser
--   2. 瀏覽語言列表（j/k 上下移動）
--   3. 安裝/移除 parser（i/x 鍵）
--   4. 啟用語言高亮（Enter 鍵，反白當前 buffer）
--   5. 按 ESC/q 關閉浮動視窗
--
-- 安裝方式：
--   mkdir -p ~/.config/nvim/lua/treesitter-float
--   將本文件存為 ~/.config/nvim/lua/treesitter-float/init.lua
--   在 init.lua 中加入：require("treesitter-float").setup()
--
-- 使用方法：
--   :TSFloat              -- 開啟浮動視窗
--   :TSFloatInstall lua   -- 直接安裝指定語言的 parser
--   :TSFloatRemove  lua   -- 直接移除指定語言的 parser
--
-- 需求：
--   - Neovim 0.12+
--   - tree-sitter CLI（安裝 parser 時需要）
--   - git（安裝 parser 時需要）
--   - C compiler（編譯 parser 時需要）
-- ============================================================================

local M = {}

-- ---------------------------------------------------------------------------
-- 預設配置
-- ---------------------------------------------------------------------------
M.config = {
  -- 浮動視窗尺寸
  width_ratio  = 0.70,
  height_ratio = 0.75,
  border       = "rounded",

  -- Parser 安裝目錄（預設放在 stdpath("data")/site/parser/）
  parser_install_dir = vim.fn.stdpath("data") .. "/site/parser",

  -- Query 檔案安裝目錄
  query_install_dir = vim.fn.stdpath("config") .. "/queries",

  -- 是否顯示內建 parser（c, lua, markdown, vim...）
  show_builtin = true,

  -- 安裝前是否確認
  confirm_install = true,
  confirm_remove  = true,

  -- 內建語言倉庫映射（語言 → git 倉庫 URL）
  -- 使用者可在 setup() 中覆蓋或擴充
  repos = {
    ["python"]       = "https://github.com/tree-sitter/tree-sitter-python",
    ["javascript"]   = "https://github.com/tree-sitter/tree-sitter-javascript",
    ["typescript"]   = "https://github.com/tree-sitter/tree-sitter-typescript",
    ["tsx"]          = "https://github.com/tree-sitter/tree-sitter-typescript",
    ["rust"]         = "https://github.com/tree-sitter/tree-sitter-rust",
    ["go"]           = "https://github.com/tree-sitter/tree-sitter-go",
    ["bash"]         = "https://github.com/tree-sitter/tree-sitter-bash",
    ["html"]         = "https://github.com/tree-sitter/tree-sitter-html",
    ["css"]          = "https://github.com/tree-sitter/tree-sitter-css",
    ["json"]         = "https://github.com/tree-sitter/tree-sitter-json",
    ["yaml"]         = "https://github.com/tree-sitter/tree-sitter-yaml",
    ["toml"]         = "https://github.com/tree-sitter/tree-sitter-toml",
    ["cpp"]          = "https://github.com/tree-sitter/tree-sitter-cpp",
    ["java"]         = "https://github.com/tree-sitter/tree-sitter-java",
    ["ruby"]         = "https://github.com/tree-sitter/tree-sitter-ruby",
    ["php"]          = "https://github.com/tree-sitter/tree-sitter-php",
    ["sql"]          = "https://github.com/tree-sitter/tree-sitter-sql",
    ["regex"]        = "https://github.com/tree-sitter/tree-sitter-regex",
    ["dockerfile"]   = "https://github.com/camdencheek/tree-sitter-dockerfile",
    ["graphql"]      = "https://github.com/tree-sitter/tree-sitter-graphql",
    ["scala"]        = "https://github.com/tree-sitter/tree-sitter-scala",
    ["kotlin"]       = "https://github.com/tree-sitter/tree-sitter-kotlin",
    ["swift"]        = "https://github.com/tree-sitter/tree-sitter-swift",
    ["dart"]         = "https://github.com/tree-sitter/tree-sitter-dart",
    ["elixir"]       = "https://github.com/tree-sitter/tree-sitter-elixir",
    ["haskell"]      = "https://github.com/tree-sitter/tree-sitter-haskell",
    ["ocaml"]        = "https://github.com/tree-sitter/tree-sitter-ocaml",
    ["zig"]          = "https://github.com/tree-sitter/tree-sitter-zig",
    ["nim"]          = "https://github.com/tree-sitter/tree-sitter-nim",
    ["julia"]        = "https://github.com/tree-sitter/tree-sitter-julia",
    ["r"]            = "https://github.com/tree-sitter/tree-sitter-r",
    ["perl"]         = "https://github.com/tree-sitter/tree-sitter-perl",
    ["latex"]        = "https://github.com/tree-sitter/tree-sitter-latex",
    ["vue"]          = "https://github.com/tree-sitter/tree-sitter-vue",
    ["svelte"]       = "https://github.com/tree-sitter/tree-sitter-svelte",
    ["astro"]        = "https://github.com/virchau13/tree-sitter-astro",
    ["prisma"]       = "https://github.com/victorhqc/tree-sitter-prisma",
    ["cmake"]        = "https://github.com/tree-sitter/tree-sitter-cmake",
    ["make"]         = "https://github.com/tree-sitter/tree-sitter-make",
  },
}

-- ---------------------------------------------------------------------------
-- 內部狀態
-- ---------------------------------------------------------------------------
local state = {
  float_buf    = nil,
  float_win    = nil,
  ns_id        = nil,
  languages    = {},   -- {lang, installed, builtin, repo}
  cursor_line  = 1,    -- 1-based，指向 languages 陣列的索引
}

-- Neovim 0.12+ 內建的 parser 列表
local BUILTIN_PARSERS = {
  ["c"] = true,
  ["lua"] = true,
  ["markdown"] = true,
  ["markdown_inline"] = true,
  ["query"] = true,
  ["vim"] = true,
  ["vimdoc"] = true,
  ["diff"] = true,
}

-- ---------------------------------------------------------------------------
-- 工具函數
-- ---------------------------------------------------------------------------

--- 檢查 tree-sitter CLI 是否可用
local function has_treesitter_cli()
  return vim.fn.executable("tree-sitter") == 1
end

--- 檢查 git 是否可用
local function has_git()
  return vim.fn.executable("git") == 1
end

--- 檢查某語言的 parser 是否已安裝
local function is_parser_installed(lang)
  local parser_path = M.config.parser_install_dir .. "/" .. lang .. ".so"
  return vim.fn.filereadable(parser_path) == 1
end

--- 掃描已安裝的所有 parser
local function get_installed_parsers()
  local installed = {}
  local pattern = M.config.parser_install_dir .. "/*.so"
  local files = vim.fn.glob(pattern, false, true)
  for _, f in ipairs(files) do
    local name = vim.fn.fnamemodify(f, ":t:r")  -- 去掉路徑和 .so
    installed[name] = true
  end
  return installed
end

--- 收集所有語言列表（內建 + 配置倉庫 + 已安裝）
local function collect_languages()
  local langs = {}
  local seen = {}
  local installed = get_installed_parsers()

  -- 1. 內建 parser
  if M.config.show_builtin then
    for lang, _ in pairs(BUILTIN_PARSERS) do
      seen[lang] = true
      table.insert(langs, {
        lang      = lang,
        installed = true,
        builtin   = true,
        repo      = nil,
      })
    end
  end

  -- 2. 配置中的倉庫語言
  for lang, repo in pairs(M.config.repos) do
    if not seen[lang] then
      seen[lang] = true
      table.insert(langs, {
        lang      = lang,
        installed = installed[lang] or false,
        builtin   = BUILTIN_PARSERS[lang] or false,
        repo      = repo,
      })
    end
  end

  -- 3. 已安裝但不在上述列表中的（使用者手動安裝的）
  for lang, _ in pairs(installed) do
    if not seen[lang] then
      seen[lang] = true
      table.insert(langs, {
        lang      = lang,
        installed = true,
        builtin   = false,
        repo      = nil,
      })
    end
  end

  -- 排序：已安裝在前，然後按字母排序
  table.sort(langs, function(a, b)
    if a.installed ~= b.installed then
      return a.installed  -- true 在前
    end
    return a.lang < b.lang
  end)

  return langs
end

-- ---------------------------------------------------------------------------
-- Float Window
-- ---------------------------------------------------------------------------

local function open_float_window()
  local editor_width  = vim.o.columns
  local editor_height = vim.o.lines

  local win_width  = math.floor(editor_width * M.config.width_ratio)
  local win_height = math.floor(editor_height * M.config.height_ratio)
  local row = math.floor((editor_height - win_height) / 2)
  local col = math.floor((editor_width - win_width) / 2)

  local buf = vim.api.nvim_create_buf(false, true)
  vim.bo[buf].buftype = "nofile"
  vim.bo[buf].bufhidden = "wipe"
  vim.bo[buf].swapfile = false
  vim.bo[buf].modifiable = true

  local title = " 🌳 Tree-sitter Parser Manager "
  local footer = " i=install x=remove h=highlight r=refresh q/ESC=close "

  local opts = {
    relative   = "editor",
    width      = win_width,
    height     = win_height,
    row        = row,
    col        = col,
    anchor     = "NW",
    style      = "minimal",
    border     = M.config.border,
    title      = title,
    title_pos  = "center",
    footer     = footer,
    footer_pos = "center",
    zindex     = 50,
  }

  local win = vim.api.nvim_open_win(buf, true, opts)

  vim.wo[win].cursorline = true
  vim.wo[win].number = false
  vim.wo[win].relativenumber = false
  vim.wo[win].wrap = false
  vim.wo[win].signcolumn = "no"
  vim.wo[win].foldcolumn = "0"

  return buf, win
end

-- ---------------------------------------------------------------------------
-- 渲染
-- ---------------------------------------------------------------------------

local function render(buf, win)
  local lines = {}
  local win_width = vim.api.nvim_win_get_width(win)
  state.languages = collect_languages()

  -- 標題
  local total = #state.languages
  local installed_count = 0
  for _, l in ipairs(state.languages) do
    if l.installed then installed_count = installed_count + 1 end
  end

  table.insert(lines, string.format(
    "  Languages: %d total │ %d installed │ %d available",
    total, installed_count, total - installed_count
  ))
  table.insert(lines, string.rep("─", win_width))

  -- 列表
  for _, item in ipairs(state.languages) do
    local icon = item.installed and "✓" or "✗"
    local tag = item.builtin and "[builtin]" or ""
    if item.repo and not item.builtin then
      tag = "[external]"
    end
    local line = string.format(" %s %-20s %-12s %s",
      icon, item.lang, tag, item.repo or ""
    )
    -- 截斷以適應視窗寬度
    if #line > win_width then
      line = line:sub(1, win_width - 3) .. "..."
    end
    table.insert(lines, line)
  end

  -- 底部提示
  table.insert(lines, string.rep("─", win_width))
  table.insert(lines, "  j/k=move i=install x=remove h=highlight r=refresh <Enter>=highlight q=close")

  vim.api.nvim_buf_set_lines(buf, 0, -1, false, lines)

  -- 高亮
  if not state.ns_id then
    state.ns_id = vim.api.nvim_create_namespace("treesitter-float")
  end
  vim.api.nvim_buf_clear_namespace(buf, state.ns_id, 0, -1)

  -- 標題高亮
  vim.api.nvim_buf_add_highlight(buf, state.ns_id, "Title", 0, 0, -1)

  -- 各行狀態高亮
  for i, item in ipairs(state.languages) do
    local row = i + 1  -- 跳過標題行（第0行）和分隔線（第1行）
    if item.installed then
      vim.api.nvim_buf_add_highlight(buf, state.ns_id, "DiffAdd", row, 0, -1)
    else
      vim.api.nvim_buf_add_highlight(buf, state.ns_id, "Comment", row, 0, -1)
    end
  end

  -- 移動游標到第一個語言（第3行，0-indexed 為 2）
  if #state.languages > 0 then
    vim.api.nvim_win_set_cursor(win, { 3, 0 })
    state.cursor_line = 1
  end
end

-- ---------------------------------------------------------------------------
-- 核心操作
-- ---------------------------------------------------------------------------

--- 取得當前游標對應的語言
local function get_current_lang()
  local cursor = vim.api.nvim_win_get_cursor(state.float_win)
  local line_idx = cursor[1]
  -- 第1行(0)=標題, 第2行(1)=分隔線, 語言從第3行(2)開始
  local lang_idx = line_idx - 2
  if lang_idx < 1 or lang_idx > #state.languages then
    return nil
  end
  return state.languages[lang_idx]
end

--- 安裝 parser
function M.install_parser(lang)
  if BUILTIN_PARSERS[lang] then
    vim.notify("「" .. lang .. "」是內建 parser，無需安裝", vim.log.levels.INFO)
    return
  end

  if is_parser_installed(lang) then
    vim.notify("Parser for '" .. lang .. "' 已安裝", vim.log.levels.INFO)
    return
  end

  local repo = M.config.repos[lang]
  if not repo then
    vim.notify("未知的語言 '" .. lang .. "'，請在配置中指定 repo", vim.log.levels.ERROR)
    return
  end

  if not has_git() then
    vim.notify("需要 git 才能安裝 parser", vim.log.levels.ERROR)
    return
  end

  if not has_treesitter_cli() then
    vim.notify("需要 tree-sitter CLI 才能編譯 parser 請先安裝: https://tree-sitter.github.io/tree-sitter/, vim.log.levels.ERROR")
    return
  end

  if M.config.confirm_install then
    local choice = vim.fn.confirm("安裝 parser '" .. lang .. "' ?", "&Yes\n&No", 2)
    if choice ~= 1 then return end
  end

  vim.notify("正在安裝 '" .. lang .. "' parser...", vim.log.levels.INFO)

  -- 使用 vim.fn.system 在背景執行
  vim.schedule(function()
    local tmpdir = vim.fn.tempname()
    vim.fn.mkdir(tmpdir, "p")

    -- 1. git clone
    local clone_cmd = string.format("git clone --depth 1 %s %s 2>&1", repo, tmpdir)
    local clone_out = vim.fn.system(clone_cmd)
    if vim.v.shell_error ~= 0 then
      vim.notify("git clone 失敗: " .. clone_out, vim.log.levels.ERROR)
      vim.fn.system("rm -rf " .. vim.fn.shellescape(tmpdir))
      return
    end

    -- 2. tree-sitter build
    local build_cmd = string.format("cd %s && tree-sitter build -o parser.so 2>&1", vim.fn.shellescape(tmpdir))
    local build_out = vim.fn.system(build_cmd)
    if vim.v.shell_error ~= 0 then
      vim.notify("編譯失敗: " .. build_out, vim.log.levels.ERROR)
      vim.fn.system("rm -rf " .. vim.fn.shellescape(tmpdir))
      return
    end

    -- 3. 複製 parser.so
    vim.fn.mkdir(M.config.parser_install_dir, "p")
    local parser_src = tmpdir .. "/parser.so"
    local parser_dst = M.config.parser_install_dir .. "/" .. lang .. ".so"
    local cp_cmd = string.format("cp %s %s 2>&1",
      vim.fn.shellescape(parser_src), vim.fn.shellescape(parser_dst))
    vim.fn.system(cp_cmd)

    -- 4. 複製 query 檔案（如果倉庫有提供）
    local query_src = tmpdir .. "/queries"
    if vim.fn.isdirectory(query_src) == 1 then
      local query_dst = M.config.query_install_dir .. "/" .. lang
      vim.fn.mkdir(query_dst, "p")
      vim.fn.system(string.format("cp -r %s/* %s/ 2>&1",
        vim.fn.shellescape(query_src), vim.fn.shellescape(query_dst)))
    end

    -- 5. 清理
    vim.fn.system("rm -rf " .. vim.fn.shellescape(tmpdir))

    vim.notify("Parser '" .. lang .. "' 安裝完成！", vim.log.levels.INFO)

    -- 刷新浮動視窗
    if state.float_win and vim.api.nvim_win_is_valid(state.float_win) then
      render(state.float_buf, state.float_win)
    end
  end)
end

--- 移除 parser
function M.remove_parser(lang)
  if BUILTIN_PARSERS[lang] then
    vim.notify("無法移除內建 parser '" .. lang .. "'", vim.log.levels.WARN)
    return
  end

  if not is_parser_installed(lang) then
    vim.notify("Parser '" .. lang .. "' 尚未安裝", vim.log.levels.WARN)
    return
  end

  if M.config.confirm_remove then
    local choice = vim.fn.confirm("移除 parser '" .. lang .. "' ?", "&Yes\n&No", 2)
    if choice ~= 1 then return end
  end

  -- 刪除 .so
  local parser_path = M.config.parser_install_dir .. "/" .. lang .. ".so"
  vim.fn.system("rm -f " .. vim.fn.shellescape(parser_path))

  -- 刪除 query 目錄
  local query_path = M.config.query_install_dir .. "/" .. lang
  if vim.fn.isdirectory(query_path) == 1 then
    vim.fn.system("rm -rf " .. vim.fn.shellescape(query_path))
  end

  vim.notify("Parser '" .. lang .. "' 已移除", vim.log.levels.INFO)

  -- 刷新
  if state.float_win and vim.api.nvim_win_is_valid(state.float_win) then
    render(state.float_buf, state.float_win)
  end
end

--- 啟用語言高亮（反白）
function M.highlight_lang(lang)
  local ok, err = pcall(function()
    -- 嘗試載入 parser
    vim.treesitter.language.add(lang)
    -- 在當前 buffer 啟用高亮
    vim.treesitter.start(0, lang)
  end)
  if ok then
    vim.notify("已啟用 '" .. lang .. "' 的 Tree-sitter 高亮", vim.log.levels.INFO)
  else
    vim.notify("無法啟用高亮: " .. tostring(err), vim.log.levels.ERROR)
  end
end

-- ---------------------------------------------------------------------------
-- 按鍵映射（在浮動視窗內）
-- ---------------------------------------------------------------------------

local function setup_keymaps(buf)
  local opts = { buffer = buf, silent = true, nowait = true }

  -- 安裝
  vim.keymap.set("n", "i", function()
    local item = get_current_lang()
    if item then
      M.install_parser(item.lang)
    end
  end, vim.tbl_extend("force", opts, { desc = "Install parser" }))

  -- 移除
  vim.keymap.set("n", "x", function()
    local item = get_current_lang()
    if item then
      M.remove_parser(item.lang)
    end
  end, vim.tbl_extend("force", opts, { desc = "Remove parser" }))

  -- 高亮（Enter）
  vim.keymap.set("n", "<CR>", function()
    local item = get_current_lang()
    if item then
      M.highlight_lang(item.lang)
    end
  end, vim.tbl_extend("force", opts, { desc = "Highlight language" }))

  -- 同樣用 h 鍵高亮
  vim.keymap.set("n", "h", function()
    local item = get_current_lang()
    if item then
      M.highlight_lang(item.lang)
    end
  end, vim.tbl_extend("force", opts, { desc = "Highlight language" }))

  -- 刷新
  vim.keymap.set("n", "r", function()
    render(state.float_buf, state.float_win)
  end, vim.tbl_extend("force", opts, { desc = "Refresh list" }))

  -- 關閉
  vim.keymap.set("n", "q", function()
    if state.float_win and vim.api.nvim_win_is_valid(state.float_win) then
      vim.api.nvim_win_close(state.float_win, true)
    end
    state.float_win = nil
    state.float_buf = nil
  end, vim.tbl_extend("force", opts, { desc = "Close window" }))

  vim.keymap.set("n", "<ESC>", function()
    if state.float_win and vim.api.nvim_win_is_valid(state.float_win) then
      vim.api.nvim_win_close(state.float_win, true)
    end
    state.float_win = nil
    state.float_buf = nil
  end, vim.tbl_extend("force", opts, { desc = "Close window" }))

  -- 防止編輯
  vim.keymap.set("n", "a", "<Nop>", opts)
  vim.keymap.set("n", "o", "<Nop>", opts)
end

-- ---------------------------------------------------------------------------
-- 公開 API
-- ---------------------------------------------------------------------------

--- 開啟浮動視窗
function M.open()
  state.float_buf, state.float_win = open_float_window()
  render(state.float_buf, state.float_win)
  setup_keymaps(state.float_buf)
end

--- 設定
function M.setup(user_config)
  M.config = vim.tbl_deep_extend("force", M.config, user_config or {})

  -- 註冊命令
  vim.api.nvim_create_user_command("TSFloat", function()
    M.open()
  end, { desc = "Open Tree-sitter float manager" })

  vim.api.nvim_create_user_command("TSFloatInstall", function(opts)
    M.install_parser(opts.args)
  end, { nargs = 1, desc = "Install a tree-sitter parser" })

  vim.api.nvim_create_user_command("TSFloatRemove", function(opts)
    M.remove_parser(opts.args)
  end, { nargs = 1, desc = "Remove a tree-sitter parser" })

  -- 可選快捷鍵
  -- vim.keymap.set("n", "<leader>ts", ":TSFloat<CR>", { desc = "Tree-sitter Float" })
end

return M
