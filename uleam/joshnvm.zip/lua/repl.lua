-- PyREPL 快捷鍵
vim.keymap.set('n', '<Leader>pr', ':PyREPLRunFile<CR>', { silent = true })
vim.keymap.set('n', '<Leader>pR', ':PyREPLRunFileReset<CR>', { silent = true })
vim.keymap.set('v', '<Leader>ps', ':PyREPLRunSelection<CR>', { silent = true })
vim.keymap.set('n', '<Leader>pl', ':PyREPLRunLine<CR>', { silent = true })
vim.keymap.set('n', '<Leader>pt', ':PyREPLToggle<CR>', { silent = true })
vim.keymap.set('n', '<Leader>px', ':PyREPLReset<CR>', { silent = true })
vim.keymap.set('n', '<Leader>pv', ':PyREPLVars<CR>', { silent = true })
