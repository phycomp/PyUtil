vim.keymap.set('n', '<leader>cc', function()
  -- 取得當前緩衝區的所有行
  local lines = vim.api.nvim_buf_get_lines(0, 0, -1, false)
  
  for i, line in ipairs(lines) do
    -- 如果該行「完全是 ---」或「包含 ---」
    if line:match('#') then
      continue
    elseif line:match("%s*%-%-%-%s*") then
      -- 將其替換為 Markdown 註解格式
      lines[i] = "#" .. line
    end
  end
  
  -- 將修改後的行寫回緩衝區
  vim.api.nvim_buf_set_lines(0, 0, -1, false, lines)
  print("已自動註解含有 --- 的行")
end, { desc = "自動註解包含 --- 的行" })
