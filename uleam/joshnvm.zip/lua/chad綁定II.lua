-- 建立一個專屬於 CHADTree 按下 'w' 的處理函式
_G.chadtree_custom_w_action = function()
  -- 透過 CHADTree 內建 API 獲取當前游標所在節點的路徑
  local stat = vim.fn['chadtree#get_current_node']()
  
  if stat and stat.path then
    local path = stat.path
    
    -- 排除資料夾，資料夾不進行圖片渲染
    if vim.fn.isdirectory(path) == 1 then
      print("此節點為資料夾，無法展示圖形。")
      return
    end

    -- 取得副檔名並轉換為小寫
    local ext = string.lower(vim.fn.fnamemodify(path, ":e"))

    -- 精準限定：只有當副檔名為 png 或 jpg 時，才呼叫 Python 的 MimeOpen 指令
    if ext == "png" or ext == "jpg" or ext == "jpeg" then
      -- 呼叫遠端 Python 插件，並將路徑作為參數安全地傳入
      vim.cmd("MimeOpen " .. vim.fn.fnameescape(path))
    else
      print("檔案非 .png 或 .jpg 格式，跳過 w 動作。")
    end
  end
end

-- 設定 Autocmd：當偵測到 FileType 為 chadtree 時，單獨為該 Buffer 綁定 'w' 鍵
vim.api.nvim_create_autocmd("FileType", {
  pattern = "chadtree",
  callback = function()
    -- 將 'w' 鍵映射到我們寫好的全域 Lua 偵測函式
    vim.keymap.set("n", "w", "<cmd>lua _G.chadtree_custom_w_action()<CR>", { 
      buffer = true, 
      silent = true, 
      desc = "CHADTree: Open PNG/JPG with Chafa" 
    })
  end,
})
