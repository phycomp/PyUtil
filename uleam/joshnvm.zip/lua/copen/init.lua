-- ~/.config/nvim/lua/plugins/copen.lua
local M = {}

-- 儲存狀態
M.float_win = nil
M.float_buf = nil
M.original_win = nil

-- 格式化 quickfix 列表
function M.format_qf_list(qf_list)
    local lines = {}
    local items = qf_list.items or qf_list
    
    for idx, item in ipairs(items) do
        -- 獲取檔案名稱
        local filename = item.filename or item.file or ''
        if filename and filename ~= '' then
            filename = vim.fn.fnamemodify(filename, ':t')
        end
        
        -- 獲取行號和列號
        local lnum = item.lnum or item.line or 0
        local col = item.col or item.column or 0
        
        -- 獲取文字
        local text = item.text or item.message or ''
        
        -- 格式化位置
        local location = ''
        if lnum and lnum > 0 and col and col > 0 then
            location = string.format('%d:%d', lnum, col)
        elseif lnum and lnum > 0 then
            location = tostring(lnum)
        else
            location = '?'
        end
        
        -- 限制文字長度
        if #text > 60 then
            text = text:sub(1, 57) .. '...'
        end
        
        -- 如果沒有檔案名稱
        if not filename or filename == '' then
            filename = string.format('buf:%s', item.bufnr or '?')
        end
        
        -- 構建顯示行
        local line = string.format('%3d | %-20s | %-10s | %s', idx, filename, location, text)
        table.insert(lines, line)
    end
    
    return lines
end

-- 關閉 float window
function M.close_float()
    if M.float_win and vim.api.nvim_win_is_valid(M.float_win) then
        vim.api.nvim_win_close(M.float_win, true)
    end
    
    if M.float_buf and vim.api.nvim_buf_is_valid(M.float_buf) then
        pcall(vim.api.nvim_buf_delete, M.float_buf, { force = true })
    end
    
    M.float_win = nil
    M.float_buf = nil
    
    -- 回到原始視窗
    if M.original_win and vim.api.nvim_win_is_valid(M.original_win) then
        vim.api.nvim_set_current_win(M.original_win)
    end
    M.original_win = nil
end

-- 跳轉到選中的 quickfix 項目
function M.jump_to_item()
    if not M.float_win or not vim.api.nvim_win_is_valid(M.float_win) then
        vim.notify('Float window is not valid', vim.log.levels.WARN)
        return
    end
    
    -- 獲取當前游標位置
    local cursor = vim.api.nvim_win_get_cursor(M.float_win)
    local line_num = cursor[1] - 1  -- 轉為 0-based index
    
    -- 獲取 quickfix 列表
    local qf_list = vim.fn.getqflist({ items = 0 })
    local items = qf_list.items or qf_list
    
    if not items or #items == 0 then
        vim.notify('Quickfix list is empty', vim.log.levels.WARN)
        return
    end
    
    if line_num < 0 or line_num >= #items then
        vim.notify(string.format('Line %d out of range', line_num + 1), vim.log.levels.WARN)
        return
    end
    
    -- 獲取對應的 quickfix 項目
    local item = items[line_num + 1]
    
    -- 嘗試多種方式取得檔案名稱
    local filename = item.filename or item.file or ''
    
    -- 如果沒有 filename，嘗試從 bufnr 獲取
    if filename == '' and item.bufnr then
        filename = vim.fn.bufname(item.bufnr)
    end
    
    -- 如果還是沒有，嘗試從 text 中提取
    if filename == '' and item.text then
        local match = item.text:match('([^%s]+%.[%w]+):(%d+)')
        if match then
            filename = match
        end
    end
    
    -- 獲取行號和列號
    local lnum = item.lnum or item.line or 0
    local col = item.col or item.column or 0
    
    if filename == '' or not lnum or lnum <= 0 then
        vim.notify('Invalid quickfix item: ' .. vim.inspect(item), vim.log.levels.WARN)
        return
    end
    
    -- 關閉 float window
    M.close_float()
    
    -- 檢查檔案是否存在，如果是相對路徑則轉為絕對路徑
    if not vim.fn.filereadable(filename) then
        local cwd = vim.fn.getcwd()
        local full_path = vim.fn.fnamemodify(cwd .. '/' .. filename, ':p')
        if vim.fn.filereadable(full_path) == 1 then
            filename = full_path
        end
    end
    
    -- 開啟檔案並跳轉
    pcall(vim.cmd, string.format('edit %s', filename))
    
    -- 跳轉到指定位置
    if col and col > 0 then
        vim.api.nvim_win_set_cursor(0, { lnum, col - 1 })
    else
        vim.api.nvim_win_set_cursor(0, { lnum, 0 })
    end
    
    -- 置中顯示
    vim.cmd('normal! zz')
    if col and col > 0 then
        vim.cmd('normal! zs')
    end
end

-- 重新整理 quickfix 列表
function M.refresh_qf_list()
    if not M.float_buf or not vim.api.nvim_buf_is_valid(M.float_buf) then
        return
    end
    
    local qf_list = vim.fn.getqflist({ items = 0 })
    local items = qf_list.items or qf_list
    
    if not items or #items == 0 then
        vim.notify('Quickfix list is empty', vim.log.levels.WARN)
        M.close_float()
        return
    end
    
    -- 更新 buffer 內容
    local lines = M.format_qf_list(qf_list)
    vim.api.nvim_buf_set_option(M.float_buf, 'modifiable', true)
    vim.api.nvim_buf_set_lines(M.float_buf, 0, -1, false, lines)
    vim.api.nvim_buf_set_option(M.float_buf, 'modifiable', false)
    
    -- 回到第一行
    if M.float_win and vim.api.nvim_win_is_valid(M.float_win) then
        vim.api.nvim_win_set_cursor(M.float_win, { 1, 0 })
    end
end

-- 開啟 float window
function M.open_copen_float()
    -- 檢查 quickfix 是否有內容
    local qf_list = vim.fn.getqflist({ items = 0 })
    local items = qf_list.items or qf_list
    
    if not items or #items == 0 then
        vim.notify('Quickfix list is empty', vim.log.levels.WARN)
        return
    end
    
    -- 儲存當前視窗
    M.original_win = vim.api.nvim_get_current_win()
    
    -- 計算 float window 尺寸
    local width = math.floor(vim.o.columns * 0.8)
    local height = math.min(#items + 2, math.floor(vim.o.lines * 0.6))
    local row = math.floor((vim.o.lines - height) / 2)
    local col = math.floor((vim.o.columns - width) / 2)
    
    -- 創建 buffer
    M.float_buf = vim.api.nvim_create_buf(false, true)
    
    -- 設置 buffer 選項
    vim.api.nvim_buf_set_option(M.float_buf, 'buftype', 'nofile')
    vim.api.nvim_buf_set_option(M.float_buf, 'swapfile', false)
    vim.api.nvim_buf_set_option(M.float_buf, 'filetype', 'qf')
    vim.api.nvim_buf_set_option(M.float_buf, 'modifiable', true)
    
    -- 填寫內容
    local lines = M.format_qf_list(qf_list)
    vim.api.nvim_buf_set_lines(M.float_buf, 0, -1, false, lines)
    vim.api.nvim_buf_set_option(M.float_buf, 'modifiable', false)
    
    -- 創建 float window 配置
    local config = {
        relative = 'editor',
        width = width,
        height = height,
        row = row,
        col = col,
        style = 'minimal',
        border = 'rounded',
        title = ' Quickfix List ',
        title_pos = 'center',
    }
    
    -- 創建 float window
    M.float_win = vim.api.nvim_open_win(M.float_buf, true, config)
    
    -- 設置 keymaps
    -- 移動光標
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', 'j', 'j', {
        desc = 'Move cursor down',
        nowait = true,
        silent = true
    })
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', 'k', 'k', {
        desc = 'Move cursor up',
        nowait = true,
        silent = true
    })
    
    -- Enter 跳轉
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', '<CR>', '', {
        callback = M.jump_to_item,
        desc = 'Jump to location',
        nowait = true,
        silent = true,
    })
    
    -- q 關閉
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', 'q', '', {
        callback = M.close_float,
        desc = 'Close float window',
        nowait = true,
        silent = true,
    })
    
    -- ESC 關閉
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', '<Esc>', '', {
        callback = M.close_float,
        desc = 'Close float window',
        nowait = true,
        silent = true,
    })
    
    -- R 重新整理
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', 'R', '', {
        callback = M.refresh_qf_list,
        desc = 'Refresh quickfix list',
        nowait = true,
        silent = true,
    })
    
    -- 頁面滾動
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', '<C-d>', '<C-d>', {
        desc = 'Scroll down',
        silent = true
    })
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', '<C-u>', '<C-u>', {
        desc = 'Scroll up',
        silent = true
    })
    
    -- 跳到開頭或結尾
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', 'gg', 'gg', {
        desc = 'Go to first line',
        silent = true
    })
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', 'G', 'G', {
        desc = 'Go to last line',
        silent = true
    })
    
    -- 上下翻頁
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', '<PageDown>', '<PageDown>', {
        desc = 'Page down',
        silent = true
    })
    vim.api.nvim_buf_set_keymap(M.float_buf, 'n', '<PageUp>', '<PageUp>', {
        desc = 'Page up',
        silent = true
    })
end

-- 設定命令
vim.api.nvim_create_user_command('CopenFloat', M.open_copen_float, {
    desc = 'Open quickfix list in float window'
})

return M
