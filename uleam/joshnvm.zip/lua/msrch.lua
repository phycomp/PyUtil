require("multisearch").setup({
  -- 可選：自訂配置（見下方說明）
  match_mode = "and",   -- "and" 或 "or"
  use_regex = false,    -- true = 正則, false = 字面
  border = "rounded",
})
