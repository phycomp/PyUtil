:UpdateRemotePlugins
:runtime! plugin/**/*.lua
:runtime! plugin/**/*.vim
":runtime! py3file plugin/**/*.py
":runtime! py3file ~/.config/nvim/rplugins/*.py
:runtime! py3file ~/.config/nvim/rplugins/python3/*.py
