set rtp+=~/.config/nvim/lua
"let g:loaded_python3_provider=1

let g:python3_host_prog=getenv('VIRTUAL_ENV').'/bin/python'
lua require('cc')
lua require('paqKEY')
lua require('regwin')
lua require('PAQs')
"lua require('pckr')
lua require('settings')
lua require('status')
"lua require('statusline')
lua require('nvimAutopair')
lua require('msrch')
" lua require('copen')
lua require('cpn')
lua require('treesitter')
"call plug#begin()
"Plug 'tpope/vim-sensible'
"Plug 'ms-jpq/chadtree', {'branch': 'chad', 'do': 'python -m chadtree deps'}

"call plug#end()
py3file ~/.config/nvim/py/ridPttrn.py
py3file ~/.config/nvim/py/rmPttrn.py
py3file ~/.config/nvim/py/srchPttrn.py
py3file ~/.config/nvim/py/b2g.py
py3file ~/.config/nvim/py/window.py
py3file ~/.config/nvim/py/window.py
py3file ~/.config/nvim/py/paqKEY.py
py3file ~/.config/nvim/py/fexp.py
"py3file ~/.config/nvim/py/bufUtil.py
py3file ~/.config/nvim/py/KEYs.py
"py3file ~/.config/nvim/py/whichKey.py
py3file ~/.config/nvim/py/cmdline.py
"py3file ~/.config/nvim/py/gimp.py
py3file ~/.config/nvim/py/merge.py
"py3file ~/.config/nvim/python3/autocmd.py
py3file ~/.config/nvim/py/zoom.py
"py3file ~/.config/nvim/py/jupyter.py
py3file ~/.config/nvim/py/regMark.py
py3file ~/.config/nvim/py/setColor.py
py3file ~/.config/nvim/py/tabLine.py
"py3file ~/.config/nvim/py/commentUtil.py
py3file ~/.config/nvim/py/fontUtil.py
py3file ~/.config/nvim/py/mdUtil.py
py3file ~/.config/nvim/py/tabUtil.py
py3file ~/.config/nvim/py/clipUtil.py
py3file ~/.config/nvim/py/ftUtil.py
"py3file ~/.config/nvim/py/schmUtil.py
py3file ~/.config/nvim/py/pnctUtil.py
py3file ~/.config/nvim/py/rcUtil.py
py3file ~/.config/nvim/py/shUtil.py
py3file ~/.config/nvim/py/sssnUtil.py
" py3file ~/.config/nvim/py/vwrHelp.py
py3file ~/.config/nvim/py/webUtil.py
py3file ~/.config/nvim/py/latex.py

" ============================================
" PyREPL v2.0 - Python REPL with Terminal/IPython/Completion/Watch
" ============================================
set timeoutlen=300
" 基本執行
"nnoremap <silent> <Leader>pr :PyREPLRunFile<CR>           " 檔案 → Terminal
"nnoremap <silent> <Leader>pR :PyREPLRunFileREPL<CR>       " 檔案 → 浮動視窗
"vnoremap <silent> <Leader>ps :PyREPLRunSelection<CR>      " 選取 → Terminal
"vnoremap <silent> <Leader>pS :PyREPLRunSelectionREPL<CR>  " 選取 → 浮動視窗
"nnoremap <silent> <Leader>pl :PyREPLRunLine<CR>            " 當前行 → Terminal

" Terminal 控制
"nnoremap <silent> <Leader>pt :PyREPLTermToggle<CR>        " 開關 Terminal

" 自動補全
"nnoremap <silent> <Leader>pc :PyREPLComplete<CR>          " 顯示補全建議
" 設定 omnifunc (可選)
"autocmd FileType python setlocal omnifunc=PyREPLCompleteFunc

" 變數監視
"nnoremap <silent> <Leader>pw :PyREPLWatchVar 
"nnoremap <silent> <Leader>pW :PyREPLWatchToggle<CR>       " 開關監視視窗
"nnoremap <silent> <Leader>pv :PyREPLVars<CR>              " 顯示變數列表

" REPL 控制
"nnoremap <silent> <Leader>px :PyREPLReset<CR>              " 重置環境
"nnoremap <silent> <Leader>pi :PyREPLEnableIPython<CR>     " 啟用 IPython
"nnoremap <silent> <Leader>po :PyREPLDisableIPython<CR>    " 停用 IPython
