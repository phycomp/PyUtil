from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect, markdown as stMarkdown, toggle as stToggle, button #slider, dataframe, code as stCode, cache as stCache, 
from pandas import DataFrame, read_excel, read_csv
from stUtil import rndrCode
from pathlib import Path
from fhndlrUtil import rcrsvDIR
from base64 import b64encode
from subprocess import run as sbprcssRUN
from os import chdir

MENU, 表單=[], ['線上', '製作PDF', 'publish']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[1]:
  prntDIR=['~/GITs/texDemo']
  with sidebar:
    母=stRadio('表單', prntDIR, horizontal=True, index=0, key='母')
  if 母:
    母層=Path(母).expanduser() #/archive
    根層=母層.iterdir()
  with sidebar:
    檔案=map(lambda x:x.resolve().name, 根層)
    md=stRadio('檔案', 檔案, horizontal=True, index=0)
  if md:
    #母=Path(母)
    leftPane, rightPane=stCLMN(2)
    with leftPane:
      newMD=text_area('原始md', open(母層/md).read(), height=800)
    with rightPane:
      newMD=text_area('更改md', newMD, height=800)
      #with open(母層/f'new{md}', 'w') as fout:
      #  fout.write(newMD)
    執行=button('執行？', key='執行')
    if 執行:
      #rndrCode(母層.parent)
      chdir(母層)    #.parent/data/dummy/pandoc-3.2/bin/
      #CMD="pandoc --pdf-engine=xelatex  -V 'mainfont:UKaiTWMBE' --toc -obook.pdf title.txt newScene1.md newScene2.md newScene3.md"
      CMD="pandoc --pdf-engine=xelatex  -V 'mainfont:UKaiTWMBE' --toc -obook.pdf title.txt newScene1.md newScene2.md newScene3.md"
      rsltMD=sbprcssRUN(CMD.split(), capture_output = True, text=True)
      rndrCode(rsltMD.stdout.split('\n')) 
      rndrCode(rsltMD.stderr.split('\n'))
      with open('book.pdf', "rb") as fin:
        base64PDF = b64encode(fin.read()).decode('utf-8')
        pdfPAGE = f'<embed src="data:application/pdf;base64,{base64PDF}#page=0" height=800 type="application/pdf" width=100% style="border:none">'
        stMarkdown(pdfPAGE, unsafe_allow_html=True) #
        #rndrCode(md)
      #  dirPRFL=profileDIR(根, 檔案)
      #  def parsePRFL(d):
      #    tmp={}
      #    for k, v in dirPRFL.items(): tmp.update({k:len(v)})
      #    return tmp
      #      #{k:len(v)} 
      #  rndrCode([根, parsePRFL(dirPRFL)])
      #  #瀏覽=stRadio('瀏覽', brwsrType, key='browser', horizontal=True, index=0)
elif menu==MENU[0]:
  page, prntDIR=10, ['~/GITs/markdown-book/book2']
  with sidebar:
    母=stRadio('表單', prntDIR, horizontal=True, index=0, key='母')
  if 母:
    母層=Path(母).expanduser() #/archive
    根層=母層.iterdir()
  with sidebar:
    檔案=map(lambda x:x.resolve().name, 根層)
    md=stRadio('檔案', 檔案, horizontal=True, index=0)
  if md:
    #母=Path(母)
    leftPane, rightPane=stCLMN(2)
    with leftPane:
      newMD=text_area('原始md', open(母層/md).read(), height=800)
    with rightPane:
      newMD=text_area('更改md', newMD, height=800)
      寫入=button('寫入？', key='寫入')
      if 寫入:
        with open(母層/f'new{md}', 'w') as fout:
          fout.write(newMD)
    執行=button('執行？', key='執行')
    from subprocess import run as sbprcssRUN
    from os import chdir
    if 執行:
      #rndrCode(母層.parent)
      chdir(母層.parent)    #/data/dummy/pandoc-3.2/bin/
      CMD='pandoc --pdf-engine=xelatex --toc -obook2/book.pdf title.txt book2/newScene1.md book2/newScene2.md book2/newScene3.md'
      rsltMD=sbprcssRUN(CMD.split(), capture_output = True, text=True)
      rndrCode(rsltMD.stdout.split('\n')) 
      rndrCode(rsltMD.stderr.split('\n'))
        
        #rndrCode(md)
      #  dirPRFL=profileDIR(根, 檔案)
      #  def parsePRFL(d):
      #    tmp={}
      #    for k, v in dirPRFL.items(): tmp.update({k:len(v)})
      #    return tmp
      #      #{k:len(v)} 
      #  rndrCode([根, parsePRFL(dirPRFL)])
      #  #瀏覽=stRadio('瀏覽', brwsrType, key='browser', horizontal=True, index=0)
    #with sidebar:
    #  分頁=stRadio('分頁', range(page), horizontal=True, index=0, key='分頁')   #
      #rndrCode([根, 檔案])

