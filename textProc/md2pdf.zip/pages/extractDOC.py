#!/usr/bin/env python
from odf import text, teletype
from odf.opendocument import load as odfLoad
from glob import glob
from os.path import splitext

FILEs=glob('*.docx')
for fname in FILEs:
  textdoc = odfLoad(fname)  #"your.odt"
  base, ext=splitext(fname)
  allParas = textdoc.getElementsByType(text.P)
  out=teletype.extractText(allParas[0])
  with open(f'{base}.raw', 'w') as fout:
    fout.write(out)
